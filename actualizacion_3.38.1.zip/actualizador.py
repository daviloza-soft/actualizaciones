"""
ACTUALIZACIÓN DEL SISTEMA — DAVI&LOZA SOFT
==========================================
Cómo funciona:

  1. El servidor consulta un archivo de versión publicado en internet
     (version.json). Si hay una versión mayor a la instalada, lo indica.
  2. El usuario ve un aviso en el sistema y elige "Actualizar ahora".
  3. Se descarga el paquete, se verifica su SHA-256 (si no coincide,
     se descarta) y se comprueba que la firma digital es válida.
  4. Se respalda la base de datos y el programa actual.
  5. Se reemplazan SOLO los archivos del programa. Nunca se tocan:
     la base de datos, las fotos, certificados, sellos, comprobantes
     ni la configuración de la empresa.
  6. El servidor se reinicia; si el arranque falla, se restaura el
     respaldo automáticamente.

Seguridad: el paquete está firmado con una clave privada que solo
tiene el proveedor. Las máquinas solo tienen la clave pública, así
que aunque alguien suplante el servidor de descargas, no puede
instalar nada que no esté firmado por DAVI&LOZA.
"""
import base64
import hashlib
import json
import os
import shutil
import time
import urllib.request
from pathlib import Path

# Archivos del PROGRAMA. Solo estos se reemplazan en una actualización.
# (los .bat no se reemplazan: Windows los lee mientras corren)
ARCHIVOS_PROGRAMA = ["sri_server.py", "index.html", "toma.html", "cargando.html",
                     "actualizador.py", "manifest.json", "sw.js"]
# Carpetas y archivos de DATOS: nunca se tocan.
NO_TOCAR = ["facturacion.db", "daviloza.db", "fotos", "certificados", "sellos",
            "comprobantes", "respaldos", "importados", "logs", "plantillas",
            "robot", "contifico.ini"]

URL_VERSION = "https://raw.githubusercontent.com/daviloza-soft/actualizaciones/main/version.json"
TIMEOUT = 20


def _version_local(app_version: str) -> tuple:
    return tuple(int(x) for x in str(app_version).split(".") if x.isdigit())


def _sin_cache(url: str) -> str:
    """GitHub guarda copia unos minutos; esto pide siempre la última."""
    return url + ("&" if "?" in url else "?") + "t=" + str(int(time.time()))


def consultar_version(app_version: str, url: str = URL_VERSION) -> dict:
    """Pregunta a internet si hay una versión nueva. No instala nada."""
    try:
        with urllib.request.urlopen(_sin_cache(url), timeout=TIMEOUT) as r:
            info = json.loads(r.read().decode("utf-8"))
    except Exception as ex:
        return {"ok": False, "error": "No se pudo consultar: " + str(ex)}
    nueva = str(info.get("version", ""))
    hay = _version_local(nueva) > _version_local(app_version)
    return {"ok": True, "instalada": app_version, "disponible": nueva,
            "hay_actualizacion": hay, "notas": info.get("notas", ""),
            "obligatoria": bool(info.get("obligatoria", False)),
            "tamano_kb": info.get("tamano_kb", 0)}


def _verificar_firma(datos: bytes, firma_b64: str, clave_publica_pem: str) -> bool:
    """Verifica la firma RSA del paquete con la clave pública del proveedor."""
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding
        clave = serialization.load_pem_public_key(clave_publica_pem.encode())
        clave.verify(base64.b64decode(firma_b64), datos,
                     padding.PKCS1v15(), hashes.SHA256())
        return True
    except Exception:
        return False


def descargar_y_validar(info: dict, carpeta_tmp: Path, clave_publica_pem: str) -> dict:
    """Baja el paquete y comprueba su integridad antes de tocar nada."""
    carpeta_tmp.mkdir(parents=True, exist_ok=True)
    destino = carpeta_tmp / ("actualizacion_" + info["version"] + ".zip")
    try:
        with urllib.request.urlopen(info["url"], timeout=120) as r:
            datos = r.read()
    except Exception as ex:
        return {"ok": False, "error": "No se pudo descargar: " + str(ex)}

    # 1. Integridad: el tamaño y la huella deben coincidir con lo publicado
    if len(datos) != int(info.get("bytes", -1)):
        return {"ok": False, "error": "El archivo llegó incompleto. Se descartó."}
    if hashlib.sha256(datos).hexdigest() != info.get("sha256", ""):
        return {"ok": False, "error": "La huella no coincide. Se descartó el archivo."}

    # 2. Autenticidad: la firma debe ser del proveedor
    if not _verificar_firma(datos, info.get("firma", ""), clave_publica_pem):
        return {"ok": False, "error": "La firma digital no es válida. Se descartó."}

    destino.write_bytes(datos)
    return {"ok": True, "ruta": str(destino)}


def aplicar(zip_path: Path, carpeta_programa: Path, carpeta_respaldo: Path) -> dict:
    """Reemplaza los archivos del programa. Guarda respaldo para revertir."""
    import zipfile
    stamp = time.strftime("%Y%m%d_%H%M%S")
    resp = carpeta_respaldo / ("version_" + stamp)
    resp.mkdir(parents=True, exist_ok=True)

    # Respaldo de los archivos del programa que se van a cambiar
    for nombre in ARCHIVOS_PROGRAMA:
        origen = carpeta_programa / nombre
        if origen.exists():
            shutil.copy2(origen, resp / nombre)

    # Extraer a una carpeta temporal primero: nada se toca hasta validar
    tmp = carpeta_respaldo / ("nueva_" + stamp)
    with zipfile.ZipFile(zip_path) as z:
        # Seguridad: rechazar rutas que salgan de la carpeta (zip slip)
        for n in z.namelist():
            if n.startswith("/") or ".." in Path(n).parts:
                raise ValueError("Paquete con rutas no permitidas: " + n)
        z.extractall(tmp)

    # Solo se reemplazan archivos del programa; cualquier otro se ignora
    cambiados = []
    for nombre in ARCHIVOS_PROGRAMA:
        nuevo = tmp / nombre
        if nuevo.exists():
            shutil.copy2(nuevo, carpeta_programa / nombre)
            cambiados.append(nombre)
    shutil.rmtree(tmp, ignore_errors=True)
    return {"ok": True, "respaldo": str(resp), "archivos": cambiados}


def revertir(carpeta_programa: Path, respaldo: Path) -> dict:
    """Vuelve a los archivos del respaldo si la actualización falla."""
    restaurados = []
    for nombre in ARCHIVOS_PROGRAMA:
        origen = respaldo / nombre
        if origen.exists():
            shutil.copy2(origen, carpeta_programa / nombre)
            restaurados.append(nombre)
    return {"ok": True, "restaurados": restaurados}


def paquete_de_version(info_servidor: dict) -> dict:
    """Del archivo de versión saca los datos del paquete a descargar."""
    return {"version": info_servidor.get("version", ""),
            "url": info_servidor.get("url", ""),
            "bytes": info_servidor.get("bytes", -1),
            "sha256": info_servidor.get("sha256", ""),
            "firma": info_servidor.get("firma", "")}


def leer_version_completa(url: str = URL_VERSION) -> dict:
    """Lee el archivo de versión completo (incluye url, firma y huella)."""
    try:
        with urllib.request.urlopen(_sin_cache(url), timeout=TIMEOUT) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return {}
