/* =====================================================
   DAVI&LOZA SOFT — Service Worker v1.0
   Estrategia: NETWORK-FIRST
   Un ERP debe mostrar datos frescos siempre; el caché
   solo actúa como respaldo si se pierde la conexión.
   ===================================================== */

const CACHE = "daviloza-soft-v1";

// Recursos base a precachear (ajusta rutas según tu sistema)
const PRECACHE = [
  "/",
  "/manifest.json",
  "/iconos/icon-192.png",
  "/iconos/icon-512.png"
];

// --- Instalación: precachear el shell básico ---
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(PRECACHE))
  );
  self.skipWaiting();
});

// --- Activación: limpiar cachés de versiones anteriores ---
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// --- Fetch: red primero, caché como respaldo ---
self.addEventListener("fetch", (event) => {
  const req = event.request;

  // Nunca interceptar POST/PUT (facturas, guardados, login)
  if (req.method !== "GET") return;

  // Nunca cachear respuestas de API/datos dinámicos
  const url = new URL(req.url);
  const esDinamico =
    url.pathname.startsWith("/api") ||
    url.search.length > 0; // peticiones con parámetros ?x=y

  event.respondWith(
    fetch(req)
      .then((res) => {
        // Guardar copia en caché solo de recursos estáticos exitosos
        if (res.ok && !esDinamico) {
          const copia = res.clone();
          caches.open(CACHE).then((cache) => cache.put(req, copia));
        }
        return res;
      })
      .catch(() =>
        // Sin conexión: intentar servir del caché
        caches.match(req).then(
          (cached) =>
            cached ||
            new Response(
              "<h2 style='font-family:sans-serif;text-align:center;margin-top:40px'>" +
                "Sin conexión con el servidor DAVI&LOZA.<br>" +
                "Verifique que Tailscale esté activo.</h2>",
              { headers: { "Content-Type": "text/html; charset=utf-8" } }
            )
        )
      )
  );
});
