#!/usr/bin/env python3
"""
DAVI&LOZA SOFT v2.1 — Sistema de Facturación Electrónica SRI Ecuador
"""

import os, sys, json, uuid, hashlib, base64, datetime, sqlite3, re

APP_VERSION = "3.38.1"

# Clave PÚBLICA del proveedor para verificar las actualizaciones.
# La clave privada (que firma los paquetes) NO está en el programa.
URL_VERSION_SERVIDOR = "https://raw.githubusercontent.com/daviloza-soft/actualizaciones/main/version.json"
_CLAVE_PUBLICA_PEM = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAujOEIb5ozcwwtgptXAly
DSBhsnARsGCzV9JITL4zsGkpf7Wd/5K8Aq7kOjGu93Kp6FV9Kcxf6U1NW/oiMGnW
pIGkt5z+DaAl8XiJ7YBymBTbqBSAWZCGJgEXjhtO/dc9oMRycubksKr4TMZz1g7f
/8js6x3PssFduj7sibXy0b5ZhnagF/3t+F/4HSlZLM+8vAYYgXFOq3JgYYc053MG
BSvu2ILUyLBPCXBZ4CsY2CHSra0IFi/H3GU2Q6yB9qZeukYqUUyS7hebxWT2snP5
skC8NiqLD4B26TzXERNiNAfC0DwXj3NLJ90PWadqFnvYOFYzh3YcdDabg7z16wjD
YQIDAQAB
-----END PUBLIC KEY-----"""  # incrementar en cada actualización relevante
import logging, secrets, time, smtplib, ssl, hmac, platform, socket
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from xml.etree import ElementTree as ET
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding as asym_padding
from cryptography.hazmat.primitives.serialization import pkcs12
from cryptography.hazmat.backends import default_backend
from cryptography.exceptions import InvalidSignature
import urllib.request, urllib.error
import threading

# ── Rutas base ───────────────────────────────────────────────
# BASE_DIR: carpeta de datos persistentes.
#  - Como .exe (PyInstaller): la carpeta donde está el ejecutable.
#  - Como script .py: la raíz del proyecto (o su padre si está en /servidor).
if getattr(sys, "frozen", False):
    _this_dir = Path(sys.executable).resolve().parent
    BASE_DIR  = _this_dir
else:
    _this_dir = Path(__file__).resolve().parent
    BASE_DIR  = _this_dir.parent if _this_dir.name == "servidor" else _this_dir

# DB_PATH: detecta automáticamente la base de datos existente
# Prioridad: facturacion.db (versión anterior) → daviloza.db (versión nueva)
def _detectar_db() -> Path:
    for nombre in ["facturacion.db", "daviloza.db"]:
        p = BASE_DIR / nombre
        if p.exists():
            return p
    return BASE_DIR / "daviloza.db"  # Nueva instalación

DB_PATH = _detectar_db()

PWA_MANIFEST = '{\n  "name": "DAVI&LOZA SOFT",\n  "short_name": "D&L SOFT",\n  "description": "Sistema de gestión empresarial y facturación electrónica SRI",\n  "start_url": "/",\n  "scope": "/",\n  "display": "standalone",\n  "orientation": "portrait",\n  "background_color": "#0f1117",\n  "theme_color": "#0f1117",\n  "lang": "es-EC",\n  "icons": [\n    {\n      "src": "/iconos/icon-192.png",\n      "sizes": "192x192",\n      "type": "image/png",\n      "purpose": "any"\n    },\n    {\n      "src": "/iconos/icon-512.png",\n      "sizes": "512x512",\n      "type": "image/png",\n      "purpose": "any"\n    },\n    {\n      "src": "/iconos/icon-512-maskable.png",\n      "sizes": "512x512",\n      "type": "image/png",\n      "purpose": "maskable"\n    }\n  ]\n}\n'

PWA_SW = '/* =====================================================\n   DAVI&LOZA SOFT — Service Worker v1.0\n   Estrategia: NETWORK-FIRST\n   Un ERP debe mostrar datos frescos siempre; el caché\n   solo actúa como respaldo si se pierde la conexión.\n   ===================================================== */\n\nconst CACHE = "daviloza-soft-v2";\n\n// Recursos base a precachear (ajusta rutas según tu sistema)\nconst PRECACHE = [\n  "/",\n  "/manifest.json",\n  "/iconos/icon-192.png",\n  "/iconos/icon-512.png"\n];\n\n// --- Instalación: precachear el shell básico ---\nself.addEventListener("install", (event) => {\n  event.waitUntil(\n    caches.open(CACHE).then((cache) => cache.addAll(PRECACHE))\n  );\n  self.skipWaiting();\n});\n\n// --- Activación: limpiar cachés de versiones anteriores ---\nself.addEventListener("activate", (event) => {\n  event.waitUntil(\n    caches.keys().then((keys) =>\n      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))\n    )\n  );\n  self.clients.claim();\n});\n\n// --- Fetch: red primero, caché como respaldo ---\nself.addEventListener("fetch", (event) => {\n  const req = event.request;\n\n  // Nunca interceptar POST/PUT (facturas, guardados, login)\n  if (req.method !== "GET") return;\n\n  // Nunca cachear respuestas de API/datos dinámicos\n  const url = new URL(req.url);\n  const esDinamico =\n    url.pathname.startsWith("/api") ||\n    url.search.length > 0; // peticiones con parámetros ?x=y\n\n  event.respondWith(\n    fetch(req)\n      .then((res) => {\n        // Guardar copia en caché solo de recursos estáticos exitosos\n        if (res.ok && !esDinamico) {\n          const copia = res.clone();\n          caches.open(CACHE).then((cache) => cache.put(req, copia));\n        }\n        return res;\n      })\n      .catch(() =>\n        // Sin conexión: intentar servir del caché\n        caches.match(req).then(\n          (cached) =>\n            cached ||\n            new Response(\n              "<h2 style=\'font-family:sans-serif;text-align:center;margin-top:40px\'>" +\n                "Sin conexión con el servidor DAVI&LOZA.<br>" +\n                "Verifique que Tailscale esté activo.</h2>",\n              { headers: { "Content-Type": "text/html; charset=utf-8" } }\n            )\n        )\n      )\n  );\n});\n'


LOG_DIR  = BASE_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

# ════════════════════════════════════════════════════════════
# CÓDIGO DE BARRAS Code128 — SVG puro (sin dependencias)
# ════════════════════════════════════════════════════════════
# Patrones Code 128 (valor_símbolo → 11 módulos binarios)
_C128_PATTERNS = [
    "11011001100","11001101100","11001100110","10010011000","10010001100",
    "10001001100","10011001000","10011000100","10001100100","11001001000",
    "11001000100","11000100100","10110011100","10011011100","10011001110",
    "10111001100","10011101100","10011100110","11001110010","11001011100",
    "11001001110","11011100100","11001110100","11101101110","11101001100",
    "11100101100","11100100110","11101100100","11100110100","11100110010",
    "11011011000","11011000110","11000110110","10100011000","10001011000",
    "10001000110","10110001000","10001101000","10001100010","11010001000",
    "11000101000","11000100010","10110111000","10110001110","10001101110",
    "10111011000","10111000110","10001110110","11101110110","11010001110",
    "11000101110","11011101000","11011100010","11011101110","11101011000",
    "11101000110","11100010110","11101101000","11101100010","11100011010",
    "11101111010","11001000010","11110001010","10100110000","10100001100",
    "10010110000","10010000110","10000101100","10000100110","10110010000",
    "10110000100","10011010000","10011000010","10000110100","10000110010",
    "11000010010","11001010000","11110111010","11000010100","10001111010",
    "10100111100","10010111100","10010011110","10111100100","10011110100",
    "10011110010","11110100100","11110010100","11110010010","11011011110",
    "11011110110","11110110110","10101111000","10100011110","10001011110",
    "10111101000","10111100010","11110101000","11110100010","10111011110",
    "10111101110","11101011110","11110101110","11010000100","11010010000",
    "11010011110","11000111010",
]
_C128_VALS = {chr(c): c-32 for c in range(32, 127)}

def barcode_code128_svg(data: str, bar_height: int = 50) -> str:
    """
    Genera código de barras Code 128B en SVG puro.
    Retorna string SVG listo para incrustar en HTML.
    La clave de acceso SRI (49 dígitos) genera ~580px de ancho.
    """
    START_B = 104
    STOP_PATTERN = "1100011101011"

    vals = [START_B]
    for ch in data:
        vals.append(_C128_VALS.get(ch, 0))

    ck = START_B
    for i, v in enumerate(vals[1:], 1):
        ck += i * v
    vals.append(ck % 103)

    modules = _C128_PATTERNS[START_B]
    for v in vals[1:]:
        modules += _C128_PATTERNS[v] if v < len(_C128_PATTERNS) else "10000000010"
    modules += STOP_PATTERN

    MOD_W  = 1.5          # ancho de un módulo en px
    QUIET  = 10           # zona silenciosa px
    total_w = int(len(modules) * MOD_W + 2 * QUIET)
    svg_h   = bar_height + 14   # barras + texto

    rects = []
    x = QUIET
    for m in modules:
        if m == '1':
            rects.append(f'<rect x="{x:.1f}" y="2" width="{MOD_W}" height="{bar_height}" fill="#000"/>')
        x += MOD_W

    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'width="{total_w}" height="{svg_h}" '
        f'viewBox="0 0 {total_w} {svg_h}">'
        f'<rect width="{total_w}" height="{svg_h}" fill="white"/>'
        + "".join(rects) +
        f'<text x="{total_w/2:.1f}" y="{svg_h-1}" text-anchor="middle" '
        f'font-family="monospace" font-size="7.5" fill="#000" letter-spacing="0.5">{data}</text>'
        f'</svg>'
    )

def barcode_data_uri(data: str, bar_height: int = 50) -> str:
    """Retorna el SVG del código de barras como data:URI para usar en <img src=...>"""
    svg = barcode_code128_svg(data, bar_height)
    b64 = base64.b64encode(svg.encode()).decode()
    return f"data:image/svg+xml;base64,{b64}"

# ════════════════════════════════════════════════════════════
# SISTEMA DE LICENCIAMIENTO
# ════════════════════════════════════════════════════════════
_LIC_SECRET = "DAVILOZA2025#SRI#EC"   # Clave secreta del sistema
LICENSE_FILE = BASE_DIR / "licencia.dat"

def _machine_id() -> str:
    """ID único y estable de la máquina."""
    parts = []
    try:
        with open("/etc/machine-id") as f:
            parts.append(f.read().strip()[:16])
    except Exception:
        pass
    parts += [socket.gethostname(), platform.system(), platform.machine()]
    return hashlib.sha256("|".join(parts).encode()).hexdigest()[:16].upper()

def generar_codigo_maquina(ruc: str = "") -> dict:
    """Retorna el código de máquina que el usuario debe enviar al propietario."""
    mid = _machine_id()
    display = f"{mid[:4]}-{mid[4:8]}-{mid[8:12]}-{mid[12:16]}"
    return {"machine_id": mid, "display": display, "ruc": ruc}

def generar_licencia_admin(machine_id: str, ruc: str = "*", dias: int = 365) -> str:
    """
    SOLO USO DEL PROPIETARIO DEL SISTEMA.
    Genera una licencia por MAQUINA — sirve para TODOS los RUC.
    Una licencia activa permite crear cualquier cantidad de RUC.
    """
    expira   = (datetime.datetime.now(TZ_EC).replace(tzinfo=None) + datetime.timedelta(days=dias)).strftime("%Y%m%d")
    # Siempre usar "*" — la licencia es por maquina, no por RUC
    payload  = f"{machine_id}:*:{expira}:{_LIC_SECRET}"
    h        = hmac.new(_LIC_SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
    code     = h[:16].upper()
    lic_code = f"{code[:4]}-{code[4:8]}-{code[8:12]}-{code[12:16]}"
    meta     = base64.b64encode(f"{machine_id}|*|{expira}".encode()).decode()
    return f"{lic_code}.{meta}"


def verificar_licencia(codigo: str, ruc: str = "") -> dict:
    """
    Verifica si la licencia es valida para esta MAQUINA.
    El RUC se IGNORA — una licencia vale para todos los RUC sin limite.
    """
    try:
        mid = _machine_id()
        if "." not in codigo:
            return {"valida": False, "mensaje": "Formato de licencia invalido"}
        lic_part, meta_part = codigo.rsplit(".", 1)
        meta_part += "=" * (-len(meta_part) % 4)
        meta  = base64.b64decode(meta_part.encode()).decode()
        parts = meta.split("|")
        if len(parts) < 3:
            return {"valida": False, "mensaje": "Licencia corrupta"}
        mid_s, _ruc_s, expira = parts[0], parts[1], parts[2]

        # Validar machine_id (ignorar guiones)
        if mid_s.replace("-","") != mid.replace("-",""):
            return {"valida": False, "mensaje": "Licencia no valida para esta maquina"}

        # NO se valida RUC — la licencia es por maquina unicamente

        # Validar expiracion
        hoy = datetime.datetime.now(TZ_EC).strftime("%Y%m%d")
        if hoy > expira:
            exp_fmt = f"{expira[:4]}-{expira[4:6]}-{expira[6:]}"
            return {"valida": False, "mensaje": f"Licencia expirada el {exp_fmt}"}

        # Validar HMAC — primero con "*", luego con RUC real (compatibilidad)
        for ruc_test in ["*", _ruc_s]:
            payload = f"{mid_s}:{ruc_test}:{expira}:{_LIC_SECRET}"
            h_esp   = hmac.new(_LIC_SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
            h_rec   = lic_part.replace("-", "").lower()
            if hmac.compare_digest(h_esp[:16].lower(), h_rec):
                dias_r  = (datetime.datetime.strptime(expira, "%Y%m%d") - datetime.datetime.now(TZ_EC).replace(tzinfo=None)).days
                exp_fmt = f"{expira[:4]}-{expira[4:6]}-{expira[6:]}"
                return {
                    "valida":         True,
                    "mensaje":        f"Licencia activa — vence {exp_fmt} ({dias_r} dias restantes)",
                    "expira":         exp_fmt,
                    "dias_restantes": dias_r,
                }

        return {"valida": False, "mensaje": "Codigo de licencia invalido o alterado"}

    except Exception as ex:
        return {"valida": False, "mensaje": f"Error verificando licencia: {ex}"}



def cargar_licencia_guardada() -> str:
    """Lee la licencia guardada en disco."""
    try:
        lf = BASE_DIR / "licencia.dat"
        if lf.exists():
            return lf.read_text(encoding="utf-8").strip()
    except Exception:
        pass
    return ""


def guardar_licencia(codigo: str):
    """Guarda la licencia en disco."""
    try:
        lf = BASE_DIR / "licencia.dat"
        lf.write_text(codigo.strip(), encoding="utf-8")
    except Exception as ex:
        log.warning("No se pudo guardar la licencia: %s", ex)


def _chequear_version_index():
    """Compara APP_VERSION con el INDEX_VER de index.html y avisa al arrancar.

    Antes esto se hacía en el .bat con python -c, pero los paréntesis del
    código Python rompían el parser de CMD dentro del for /f. Aquí es
    simple, seguro y funciona igual en cualquier Windows.
    """
    try:
        p = BASE_DIR / "index.html"
        if not p.exists():
            log.warning("  Interfaz      : ✗ FALTA index.html en %s", BASE_DIR)
            return
        txt = p.read_text(encoding="utf-8", errors="replace")
        m = re.search(r'INDEX_VER\s*=\s*"([^"]+)"', txt)
        if not m:
            log.info("  Interfaz      : index.html sin número de versión")
            return
        vidx = m.group(1)
        if vidx == APP_VERSION:
            log.info("  Interfaz      : ✓ index.html v%s (coincide)", vidx)
        else:
            log.warning("  Interfaz      : ✗ DESAJUSTE — servidor v%s, index.html v%s",
                        APP_VERSION, vidx)
            log.warning("                  Reemplace los DOS archivos con los de la misma entrega.")
    except Exception as ex:
        log.info("  Interfaz      : no se pudo leer la versión (%s)", ex)


def estado_licencia(ruc: str = "") -> dict:
    """
    Estado de la licencia de esta MAQUINA.
    El parametro ruc se IGNORA — la licencia no depende del RUC.
    Con licencia activa el sistema funciona sin restricciones para cualquier RUC.
    """
    codigo = cargar_licencia_guardada()
    mid_d  = generar_codigo_maquina()
    if not codigo:
        return {
            "activa":          False,
            "en_periodo_gracia": False,
            "mensaje":         "Sin licencia activada. Envia el codigo de maquina al proveedor para activar.",
            "dias_restantes":  0,
            "machine_id":      _machine_id(),
            "machine_display": mid_d["display"],
        }
    res = verificar_licencia(codigo)   # Sin RUC — siempre valida para cualquier RUC
    return {
        "activa":          res["valida"],
        "en_periodo_gracia": False,
        "mensaje":         res["mensaje"],
        "dias_restantes":  res.get("dias_restantes", 0),
        "expira":          res.get("expira", ""),
        "machine_id":      _machine_id(),
        "machine_display": mid_d["display"],
    }

# ── Logging ──────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "sri_server.log", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
SESSION_TIMEOUT = 86400  # 24 horas
log = logging.getLogger("FacturaSoft")

# ── URLs WebService SRI ──────────────────────────────────────
SRI = {
    "1": {  # PRUEBAS
        "recepcion":    "https://celcer.sri.gob.ec/comprobantes-electronicos-ws/RecepcionComprobantesOffline",
        "autorizacion": "https://celcer.sri.gob.ec/comprobantes-electronicos-ws/AutorizacionComprobantesOffline",
    },
    "2": {  # PRODUCCIÓN
        "recepcion":    "https://cel.sri.gob.ec/comprobantes-electronicos-ws/RecepcionComprobantesOffline",
        "autorizacion": "https://cel.sri.gob.ec/comprobantes-electronicos-ws/AutorizacionComprobantesOffline",
    },
}

# ════════════════════════════════════════════════════════════
# FECHA ECUADOR (UTC-5) — FIX día adelantado
# ════════════════════════════════════════════════════════════
TZ_EC = datetime.timezone(datetime.timedelta(hours=-5))

def now_ec() -> str:
    return datetime.datetime.now(TZ_EC).strftime("%Y-%m-%d %H:%M:%S")

def today_ec() -> str:
    return datetime.datetime.now(TZ_EC).strftime("%Y-%m-%d")

def fecha_xml(s: str) -> str:
    """YYYY-MM-DD → DD/MM/YYYY"""
    try:
        return datetime.datetime.strptime(s, "%Y-%m-%d").strftime("%d/%m/%Y")
    except Exception:
        return datetime.datetime.now(TZ_EC).strftime("%d/%m/%Y")

# ════════════════════════════════════════════════════════════
# SESIONES
# ════════════════════════════════════════════════════════════
SESSIONS: dict = {}

MAX_CONEXIONES_POR_EMPRESA = 5   # Límite de máquinas simultáneas por empresa

# Apagado automático: si el navegador deja de enviar "ping" (se cerró), el sistema se apaga solo
_last_ping = [time.time()]
_ping_active = [False]
_AUTO_OFF_SEG = 180   # segundos sin señal del navegador antes de apagar
def _reiniciar_servidor_luego(espera=2.0):
    """Tras una actualización: cierra este proceso y arranca uno nuevo con
    los archivos nuevos. Sin esto, python seguiría corriendo el código viejo
    que tiene cargado en memoria hasta que alguien lo cierre a mano."""
    def _hilo():
        time.sleep(espera)  # dejar salir la respuesta al navegador
        try:
            _srv = globals().get("srv")
            if _srv is not None:
                _srv.shutdown()
                _srv.server_close()
        except Exception:
            pass
        try:
            import subprocess
            env = dict(os.environ, DLS_NO_BROWSER="1")
            script = str(Path(BASE_DIR) / "sri_server.py")
            if not os.path.exists(script):
                script = os.path.abspath(__file__)
            flags = 0
            if os.name == "nt":
                flags = getattr(subprocess, "DETACHED_PROCESS", 0) | \
                        getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            subprocess.Popen([sys.executable, script], cwd=str(BASE_DIR),
                             env=env, creationflags=flags, close_fds=True)
        except Exception as ex:
            log.error("No se pudo reiniciar solo: %s — cierre y abra el sistema", ex)
        os._exit(0)
    # NO daemon: al apagar el servidor el hilo principal termina, y un hilo
    # daemon moriría con él antes de arrancar el proceso nuevo.
    threading.Thread(target=_hilo, daemon=False).start()


def _watchdog_apagado():
    """Antes apagaba el servidor cuando un navegador dejaba de responder.

    Eso estaba mal en una instalacion de varias maquinas: al cerrar el
    navegador de CUALQUIER equipo se caia el servicio para todos, y el
    vigilante lo volvia a levantar, con lo que el sistema parecia
    reiniciarse solo. Ahora cerrar el navegador solo termina la SESION de
    esa maquina; el servidor sigue atendiendo a las demas.
    Para apagar el servidor de verdad: DETENER_DAVILOZA.bat en la PC
    principal.
    """
    while True:
        time.sleep(60)
        try:
            if _ping_active[0] and (time.time() - _last_ping[0] > _AUTO_OFF_SEG):
                _ping_active[0] = False
                log.info("Sin señal de navegadores. El servidor sigue encendido.")
        except Exception:
            pass

def sesion_crear(uid, eid, rol, nombre, rol_empresa="cajero", ip="", maquina="") -> str:
    t = secrets.token_hex(32)
    SESSIONS[t] = {
        "usuario_id": uid, "empresa_id": eid,
        "rol": rol, "nombre": nombre, "rol_empresa": rol_empresa,
        "expires": time.time() + 8 * 3600,
        "ip": ip, "maquina": maquina,
    }
    # Registrar en DB para control multimáquina
    try:
        c = db()
        # Limpiar sesiones expiradas de esta empresa
        c.execute("""DELETE FROM conexiones_activas WHERE empresa_id=?
                     AND token NOT IN ({})""".format(
                         ",".join(f"'{k}'" for k in SESSIONS.keys()) or "''"
                     ), (eid,))
        c.execute("""INSERT OR REPLACE INTO conexiones_activas
            (empresa_id,token,ip_address,nombre_maquina,usuario_id,usuario_nombre,
             primera_conexion,ultima_actividad)
            VALUES (?,?,?,?,?,?,?,?)""",
            [eid, t, ip, maquina or ip, uid, nombre, now_ec(), now_ec()])
        c.commit(); c.close()
    except Exception as ex:
        log.warning("Error registrando conexión: %s", ex)
    return t

def sesion_get(token: str) -> dict | None:
    if not token:
        return None
    s = SESSIONS.get(token)
    if not s:
        # ── Restaurar sesión desde la BD (p.ej. tras reiniciar el servidor) ──
        try:
            c = db()
            row = rd(c.execute("SELECT * FROM conexiones_activas WHERE token=?", (token,)).fetchone())
            if row:
                # Vigencia: última actividad dentro de 8 horas
                try:
                    ult = datetime.datetime.strptime(row["ultima_actividad"], "%Y-%m-%d %H:%M:%S")
                    vigente = (datetime.datetime.now(TZ_EC).replace(tzinfo=None) - ult).total_seconds() < 8*3600
                except Exception:
                    vigente = True
                if vigente:
                    u = rd(c.execute("SELECT id,username,nombre,rol FROM usuarios WHERE id=?", (row["usuario_id"],)).fetchone())
                    if u:
                        ue = rd(c.execute("SELECT rol FROM usuario_empresa WHERE usuario_id=? AND empresa_id=?",
                                          (u["id"], row["empresa_id"])).fetchone())
                        s = {"usuario_id": u["id"], "empresa_id": row["empresa_id"],
                             "rol": u["rol"], "nombre": u["nombre"],
                             "rol_empresa": (ue or {}).get("rol", "cajero"),
                             "expires": time.time() + 8*3600,
                             "ip": row.get("ip_address",""), "maquina": row.get("nombre_maquina","")}
                        SESSIONS[token] = s
                        log.info("Sesión restaurada desde BD para %s", u["username"])
                else:
                    c.execute("DELETE FROM conexiones_activas WHERE token=?", (token,)); c.commit()
            c.close()
        except Exception as ex:
            log.warning("No se pudo restaurar sesión: %s", ex)
        if not s:
            return None
    if time.time() > s["expires"]:
        del SESSIONS[token]
        try:
            c = db(); c.execute("DELETE FROM conexiones_activas WHERE token=?",(token,)); c.commit(); c.close()
        except: pass
        return None
    # Actualizar actividad cada 60 segundos
    if "last_db_update" not in s or time.time() - s.get("last_db_update",0) > 60:
        s["last_db_update"] = time.time()
        try:
            c = db(); c.execute("UPDATE conexiones_activas SET ultima_actividad=? WHERE token=?",(now_ec(),token)); c.commit(); c.close()
        except: pass
    return s

def sesion_eliminar(token: str):
    if token in SESSIONS:
        del SESSIONS[token]
    try:
        c = db(); c.execute("DELETE FROM conexiones_activas WHERE token=?",(token,)); c.commit(); c.close()
    except: pass

def verificar_limite_conexiones(eid: int) -> tuple[bool, int, int]:
    """Verifica si la empresa ha alcanzado el límite de conexiones simultáneas.
    Retorna (puede_conectar, conexiones_activas, limite)"""
    try:
        # Limpiar sesiones expiradas del diccionario en memoria
        ahora = time.time()
        tokens_activos = {k for k,v in SESSIONS.items() if ahora < v.get("expires",0) and v.get("empresa_id") == eid}
        activas = len(tokens_activos)
        return activas < MAX_CONEXIONES_POR_EMPRESA, activas, MAX_CONEXIONES_POR_EMPRESA
    except:
        return True, 0, MAX_CONEXIONES_POR_EMPRESA

def get_conexiones_empresa(eid: int) -> list:
    """Retorna todas las conexiones activas de una empresa."""
    try:
        ahora = time.time()
        result = []
        for token, s in list(SESSIONS.items()):
            if s.get("empresa_id") == eid and ahora < s.get("expires",0):
                result.append({
                    "token_preview": token[:8] + "...",
                    "usuario": s.get("nombre",""),
                    "ip": s.get("ip",""),
                    "maquina": s.get("maquina",""),
                    "rol": s.get("rol_empresa",""),
                })
        return result
    except:
        return []

# ════════════════════════════════════════════════════════════
# BASE DE DATOS
# ════════════════════════════════════════════════════════════
def hash_password(password: str, salt: str = None) -> str:
    """Hash con salt usando PBKDF2 (seguro). Formato: pbkdf2$salt$hash"""
    import os, binascii
    if salt is None:
        salt = binascii.hexlify(os.urandom(16)).decode()
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100000)
    return f"pbkdf2${salt}${binascii.hexlify(dk).decode()}"

def verify_password(password: str, stored_hash: str) -> bool:
    """Verifica password. Soporta formato nuevo (pbkdf2) y antiguo (sha256)."""
    if not stored_hash:
        return False
    if stored_hash.startswith("pbkdf2$"):
        try:
            _, salt, _ = stored_hash.split("$")
            return hash_password(password, salt) == stored_hash
        except Exception:
            return False
    # Compatibilidad: hash antiguo sha256 sin salt
    return hashlib.sha256(password.encode()).hexdigest() == stored_hash

def db() -> sqlite3.Connection:
    c = sqlite3.connect(str(DB_PATH), check_same_thread=False, timeout=15)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA busy_timeout=10000")
    c.execute("PRAGMA foreign_keys=ON")
    return c

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS empresas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL, nombre_comercial TEXT DEFAULT '',
        ruc TEXT UNIQUE NOT NULL, direccion TEXT DEFAULT '',
        telefono TEXT DEFAULT '', email TEXT DEFAULT '', ciudad TEXT DEFAULT '',
        iva_porcentaje REAL DEFAULT 15,
        facturacion_electronica INTEGER DEFAULT 0,
        ambiente TEXT DEFAULT '1',
        estab TEXT DEFAULT '001', pto_emi TEXT DEFAULT '001',
        secuencial_actual INTEGER DEFAULT 1,
        sec_inicio_fac INTEGER DEFAULT 0, sec_inicio_nc INTEGER DEFAULT 0,
        sec_inicio_gr INTEGER DEFAULT 0, sec_inicio_lc INTEGER DEFAULT 0,
        obligado_contabilidad TEXT DEFAULT 'NO',
        contribuyente_especial TEXT DEFAULT '',
        cert_path TEXT DEFAULT '', cert_password TEXT DEFAULT '',
        smtp_host TEXT DEFAULT '', smtp_port INTEGER DEFAULT 587,
        smtp_user TEXT DEFAULT '', smtp_pass TEXT DEFAULT '',
        smtp_from TEXT DEFAULT '',
        logo_base64 TEXT DEFAULT '',
        activa INTEGER DEFAULT 1, created_at TEXT
    );

    CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
        nombre TEXT NOT NULL, email TEXT DEFAULT '',
        rol TEXT DEFAULT 'cajero', activo INTEGER DEFAULT 1,
        ultimo_acceso TEXT DEFAULT '', created_at TEXT
    );

    CREATE TABLE IF NOT EXISTS usuario_empresa (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER NOT NULL, empresa_id INTEGER NOT NULL,
        rol TEXT DEFAULT 'cajero',
        UNIQUE(usuario_id, empresa_id),
        FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
        FOREIGN KEY(empresa_id) REFERENCES empresas(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS clientes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        empresa_id INTEGER NOT NULL, ruc_cedula TEXT DEFAULT '',
        nombre TEXT NOT NULL,
        tipo_identificacion TEXT DEFAULT '05',
        email TEXT DEFAULT '', telefono TEXT DEFAULT '',
        direccion TEXT DEFAULT '', created_at TEXT,
        FOREIGN KEY(empresa_id) REFERENCES empresas(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS productos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        empresa_id INTEGER NOT NULL, codigo TEXT DEFAULT '',
        nombre TEXT NOT NULL, descripcion TEXT DEFAULT '',
        precio REAL DEFAULT 0, stock INTEGER DEFAULT 0,
        unidad TEXT DEFAULT 'unidad', activo INTEGER DEFAULT 1,
        FOREIGN KEY(empresa_id) REFERENCES empresas(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS facturas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        empresa_id INTEGER NOT NULL, numero TEXT NOT NULL,
        clave_acceso TEXT DEFAULT '', cliente_id INTEGER, usuario_id INTEGER,
        fecha TEXT NOT NULL, subtotal REAL DEFAULT 0, iva REAL DEFAULT 0,
        total REAL DEFAULT 0, descuento REAL DEFAULT 0,
        estado TEXT DEFAULT 'PENDIENTE', estado_sri TEXT DEFAULT '',
        autorizacion TEXT DEFAULT '', fecha_autorizacion TEXT DEFAULT '',
        xml_path TEXT DEFAULT '', ride_path TEXT DEFAULT '',
        notas TEXT DEFAULT '', created_at TEXT,
        UNIQUE(empresa_id, numero),
        FOREIGN KEY(empresa_id) REFERENCES empresas(id),
        FOREIGN KEY(cliente_id) REFERENCES clientes(id)
    );

    CREATE TABLE IF NOT EXISTS factura_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        factura_id INTEGER NOT NULL, producto_id INTEGER,
        codigo TEXT DEFAULT '', descripcion TEXT NOT NULL,
        cantidad REAL NOT NULL, precio_unitario REAL NOT NULL,
        descuento REAL DEFAULT 0, subtotal REAL NOT NULL,
        FOREIGN KEY(factura_id) REFERENCES facturas(id) ON DELETE CASCADE
    );

    -- ── NOTAS DE CRÉDITO ─────────────────────────────────────
    CREATE TABLE IF NOT EXISTS notas_credito (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        empresa_id INTEGER NOT NULL,
        numero TEXT NOT NULL,
        factura_ref_id INTEGER,
        factura_ref_numero TEXT DEFAULT '',
        cliente_id INTEGER,
        usuario_id INTEGER,
        fecha TEXT NOT NULL,
        tipo TEXT DEFAULT 'DESCUENTO', -- DESCUENTO | DEVOLUCION | ANULACION
        motivo TEXT DEFAULT '',
        subtotal REAL DEFAULT 0,
        iva REAL DEFAULT 0,
        total REAL DEFAULT 0,
        clave_acceso TEXT DEFAULT '',
        estado TEXT DEFAULT 'PENDIENTE',
        estado_sri TEXT DEFAULT '',
        autorizacion TEXT DEFAULT '',
        fecha_autorizacion TEXT DEFAULT '',
        xml_path TEXT DEFAULT '',
        ride_path TEXT DEFAULT '',
        notas TEXT DEFAULT '',
        created_at TEXT,
        UNIQUE(empresa_id, numero),
        FOREIGN KEY(empresa_id) REFERENCES empresas(id),
        FOREIGN KEY(factura_ref_id) REFERENCES facturas(id),
        FOREIGN KEY(cliente_id) REFERENCES clientes(id)
    );

    CREATE TABLE IF NOT EXISTS nota_credito_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nota_id INTEGER NOT NULL,
        producto_id INTEGER,
        codigo TEXT DEFAULT '',
        descripcion TEXT NOT NULL,
        cantidad REAL NOT NULL,
        precio_unitario REAL NOT NULL,
        descuento REAL DEFAULT 0,
        subtotal REAL NOT NULL,
        FOREIGN KEY(nota_id) REFERENCES notas_credito(id) ON DELETE CASCADE
    );

    -- ── GUÍAS DE REMISIÓN ─────────────────────────────────────
    CREATE TABLE IF NOT EXISTS guias_remision (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        empresa_id INTEGER NOT NULL,
        numero TEXT NOT NULL,
        cliente_id INTEGER,
        usuario_id INTEGER,
        fecha_inicio TEXT NOT NULL,
        fecha_fin TEXT,
        motivo_traslado TEXT DEFAULT 'VENTA',
        ruta TEXT DEFAULT '',
        dir_partida TEXT DEFAULT '',
        dir_destino TEXT DEFAULT '',
        transportista_ruc TEXT DEFAULT '',
        transportista_nombre TEXT DEFAULT '',
        placa TEXT DEFAULT '',
        factura_ref_numero TEXT DEFAULT '',
        clave_acceso TEXT DEFAULT '',
        estado TEXT DEFAULT 'PENDIENTE',
        estado_sri TEXT DEFAULT '',
        autorizacion TEXT DEFAULT '',
        fecha_autorizacion TEXT DEFAULT '',
        xml_path TEXT DEFAULT '',
        ride_path TEXT DEFAULT '',
        notas TEXT DEFAULT '',
        created_at TEXT,
        UNIQUE(empresa_id, numero),
        FOREIGN KEY(empresa_id) REFERENCES empresas(id)
    );

    CREATE TABLE IF NOT EXISTS guia_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guia_id INTEGER NOT NULL,
        producto_id INTEGER,
        codigo TEXT DEFAULT '',
        descripcion TEXT NOT NULL,
        cantidad REAL NOT NULL,
        FOREIGN KEY(guia_id) REFERENCES guias_remision(id) ON DELETE CASCADE
    );

    -- ── LIQUIDACIONES DE COMPRA (codDoc=03) ───────────────────
    -- Emitidas para compras a personas naturales sin RUC
    -- que no pueden emitir comprobantes de venta
    CREATE TABLE IF NOT EXISTS liquidaciones_compra (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        empresa_id INTEGER NOT NULL,
        numero TEXT NOT NULL,
        proveedor_tipo_id TEXT DEFAULT '05',  -- 05=Cedula, 06=Pasaporte
        proveedor_identificacion TEXT NOT NULL,
        proveedor_razon_social TEXT NOT NULL,
        proveedor_direccion TEXT DEFAULT '',
        proveedor_email TEXT DEFAULT '',
        fecha TEXT NOT NULL,
        subtotal REAL DEFAULT 0,
        iva REAL DEFAULT 0,
        total REAL DEFAULT 0,
        motivo TEXT DEFAULT '',
        forma_pago TEXT DEFAULT 'EFECTIVO',
        clave_acceso TEXT DEFAULT '',
        estado TEXT DEFAULT 'PENDIENTE',
        estado_sri TEXT DEFAULT '',
        autorizacion TEXT DEFAULT '',
        fecha_autorizacion TEXT DEFAULT '',
        ride_path TEXT DEFAULT '',
        usuario_id INTEGER,
        created_at TEXT,
        UNIQUE(empresa_id, numero),
        FOREIGN KEY(empresa_id) REFERENCES empresas(id)
    );

    CREATE TABLE IF NOT EXISTS liquidacion_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        liquidacion_id INTEGER NOT NULL,
        codigo TEXT DEFAULT '',
        descripcion TEXT NOT NULL,
        cantidad REAL NOT NULL,
        precio_unitario REAL NOT NULL,
        descuento REAL DEFAULT 0,
        subtotal REAL NOT NULL,
        FOREIGN KEY(liquidacion_id) REFERENCES liquidaciones_compra(id) ON DELETE CASCADE
    );

    -- ── CUENTAS POR COBRAR ────────────────────────────────────
    CREATE TABLE IF NOT EXISTS cuentas_cobrar (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        empresa_id INTEGER NOT NULL,
        cliente_id INTEGER NOT NULL,
        factura_id INTEGER,
        nota_credito_id INTEGER,
        tipo TEXT DEFAULT 'FACTURA', -- FACTURA | NOTA_CREDITO | ABONO | PAGO_NC
        concepto TEXT DEFAULT '',
        monto REAL NOT NULL,       -- positivo=debe, negativo=abono/NC
        saldo REAL NOT NULL,       -- saldo acumulado del cliente
        fecha TEXT NOT NULL,
        usuario_id INTEGER,
        estado TEXT DEFAULT 'PENDIENTE', -- PENDIENTE | PAGADO | PARCIAL
        referencia TEXT DEFAULT '',
        created_at TEXT,
        FOREIGN KEY(empresa_id) REFERENCES empresas(id),
        FOREIGN KEY(cliente_id) REFERENCES clientes(id),
        FOREIGN KEY(factura_id) REFERENCES facturas(id)
    );

    -- ── MOVIMIENTOS DE STOCK ──────────────────────────────────
    CREATE TABLE IF NOT EXISTS stock_movimientos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        empresa_id INTEGER NOT NULL,
        producto_id INTEGER NOT NULL,
        tipo TEXT NOT NULL,        -- VENTA | DEVOLUCION | AJUSTE | ENTRADA
        cantidad REAL NOT NULL,    -- negativo=salida, positivo=entrada
        stock_antes REAL DEFAULT 0,
        stock_despues REAL DEFAULT 0,
        referencia_id INTEGER,     -- factura_id, nota_id, etc.
        referencia_tipo TEXT DEFAULT '',
        notas TEXT DEFAULT '',
        fecha TEXT,
        usuario_id INTEGER,
        FOREIGN KEY(empresa_id) REFERENCES empresas(id),
        FOREIGN KEY(producto_id) REFERENCES productos(id)
    );

    CREATE TABLE IF NOT EXISTS sri_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        empresa_id INTEGER, factura_id INTEGER, fecha TEXT,
        accion TEXT, resultado TEXT, mensaje TEXT, detalle TEXT
    );

    -- ── CONEXIONES ACTIVAS (multi-máquina) ───────────────────
    CREATE TABLE IF NOT EXISTS conexiones_activas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        empresa_id INTEGER NOT NULL,
        token TEXT NOT NULL,
        ip_address TEXT DEFAULT '',
        nombre_maquina TEXT DEFAULT '',
        usuario_id INTEGER,
        usuario_nombre TEXT DEFAULT '',
        primera_conexion TEXT,
        ultima_actividad TEXT,
        UNIQUE(token)
    );

    -- ── CAJA / REPORTE DIARIO ─────────────────────────────────
    CREATE TABLE IF NOT EXISTS caja_sesiones (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        empresa_id INTEGER NOT NULL,
        usuario_id INTEGER,
        fecha TEXT NOT NULL,           -- YYYY-MM-DD
        estado TEXT DEFAULT 'ABIERTA', -- ABIERTA | CERRADA
        saldo_inicial REAL DEFAULT 0,
        saldo_final REAL DEFAULT 0,
        total_ingresos REAL DEFAULT 0,
        total_egresos REAL DEFAULT 0,
        total_facturas REAL DEFAULT 0,
        observaciones TEXT DEFAULT '',
        created_at TEXT,
        cerrada_at TEXT,
        UNIQUE(empresa_id, fecha),
        FOREIGN KEY(empresa_id) REFERENCES empresas(id)
    );

    CREATE TABLE IF NOT EXISTS caja_movimientos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        empresa_id INTEGER NOT NULL,
        sesion_id INTEGER NOT NULL,
        factura_id INTEGER,
        tipo TEXT NOT NULL,            -- INGRESO_FACTURA | INGRESO_OTRO | EGRESO
        categoria TEXT DEFAULT '',     -- Arriendo, Servicios, Sueldos, Compras, Otro...
        concepto TEXT NOT NULL,
        monto REAL NOT NULL,
        metodo_pago TEXT DEFAULT 'EFECTIVO', -- EFECTIVO | TRANSFERENCIA | TARJETA | CHEQUE
        comprobante TEXT DEFAULT '',   -- N° factura o referencia
        fecha TEXT NOT NULL,
        hora TEXT DEFAULT '',
        usuario_id INTEGER,
        created_at TEXT,
        FOREIGN KEY(empresa_id) REFERENCES empresas(id),
        FOREIGN KEY(sesion_id) REFERENCES caja_sesiones(id),
        FOREIGN KEY(factura_id) REFERENCES facturas(id)
    );
    """)

    # ═══ MÓDULO COMPRAS/GASTOS ═══
    conn.execute("""CREATE TABLE IF NOT EXISTS proveedores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            nombre TEXT NOT NULL,
            ruc_cedula TEXT,
            tipo_identificacion TEXT DEFAULT '04',
            email TEXT DEFAULT '',
            telefono TEXT DEFAULT '',
            celular TEXT DEFAULT '',
            direccion TEXT DEFAULT '',
            tipo TEXT DEFAULT 'PROVEEDOR',
            created_at TEXT)""")

    conn.execute("""CREATE TABLE IF NOT EXISTS categorias_gasto (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            nombre TEXT NOT NULL,
            tipo TEXT DEFAULT 'GASTO',
            cuenta_contable TEXT DEFAULT '',
            activa INTEGER DEFAULT 1)""")

    conn.execute("""CREATE TABLE IF NOT EXISTS compras (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            numero TEXT,
            numero_autorizacion TEXT DEFAULT '',
            proveedor_id INTEGER,
            categoria_id INTEGER,
            usuario_id INTEGER,
            fecha TEXT,
            fecha_registro TEXT,
            subtotal REAL DEFAULT 0,
            iva REAL DEFAULT 0,
            total REAL DEFAULT 0,
            tipo TEXT DEFAULT 'GASTO',
            forma_pago TEXT DEFAULT '01',
            estado TEXT DEFAULT 'REGISTRADA',
            estado_pago TEXT DEFAULT 'PENDIENTE',
            notas TEXT DEFAULT '',
            created_at TEXT)""")

    conn.execute("""CREATE TABLE IF NOT EXISTS compra_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            compra_id INTEGER,
            codigo TEXT DEFAULT '',
            descripcion TEXT,
            cantidad REAL DEFAULT 1,
            precio_unitario REAL DEFAULT 0,
            descuento REAL DEFAULT 0,
            subtotal REAL DEFAULT 0,
            iva_tarifa REAL DEFAULT 15,
            iva_valor REAL DEFAULT 0)""")

    # ═══ MÓDULO CONTABILIDAD ═══
    conn.execute("""CREATE TABLE IF NOT EXISTS plan_cuentas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            codigo TEXT NOT NULL,
            codigo_rapido TEXT DEFAULT '',
            nombre TEXT NOT NULL,
            nivel INTEGER DEFAULT 1,
            tipo TEXT DEFAULT 'DETALLE',
            naturaleza TEXT DEFAULT 'DEUDORA',
            grupo TEXT DEFAULT '',
            padre_codigo TEXT DEFAULT '',
            activa INTEGER DEFAULT 1,
            editable INTEGER DEFAULT 1)""")

    conn.execute("""CREATE TABLE IF NOT EXISTS asientos_contables (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            numero INTEGER,
            fecha TEXT,
            concepto TEXT,
            referencia TEXT DEFAULT '',
            tipo TEXT DEFAULT 'MANUAL',
            origen_id INTEGER DEFAULT 0,
            usuario_id INTEGER,
            estado TEXT DEFAULT 'ACTIVO',
            created_at TEXT)""")

    conn.execute("""CREATE TABLE IF NOT EXISTS asiento_detalle (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asiento_id INTEGER,
            cuenta_codigo TEXT,
            cuenta_nombre TEXT,
            debe REAL DEFAULT 0,
            haber REAL DEFAULT 0,
            referencia TEXT DEFAULT '')""")

    # ── Mapeo de cuentas contables por empresa (asientos automáticos) ──
    conn.execute("""CREATE TABLE IF NOT EXISTS config_contable (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER UNIQUE,
            auto_asientos INTEGER DEFAULT 1,
            cta_caja TEXT DEFAULT '1.1.01.01',
            cta_bancos TEXT DEFAULT '1.1.01.02',
            cta_cxc TEXT DEFAULT '1.1.02.05',
            cta_ventas TEXT DEFAULT '4.1.01.01',
            cta_iva_ventas TEXT DEFAULT '2.1.07.01',
            cta_dev_ventas TEXT DEFAULT '4.1.02',
            cta_cxp TEXT DEFAULT '2.1.03.01',
            cta_inventario TEXT DEFAULT '1.1.03.01',
            cta_gastos TEXT DEFAULT '5.2.01',
            cta_iva_compras TEXT DEFAULT '1.1.05.02',
            cta_ret_iva TEXT DEFAULT '2.1.07.02',
            cta_ret_renta TEXT DEFAULT '2.1.07.03',
            updated_at TEXT DEFAULT '')""")

    # ── Retenciones (comprobante de retención) — cabecera + detalle ──
    conn.execute("""CREATE TABLE IF NOT EXISTS retenciones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            numero TEXT,
            compra_id INTEGER DEFAULT 0,
            proveedor_id INTEGER DEFAULT 0,
            proveedor_nombre TEXT DEFAULT '',
            proveedor_ruc TEXT DEFAULT '',
            fecha TEXT,
            doc_sustento_tipo TEXT DEFAULT '01',
            doc_sustento_numero TEXT DEFAULT '',
            base_total REAL DEFAULT 0,
            total_ret_iva REAL DEFAULT 0,
            total_ret_renta REAL DEFAULT 0,
            total_retenido REAL DEFAULT 0,
            estado TEXT DEFAULT 'EMITIDA',
            clave_acceso TEXT DEFAULT '',
            autorizacion TEXT DEFAULT '',
            usuario_id INTEGER,
            created_at TEXT)""")

    conn.execute("""CREATE TABLE IF NOT EXISTS retencion_detalle (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            retencion_id INTEGER,
            tipo_impuesto TEXT DEFAULT 'RENTA',
            codigo TEXT DEFAULT '',
            concepto TEXT DEFAULT '',
            base_imponible REAL DEFAULT 0,
            porcentaje REAL DEFAULT 0,
            valor_retenido REAL DEFAULT 0)""")

    # ── Nómina / Roles de pago ──
    conn.execute("""CREATE TABLE IF NOT EXISTS roles_nomina (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            periodo TEXT,
            fecha TEXT,
            concepto TEXT DEFAULT '',
            num_empleados INTEGER DEFAULT 0,
            total_ingresos REAL DEFAULT 0,
            total_iess_personal REAL DEFAULT 0,
            total_deducciones REAL DEFAULT 0,
            total_liquido REAL DEFAULT 0,
            total_aporte_patronal REAL DEFAULT 0,
            incluir_provisiones INTEGER DEFAULT 0,
            total_provisiones REAL DEFAULT 0,
            estado TEXT DEFAULT 'REGISTRADO',
            usuario_id INTEGER,
            created_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS nomina_detalle (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            rol_id INTEGER,
            empleado TEXT DEFAULT '',
            cargo TEXT DEFAULT '',
            sueldo REAL DEFAULT 0,
            otros_ingresos REAL DEFAULT 0,
            iess_personal REAL DEFAULT 0,
            anticipos REAL DEFAULT 0,
            otras_deducciones REAL DEFAULT 0,
            liquido REAL DEFAULT 0)""")

    # ── Roles de pago moderno: colaboradores, sucursales y novedades del mes ──
    conn.execute("""CREATE TABLE IF NOT EXISTS empleados (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            nombres TEXT DEFAULT '',
            cedula TEXT DEFAULT '',
            cargo TEXT DEFAULT '',
            sucursal TEXT DEFAULT '',
            sueldo REAL DEFAULT 0,
            regimen TEXT DEFAULT 'LABORAL',
            fecha_ingreso TEXT DEFAULT '',
            fecha_egreso TEXT DEFAULT '',
            region TEXT DEFAULT 'COSTA',
            fondos_reserva TEXT DEFAULT 'PROVISIONA',
            mensualiza_decimos INTEGER DEFAULT 0,
            forma_pago TEXT DEFAULT 'EFECTIVO',
            email TEXT DEFAULT '',
            estado TEXT DEFAULT 'ACTIVO',
            created_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS sucursales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            nombre TEXT DEFAULT '',
            cta_gasto_sueldos TEXT DEFAULT '',
            created_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS nomina_novedades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            empleado_id INTEGER,
            periodo TEXT,
            tipo TEXT,
            concepto TEXT DEFAULT '',
            valor REAL DEFAULT 0,
            cuotas INTEGER DEFAULT 1,
            observacion TEXT DEFAULT '',
            estado TEXT DEFAULT 'ACTIVO',
            created_at TEXT)""")

    # ── Módulo de Bancos ──
    conn.execute("""CREATE TABLE IF NOT EXISTS cuentas_bancarias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            banco TEXT DEFAULT '',
            numero_cuenta TEXT DEFAULT '',
            tipo TEXT DEFAULT 'CORRIENTE',
            titular TEXT DEFAULT '',
            cuenta_contable TEXT DEFAULT '',
            secuencia_cheque INTEGER DEFAULT 1,
            saldo_inicial REAL DEFAULT 0,
            moneda TEXT DEFAULT 'USD',
            estado TEXT DEFAULT 'ACTIVO',
            created_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS tomas_fisicas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            nombre TEXT DEFAULT '',
            bodega_id INTEGER DEFAULT 0,
            sucursal_id INTEGER DEFAULT 0,
            estado TEXT DEFAULT 'ABIERTA',
            inicio TEXT, cierre TEXT DEFAULT '',
            usuario_id INTEGER, notas TEXT DEFAULT '',
            asiento_id INTEGER DEFAULT 0)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS toma_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            toma_id INTEGER,
            producto_id INTEGER DEFAULT 0,
            codigo TEXT DEFAULT '', nombre TEXT DEFAULT '',
            cantidad REAL DEFAULT 0,
            precio REAL DEFAULT 0, costo REAL DEFAULT 0,
            contado_en TEXT, usuario_id INTEGER,
            nuevo INTEGER DEFAULT 0,
            foto INTEGER DEFAULT 0,
            notas TEXT DEFAULT '')""")
    conn.execute("""CREATE INDEX IF NOT EXISTS ix_toma_items ON toma_items(toma_id, producto_id)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS cierres_mes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            periodo TEXT,
            estado TEXT DEFAULT 'CERRADO',
            cerrado_por INTEGER,
            cerrado_en TEXT,
            reabierto_por INTEGER DEFAULT 0,
            reabierto_en TEXT DEFAULT '',
            motivo_reapertura TEXT DEFAULT '',
            notas TEXT DEFAULT '')""")
    conn.execute("""CREATE TABLE IF NOT EXISTS movimientos_banco (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            cuenta_bancaria_id INTEGER,
            fecha TEXT,
            tipo TEXT,
            concepto TEXT DEFAULT '',
            beneficiario TEXT DEFAULT '',
            documento TEXT DEFAULT '',
            ingreso REAL DEFAULT 0,
            egreso REAL DEFAULT 0,
            estado_concil TEXT DEFAULT 'PENDIENTE',
            fecha_concil TEXT DEFAULT '',
            origen_tipo TEXT DEFAULT '',
            origen_id INTEGER DEFAULT 0,
            asiento_id INTEGER DEFAULT 0,
            estado TEXT DEFAULT 'ACTIVO',
            usuario_id INTEGER,
            created_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS comprobantes_egreso (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            numero TEXT,
            fecha TEXT,
            cuenta_bancaria_id INTEGER,
            forma_pago TEXT DEFAULT 'CHEQUE',
            cheque_numero TEXT DEFAULT '',
            beneficiario_tipo TEXT DEFAULT 'PROVEEDOR',
            proveedor_id INTEGER DEFAULT 0,
            beneficiario TEXT DEFAULT '',
            aplicar_a TEXT DEFAULT 'CXP',
            compra_id INTEGER DEFAULT 0,
            cuenta_contrapartida TEXT DEFAULT '',
            concepto TEXT DEFAULT '',
            monto REAL DEFAULT 0,
            estado TEXT DEFAULT 'EMITIDO',
            asiento_id INTEGER DEFAULT 0,
            usuario_id INTEGER,
            created_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS comprobantes_ingreso (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            numero TEXT,
            fecha TEXT,
            cuenta_bancaria_id INTEGER,
            forma TEXT DEFAULT 'DEPOSITO',
            referencia TEXT DEFAULT '',
            origen_tipo TEXT DEFAULT 'CLIENTE',
            cliente_id INTEGER DEFAULT 0,
            origen TEXT DEFAULT '',
            aplicar_a TEXT DEFAULT 'CXC',
            factura_id INTEGER DEFAULT 0,
            cuenta_contrapartida TEXT DEFAULT '',
            concepto TEXT DEFAULT '',
            monto REAL DEFAULT 0,
            estado TEXT DEFAULT 'EMITIDO',
            asiento_id INTEGER DEFAULT 0,
            usuario_id INTEGER,
            created_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS aplicaciones_anticipo (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            tipo TEXT DEFAULT 'CLIENTE',
            tercero_id INTEGER DEFAULT 0,
            doc_id INTEGER DEFAULT 0,
            doc_numero TEXT DEFAULT '',
            monto REAL DEFAULT 0,
            fecha TEXT,
            asiento_id INTEGER DEFAULT 0,
            estado TEXT DEFAULT 'ACTIVO',
            usuario_id INTEGER,
            created_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS establecimientos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            codigo TEXT,
            nombre TEXT,
            cuenta_caja TEXT DEFAULT '',
            estado TEXT DEFAULT 'ACTIVO',
            created_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS extracto_banco (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            cuenta_bancaria_id INTEGER,
            fecha TEXT,
            concepto TEXT DEFAULT '',
            oficina TEXT DEFAULT '',
            documento TEXT DEFAULT '',
            tipo TEXT DEFAULT '',
            ingreso REAL DEFAULT 0,
            egreso REAL DEFAULT 0,
            saldo REAL DEFAULT 0,
            codigo TEXT DEFAULT '',
            conciliado INTEGER DEFAULT 0,
            mov_banco_id INTEGER DEFAULT 0,
            lote TEXT DEFAULT '',
            created_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS importaciones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            proyecto TEXT DEFAULT '',
            fecha TEXT,
            supuestos TEXT DEFAULT '{}',
            fob_total REAL DEFAULT 0,
            inversion REAL DEFAULT 0,
            venta_proy REAL DEFAULT 0,
            estado TEXT DEFAULT 'BORRADOR',
            usuario_id INTEGER,
            created_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS importacion_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            importacion_id INTEGER,
            codigo TEXT DEFAULT '',
            descripcion TEXT DEFAULT '',
            cantidad REAL DEFAULT 0,
            fob_unit REAL DEFAULT 0,
            costo_unit REAL DEFAULT 0,
            p_mayorista REAL DEFAULT 0,
            pvp REAL DEFAULT 0)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS bodegas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            nombre TEXT,
            codigo TEXT DEFAULT '',
            principal INTEGER DEFAULT 0,
            estado TEXT DEFAULT 'ACTIVO',
            created_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS stock_bodega (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            producto_id INTEGER,
            bodega_id INTEGER,
            cantidad REAL DEFAULT 0,
            UNIQUE(producto_id, bodega_id))""")
    # ── Índices de rendimiento (grandes volúmenes) ──
    for ix in [
        "CREATE INDEX IF NOT EXISTS ix_fact_emp ON facturas(empresa_id)",
        "CREATE INDEX IF NOT EXISTS ix_fact_emp_fecha ON facturas(empresa_id,fecha)",
        "CREATE INDEX IF NOT EXISTS ix_fact_emp_num ON facturas(empresa_id,numero)",
        "CREATE INDEX IF NOT EXISTS ix_fact_emp_cli ON facturas(empresa_id,cliente_id)",
        "CREATE INDEX IF NOT EXISTS ix_fact_emp_estado ON facturas(empresa_id,estado)",
        "CREATE INDEX IF NOT EXISTS ix_fact_clave ON facturas(empresa_id,clave_acceso)",
        "CREATE INDEX IF NOT EXISTS ix_cxc_emp_cli ON cuentas_cobrar(empresa_id,cliente_id)",
        "CREATE INDEX IF NOT EXISTS ix_cxc_fact ON cuentas_cobrar(factura_id)",
        "CREATE INDEX IF NOT EXISTS ix_cli_emp_ruc ON clientes(empresa_id,ruc_cedula)",
        "CREATE INDEX IF NOT EXISTS ix_prov_emp_ruc ON proveedores(empresa_id,ruc_cedula)",
        "CREATE INDEX IF NOT EXISTS ix_comp_emp_prov ON compras(empresa_id,proveedor_id)",
        "CREATE INDEX IF NOT EXISTS ix_comp_emp_estpago ON compras(empresa_id,estado_pago)",
        "CREATE INDEX IF NOT EXISTS ix_adet_asiento ON asiento_detalle(asiento_id)",
        "CREATE INDEX IF NOT EXISTS ix_asi_emp_tipo ON asientos_contables(empresa_id,tipo,origen_id)",
        "CREATE INDEX IF NOT EXISTS ix_asi_emp_fecha ON asientos_contables(empresa_id,fecha)",
        "CREATE INDEX IF NOT EXISTS ix_movb_emp_cta ON movimientos_banco(empresa_id,cuenta_bancaria_id)",
    ]:
        try: conn.execute(ix)
        except Exception: pass
    # Corregir cuentas de ventas: de la cuenta grupo 4.1.01 a las de detalle 4.1.01.01/4.1.01.02
    try:
        for emp in conn.execute("SELECT id FROM empresas").fetchall():
            eid0 = emp[0]
            cc = conn.execute("SELECT cta_ventas, cta_ventas_0 FROM config_contable WHERE empresa_id=?", (eid0,)).fetchone()
            if not cc: continue
            tiene_15 = conn.execute("SELECT 1 FROM plan_cuentas WHERE empresa_id=? AND codigo='4.1.01.01'", (eid0,)).fetchone()
            tiene_0  = conn.execute("SELECT 1 FROM plan_cuentas WHERE empresa_id=? AND codigo='4.1.01.02'", (eid0,)).fetchone()
            v15 = (cc[0] or "").strip(); v0 = (cc[1] or "").strip()
            if tiene_15 and v15 in ("", "4.1.01"):
                conn.execute("UPDATE config_contable SET cta_ventas='4.1.01.01' WHERE empresa_id=?", (eid0,))
            if tiene_0 and v0 in ("", "4.1.01"):
                conn.execute("UPDATE config_contable SET cta_ventas_0='4.1.01.02' WHERE empresa_id=?", (eid0,))
    except Exception:
        pass
    # Sembrar establecimientos por defecto (serie → sucursal) si no existen
    try:
        for emp in conn.execute("SELECT id FROM empresas").fetchall():
            eid0 = emp[0]
            if not conn.execute("SELECT 1 FROM establecimientos WHERE empresa_id=?", (eid0,)).fetchone():
                for cod, nom in [("001","Quito"),("002","Guayaquil"),("004","Milagro"),("005","Manta")]:
                    conn.execute("INSERT INTO establecimientos (empresa_id,codigo,nombre,estado,created_at) VALUES (?,?,?,?,?)",
                                 (eid0, cod, nom, "ACTIVO", now_ec()))
    except Exception:
        pass

    # ── Comprobantes de Compra/Venta (nota de pedido con abono) — módulo independiente ──
    conn.execute("""CREATE TABLE IF NOT EXISTS comprobantes_cv (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            numero TEXT,
            fecha_emision TEXT,
            vencimiento_dias INTEGER DEFAULT 0,
            documento TEXT DEFAULT '',
            cliente_nombre TEXT DEFAULT '',
            cliente_ci TEXT DEFAULT '',
            cliente_email TEXT DEFAULT '',
            telefonos TEXT DEFAULT '',
            vendedor TEXT DEFAULT '',
            estado TEXT DEFAULT 'pendiente',
            bodega TEXT DEFAULT '',
            direccion TEXT DEFAULT '',
            descripcion TEXT DEFAULT '',
            subtotal_15 REAL DEFAULT 0,
            subtotal_5 REAL DEFAULT 0,
            subtotal_0 REAL DEFAULT 0,
            iva_15 REAL DEFAULT 0,
            iva_5 REAL DEFAULT 0,
            total REAL DEFAULT 0,
            total_abono REAL DEFAULT 0,
            saldo REAL DEFAULT 0,
            anulado INTEGER DEFAULT 0,
            usuario_id INTEGER,
            usuario_nombre TEXT DEFAULT '',
            created_at TEXT)""")

    conn.execute("""CREATE TABLE IF NOT EXISTS comprobante_cv_det (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            comprobante_id INTEGER,
            cantidad REAL DEFAULT 1,
            unidad TEXT DEFAULT 'Unid.',
            codigo TEXT DEFAULT '',
            bien_servicio TEXT DEFAULT '',
            detalle TEXT DEFAULT '',
            precio REAL DEFAULT 0,
            ret_ir TEXT DEFAULT '',
            desc_pct REAL DEFAULT 0,
            abono REAL DEFAULT 0,
            iva_tarifa REAL DEFAULT 0,
            subtotal REAL DEFAULT 0)""")



    # ── Registro de firmas de PDF (para el QR de verificación) ──
    conn.execute("""CREATE TABLE IF NOT EXISTS firmas_pdf (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER,
            token TEXT UNIQUE,
            archivo TEXT DEFAULT '',
            firmante TEXT DEFAULT '',
            cedula TEXT DEFAULT '',
            ruc_empresa TEXT DEFAULT '',
            razon TEXT DEFAULT '',
            ubicacion TEXT DEFAULT '',
            sha256 TEXT DEFAULT '',
            firmado_en TEXT DEFAULT '',
            usuario_id INTEGER,
            created_at TEXT)""")
    conn.execute("CREATE INDEX IF NOT EXISTS ix_firmas_pdf_token ON firmas_pdf(token)")

    # Empresa inicial
    if not conn.execute("SELECT id FROM empresas LIMIT 1").fetchone():
        conn.execute("""INSERT INTO empresas (nombre,ruc,direccion,ciudad,created_at)
                        VALUES ('Mi Empresa S.A.','0990000001001','Guayaquil, Ecuador','Guayaquil',?)""",
                     (now_ec(),))
        eid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    else:
        eid = conn.execute("SELECT id FROM empresas LIMIT 1").fetchone()["id"]

    # Admin inicial
    if not conn.execute("SELECT id FROM usuarios WHERE username='admin'").fetchone():
        ph = hashlib.sha256("admin123".encode()).hexdigest()
        conn.execute("INSERT INTO usuarios (username,password_hash,nombre,rol,created_at) VALUES ('admin',?,'Administrador','admin',?)",
                     (ph, now_ec()))
        uid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.execute("INSERT OR IGNORE INTO usuario_empresa (usuario_id,empresa_id,rol) VALUES (?,?,'admin')", (uid, eid))

    conn.commit()
    conn.close()

    # ── MIGRACIÓN: Agregar columnas nuevas a DBs existentes ──────
    # Esto permite actualizar el sistema sin perder datos
    _migrar_columnas()

    # ── Sembrar plan de cuentas (JSON externo o plan estándar incrustado) ──
    _seed_plan_cuentas()

    _mkdirs(eid)
    log.info("DB lista: %s", DB_PATH)


def _migrar_columnas():
    """Agrega columnas nuevas a tablas existentes sin borrar datos."""
    conn = db()
    migraciones = [
        # (tabla, columna, definicion)
        ("empresas", "logo_base64",          "TEXT DEFAULT ''"),
        ("empresas", "smtp_host",             "TEXT DEFAULT ''"),
        ("empresas", "smtp_port",             "INTEGER DEFAULT 587"),
        ("empresas", "smtp_user",             "TEXT DEFAULT ''"),
        ("empresas", "smtp_pass",             "TEXT DEFAULT ''"),
        ("empresas", "smtp_from",             "TEXT DEFAULT ''"),
        ("empresas", "envio_auto_correo",     "INTEGER DEFAULT 0"),
        ("empresas", "contribuyente_especial","TEXT DEFAULT ''"),
        ("empresas", "nombre_comercial",      "TEXT DEFAULT ''"),
        ("liquidaciones_compra", "estado_sri","TEXT DEFAULT ''"),
        ("liquidaciones_compra", "autorizacion","TEXT DEFAULT ''"),
        ("liquidaciones_compra", "fecha_autorizacion","TEXT DEFAULT ''"),
        ("liquidaciones_compra", "clave_acceso","TEXT DEFAULT ''"),
        ("liquidaciones_compra", "ride_path", "TEXT DEFAULT ''"),
        ("guias_remision",  "tipo_identificacion", "TEXT DEFAULT '05'"),
        ("notas_credito",   "factura_ref_numero",   "TEXT DEFAULT ''"),
        ("caja_sesiones",   "total_egresos",        "REAL DEFAULT 0"),
        ("caja_movimientos","metodo_pago",           "TEXT DEFAULT 'EFECTIVO'"),
        ("caja_movimientos","comprobante",           "TEXT DEFAULT ''"),
        ("clientes", "celular",                    "TEXT DEFAULT ''"),
        ("empresas", "tema",                        "TEXT DEFAULT 'oscuro'"),
        ("empresas", "carpeta",                     "TEXT DEFAULT ''"),
        ("usuarios", "modulos",                     "TEXT DEFAULT ''"),
        ("productos", "tipo",                       "TEXT DEFAULT 'PRODUCTO'"),
        ("empresas",       "precios_incluyen_iva", "INTEGER DEFAULT 0"),
        ("empresas",       "sello_activo",         "INTEGER DEFAULT 0"),
        ("empresas",       "sello_pos",            "TEXT DEFAULT 'inf-der'"),
        ("empresas",       "sello_escala",         "REAL DEFAULT 1.0"),
        ("empresas",       "sello_opacidad",       "REAL DEFAULT 0.9"),
        ("empresas",       "sello_pagina",         "TEXT DEFAULT 'ultima'"),
        # ── Sucursales (v3.18.0) ──
        ("empresas",       "usa_sucursales",       "INTEGER DEFAULT 0"),
        ("empresas",       "bloquear_cerrados",    "INTEGER DEFAULT 1"),
        ("productos",      "precio_mayorista",     "REAL DEFAULT 0"),
        ("productos",      "precio_otros",         "REAL DEFAULT 0"),
        ("productos",      "cant_mayorista",       "INTEGER DEFAULT 6"),
        ("productos",      "foto",                 "TEXT DEFAULT ''"),
        ("comprobantes_egreso", "empleado_id",     "INTEGER DEFAULT 0"),
        ("empresas",       "suc_bloquea_stock",    "INTEGER DEFAULT 1"),
        ("usuarios",       "sucursal_id",          "INTEGER DEFAULT 0"),
        ("sucursales",     "codigo",               "TEXT DEFAULT '001'"),
        ("sucursales",     "direccion",            "TEXT DEFAULT ''"),
        ("sucursales",     "telefono",             "TEXT DEFAULT ''"),
        ("sucursales",     "pto_emi",              "TEXT DEFAULT '001'"),
        ("sucursales",     "bodega_id",            "INTEGER DEFAULT 0"),
        ("sucursales",     "estado",               "TEXT DEFAULT 'ACTIVA'"),
        ("sucursales",     "created_at",           "TEXT DEFAULT ''"),
        ("facturas",       "sucursal_id",          "INTEGER DEFAULT 0"),
        ("notas_credito",  "sucursal_id",          "INTEGER DEFAULT 0"),
        ("guias_remision", "sucursal_id",          "INTEGER DEFAULT 0"),
        ("liquidaciones_compra", "sucursal_id",    "INTEGER DEFAULT 0"),
        ("compras",        "sucursal_id",          "INTEGER DEFAULT 0"),
        ("factura_items",  "iva_tarifa",           "REAL DEFAULT -1"),
        ("factura_items",  "iva_valor",            "REAL DEFAULT 0"),
        ("nomina_detalle", "numero",          "TEXT DEFAULT ''"),
        ("empresas",       "rol_prefijo",     "TEXT DEFAULT 'ROL'"),
        ("empresas",       "rol_secuencial",  "INTEGER DEFAULT 1"),
        ("empresas",       "rol_digitos",     "INTEGER DEFAULT 6"),
        ("productos", "graba_iva",                  "INTEGER DEFAULT 1"),
        ("productos", "iva_porcentaje",             "REAL DEFAULT 15"),
        ("productos", "costo",                      "REAL DEFAULT 0"),
        ("productos", "cuenta_inventario",          "TEXT DEFAULT ''"),
        ("productos", "cuenta_ingreso",             "TEXT DEFAULT ''"),
        ("productos", "cuenta_costo",               "TEXT DEFAULT ''"),
        ("stock_movimientos", "bodega_id",          "INTEGER DEFAULT 0"),
        ("stock_movimientos", "bodega_destino_id",  "INTEGER DEFAULT 0"),
        ("stock_movimientos", "asiento_id",         "INTEGER DEFAULT 0"),
        ("usuarios", "secuencial",                  "TEXT DEFAULT ''"),
        ("compras", "sustento",                    "TEXT DEFAULT '01'"),
        ("facturas", "forma_pago",                "TEXT DEFAULT '01'"),
        ("empresas", "sec_inicio_fac",     "INTEGER DEFAULT 0"),
        ("empresas", "sec_inicio_nc",      "INTEGER DEFAULT 0"),
        ("empresas", "sec_inicio_gr",      "INTEGER DEFAULT 0"),
        ("empresas", "sec_inicio_lc",      "INTEGER DEFAULT 0"),
        ("empresas", "sec_inicio_ret",     "INTEGER DEFAULT 0"),
        ("config_contable", "cta_ret_iva",   "TEXT DEFAULT '2.1.07.02'"),
        ("config_contable", "cta_ret_renta", "TEXT DEFAULT '2.1.07.03'"),
        ("retenciones", "estado_sri",        "TEXT DEFAULT 'BORRADOR'"),
        ("retenciones", "fecha_autorizacion","TEXT DEFAULT ''"),
        ("retenciones", "periodo_fiscal",    "TEXT DEFAULT ''"),
        ("config_contable", "cta_gasto_sueldos",   "TEXT DEFAULT '5.1.01.01'"),
        ("config_contable", "cta_aporte_patronal", "TEXT DEFAULT '5.1.01.06'"),
        ("config_contable", "cta_beneficios",      "TEXT DEFAULT '5.1.01.07'"),
        ("config_contable", "cta_iess_pagar",      "TEXT DEFAULT '2.1.07.05'"),
        ("config_contable", "cta_sueldos_pagar",   "TEXT DEFAULT '2.1.03.02'"),
        ("config_contable", "cta_anticipos_emp",   "TEXT DEFAULT '1.1.02.10'"),
        ("config_contable", "cta_beneficios_pagar","TEXT DEFAULT '2.1.07.06'"),
        ("config_contable", "cta_prestamos_emp",   "TEXT DEFAULT '1.1.02.11'"),
        ("config_contable", "cta_multas",          "TEXT DEFAULT '4.2.01'"),
        ("roles_nomina", "total_anticipos",  "REAL DEFAULT 0"),
        ("roles_nomina", "total_prestamos",  "REAL DEFAULT 0"),
        ("roles_nomina", "total_multas",     "REAL DEFAULT 0"),
        ("nomina_detalle", "anticipo_sueldo","REAL DEFAULT 0"),
        ("nomina_detalle", "prestamo",       "REAL DEFAULT 0"),
        ("nomina_detalle", "multa",          "REAL DEFAULT 0"),
        ("nomina_detalle", "empleado_id",    "INTEGER DEFAULT 0"),
        ("nomina_detalle", "regimen",        "TEXT DEFAULT 'LABORAL'"),
        ("nomina_detalle", "sucursal",       "TEXT DEFAULT ''"),
        ("nomina_detalle", "otros_descuentos","REAL DEFAULT 0"),
        ("config_contable", "cta_honorarios","TEXT DEFAULT '5.2.05'"),
        ("config_contable", "cta_anticipo_clientes","TEXT DEFAULT '2.1.05.01'"),
        ("config_contable", "cta_anticipo_proveedores","TEXT DEFAULT '1.1.02.06'"),
        ("config_contable", "cta_gasto_bancario","TEXT DEFAULT '5.2.06'"),
        ("config_contable", "cta_ingreso_financiero","TEXT DEFAULT '4.3.01'"),
        ("config_contable", "cta_caja_chica","TEXT DEFAULT '1.1.01.03'"),
        ("config_contable", "cta_ventas_0","TEXT DEFAULT '4.1.01.02'"),
        ("comprobantes_egreso", "origen_fondos","TEXT DEFAULT 'BANCO'"),
        ("roles_nomina", "total_otros_ingresos","REAL DEFAULT 0"),
        ("roles_nomina", "total_honorarios",    "REAL DEFAULT 0"),
        ("comprobantes_cv", "cliente_email",     "TEXT DEFAULT ''"),
        ("empresas", "prov_sistema_ruc",   "TEXT DEFAULT '0993394602001'"),
        ("empresas", "prov_sistema_campo", "TEXT DEFAULT 'RUC Proveedor'"),
    ]
    for tabla, columna, defn in migraciones:
        try:
            conn.execute(f"ALTER TABLE {tabla} ADD COLUMN {columna} {defn}")
            log.info("Migración: %s.%s agregada", tabla, columna)
        except Exception:
            pass  # La columna ya existe — ignorar
    conn.commit()
    conn.close()
    log.info("Migración de columnas completada")

# Plan de cuentas NIIF Ecuador estándar (fallback si no hay JSON externo)
# (codigo, nombre, nivel, tipo, naturaleza, grupo, padre)
PLAN_NIIF_DEFAULT = [
    ("1","ACTIVO",1,"GRUPO","DEUDORA","ACTIVO",""),
    ("1.1","ACTIVO CORRIENTE",2,"GRUPO","DEUDORA","ACTIVO","1"),
    ("1.1.01","Efectivo y equivalentes al efectivo",3,"GRUPO","DEUDORA","ACTIVO","1.1"),
    ("1.1.01.01","Caja",4,"DETALLE","DEUDORA","ACTIVO","1.1.01"),
    ("1.1.01.02","Bancos",4,"DETALLE","DEUDORA","ACTIVO","1.1.01"),
    ("1.1.02","Cuentas y documentos por cobrar",3,"GRUPO","DEUDORA","ACTIVO","1.1"),
    ("1.1.02.05","Cuentas por cobrar clientes",4,"DETALLE","DEUDORA","ACTIVO","1.1.02"),
    ("1.1.03","Inventarios",3,"GRUPO","DEUDORA","ACTIVO","1.1"),
    ("1.1.03.01","Inventario de mercaderías",4,"DETALLE","DEUDORA","ACTIVO","1.1.03"),
    ("1.1.05","Activos por impuestos corrientes",3,"GRUPO","DEUDORA","ACTIVO","1.1"),
    ("1.1.05.02","Crédito tributario IVA",4,"DETALLE","DEUDORA","ACTIVO","1.1.05"),
    ("1.1.05.03","Anticipo retención en la fuente (Renta)",4,"DETALLE","DEUDORA","ACTIVO","1.1.05"),
    ("1.2","ACTIVO NO CORRIENTE",2,"GRUPO","DEUDORA","ACTIVO","1"),
    ("1.2.01","Propiedad, planta y equipo",3,"GRUPO","DEUDORA","ACTIVO","1.2"),
    ("1.2.01.01","Muebles y enseres",4,"DETALLE","DEUDORA","ACTIVO","1.2.01"),
    ("1.2.01.02","Equipo de cómputo",4,"DETALLE","DEUDORA","ACTIVO","1.2.01"),
    ("2","PASIVO",1,"GRUPO","ACREEDORA","PASIVO",""),
    ("2.1","PASIVO CORRIENTE",2,"GRUPO","ACREEDORA","PASIVO","2"),
    ("2.1.03","Cuentas y documentos por pagar",3,"GRUPO","ACREEDORA","PASIVO","2.1"),
    ("2.1.03.01","Cuentas por pagar proveedores",4,"DETALLE","ACREEDORA","PASIVO","2.1.03"),
    ("2.1.07","Obligaciones fiscales (impuestos por pagar)",3,"GRUPO","ACREEDORA","PASIVO","2.1"),
    ("2.1.07.01","IVA en ventas (por pagar)",4,"DETALLE","ACREEDORA","PASIVO","2.1.07"),
    ("2.1.07.02","Retención IVA por pagar",4,"DETALLE","ACREEDORA","PASIVO","2.1.07"),
    ("2.1.07.03","Retención en la fuente (Renta) por pagar",4,"DETALLE","ACREEDORA","PASIVO","2.1.07"),
    ("2.1.08","Obligaciones con el IESS",3,"GRUPO","ACREEDORA","PASIVO","2.1"),
    ("2.1.10","Sueldos y beneficios por pagar",3,"DETALLE","ACREEDORA","PASIVO","2.1"),
    ("3","PATRIMONIO",1,"GRUPO","ACREEDORA","PATRIMONIO",""),
    ("3.1","Capital",2,"GRUPO","ACREEDORA","PATRIMONIO","3"),
    ("3.1.01","Capital social",3,"DETALLE","ACREEDORA","PATRIMONIO","3.1"),
    ("3.2","Resultados",2,"GRUPO","ACREEDORA","PATRIMONIO","3"),
    ("3.2.01","Utilidad del ejercicio",3,"DETALLE","ACREEDORA","PATRIMONIO","3.2"),
    ("3.2.02","Pérdida del ejercicio",3,"DETALLE","DEUDORA","PATRIMONIO","3.2"),
    ("4","INGRESOS",1,"GRUPO","ACREEDORA","INGRESO",""),
    ("4.1","Ingresos operacionales",2,"GRUPO","ACREEDORA","INGRESO","4"),
    ("4.1.01","Ventas",3,"DETALLE","ACREEDORA","INGRESO","4.1"),
    ("4.1.02","Devoluciones en ventas",3,"DETALLE","DEUDORA","INGRESO","4.1"),
    ("4.2","Otros ingresos",2,"GRUPO","ACREEDORA","INGRESO","4"),
    ("4.2.01","Otros ingresos",3,"DETALLE","ACREEDORA","INGRESO","4.2"),
    ("5","COSTOS Y GASTOS",1,"GRUPO","DEUDORA","GASTO",""),
    ("5.1","Costo de ventas",2,"GRUPO","DEUDORA","COSTO","5"),
    ("5.1.01","Costo de mercaderías vendidas",3,"DETALLE","DEUDORA","COSTO","5.1"),
    ("5.2","Gastos",2,"GRUPO","DEUDORA","GASTO","5"),
    ("5.2.01","Gastos generales",3,"DETALLE","DEUDORA","GASTO","5.2"),
    ("5.2.02","Sueldos y salarios",3,"DETALLE","DEUDORA","GASTO","5.2"),
    ("5.2.03","Servicios básicos",3,"DETALLE","DEUDORA","GASTO","5.2"),
    ("5.2.04","Arriendos",3,"DETALLE","DEUDORA","GASTO","5.2"),
    ("5.2.05","Honorarios profesionales",3,"DETALLE","DEUDORA","GASTO","5.2"),
]

def _seed_plan_cuentas():
    """Siembra el plan de cuentas para empresas sin plan.
    Usa plan_cuentas_niif.json si existe; si no, usa el plan estándar incrustado."""
    conn = db()
    try:
        # Buscar JSON externo (si el usuario tiene uno personalizado)
        _pc_json = None
        for _jp in [BASE_DIR / "plan_cuentas_niif.json",
                    BASE_DIR.parent / "plan_cuentas_niif.json",
                    Path("plan_cuentas_niif.json"),
                    Path("C:/daviloza_soft/plan_cuentas_niif.json")]:
            try:
                if _jp.exists():
                    import json as _json
                    _pc_json = _json.loads(_jp.read_text(encoding="utf-8"))
                    break
            except Exception:
                pass
        for eid_s in [r[0] for r in conn.execute("SELECT id FROM empresas").fetchall()]:
            if conn.execute("SELECT 1 FROM plan_cuentas WHERE empresa_id=?", (eid_s,)).fetchone():
                continue  # ya tiene plan, no tocar
            if _pc_json:
                for pc in _pc_json:
                    cr = str(pc["codigo"]).replace(".", "")
                    conn.execute("INSERT INTO plan_cuentas (empresa_id,codigo,codigo_rapido,nombre,nivel,tipo,naturaleza,grupo,padre_codigo) VALUES (?,?,?,?,?,?,?,?,?)",
                                 (eid_s, pc["codigo"], cr, pc["nombre"], pc.get("nivel",1), pc.get("tipo","DETALLE"), pc.get("naturaleza","DEUDORA"), pc.get("grupo",""), pc.get("padre","")))
                log.info("Plan de cuentas (JSON) cargado: %d cuentas para empresa %d", len(_pc_json), eid_s)
            else:
                for cod, nom, niv, tip, nat, gru, pad in PLAN_NIIF_DEFAULT:
                    conn.execute("INSERT INTO plan_cuentas (empresa_id,codigo,codigo_rapido,nombre,nivel,tipo,naturaleza,grupo,padre_codigo) VALUES (?,?,?,?,?,?,?,?,?)",
                                 (eid_s, cod, cod.replace(".", ""), nom, niv, tip, nat, gru, pad))
                log.info("Plan de cuentas (estándar incrustado) cargado: %d cuentas para empresa %d", len(PLAN_NIIF_DEFAULT), eid_s)
        conn.commit()
    except Exception as e:
        log.warning("No se pudo sembrar el plan de cuentas: %s", e)
    finally:
        conn.close()
    # ── Carpetas de comprobantes con el nombre real de cada empresa ──
    try:
        conn2 = db()
        _migrar_carpetas_empresas(conn2)
        conn2.commit(); conn2.close()
    except Exception as e:
        log.warning("Migración de carpetas de empresas: %s", e)

    # ── Reparar productos con IVA inconsistente ("no graba" pero % > 0, o al revés) ──
    try:
        conn3 = db()
        r1 = conn3.execute("UPDATE productos SET iva_porcentaje=0 WHERE graba_iva=0 AND IFNULL(iva_porcentaje,0)<>0").rowcount
        r2 = conn3.execute("UPDATE productos SET iva_porcentaje=15 WHERE IFNULL(graba_iva,1)=1 AND IFNULL(iva_porcentaje,0)<=0").rowcount
        conn3.commit(); conn3.close()
        if r1 or r2:
            log.info("Productos con IVA corregidos: %d puestos a 0%% (no gravan), %d puestos a 15%% (gravan)", r1, r2)
    except Exception as e:
        log.warning("Reparación de IVA de productos: %s", e)

# ════════════════════════════════════════════════════════════════
#  ASIENTOS CONTABLES AUTOMÁTICOS
# ════════════════════════════════════════════════════════════════
# ════════════════════════════════════════════════════════════
# ROLES DE PAGO INDIVIDUALES
# Cada empleado recibe su propio rol numerado e imprimible, con
# todos los ingresos y descuentos desglosados. El formato del
# número (prefijo, secuencial y dígitos) se define por empresa
# en Configuración.
# ════════════════════════════════════════════════════════════

def _rol_f(v, dv=0.0):
    try:
        if v is None or v == "":
            return dv
        return float(v)
    except Exception:
        return dv


def _rol_cfg(emp):
    emp = emp or {}
    try:
        dig = int(emp.get("rol_digitos") or 6)
    except Exception:
        dig = 6
    return {"prefijo": str(emp.get("rol_prefijo") or "ROL").strip() or "ROL",
            "secuencial": int(_rol_f(emp.get("rol_secuencial"), 1) or 1),
            "digitos": max(1, min(dig, 12))}


def _rol_siguiente_numero(c, eid, cantidad=1):
    """Reserva 'cantidad' números y devuelve la lista ya formateada."""
    emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
    cfg = _rol_cfg(emp)
    inicio = cfg["secuencial"]
    nums = [cfg["prefijo"] + "-" + str(inicio + i).zfill(cfg["digitos"])
            for i in range(max(1, cantidad))]
    c.execute("UPDATE empresas SET rol_secuencial=? WHERE id=?",
              (inicio + max(1, cantidad), eid))
    return nums


_ROL_UNI = ["", "UNO", "DOS", "TRES", "CUATRO", "CINCO", "SEIS", "SIETE", "OCHO", "NUEVE",
            "DIEZ", "ONCE", "DOCE", "TRECE", "CATORCE", "QUINCE", "DIECISEIS", "DIECISIETE",
            "DIECIOCHO", "DIECINUEVE", "VEINTE"]
_ROL_DEC = ["", "", "VEINTE", "TREINTA", "CUARENTA", "CINCUENTA", "SESENTA", "SETENTA",
            "OCHENTA", "NOVENTA"]
_ROL_CEN = ["", "CIENTO", "DOSCIENTOS", "TRESCIENTOS", "CUATROCIENTOS", "QUINIENTOS",
            "SEISCIENTOS", "SETECIENTOS", "OCHOCIENTOS", "NOVECIENTOS"]


def _rol_centenas(n):
    n = int(n)
    if n == 0:
        return ""
    if n == 100:
        return "CIEN"
    t = ""
    c_, r = divmod(n, 100)
    if c_:
        t += _ROL_CEN[c_]
    if r:
        if t:
            t += " "
        if r <= 20:
            t += _ROL_UNI[r]
        else:
            d, u = divmod(r, 10)
            if d == 2:
                t += "VEINTI" + _ROL_UNI[u].lower().upper() if u else "VEINTE"
            else:
                t += _ROL_DEC[d] + (" Y " + _ROL_UNI[u] if u else "")
    return t


def _rol_letras(monto):
    """Convierte un valor a letras. Ej: 470.5 → CUATROCIENTOS SETENTA 50/100"""
    monto = round(_rol_f(monto), 2)
    ent = int(monto)
    cts = int(round((monto - ent) * 100))
    if ent == 0:
        txt = "CERO"
    else:
        mill, resto = divmod(ent, 1000000)
        miles, uni = divmod(resto, 1000)
        partes = []
        if mill:
            partes.append("UN MILLON" if mill == 1
                          else re.sub(r"UNO$", "UN", _rol_centenas(mill)) + " MILLONES")
        if miles:
            # "VEINTIUNO MIL" no existe: delante de MIL/MILLONES va UN, no UNO
            partes.append("MIL" if miles == 1
                          else re.sub(r"UNO$", "UN", _rol_centenas(miles)) + " MIL")
        if uni:
            partes.append(_rol_centenas(uni))
        txt = " ".join(x for x in partes if x)
    return txt + " " + str(cts).zfill(2) + "/100 DOLARES"


def _rol_datos_empleado(c, eid, nombre):
    """Busca la ficha del empleado para completar cédula y sucursal."""
    try:
        r = rd(c.execute("""SELECT * FROM empleados WHERE empresa_id=? AND UPPER(nombres)=UPPER(?)""",
                         (eid, (nombre or "").strip())).fetchone())
        return r or {}
    except Exception:
        return {}


def _rol_autonumerar(eid, ids):
    """Pone numero a los roles que se van a imprimir y no lo tengan.

    Los roles emitidos antes de que existiera la numeracion salian como
    "(sin numerar)". Al imprimirlos se les asigna su numero definitivo.
    """
    c = db()
    faltan = []
    for i in ids:
        r = rd(c.execute("""SELECT d.id, d.numero FROM nomina_detalle d
                            JOIN roles_nomina r ON r.id=d.rol_id
                            WHERE d.id=? AND r.empresa_id=?""", (int(i), eid)).fetchone())
        if r and not str(r.get("numero") or "").strip():
            faltan.append(r["id"])
    if faltan:
        for did, num in zip(faltan, _rol_siguiente_numero(c, eid, len(faltan))):
            c.execute("UPDATE nomina_detalle SET numero=? WHERE id=?", (num, did))
        c.commit()
    c.close()
    return len(faltan)


def _rol_individual_pdf(eid, det_ids):
    """Arma el PDF de uno o varios roles individuales."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle, Paragraph,
                                    Spacer, PageBreak, HRFlowable)
    import io as _io

    c = db()
    emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()) or {}

    def esc(v):
        return str(v if v is not None else "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    st_t  = ParagraphStyle("t",  fontName="Helvetica-Bold", fontSize=13, leading=16)
    st_b  = ParagraphStyle("b",  fontName="Helvetica-Bold", fontSize=9,  leading=12)
    st_n  = ParagraphStyle("n",  fontName="Helvetica",      fontSize=9,  leading=12)
    st_sm = ParagraphStyle("sm", fontName="Helvetica",      fontSize=7.5, leading=10,
                           textColor=colors.HexColor("#555555"))
    st_r  = ParagraphStyle("r",  fontName="Helvetica",      fontSize=9,  leading=12, alignment=2)
    st_rb = ParagraphStyle("rb", fontName="Helvetica-Bold", fontSize=9,  leading=12, alignment=2)

    el = []
    primero = True
    for did in det_ids:
        d = rd(c.execute("SELECT * FROM nomina_detalle WHERE id=?", (int(did),)).fetchone())
        if not d:
            continue
        rol = rd(c.execute("SELECT * FROM roles_nomina WHERE id=?", (d.get("rol_id"),)).fetchone()) or {}
        if int(rol.get("empresa_id") or 0) != int(eid):
            continue
        ficha = _rol_datos_empleado(c, eid, d.get("empleado"))
        if not primero:
            el.append(PageBreak())
        primero = False

        # ── Encabezado ──
        izq = [Paragraph(esc(emp.get("nombre", "")), st_t),
               Paragraph("RUC: " + esc(emp.get("ruc", "")), st_n),
               Paragraph(esc(emp.get("direccion", "") or ""), st_sm)]
        der = [Paragraph("<b>ROL DE PAGOS</b>", st_rb),
               Paragraph("N.º " + esc(d.get("numero") or "(sin numerar)"), st_rb),
               Paragraph("Período: " + esc(rol.get("periodo", "")), st_r),
               Paragraph("Fecha: " + esc(rol.get("fecha", "")), st_r)]
        t = Table([[izq, der]], colWidths=[105 * mm, 65 * mm])
        t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                               ("LEFTPADDING", (0, 0), (-1, -1), 0),
                               ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
        el.append(t)
        el.append(Spacer(1, 4 * mm))
        el.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#333333")))
        el.append(Spacer(1, 4 * mm))

        # ── Datos del colaborador ──
        datos = [[Paragraph("<b>Colaborador:</b> " + esc(d.get("empleado", "")), st_n),
                  Paragraph("<b>Cédula:</b> " + esc(ficha.get("cedula", "") or "—"), st_n)],
                 [Paragraph("<b>Cargo:</b> " + esc(d.get("cargo", "") or "—"), st_n),
                  Paragraph("<b>Sucursal:</b> " + esc(ficha.get("sucursal", "") or "—"), st_n)],
                 [Paragraph("<b>Ingreso:</b> " + esc(ficha.get("fecha_ingreso", "") or "—"), st_n),
                  Paragraph("<b>Forma de pago:</b> " + esc(ficha.get("forma_pago", "") or "—"), st_n)]]
        td = Table(datos, colWidths=[95 * mm, 75 * mm])
        td.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#999999")),
                                ("INNERGRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#DDDDDD")),
                                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                                ("TOPPADDING", (0, 0), (-1, -1), 4),
                                ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
        el.append(td)
        el.append(Spacer(1, 5 * mm))

        # ── Ingresos y descuentos, uno al lado del otro ──
        su = _rol_f(d.get("sueldo")); ot = _rol_f(d.get("otros_ingresos"))
        ip = _rol_f(d.get("iess_personal")); an = _rol_f(d.get("anticipo_sueldo"))
        pr = _rol_f(d.get("prestamo")); mu = _rol_f(d.get("multa"))
        od = _rol_f(d.get("otras_deducciones"))
        if an == 0:
            an = _rol_f(d.get("anticipos"))
        ting = round(su + ot, 2)
        tded = round(ip + an + pr + mu + od, 2)
        liq  = _rol_f(d.get("liquido"), round(ting - tded, 2))

        ing_rows = [[Paragraph("<b>INGRESOS</b>", st_b), Paragraph("<b>VALOR</b>", st_rb)],
                    [Paragraph("Sueldo del período", st_n), Paragraph("%.2f" % su, st_r)],
                    [Paragraph("Otros ingresos", st_n), Paragraph("%.2f" % ot, st_r)],
                    [Paragraph("<b>TOTAL INGRESOS</b>", st_b), Paragraph("<b>%.2f</b>" % ting, st_rb)]]
        ded_rows = [[Paragraph("<b>DESCUENTOS</b>", st_b), Paragraph("<b>VALOR</b>", st_rb)],
                    [Paragraph("Aporte personal IESS", st_n), Paragraph("%.2f" % ip, st_r)],
                    [Paragraph("Anticipo de sueldo", st_n), Paragraph("%.2f" % an, st_r)],
                    [Paragraph("Préstamo", st_n), Paragraph("%.2f" % pr, st_r)],
                    [Paragraph("Multas", st_n), Paragraph("%.2f" % mu, st_r)],
                    [Paragraph("Otros descuentos", st_n), Paragraph("%.2f" % od, st_r)],
                    [Paragraph("<b>TOTAL DESCUENTOS</b>", st_b), Paragraph("<b>%.2f</b>" % tded, st_rb)]]
        while len(ing_rows) < len(ded_rows):
            ing_rows.insert(-1, [Paragraph("", st_n), Paragraph("", st_r)])

        def estilo(tb, filas):
            tb.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#EFEFEF")),
                ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#999999")),
                ("INNERGRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#DDDDDD")),
                ("LINEABOVE", (0, filas - 1), (-1, filas - 1), 0.8, colors.HexColor("#333333")),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
        ti_ = Table(ing_rows, colWidths=[58 * mm, 25 * mm]); estilo(ti_, len(ing_rows))
        td_ = Table(ded_rows, colWidths=[58 * mm, 25 * mm]); estilo(td_, len(ded_rows))
        cont = Table([[ti_, td_]], colWidths=[85 * mm, 85 * mm])
        cont.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                                  ("LEFTPADDING", (0, 0), (-1, -1), 0),
                                  ("RIGHTPADDING", (0, 0), (0, 0), 4)]))
        el.append(cont)
        el.append(Spacer(1, 5 * mm))

        # ── Líquido ──
        liq_t = Table([[Paragraph("<b>LÍQUIDO A RECIBIR</b>", st_b),
                        Paragraph("<b>USD %.2f</b>" % liq, st_rb)],
                       [Paragraph("Son: " + _rol_letras(liq), st_sm), Paragraph("", st_n)]],
                      colWidths=[125 * mm, 45 * mm])
        liq_t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E8EEF7")),
            ("BOX", (0, 0), (-1, -1), 0.8, colors.HexColor("#333333")),
            ("SPAN", (0, 1), (-1, 1)),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
        el.append(liq_t)
        el.append(Spacer(1, 18 * mm))

        # ── Firmas ──
        firma = Table([[Paragraph("_______________________________<br/><b>" +
                                  esc(d.get("empleado", "")) + "</b><br/>" +
                                  esc(ficha.get("cedula", "") or "") +
                                  "<br/>RECIBÍ CONFORME", st_sm),
                        Paragraph("_______________________________<br/><b>" +
                                  esc(emp.get("representante", "") or emp.get("nombre", "")) +
                                  "</b><br/>" + esc(emp.get("ruc", "")) +
                                  "<br/>EMPLEADOR", st_sm)]],
                      colWidths=[85 * mm, 85 * mm])
        firma.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER"),
                                   ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        el.append(firma)

    c.close()
    if not el:
        raise ValueError("No se encontró el rol solicitado.")
    buf = _io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4,
                            leftMargin=20 * mm, rightMargin=20 * mm,
                            topMargin=15 * mm, bottomMargin=15 * mm,
                            title="Rol de pagos")
    doc.build(el)
    return buf.getvalue()


# ════════════════════════════════════════════════════════════
# CIERRE DE MES
# Una vez cerrado un mes no se puede contabilizar nada con fecha
# dentro de ese mes: ni facturas, ni compras, ni egresos, ni
# asientos manuales. Solo el administrador puede reabrirlo, y
# queda registrado quién lo hizo y por qué.
# ════════════════════════════════════════════════════════════

def _periodo_de(fecha) -> str:
    """De una fecha saca el periodo AAAA-MM."""
    f = str(fecha or "").strip()
    if len(f) >= 7 and f[4] == "-":
        return f[:7]
    if "/" in f:
        p = f.split("/")
        if len(p) == 3 and len(p[2]) == 4:
            return p[2] + "-" + p[1].zfill(2)
    return today_ec()[:7]


def _mes_cerrado(c, eid, fecha) -> str:
    """Devuelve el aviso si ese mes está cerrado, o "" si se puede trabajar."""
    try:
        emp = rd(c.execute("SELECT bloquear_cerrados FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
        if int(emp.get("bloquear_cerrados", 1) or 0) == 0:
            return ""
        per = _periodo_de(fecha)
        r = rd(c.execute("""SELECT estado, cerrado_en FROM cierres_mes
                            WHERE empresa_id=? AND periodo=?""", (eid, per)).fetchone())
        if r and str(r.get("estado") or "") == "CERRADO":
            return ("El mes " + per + " está CERRADO contablemente (cerrado el " +
                    str(r.get("cerrado_en") or "")[:10] + "). No se puede registrar ni "
                    "modificar nada con esa fecha. Si necesita hacerlo, el administrador "
                    "debe reabrir el mes en Contabilidad → Cierres.")
    except Exception as ex:
        log.warning("Revisión de cierre de mes: %s", ex)
    return ""


# Endpoints que registran movimientos con fecha y por lo tanto no pueden
# entrar a un mes ya cerrado.
_RUTAS_CONTABLES = (
    "/api/facturas", "/api/notas_credito", "/api/guias", "/api/liquidaciones",
    "/api/compras", "/api/comprobante_egreso", "/api/comprobante_ingreso",
    "/api/asiento", "/api/asiento_manual", "/api/otro_banco",
    "/api/procesar_nomina", "/api/nomina", "/api/pagar_compra", "/api/prestamo_empleado",
    "/api/movimiento_banco", "/api/traspaso", "/api/ajuste_inventario",
)


def _guardia_cierre(p, body, eid):
    """Si la ruta registra movimientos y el mes está cerrado, devuelve el aviso."""
    if p not in _RUTAS_CONTABLES:
        return ""
    fecha = ""
    for campo in ("fecha", "fecha_emision", "periodo"):
        v = str((body or {}).get(campo) or "").strip()
        if v:
            fecha = v
            break
    if not fecha:
        return ""
    c = db()
    try:
        return _mes_cerrado(c, eid, fecha)
    finally:
        c.close()


def _egreso_pdf_bytes(eg, emp, cta=None, usuario=""):
    """Comprobante de egreso en PDF, con el formato de los comprobantes.

    Sirve igual para un pago a proveedor, un gasto sin factura y un
    préstamo o anticipo a un empleado: cambia el beneficiario y la cuenta
    a la que se aplica.
    """
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle,
                                    Paragraph, Spacer)
    from reportlab.lib.styles import ParagraphStyle
    import io as _io

    eg = dict(eg or {}); emp = dict(emp or {}); cta = dict(cta or {})

    def _e(v):
        s = str(v if v is not None else "")
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    def _n(v):
        try:
            return "%.2f" % float(v or 0)
        except Exception:
            return "0.00"

    AZUL = colors.HexColor("#1c3d6e")
    LINEA = colors.HexColor("#B9C4D4")
    GRIS = colors.HexColor("#555555")
    st_emp = ParagraphStyle("emp", fontName="Helvetica-Bold", fontSize=11, leading=13.5, textColor=AZUL)
    st_n   = ParagraphStyle("n",   fontName="Helvetica",      fontSize=8.5, leading=11.5)
    st_b   = ParagraphStyle("b",   fontName="Helvetica-Bold", fontSize=8.5, leading=11.5)
    st_sm  = ParagraphStyle("sm",  fontName="Helvetica",      fontSize=7.5, leading=10, textColor=GRIS)
    st_tit = ParagraphStyle("tit", fontName="Helvetica-Bold", fontSize=12, leading=15, textColor=AZUL)
    st_r   = ParagraphStyle("r",   fontName="Helvetica",      fontSize=8.5, leading=11.5, alignment=2)
    st_rb  = ParagraphStyle("rb",  fontName="Helvetica-Bold", fontSize=10, leading=13, alignment=2)
    st_cab = ParagraphStyle("cab", fontName="Helvetica-Bold", fontSize=8, leading=10,
                            alignment=1, textColor=colors.white)
    st_c   = ParagraphStyle("c",   fontName="Helvetica",      fontSize=8, leading=10, alignment=1)

    buf = _io.BytesIO()
    pdf = SimpleDocTemplate(buf, pagesize=A4, leftMargin=16 * mm, rightMargin=16 * mm,
                            topMargin=14 * mm, bottomMargin=14 * mm,
                            title="Comprobante de egreso " + str(eg.get("numero") or ""))
    el = []
    ANCHO = 178 * mm

    izq = [Paragraph(_e(emp.get("nombre", "")), st_emp),
           Paragraph("RUC: " + _e(emp.get("ruc", "")), st_n),
           Paragraph(_e(emp.get("direccion", "") or ""), st_sm)]
    der = [Paragraph("Usuario: " + _e(usuario or ""), st_sm),
           Paragraph("Impreso: " + _e(today_ec()), st_sm)]
    t = Table([[izq, der]], colWidths=[ANCHO * 0.65, ANCHO * 0.35])
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("ALIGN", (1, 0), (1, 0), "RIGHT"),
                           ("LEFTPADDING", (0, 0), (-1, -1), 0),
                           ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    el.append(t)
    el.append(Spacer(1, 3 * mm))

    tipo = str(eg.get("beneficiario_tipo") or "PROVEEDOR").upper()
    titulo = "COMPROBANTE DE EGRESO"
    if tipo == "EMPLEADO":
        titulo = "COMPROBANTE DE EGRESO — PRÉSTAMO / ANTICIPO A EMPLEADO"
    el.append(Paragraph(_e(titulo) + ": " + _e(eg.get("numero") or ""), st_tit))
    el.append(Spacer(1, 2 * mm))

    forma = str(eg.get("forma_pago") or "").upper()
    pago = forma.title()
    if forma == "CHEQUE" and str(eg.get("cheque_numero") or "").strip():
        pago = "Cheque N.º " + str(eg.get("cheque_numero"))
    if cta.get("banco"):
        pago += "  ·  " + str(cta.get("banco")) + " " + str(cta.get("numero") or "")

    datos = [
        [Paragraph("<b>Fecha:</b> " + _e(str(eg.get("fecha", ""))[:10]), st_n),
         Paragraph("<b>Estado:</b> " + _e(eg.get("estado") or "EMITIDO"), st_n)],
        [Paragraph("<b>Beneficiario:</b> " + _e(eg.get("beneficiario") or ""), st_n),
         Paragraph("<b>Tipo:</b> " + _e(tipo.title()), st_n)],
        [Paragraph("<b>Forma de pago:</b> " + _e(pago), st_n),
         Paragraph("<b>Aplicado a:</b> " +
                   ("Factura de compra" if str(eg.get("aplicar_a")) == "CXP" else "Cuenta contable"), st_n)],
    ]
    td = Table(datos, colWidths=[ANCHO * 0.58, ANCHO * 0.42])
    td.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.8, AZUL),
                            ("INNERGRID", (0, 0), (-1, -1), 0.4, LINEA),
                            ("LEFTPADDING", (0, 0), (-1, -1), 6),
                            ("TOPPADDING", (0, 0), (-1, -1), 4),
                            ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
    el.append(td)
    el.append(Spacer(1, 3 * mm))

    detalle = str(eg.get("detalle_aplicado") or "")
    if not detalle:
        if str(eg.get("aplicar_a")) == "CXP":
            detalle = "Pago de factura de compra" + (" " + str(eg.get("compra_numero")) if eg.get("compra_numero") else "")
        else:
            detalle = "Cuenta " + str(eg.get("cuenta_contrapartida") or "")
    filas = [[Paragraph("Concepto", st_cab), Paragraph("Aplicado a", st_cab), Paragraph("Valor", st_cab)],
             [Paragraph(_e(eg.get("concepto") or ""), st_n),
              Paragraph(_e(detalle), st_n),
              Paragraph("$" + _n(eg.get("monto")), st_r)]]
    tdet = Table(filas, colWidths=[ANCHO * 0.46, ANCHO * 0.34, ANCHO * 0.20])
    tdet.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), AZUL),
                              ("GRID", (0, 0), (-1, -1), 0.5, LINEA),
                              ("BOX", (0, 0), (-1, -1), 0.8, AZUL),
                              ("VALIGN", (0, 0), (-1, -1), "TOP"),
                              ("LEFTPADDING", (0, 0), (-1, -1), 6),
                              ("TOPPADDING", (0, 0), (-1, -1), 5),
                              ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    el.append(tdet)
    el.append(Spacer(1, 2 * mm))

    ttot = Table([[Paragraph("TOTAL PAGADO", st_b), Paragraph("$" + _n(eg.get("monto")), st_rb)]],
                 colWidths=[ANCHO * 0.80, ANCHO * 0.20])
    ttot.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#E8EEF7")),
                              ("BOX", (0, 0), (-1, -1), 0.8, AZUL),
                              ("LEFTPADDING", (0, 0), (-1, -1), 6),
                              ("TOPPADDING", (0, 0), (-1, -1), 5),
                              ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    el.append(ttot)
    el.append(Spacer(1, 16 * mm))

    firmas = Table([[Paragraph("_________________________<br/>Elaborado por", st_c),
                     Paragraph("_________________________<br/>Aprobado por", st_c),
                     Paragraph("_________________________<br/>Recibí conforme", st_c)]],
                   colWidths=[ANCHO / 3.0] * 3)
    firmas.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER")]))
    el.append(firmas)
    el.append(Spacer(1, 6 * mm))
    el.append(Paragraph(_e(emp.get("nombre", "")) + " · RUC " + _e(emp.get("ruc", "")) +
                        " · Generado por DAVI&amp;LOZA SOFT", st_sm))
    pdf.build(el)
    return buf.getvalue()


# ════════════════════════════════════════════════════════════
# FOTO DEL PRODUCTO
# La imagen se guarda como archivo en disco, nunca dentro de la
# base de datos: así la base no se infla y el servidor no se
# pone lento. Al subirla se reduce a 500 px y se recomprime, de
# modo que cada foto pesa unas pocas decenas de KB. Al servirla
# se marca como cacheable, para que cada computadora la descargue
# una sola vez y no en cada factura.
# ════════════════════════════════════════════════════════════

FOTO_LADO_MAX = 500          # px del lado mayor
FOTO_CALIDAD = 80            # calidad JPEG


def _foto_dir(eid):
    d = BASE_DIR / "fotos" / _dir_emp(eid)
    d.mkdir(parents=True, exist_ok=True)
    return d


def _foto_ruta(eid, pid):
    return _foto_dir(eid) / (str(int(pid)) + ".jpg")


def _foto_guardar(eid, pid, crudo):
    """Reduce y guarda la foto. Devuelve el tamaño final en bytes."""
    try:
        from PIL import Image
        import io as _io
    except Exception:
        raise ValueError("Falta la librería Pillow. Cierre el sistema y ábralo "
                         "con INICIAR_SERVIDOR.bat para que se instale sola.")
    try:
        im = Image.open(_io.BytesIO(crudo))
    except Exception as ex:
        raise ValueError("No se pudo leer la imagen: " + str(ex))
    im = im.convert("RGB")
    if max(im.size) > FOTO_LADO_MAX:
        f = FOTO_LADO_MAX / float(max(im.size))
        im = im.resize((max(1, int(im.size[0] * f)), max(1, int(im.size[1] * f))), Image.LANCZOS)
    ruta = _foto_ruta(eid, pid)
    im.save(str(ruta), format="JPEG", quality=FOTO_CALIDAD, optimize=True)
    return ruta.stat().st_size


# ════════════════════════════════════════════════════════════
# TOMA FÍSICA DE INVENTARIO
# El conteo se hace desde el celular, en la misma red. Cada
# producto contado queda con su hora: lo que se venda DESPUÉS de
# contarlo se descuenta solo, para que la diferencia sea real
# aunque se siga facturando mientras se cuenta.
# Al cerrar se muestra la diferencia y el usuario decide si la
# aplica; recién ahí se ajusta el stock y se genera el asiento.
# ════════════════════════════════════════════════════════════

def _toma_abierta(c, eid, bodega_id=0):
    sql = "SELECT * FROM tomas_fisicas WHERE empresa_id=? AND estado='ABIERTA'"
    par = [eid]
    if bodega_id:
        sql += " AND bodega_id=?"
        par.append(int(bodega_id))
    return rd(c.execute(sql + " ORDER BY id DESC LIMIT 1", par).fetchone())


def _toma_vendido_despues(c, eid, producto_id, desde):
    """Unidades facturadas o prefacturadas después de contar el producto."""
    if not producto_id or not desde:
        return 0.0
    total = 0.0
    try:
        cod_p = rd(c.execute("SELECT codigo FROM productos WHERE id=?", (producto_id,)).fetchone()) or {}
        cod_p = str(cod_p.get("codigo") or "").strip()
        # Se cruza por producto y también por código: las facturas viejas no
        # guardaban el producto en el detalle.
        r = c.execute("""SELECT IFNULL(SUM(i.cantidad),0) FROM factura_items i
                         JOIN facturas f ON f.id = i.factura_id
                         WHERE f.empresa_id=? AND IFNULL(f.estado,'')<>'ANULADA'
                           AND (i.producto_id = ?
                                OR (IFNULL(i.producto_id,0)=0 AND ?<>'' AND i.codigo = ?))
                           AND IFNULL(f.created_at, f.fecha) > ?""",
                      (eid, producto_id, cod_p, cod_p, desde)).fetchone()
        total += float(r[0] or 0)
    except Exception as ex:
        log.warning("toma: ventas posteriores: %s", ex)
    # Prefacturas (comprobantes de compra/venta): se cruzan por código
    try:
        cod = rd(c.execute("SELECT codigo FROM productos WHERE id=?", (producto_id,)).fetchone()) or {}
        cod = str(cod.get("codigo") or "").strip()
        if cod:
            r2 = c.execute("""SELECT IFNULL(SUM(d.cantidad),0) FROM comprobante_cv_det d
                              JOIN comprobantes_cv v ON v.id = d.comprobante_id
                              WHERE v.empresa_id=? AND d.codigo=?
                                AND IFNULL(v.estado,'')<>'anulado'
                                AND IFNULL(v.created_at, v.fecha_emision) > ?""",
                           (eid, cod, desde)).fetchone()
            total += float(r2[0] or 0)
    except Exception as ex:
        log.warning("toma: prefacturas posteriores: %s", ex)
    return round(total, 4)


def _toma_diferencias(c, eid, toma_id):
    """Compara lo contado (ya descontadas las ventas) contra el sistema."""
    toma = rd(c.execute("SELECT * FROM tomas_fisicas WHERE id=? AND empresa_id=?",
                        (toma_id, eid)).fetchone())
    if not toma:
        return None, []
    bid = int(toma.get("bodega_id") or 0) or _bodega_principal(c, eid)
    items = rl(c.execute("SELECT * FROM toma_items WHERE toma_id=? ORDER BY nombre", (toma_id,)).fetchall())
    salida = []
    contados = set()
    for it in items:
        pid = int(it.get("producto_id") or 0)
        contados.add(pid)
        vendido = _toma_vendido_despues(c, eid, pid, it.get("contado_en"))
        contado = float(it.get("cantidad") or 0)
        ajustado = round(contado - vendido, 4)
        sistema = 0.0
        costo = float(it.get("costo") or 0)
        if pid:
            r = c.execute("SELECT cantidad FROM stock_bodega WHERE producto_id=? AND bodega_id=?",
                          (pid, bid)).fetchone()
            sistema = float(r[0]) if r else 0.0
            p = rd(c.execute("SELECT costo FROM productos WHERE id=?", (pid,)).fetchone()) or {}
            if not costo:
                costo = float(p.get("costo") or 0)
        salida.append({"item_id": it["id"], "producto_id": pid,
                       "codigo": it.get("codigo", ""), "nombre": it.get("nombre", ""),
                       "contado": contado, "vendido_despues": vendido,
                       "contado_ajustado": ajustado, "sistema": round(sistema, 4),
                       "diferencia": round(ajustado - sistema, 4),
                       "costo": costo, "nuevo": int(it.get("nuevo") or 0),
                       "foto": int(it.get("foto") or 0)})
    # Productos del catálogo que nadie contó: quedarían en cero
    try:
        for p in rl(c.execute("""SELECT p.id, p.codigo, p.nombre, p.costo,
                                 IFNULL(sb.cantidad,0) AS cant
                                 FROM productos p
                                 LEFT JOIN stock_bodega sb ON sb.producto_id=p.id AND sb.bodega_id=?
                                 WHERE p.empresa_id=? AND IFNULL(p.activo,1)=1
                                   AND IFNULL(p.tipo,'PRODUCTO')<>'SERVICIO'""",
                              (bid, eid)).fetchall()):
            if p["id"] in contados:
                continue
            if abs(float(p.get("cant") or 0)) < 0.0001:
                continue
            salida.append({"item_id": 0, "producto_id": p["id"], "codigo": p.get("codigo", ""),
                           "nombre": p.get("nombre", ""), "contado": 0.0, "vendido_despues": 0.0,
                           "contado_ajustado": 0.0, "sistema": round(float(p.get("cant") or 0), 4),
                           "diferencia": round(-float(p.get("cant") or 0), 4),
                           "costo": float(p.get("costo") or 0), "nuevo": 0, "foto": 0,
                           "sin_contar": True})
    except Exception as ex:
        log.warning("toma: no contados: %s", ex)
    return toma, salida


# ════════════════════════════════════════════════════════════
# ETIQUETAS CON CÓDIGO DE BARRAS
# Se usa Code 128 porque admite letras, números y guiones: así un
# código como "6188-3" se imprime y se lee tal cual. EAN-13 solo
# acepta 12 dígitos con dígito verificador, y no sirve para los
# códigos internos que ya tiene el catálogo.
# La pistola lectora no necesita configuración: se comporta como
# un teclado, escribe el código y manda Enter.
# ════════════════════════════════════════════════════════════

ETIQUETA_FORMATOS = {
    "a4_33":  {"nombre": "A4 · 33 etiquetas (3 x 11)", "cols": 3, "filas": 11,
               "ancho": 70, "alto": 25.4, "mx": 0, "my": 12.7},
    "a4_24":  {"nombre": "A4 · 24 etiquetas (3 x 8)",  "cols": 3, "filas": 8,
               "ancho": 70, "alto": 35,   "mx": 0, "my": 10},
    "a4_12":  {"nombre": "A4 · 12 etiquetas (2 x 6)",  "cols": 2, "filas": 6,
               "ancho": 99, "alto": 42,   "mx": 5, "my": 15},
}


def _etiquetas_pdf(eid, productos, formato="a4_33", copias=1, mostrar_precio=True,
                   mostrar_imagen=False):
    """Hoja de etiquetas lista para imprimir en papel adhesivo.

    Cada producto puede traer su propio número de copias (clave "copias"),
    que es lo que usa la cola de impresión.
    """
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.pdfgen import canvas as _canvas
    from reportlab.graphics.barcode import code128
    from reportlab.lib.utils import ImageReader
    import io as _io

    f = ETIQUETA_FORMATOS.get(formato) or ETIQUETA_FORMATOS["a4_33"]
    ANCHO, ALTO = A4
    ce, al = f["ancho"] * mm, f["alto"] * mm
    mx, my = f["mx"] * mm, f["my"] * mm
    cols, filas = f["cols"], f["filas"]
    # Centrar la rejilla en la hoja
    izq = (ANCHO - (cols * ce)) / 2.0
    arr = ALTO - my

    buf = _io.BytesIO()
    cv = _canvas.Canvas(buf, pagesize=A4)
    cv.setTitle("Etiquetas de productos")

    lista = []
    for p in productos:
        n = int(p.get("copias") or 0) or max(1, int(copias))
        for _ in range(max(1, min(500, n))):
            lista.append(p)

    i = 0
    for p in lista:
        pos = i % (cols * filas)
        if pos == 0 and i > 0:
            cv.showPage()
        col = pos % cols
        fil = pos // cols
        x = izq + col * ce
        y = arr - (fil + 1) * al
        cod = str(p.get("codigo") or "").strip()
        nom = str(p.get("nombre") or "")[:38]
        pre = p.get("precio")

        # Reparto vertical de la etiqueta, de arriba hacia abajo:
        # nombre · barras · código legible · precio. Sin encimarse.
        y_nom = y + al * 0.82
        y_bar = y + al * 0.34
        h_bar = al * 0.40
        y_cod = y + al * 0.20
        y_pre = y + al * 0.05
        # Con foto, la etiqueta se parte: imagen a la izquierda, barras a la derecha
        x_izq = x
        ancho_util = ce
        if mostrar_imagen:
            # La foto se mantiene chica a propósito: si le quita ancho al código
            # de barras, las barras salen tan finas que la pistola ya no las lee.
            lado = min(al * 0.46, ce * 0.17)
            # Y si el código es tan largo que ni así entra, manda el código:
            # esa etiqueta sale sin foto antes que salir ilegible.
            if cod:
                try:
                    prueba = code128.Code128(cod, barHeight=1, barWidth=0.33, humanReadable=False)
                    if prueba.width > (ce - lado - 7 * mm) - 5 * mm:
                        lado = 0
                except Exception:
                    lado = 0
        if mostrar_imagen and lado > 0:
            try:
                rf = _foto_ruta(eid, p.get("id") or 0)
                if rf.exists():
                    cv.drawImage(ImageReader(str(rf)), x + 2 * mm, y + (al - lado) / 2.0,
                                 width=lado, height=lado, preserveAspectRatio=True, mask="auto")
            except Exception as ex:
                log.warning("etiqueta sin foto %s: %s", p.get("codigo"), ex)
            # El código necesita una franja blanca a cada lado para ser legible
            # (zona muda). Si la foto se le pega, la pistola falla.
            x_izq = x + lado + 4 * mm
            ancho_util = ce - lado - 7 * mm
        # Nombre
        cv.setFont("Helvetica-Bold", 7.5)
        cv.drawCentredString(x_izq + ancho_util / 2, y_nom, nom[:(26 if mostrar_imagen else 34)])
        # Código de barras
        if cod:
            try:
                bc = code128.Code128(cod, barHeight=h_bar, barWidth=0.40,
                                     humanReadable=False)
                bw = bc.width
                # Las barras se ajustan para APROVECHAR todo el ancho libre.
                # Antes solo se angostaban si no cabían, y un código largo
                # quedaba tan fino que la pistola no lo leía: la barra más
                # delgada debe medir al menos 0,19 mm para ser legible.
                ancho_disp = ancho_util - 5 * mm
                if bw > 0:
                    factor = ancho_disp / bw
                    nuevo_ancho = min(1.10, max(0.55, 0.40 * factor))
                    bc = code128.Code128(cod, barHeight=h_bar,
                                         barWidth=nuevo_ancho,
                                         humanReadable=False)
                    bw = bc.width
                    # Si al ensanchar se pasó del espacio, se vuelve al mínimo
                    if bw > ancho_disp:
                        bc = code128.Code128(cod, barHeight=h_bar, barWidth=0.55,
                                             humanReadable=False)
                        bw = bc.width
                bc.drawOn(cv, x_izq + (ancho_util - bw) / 2.0, y_bar)
            except Exception as ex:
                log.warning("etiqueta %s: %s", cod, ex)
            cv.setFont("Helvetica", 6.5)
            cv.drawCentredString(x_izq + ancho_util / 2, y_cod, cod)
        else:
            cv.setFont("Helvetica", 6.5)
            cv.drawCentredString(x_izq + ancho_util / 2, y_bar + h_bar / 2, "(sin código)")
        # Precio
        if mostrar_precio and pre is not None:
            cv.setFont("Helvetica-Bold", 8.5)
            try:
                cv.drawCentredString(x_izq + ancho_util / 2, y_pre, "$ %.2f" % float(pre or 0))
            except Exception:
                pass
        i += 1

    cv.showPage()
    cv.save()
    return buf.getvalue()


def _cfg_contable(c, eid):
    """Devuelve el mapeo de cuentas de la empresa, creando defaults si falta."""
    row = c.execute("SELECT * FROM config_contable WHERE empresa_id=?", (eid,)).fetchone()
    if not row:
        c.execute("INSERT INTO config_contable (empresa_id,updated_at) VALUES (?,?)", (eid, now_ec()))
        row = c.execute("SELECT * FROM config_contable WHERE empresa_id=?", (eid,)).fetchone()
    cfg = dict(row)
    # Defaults defensivos: si alguna cuenta quedó vacía/NULL, asignar un valor por defecto
    _defaults = {
        "cta_caja":"1.1.01.01","cta_bancos":"1.1.01.02","cta_cxc":"1.1.02.05","cta_ventas":"4.1.01.01",
        "cta_iva_ventas":"2.1.07.01","cta_dev_ventas":"4.1.02","cta_cxp":"2.1.03.01","cta_inventario":"1.1.03.01",
        "cta_gastos":"5.2.01","cta_iva_compras":"1.1.05.02","cta_ret_iva":"2.1.07.02","cta_ret_renta":"2.1.07.03",
        "cta_gasto_sueldos":"5.1.01.01","cta_aporte_patronal":"5.1.01.06","cta_beneficios":"5.1.01.07",
        "cta_iess_pagar":"2.1.07.05","cta_sueldos_pagar":"2.1.03.02","cta_anticipos_emp":"1.1.02.10",
        "cta_beneficios_pagar":"2.1.07.06","cta_prestamos_emp":"1.1.02.11","cta_multas":"4.2.01",
        "cta_honorarios":"5.2.05",
        "cta_anticipo_clientes":"2.1.05.01","cta_anticipo_proveedores":"1.1.02.06",
        "cta_gasto_bancario":"5.2.06","cta_ingreso_financiero":"4.3.01","cta_caja_chica":"1.1.01.03",
        "cta_ventas_0":"4.1.01.02",
    }
    for k, v in _defaults.items():
        if not str(cfg.get(k) or "").strip():
            cfg[k] = v
    return cfg

def _nombre_cuenta(c, eid, codigo):
    """Resuelve el nombre de una cuenta desde el plan; si no existe, usa el código."""
    if not codigo:
        return ""
    r = c.execute("SELECT nombre FROM plan_cuentas WHERE empresa_id=? AND codigo=?", (eid, codigo)).fetchone()
    return r["nombre"] if r else codigo

def generar_asiento_auto(c, eid, usuario_id, fecha, concepto, tipo, origen_id, lineas, forzar=False):
    # El candado del cierre se aplica ANTES, al recibir la petición
    # (_guardia_cierre). Aquí solo queda un registro por si algún camino
    # interno intentara contabilizar en un mes cerrado.
    try:
        _cerr = _mes_cerrado(c, eid, fecha)
        if _cerr:
            log.warning("Asiento en mes cerrado (%s): %s", tipo, _cerr[:80])
    except Exception:
        pass
    """
    Crea un asiento automático cuadrado (partida doble).
    lineas: lista de tuplas (cuenta_codigo, debe, haber).
    No hace commit ni cierra la conexion (la maneja el handler).
    Nunca interrumpe el guardado del documento: si algo falla solo registra el error.
    Devuelve el id del asiento o None.
    """
    try:
        cfg = _cfg_contable(c, eid)
        if not forzar and not int(cfg.get("auto_asientos", 1)):
            return None
        # Anti-duplicados: si ya existe un asiento ACTIVO para este origen, no recrear
        ya = c.execute("SELECT id FROM asientos_contables WHERE empresa_id=? AND tipo=? AND origen_id=? AND estado='ACTIVO'",
                       (eid, tipo, origen_id)).fetchone()
        if ya:
            return ya["id"]
        # Filtrar lineas con valor y redondear a 2 decimales
        det = []
        for cod, debe, haber in lineas:
            d = round(float(debe or 0), 2)
            h = round(float(haber or 0), 2)
            if d == 0 and h == 0:
                continue
            det.append((cod, d, h))
        if not det:
            return None
        # Validar partida doble
        td = round(sum(x[1] for x in det), 2)
        th = round(sum(x[2] for x in det), 2)
        if abs(td - th) > 0.05:
            log.warning("Asiento auto descuadrado (%s/%s): debe=%.2f haber=%.2f — no se genera", tipo, origen_id, td, th)
            return None
        # Cuadre por redondeo: si hay diferencia de centavos, ajustarla en la línea de mayor monto
        diff = round(td - th, 2)
        if diff != 0:
            idx = max(range(len(det)), key=lambda i: max(det[i][1], det[i][2]))
            cod, d, h = det[idx]
            if d >= h:
                det[idx] = (cod, round(d - diff, 2), h)
            else:
                det[idx] = (cod, d, round(h + diff, 2))
        numero = (c.execute("SELECT COALESCE(MAX(numero),0)+1 FROM asientos_contables WHERE empresa_id=?", (eid,)).fetchone()[0])
        c.execute("""INSERT INTO asientos_contables
            (empresa_id,numero,fecha,concepto,referencia,tipo,origen_id,usuario_id,estado,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (eid, numero, fecha, concepto, concepto, tipo, origen_id, usuario_id, "ACTIVO", now_ec()))
        aid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
        for cod, d, h in det:
            c.execute("""INSERT INTO asiento_detalle
                (asiento_id,cuenta_codigo,cuenta_nombre,debe,haber,referencia)
                VALUES (?,?,?,?,?,?)""",
                (aid, cod, _nombre_cuenta(c, eid, cod), d, h, concepto))
        log.info("Asiento auto #%d generado (%s/%s)", numero, tipo, origen_id)
        return aid
    except Exception as e:
        log.warning("No se pudo generar asiento auto (%s/%s): %s", tipo, origen_id, e)
        return None

def revertir_asiento_auto(c, eid, tipo, origen_id):
    """Marca como ANULADO el asiento automatico de un documento anulado."""
    try:
        c.execute("UPDATE asientos_contables SET estado='ANULADO' WHERE empresa_id=? AND tipo=? AND origen_id=? AND estado='ACTIVO'",
                  (eid, tipo, origen_id))
        log.info("Asiento auto revertido (%s/%s)", tipo, origen_id)
    except Exception as e:
        log.warning("No se pudo revertir asiento auto (%s/%s): %s", tipo, origen_id, e)

def _calc_provisiones(ingresos, num_emp, sbu=470.0):
    """Provisión mensual de beneficios sociales (Ecuador):
    décimo tercero (1/12), fondos de reserva (1/12), vacaciones (1/24) sobre ingresos,
    y décimo cuarto (SBU/12 por empleado)."""
    ing = float(ingresos or 0); n = int(num_emp or 0); sbu = float(sbu or 0)
    d3 = ing / 12.0
    fr = ing / 12.0
    vac = ing / 24.0
    d4 = (sbu / 12.0) * n
    return round(d3 + fr + vac + d4, 2)

def _asiento_nomina(c, eid, uid, rol):
    """Genera (forzado) el asiento contable de un rol de nómina, cuadrado en partida doble."""
    cfg = _cfg_contable(c, eid)
    ing=float(rol["total_ingresos"] or 0); iessp=float(rol["total_iess_personal"] or 0)
    pat=float(rol["total_aporte_patronal"] or 0)
    t_ant=float(rol["total_anticipos"] or 0); t_pre=float(rol["total_prestamos"] or 0); t_mul=float(rol["total_multas"] or 0)
    ded=float(rol["total_deducciones"] or 0)
    t_ot=round(ded - t_ant - t_pre - t_mul, 2)
    liq=float(rol["total_liquido"] or 0); prov=float(rol["total_provisiones"] or 0); incprov=rol["incluir_provisiones"]
    lineas=[(cfg["cta_gasto_sueldos"], round(ing,2), 0)]
    if pat>0: lineas.append((cfg["cta_aporte_patronal"], pat, 0))
    if incprov and prov>0: lineas.append((cfg["cta_beneficios"], prov, 0))
    if (iessp+pat)>0: lineas.append((cfg["cta_iess_pagar"], 0, round(iessp+pat,2)))
    if (t_ant+t_ot)>0: lineas.append((cfg["cta_anticipos_emp"], 0, round(t_ant+t_ot,2)))
    if t_pre>0: lineas.append((cfg["cta_prestamos_emp"], 0, round(t_pre,2)))
    if t_mul>0: lineas.append((cfg["cta_multas"], 0, round(t_mul,2)))
    lineas.append((cfg["cta_sueldos_pagar"], 0, round(liq,2)))
    if incprov and prov>0: lineas.append((cfg["cta_beneficios_pagar"], 0, prov))
    return generar_asiento_auto(c, eid, uid, rol["fecha"],
        "Nómina " + str(rol["periodo"] or "") + " — " + str(rol["concepto"] or ""), "NOMINA", rol["id"], lineas, forzar=True)

def _asiento_nomina_proc(c, eid, uid, rol_id, fecha, periodo, emps, total_prov=0.0):
    """Asiento de un rol procesado: sueldos por sucursal, honorarios (civil) sin IESS,
    aporte patronal, IESS por pagar, anticipos/préstamos/multas/otros descuentos y líquido."""
    cfg = _cfg_contable(c, eid)
    suc_map = {}
    for s in c.execute("SELECT nombre, cta_gasto_sueldos FROM sucursales WHERE empresa_id=?", (eid,)).fetchall():
        if (s["cta_gasto_sueldos"] or "").strip():
            suc_map[(s["nombre"] or "").strip().upper()] = s["cta_gasto_sueldos"].strip()
    deb = {}
    def add_deb(cta, val):
        if val and cta: deb[cta] = round(deb.get(cta, 0) + val, 2)
    t_iess = t_ant = t_pre = t_mul = t_odesc = t_neto = t_pat = 0.0
    for e in emps:
        ing = float(e["sueldo"]) + float(e["otros_ing"])
        if e["regimen"] == "CIVIL":
            add_deb(cfg["cta_honorarios"], ing)
        else:
            cta = suc_map.get((e["sucursal"] or "").strip().upper(), cfg["cta_gasto_sueldos"])
            add_deb(cta, ing); t_pat += float(e["aporte_pat"])
        t_iess += float(e["iess_personal"]) + float(e["aporte_pat"])
        t_ant += float(e["anticipo"]); t_pre += float(e["prestamo"]); t_mul += float(e["multa"])
        t_odesc += float(e["otros_desc"]); t_neto += float(e["neto"])
    lineas = [(cta, round(val, 2), 0) for cta, val in deb.items()]
    if t_pat > 0: lineas.append((cfg["cta_aporte_patronal"], round(t_pat, 2), 0))
    if total_prov and total_prov > 0: lineas.append((cfg["cta_beneficios"], round(total_prov, 2), 0))
    if t_iess > 0: lineas.append((cfg["cta_iess_pagar"], 0, round(t_iess, 2)))
    if (t_ant + t_odesc) > 0: lineas.append((cfg["cta_anticipos_emp"], 0, round(t_ant + t_odesc, 2)))
    if t_pre > 0: lineas.append((cfg["cta_prestamos_emp"], 0, round(t_pre, 2)))
    if t_mul > 0: lineas.append((cfg["cta_multas"], 0, round(t_mul, 2)))
    lineas.append((cfg["cta_sueldos_pagar"], 0, round(t_neto, 2)))
    if total_prov and total_prov > 0: lineas.append((cfg["cta_beneficios_pagar"], 0, round(total_prov, 2)))
    return generar_asiento_auto(c, eid, uid, fecha, "Rol de pagos " + str(periodo), "NOMINA", rol_id, lineas, forzar=True)

# ── Helpers Bancos ──
def _num_comprobante(c, eid, tabla, prefijo):
    n = c.execute("SELECT COUNT(*)+1 FROM " + tabla + " WHERE empresa_id=?", (eid,)).fetchone()[0]
    return prefijo + "-" + str(n).zfill(6)

def _next_cheque(c, eid, cuenta_id):
    row = c.execute("SELECT secuencia_cheque FROM cuentas_bancarias WHERE id=? AND empresa_id=?", (cuenta_id, eid)).fetchone()
    n = int((row[0] if row else 1) or 1)
    c.execute("UPDATE cuentas_bancarias SET secuencia_cheque=? WHERE id=? AND empresa_id=?", (n + 1, cuenta_id, eid))
    return str(n)

def _mov_banco(c, eid, cuenta_id, fecha, tipo, concepto, beneficiario, ingreso, egreso, documento, origen_tipo, origen_id, asiento_id, uid):
    c.execute("""INSERT INTO movimientos_banco
        (empresa_id,cuenta_bancaria_id,fecha,tipo,concepto,beneficiario,documento,ingreso,egreso,
         estado_concil,origen_tipo,origen_id,asiento_id,estado,usuario_id,created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (eid, cuenta_id, fecha, tipo, concepto, beneficiario or "", documento or "",
         round(float(ingreso or 0), 2), round(float(egreso or 0), 2), "PENDIENTE",
         origen_tipo or "", origen_id or 0, asiento_id or 0, "ACTIVO", uid, now_ec()))
    return c.execute("SELECT last_insert_rowid()").fetchone()[0]

def _cta_banco(c, eid, cuenta_id):
    """Cuenta contable de la cuenta bancaria (subcuenta de Bancos); fallback a cta_bancos del config."""
    row = c.execute("SELECT cuenta_contable FROM cuentas_bancarias WHERE id=? AND empresa_id=?", (cuenta_id, eid)).fetchone()
    cc = (row[0] if row else "") or ""
    if cc.strip():
        return cc.strip()
    return _cfg_contable(c, eid)["cta_bancos"]

def _saldo_banco(c, eid, cuenta_id):
    row = c.execute("SELECT saldo_inicial FROM cuentas_bancarias WHERE id=? AND empresa_id=?", (cuenta_id, eid)).fetchone()
    si = float((row[0] if row else 0) or 0)
    mv = c.execute("""SELECT COALESCE(SUM(ingreso),0), COALESCE(SUM(egreso),0)
        FROM movimientos_banco WHERE empresa_id=? AND cuenta_bancaria_id=? AND estado='ACTIVO'""", (eid, cuenta_id)).fetchone()
    return round(si + float(mv[0] or 0) - float(mv[1] or 0), 2)

# ════════════════════════════════════════════════════════════════
#  RETENCIONES — catálogo de códigos SRI Ecuador
# ════════════════════════════════════════════════════════════════
# (porcentajes referenciales; el usuario puede ajustar base y % por línea)
CODIGOS_RETENCION = [
    # RENTA
    {"tipo":"RENTA","codigo":"303","concepto":"Honorarios profesionales y dietas","porcentaje":10.0},
    {"tipo":"RENTA","codigo":"304","concepto":"Servicios donde predomina el intelecto","porcentaje":8.0},
    {"tipo":"RENTA","codigo":"307","concepto":"Servicios donde predomina la mano de obra","porcentaje":2.0},
    {"tipo":"RENTA","codigo":"308","concepto":"Servicios entre sociedades","porcentaje":2.0},
    {"tipo":"RENTA","codigo":"309","concepto":"Servicios de publicidad y comunicación","porcentaje":1.75},
    {"tipo":"RENTA","codigo":"310","concepto":"Transporte privado de pasajeros o carga","porcentaje":1.0},
    {"tipo":"RENTA","codigo":"312","concepto":"Transferencia de bienes muebles","porcentaje":1.75},
    {"tipo":"RENTA","codigo":"319","concepto":"Arrendamiento mercantil","porcentaje":1.0},
    {"tipo":"RENTA","codigo":"320","concepto":"Arrendamiento de bienes inmuebles","porcentaje":8.0},
    {"tipo":"RENTA","codigo":"322","concepto":"Seguros y reaseguros (10% del valor)","porcentaje":1.75},
    {"tipo":"RENTA","codigo":"332","concepto":"Otras retenciones aplicables 2,75%","porcentaje":2.75},
    {"tipo":"RENTA","codigo":"343","concepto":"Otras compras de bienes no sujetas a %","porcentaje":1.75},
    # IVA
    {"tipo":"IVA","codigo":"9","concepto":"Retención IVA 30% (bienes)","porcentaje":30.0},
    {"tipo":"IVA","codigo":"10","concepto":"Retención IVA 70% (servicios)","porcentaje":70.0},
    {"tipo":"IVA","codigo":"11","concepto":"Retención IVA 100% (honorarios, arriendos, liquidaciones)","porcentaje":100.0},
    {"tipo":"IVA","codigo":"8","concepto":"Retención IVA 20%","porcentaje":20.0},
    {"tipo":"IVA","codigo":"7","concepto":"Retención IVA 10%","porcentaje":10.0},
]

def _parse_extracto_pdf(pdf_bytes):
    """Extrae movimientos de un estado de cuenta en PDF (formato Banco Pichincha:
    Fecha | Concepto | Oficina | Documento | Tipo(C/D) | Monto | Codigo | Saldo).
    Devuelve (lista_movimientos, mensaje_error|None)."""
    try:
        import pdfplumber, io
    except Exception:
        return None, "Falta la librería 'pdfplumber' en el servidor. Reinstala con el instalador actualizado."
    import re
    movs = []
    pat = re.compile(r'^(\d{2}/\d{2}/\d{4})\s+(.*?)\s+([CD])\s+([\d.,]+)\s+(\d{3,7})\s+([\d.,]+)\s*$')
    def num(s):
        s = (s or "").replace(",", "")
        try: return float(s)
        except Exception: return 0.0
    def ofic(resto):
        m2 = re.match(r'^(.*?)\s+(AG\.?\s*[\w\.]+|MATRIZ|OF\.?\s*[\w\.]+|SUC\.?\s*[\w\.]+)\s+(\d+)\s*$', resto)
        if m2: return m2.group(1).strip(), m2.group(2).strip(), m2.group(3).strip()
        m3 = re.match(r'^(.*?)\s+(\d+)\s*$', resto)
        if m3: return m3.group(1).strip(), "", m3.group(2).strip()
        return resto.strip(), "", ""
    try:
        with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
            buffer = ""
            for page in pdf.pages:
                txt = page.extract_text() or ""
                for raw in txt.split("\n"):
                    line = raw.strip()
                    if not line: continue
                    # Ignorar encabezados/pies
                    low = line.lower()
                    if any(h in low for h in ["fecha concepto","detalle de movimientos","saldo anterior","banco pichincha","página","pagina","estado de cuenta"]):
                        continue
                    # Si la línea empieza con fecha, es un movimiento nuevo (posible multi-línea)
                    if re.match(r'^\d{2}/\d{2}/\d{4}\s', line):
                        if buffer: _try_add(buffer, movs, pat, num, ofic)
                        buffer = line
                    else:
                        # continuación del concepto de la línea anterior
                        if buffer: buffer += " " + line
            if buffer: _try_add(buffer, movs, pat, num, ofic)
        return movs, None
    except Exception as ex:
        log.warning("Error leyendo PDF de extracto: %s", ex)
        return None, "No se pudo leer el PDF: " + str(ex)

def _try_add(line, movs, pat, num, ofic):
    import re
    line = re.sub(r'\s+', ' ', line).strip()
    m = pat.match(line)
    if not m: return
    fecha, resto, tipo, monto, cod, saldo = m.groups()
    concepto, oficina, doc = ofic(resto)
    p = fecha.split("/")
    fecha_iso = f"{p[2]}-{p[1]}-{p[0]}" if len(p) == 3 else fecha
    val = num(monto)
    movs.append({
        "fecha": fecha_iso, "concepto": concepto, "oficina": oficina, "documento": doc,
        "tipo": tipo, "codigo": cod, "saldo": num(saldo),
        "ingreso": val if tipo == "C" else 0.0,
        "egreso": val if tipo == "D" else 0.0})


def _reporte_sri_xlsx(eid, tipo, anio, mes):
    import openpyxl, io
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    mes_z = str(mes).zfill(2) if mes else ""
    pref = f"{anio}-{mes_z}" if mes else str(anio)
    condv = "substr(f.fecha,1,7)=?" if mes else "substr(f.fecha,1,4)=?"
    condc = "substr(co.fecha,1,7)=?" if mes else "substr(co.fecha,1,4)=?"
    arg = pref if mes else anio
    c = db()
    emp = rd(c.execute("SELECT nombre,ruc FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
    wb = openpyxl.Workbook()
    hdr_fill = PatternFill("solid", fgColor="1F4E78"); hdr_font = Font(color="FFFFFF", bold=True, size=9)
    tot_fill = PatternFill("solid", fgColor="D9E1F2"); bold = Font(bold=True)
    thin = Side(style="thin", color="BBBBBB"); border = Border(left=thin,right=thin,top=thin,bottom=thin)

    def hoja_ventas(ws):
        ws.merge_cells(start_row=1,start_column=1,end_row=1,end_column=10)
        ws.cell(1,1,f"REPORTE DE VENTAS — {emp.get('nombre','')} (RUC {emp.get('ruc','')}) — Período {pref}").font=Font(bold=True,size=12)
        cols=["#","Fecha","Factura","RUC Cliente","Cliente","Base 0%","Base 15%","IVA","Total","Estado"]
        for j,h in enumerate(cols,1):
            cell=ws.cell(3,j,h); cell.fill=hdr_fill; cell.font=hdr_font; cell.border=border
            cell.alignment=Alignment(horizontal="center",wrap_text=True)
        rows=rl(c.execute(f"""SELECT f.numero,f.fecha,f.subtotal,f.iva,f.total,f.estado,
                cl.nombre AS cliente, cl.ruc_cedula AS ruc
                FROM facturas f LEFT JOIN clientes cl ON f.cliente_id=cl.id
                WHERE f.empresa_id=? AND {condv} ORDER BY f.fecha, f.id""",(eid,arg)).fetchall())
        r0=4; tb0=tb15=tiva=ttot=0
        for i,f in enumerate(rows,1):
            anul=str(f.get("estado","")).upper()=="ANULADA"
            iva=float(f.get("iva") or 0); sub=float(f.get("subtotal") or 0)
            b15=round(iva/0.15,2) if iva>0 else 0; b0=round(sub-b15,2); b0=b0 if b0>0 else 0
            vals=[i,f.get("fecha",""),f.get("numero",""),f.get("ruc",""),f.get("cliente",""),
                  b0,b15,round(iva,2),round(float(f.get("total") or 0),2),"ANULADA" if anul else "Vigente"]
            for j,v in enumerate(vals,1):
                cell=ws.cell(r0,j,v); cell.border=border
                if isinstance(v,(int,float)) and j>=6: cell.number_format='#,##0.00'
            if not anul: tb0+=b0;tb15+=b15;tiva+=iva;ttot+=float(f.get("total") or 0)
            r0+=1
        tv=["","","","","TOTALES",round(tb0,2),round(tb15,2),round(tiva,2),round(ttot,2),""]
        for j,v in enumerate(tv,1):
            cell=ws.cell(r0,j,v); cell.fill=tot_fill; cell.font=bold; cell.border=border
            if isinstance(v,(int,float)) and j>=6: cell.number_format='#,##0.00'
        for j,w in enumerate([5,12,20,15,34,13,13,12,13,11],1): ws.column_dimensions[openpyxl.utils.get_column_letter(j)].width=w
        ws.freeze_panes="A4"

    def hoja_compras(ws):
        ws.merge_cells(start_row=1,start_column=1,end_row=1,end_column=10)
        ws.cell(1,1,f"REPORTE DE COMPRAS — {emp.get('nombre','')} (RUC {emp.get('ruc','')}) — Período {pref}").font=Font(bold=True,size=12)
        cols=["#","Fecha","Comprobante","RUC Proveedor","Proveedor","Base 0%","Base 15%","IVA","Total","Estado"]
        for j,h in enumerate(cols,1):
            cell=ws.cell(3,j,h); cell.fill=hdr_fill; cell.font=hdr_font; cell.border=border
            cell.alignment=Alignment(horizontal="center",wrap_text=True)
        rows=rl(c.execute(f"""SELECT co.numero,co.fecha,co.subtotal,co.iva,co.total,co.estado,
                pr.nombre AS proveedor, pr.ruc_cedula AS ruc
                FROM compras co LEFT JOIN proveedores pr ON co.proveedor_id=pr.id
                WHERE co.empresa_id=? AND {condc} ORDER BY co.fecha, co.id""",(eid,arg)).fetchall())
        r0=4; tb0=tb15=tiva=ttot=0
        for i,co in enumerate(rows,1):
            anul=str(co.get("estado","")).upper()=="ANULADA"
            iva=float(co.get("iva") or 0); sub=float(co.get("subtotal") or 0)
            b15=round(iva/0.15,2) if iva>0 else 0; b0=round(sub-b15,2); b0=b0 if b0>0 else 0
            vals=[i,co.get("fecha",""),co.get("numero",""),co.get("ruc",""),co.get("proveedor",""),
                  b0,b15,round(iva,2),round(float(co.get("total") or 0),2),"ANULADA" if anul else "Vigente"]
            for j,v in enumerate(vals,1):
                cell=ws.cell(r0,j,v); cell.border=border
                if isinstance(v,(int,float)) and j>=6: cell.number_format='#,##0.00'
            if not anul: tb0+=b0;tb15+=b15;tiva+=iva;ttot+=float(co.get("total") or 0)
            r0+=1
        tv=["","","","","TOTALES",round(tb0,2),round(tb15,2),round(tiva,2),round(ttot,2),""]
        for j,v in enumerate(tv,1):
            cell=ws.cell(r0,j,v); cell.fill=tot_fill; cell.font=bold; cell.border=border
            if isinstance(v,(int,float)) and j>=6: cell.number_format='#,##0.00'
        for j,w in enumerate([5,12,20,15,34,13,13,12,13,11],1): ws.column_dimensions[openpyxl.utils.get_column_letter(j)].width=w
        ws.freeze_panes="A4"

    if tipo == "libro":
        ws1 = wb.active; ws1.title = "Ventas"; hoja_ventas(ws1)
        ws2 = wb.create_sheet("Compras"); hoja_compras(ws2)
        fname = f"Libro_Ventas_Compras_{pref}.xlsx"
    elif tipo == "compras":
        ws = wb.active; ws.title = "Compras"; hoja_compras(ws)
        fname = f"Reporte_compras_{pref}.xlsx"
    else:
        ws = wb.active; ws.title = "Ventas"; hoja_ventas(ws)
        fname = f"Reporte_ventas_{pref}.xlsx"
    c.close()
    buf=io.BytesIO(); wb.save(buf)
    return buf.getvalue(), fname

def _reporte_sri_xlsx_OLD(eid, tipo, anio, mes):
    import openpyxl, io
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    mes_z = str(mes).zfill(2) if mes else ""
    pref = f"{anio}-{mes_z}" if mes else str(anio)
    condv = "substr(f.fecha,1,7)=?" if mes else "substr(f.fecha,1,4)=?"
    condc = "substr(co.fecha,1,7)=?" if mes else "substr(co.fecha,1,4)=?"
    arg = pref if mes else anio
    c = db()
    emp = rd(c.execute("SELECT nombre,ruc FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
    wb = openpyxl.Workbook(); ws = wb.active
    hdr_fill = PatternFill("solid", fgColor="1F4E78"); hdr_font = Font(color="FFFFFF", bold=True, size=9)
    tot_fill = PatternFill("solid", fgColor="D9E1F2"); bold = Font(bold=True)
    thin = Side(style="thin", color="BBBBBB"); border = Border(left=thin,right=thin,top=thin,bottom=thin)
    def escribe_encabezado(titulo, cols):
        ws.merge_cells(start_row=1,start_column=1,end_row=1,end_column=len(cols))
        cc = ws.cell(1,1,f"{titulo} — {emp.get('nombre','')} (RUC {emp.get('ruc','')}) — Período {pref}")
        cc.font = Font(bold=True, size=12)
        for j,h in enumerate(cols,1):
            cell = ws.cell(3,j,h); cell.fill=hdr_fill; cell.font=hdr_font; cell.border=border
            cell.alignment = Alignment(horizontal="center", wrap_text=True)
    if tipo == "compras":
        rows = rl(c.execute(f"""SELECT co.numero, co.fecha, co.subtotal, co.iva, co.total, co.estado, co.tipo,
                pr.nombre AS proveedor, pr.ruc_cedula AS ruc
                FROM compras co LEFT JOIN proveedores pr ON co.proveedor_id=pr.id
                WHERE co.empresa_id=? AND {condc} ORDER BY co.fecha, co.id""", (eid, arg)).fetchall())
        cols = ["#","Fecha","Comprobante","RUC Proveedor","Proveedor","Base 0%","Base 15%","IVA","Total","Estado"]
        escribe_encabezado("REPORTE DE COMPRAS", cols)
        r0 = 4; tb0=tb15=tiva=ttot=0
        for i,co in enumerate(rows,1):
            anul = str(co.get("estado","")).upper()=="ANULADA"
            iva=float(co.get("iva") or 0); sub=float(co.get("subtotal") or 0)
            b15=round(iva/0.15,2) if iva>0 else 0; b0=round(sub-b15,2); b0=b0 if b0>0 else 0
            vals=[i, co.get("fecha",""), co.get("numero",""), co.get("ruc",""), co.get("proveedor",""),
                  round(b0,2), round(b15,2), round(iva,2), round(float(co.get("total") or 0),2),
                  "ANULADA" if anul else "Vigente"]
            for j,v in enumerate(vals,1):
                cell=ws.cell(r0,j,v); cell.border=border
                if isinstance(v,(int,float)) and j>=6: cell.number_format='#,##0.00'
            if not anul: tb0+=b0; tb15+=b15; tiva+=iva; ttot+=float(co.get("total") or 0)
            r0+=1
        tv=[ "","","","","TOTALES", round(tb0,2), round(tb15,2), round(tiva,2), round(ttot,2), "" ]
    else:
        rows = rl(c.execute(f"""SELECT f.numero, f.fecha, f.subtotal, f.iva, f.total, f.estado,
                cl.nombre AS cliente, cl.ruc_cedula AS ruc
                FROM facturas f LEFT JOIN clientes cl ON f.cliente_id=cl.id
                WHERE f.empresa_id=? AND {condv} ORDER BY f.fecha, f.id""", (eid, arg)).fetchall())
        cols = ["#","Fecha","Factura","RUC Cliente","Cliente","Base 0%","Base 15%","IVA","Total","Estado"]
        escribe_encabezado("REPORTE DE VENTAS", cols)
        r0=4; tb0=tb15=tiva=ttot=0
        for i,f in enumerate(rows,1):
            anul=str(f.get("estado","")).upper()=="ANULADA"
            iva=float(f.get("iva") or 0); sub=float(f.get("subtotal") or 0)
            b15=round(iva/0.15,2) if iva>0 else 0; b0=round(sub-b15,2); b0=b0 if b0>0 else 0
            vals=[i, f.get("fecha",""), f.get("numero",""), f.get("ruc",""), f.get("cliente",""),
                  b0, b15, round(iva,2), round(float(f.get("total") or 0),2), "ANULADA" if anul else "Vigente"]
            for j,v in enumerate(vals,1):
                cell=ws.cell(r0,j,v); cell.border=border
                if isinstance(v,(int,float)) and j>=6: cell.number_format='#,##0.00'
            if not anul: tb0+=b0; tb15+=b15; tiva+=iva; ttot+=float(f.get("total") or 0)
            r0+=1
        tv=[ "","","","","TOTALES", round(tb0,2), round(tb15,2), round(tiva,2), round(ttot,2), "" ]
    c.close()
    for j,v in enumerate(tv,1):
        cell=ws.cell(r0,j,v); cell.fill=tot_fill; cell.font=bold; cell.border=border
        if isinstance(v,(int,float)) and j>=6: cell.number_format='#,##0.00'
    anchos=[5,12,20,15,34,13,13,12,13,11]
    for j,w in enumerate(anchos,1): ws.column_dimensions[openpyxl.utils.get_column_letter(j)].width=w
    ws.freeze_panes="A4"
    buf=io.BytesIO(); wb.save(buf)
    fname=f"Reporte_{tipo}_{pref}.xlsx"
    return buf.getvalue(), fname

# ══════════════════════════════════════════════════════════════════════════
#  ANEXO TRANSACCIONAL SIMPLIFICADO (ATS) — SRI Ecuador
#  Esquema oficial: https://descargas.sri.gob.ec/download/anexos/ats/ats.xsd
#
#  REGLA CENTRAL (la que provocaba "TOTAL DE VENTAS ... sumatoria [0.00]"):
#    totalVentas = suma de baseNoGraIva + baseImponible + baseImpGrav
#                  de TODOS los <detalleVentas>.  SIN IVA.
#    El SRI NO usa <ventasEstablecimiento> para ese cuadre.
#
#  Por eso el consumidor final SÍ va dentro de <detalleVentas>, pero
#  CONSOLIDADO en un solo registro (tpIdCliente 07 / idCliente 9999999999999).
#  Si se mandan varios registros con la misma clave, el DIMM responde
#  "SE HAN DETECTADO REGISTROS DUPLICADOS DE VENTAS".
# ══════════════════════════════════════════════════════════════════════════

# Si algún día el DIMM rechazara el consumidor final en el detalle, poner en
# False: pasa a reportarse solo en <ventasEstablecimiento> y totalVentas baja.
ATS_CF_EN_DETALLE = True

_ATS_CF_ID = "9999999999999"


def _ats_txt(s, maxlen=300):
    """razonSocial y denoCli solo aceptan [A-Za-z0-9 ] en el XSD del SRI:
    sin tildes, sin Ñ, sin puntos, comas ni &.  'ZHUANGMONAR S.A.' -> 'ZHUANGMONAR SA'."""
    import unicodedata as _ud
    s = _ud.normalize("NFD", str(s or ""))
    s = "".join(ch for ch in s if _ud.category(ch) != "Mn")
    s = s.replace("&", " Y ").replace(".", "")
    s = re.sub(r"[^A-Za-z0-9 ]", " ", s)
    s = re.sub(r"\s+", " ", s).strip().upper()
    return s[:maxlen]


def _ats_fecha(f):
    """El ATS exige dd/mm/aaaa. En la base las fechas están en aaaa-mm-dd."""
    s = str(f or "").strip()[:10]
    if re.match(r"^\d{4}-\d{2}-\d{2}$", s):
        return s[8:10] + "/" + s[5:7] + "/" + s[0:4]
    return s


def _ats_n(v):
    """monedaType: siempre dos decimales."""
    try:
        return "%.2f" % round(float(v or 0), 2)
    except Exception:
        return "0.00"


def _ats_split(num):
    """'001-002-000000123' -> ('001','002','000000123')"""
    p = str(num or "").split("-")
    if len(p) == 3:
        return p[0].zfill(3)[-3:], p[1].zfill(3)[-3:], p[2].zfill(9)[-9:]
    d = re.sub(r"\D", "", str(num or ""))
    if len(d) >= 15:
        return d[:3], d[3:6], d[6:15]
    return "001", "001", d.zfill(9)[-9:]


def _ats_tid_venta(ident):
    """Tabla 2 del ATS para ventas: 04 RUC, 05 cédula, 06 pasaporte,
    07 consumidor final."""
    i = re.sub(r"\D", "", str(ident or ""))
    if not i or i == _ATS_CF_ID:
        return "07", _ATS_CF_ID
    if len(i) == 13:
        return "04", i
    if len(i) == 10:
        return "05", i
    return "06", (str(ident or "").strip() or _ATS_CF_ID)


def _ats_ced_ok(ident):
    """Dígito verificador de cédula ecuatoriana. El DIMM lo valida en las
    ventas con tipo de identificación 05 y rechaza el registro completo."""
    i = re.sub(r"\D", "", str(ident or ""))
    if len(i) != 10:
        return False
    prov = int(i[:2])
    if prov < 1 or (prov > 24 and prov != 30):
        return False
    if int(i[2]) > 5:
        return False
    s = 0
    for k, ch in enumerate(i[:9]):
        d = int(ch) * (2 if k % 2 == 0 else 1)
        if d > 9:
            d -= 9
        s += d
    return (10 - (s % 10)) % 10 == int(i[9])


def _ats_datos(eid, anio, mes):
    """Lee de la base todo lo que necesita el anexo del período."""
    mes = str(mes).zfill(2)
    pref = str(anio) + "-" + mes
    c = db()
    emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
    compras = rl(c.execute("""SELECT co.*, pr.nombre AS prov_nombre, pr.ruc_cedula AS prov_ruc
        FROM compras co LEFT JOIN proveedores pr ON co.proveedor_id=pr.id
        WHERE co.empresa_id=? AND substr(co.fecha,1,7)=? AND IFNULL(co.estado,'')!='ANULADA'
        ORDER BY co.fecha, co.id""", (eid, pref)).fetchall())
    rets = rl(c.execute("""SELECT r.compra_id, r.numero AS ret_numero, r.fecha AS ret_fecha,
               r.autorizacion AS ret_aut, r.clave_acceso AS ret_clave,
               d.tipo_impuesto, d.codigo, d.base_imponible, d.porcentaje, d.valor_retenido
        FROM retenciones r JOIN retencion_detalle d ON d.retencion_id=r.id
        WHERE r.empresa_id=? AND substr(r.fecha,1,7)=? AND IFNULL(r.estado,'')!='ANULADA'
        ORDER BY r.id""", (eid, pref)).fetchall())
    ventas = rl(c.execute("""SELECT f.*, cl.nombre AS cli_nombre, cl.ruc_cedula AS cli_ruc
        FROM facturas f LEFT JOIN clientes cl ON f.cliente_id=cl.id
        WHERE f.empresa_id=? AND substr(f.fecha,1,7)=? AND IFNULL(f.estado,'')!='ANULADA'
        ORDER BY f.fecha, f.id""", (eid, pref)).fetchall())
    anulados = rl(c.execute("""SELECT f.numero, f.autorizacion, f.clave_acceso
        FROM facturas f WHERE f.empresa_id=? AND substr(f.fecha,1,7)=? AND f.estado='ANULADA'
        ORDER BY f.id""", (eid, pref)).fetchall())
    c.close()

    # retenciones separadas por impuesto y agrupadas por compra
    ret_renta = {}
    ret_iva = {}
    ret_doc = {}
    for r in rets:
        cid = r.get("compra_id") or 0
        tipo = str(r.get("tipo_impuesto") or "RENTA").upper()
        if tipo.startswith("I"):
            ret_iva.setdefault(cid, []).append(r)
        else:
            ret_renta.setdefault(cid, []).append(r)
        if cid and cid not in ret_doc:
            ret_doc[cid] = r
    return {"emp": emp, "compras": compras, "ventas": ventas, "anulados": anulados,
            "ret_renta": ret_renta, "ret_iva": ret_iva, "ret_doc": ret_doc,
            "anio": str(anio), "mes": mes}


def _ats_agrupar_ventas(ventas):
    """Consolida las ventas en registros de detalleVentas.
    Clave: tipo de identificación + identificación + tipo de comprobante.
    Un solo registro por clave (el DIMM rechaza los repetidos)."""
    grupos = {}
    for v in ventas:
        tid, ident = _ats_tid_venta(v.get("cli_ruc"))
        if tid == "07" and not ATS_CF_EN_DETALLE:
            continue
        k = (tid, ident, "18")
        g = grupos.get(k)
        if g is None:
            g = {"tid": tid, "id": ident, "tipoComp": "18",
                 "nombre": _ats_txt(v.get("cli_nombre") or "CONSUMIDOR FINAL"),
                 "n": 0, "base0": 0.0, "baseGrav": 0.0, "baseNoObj": 0.0,
                 "iva": 0.0, "retIva": 0.0, "retRenta": 0.0, "formas": []}
            grupos[k] = g
        sub = float(v.get("subtotal") or 0)
        iva = float(v.get("iva") or 0)
        g["n"] += 1
        g["iva"] += iva
        # el reparto lo decide el IVA real de la factura, no el tipo de cliente
        if iva > 0.005:
            g["baseGrav"] += sub
        else:
            g["base0"] += sub
        if "01" not in g["formas"]:
            g["formas"].append("01")
    return list(grupos.values())


def _ats_establecimientos(ventas, emp):
    """Ventas por establecimiento, tomadas del número de cada factura.
    La suma tiene que dar igual que totalVentas."""
    est = {}
    for v in ventas:
        e, _p, _s = _ats_split(v.get("numero"))
        est[e] = est.get(e, 0.0) + float(v.get("subtotal") or 0)
    if not est:
        est[str(emp.get("estab") or "001").zfill(3)] = 0.0
    return est


def _ats_xml(eid, anio, mes):
    """Genera el ATS en XML según el XSD oficial del SRI."""
    d = _ats_datos(eid, anio, mes)
    emp = d["emp"]; anio = d["anio"]; mes = d["mes"]
    ruc_inf = re.sub(r"\D", "", str(emp.get("ruc") or ""))
    razon = _ats_txt(emp.get("nombre"), 500) or "SIN RAZON SOCIAL"

    grupos = _ats_agrupar_ventas(d["ventas"])
    total_ventas = round(sum(g["baseNoObj"] + g["base0"] + g["baseGrav"] for g in grupos), 2)
    est = _ats_establecimientos(d["ventas"], emp)

    X = ['<?xml version="1.0" encoding="ISO-8859-1"?>', '<iva>',
         '<TipoIDInformante>R</TipoIDInformante>',
         '<IdInformante>' + ruc_inf + '</IdInformante>',
         '<razonSocial>' + razon + '</razonSocial>',
         '<Anio>' + str(anio) + '</Anio>',
         '<Mes>' + mes + '</Mes>',
         '<numEstabRuc>' + str(max(1, len(est))).zfill(3) + '</numEstabRuc>',
         '<totalVentas>' + _ats_n(total_ventas) + '</totalVentas>',
         '<codigoOperativo>IVA</codigoOperativo>']

    # ─────────────────────────── COMPRAS ───────────────────────────
    if d["compras"]:
        X.append('<compras>')
    for co in d["compras"]:
        cid = co.get("id")
        ruc = re.sub(r"\D", "", str(co.get("prov_ruc") or ""))
        tp = "01" if len(ruc) == 13 else ("02" if len(ruc) == 10 else "03")
        e, p, s = _ats_split(co.get("numero"))
        sub = round(float(co.get("subtotal") or 0), 2)
        iva = round(float(co.get("iva") or 0), 2)
        baseGrav = sub if iva > 0.005 else 0.0
        base0 = 0.0 if iva > 0.005 else sub

        # retenciones de IVA repartidas según el porcentaje retenido
        riva = {"10": 0.0, "20": 0.0, "30": 0.0, "50": 0.0, "70": 0.0, "100": 0.0}
        for r in d["ret_iva"].get(cid, []):
            pct = round(float(r.get("porcentaje") or 0), 2)
            val = round(float(r.get("valor_retenido") or 0), 2)
            k = "100" if pct >= 99 else ("70" if pct >= 65 else ("50" if pct >= 45
                else ("30" if pct >= 25 else ("20" if pct >= 15 else "10"))))
            riva[k] += val

        X += ['<detalleCompras>',
              '<codSustento>' + str(co.get("sustento") or "01").zfill(2) + '</codSustento>',
              '<tpIdProv>' + tp + '</tpIdProv>',
              '<idProv>' + (ruc or "9999999999999") + '</idProv>',
              '<tipoComprobante>01</tipoComprobante>',
              '<parteRel>NO</parteRel>',
              '<fechaRegistro>' + _ats_fecha(co.get("fecha_registro") or co.get("fecha")) + '</fechaRegistro>',
              '<establecimiento>' + e + '</establecimiento>',
              '<puntoEmision>' + p + '</puntoEmision>',
              '<secuencial>' + s + '</secuencial>',
              '<fechaEmision>' + _ats_fecha(co.get("fecha")) + '</fechaEmision>',
              '<autorizacion>' + re.sub(r"\D", "", str(co.get("numero_autorizacion") or "")) + '</autorizacion>',
              '<baseNoGraIva>0.00</baseNoGraIva>',
              '<baseImponible>' + _ats_n(base0) + '</baseImponible>',
              '<baseImpGrav>' + _ats_n(baseGrav) + '</baseImpGrav>',
              '<baseImpExe>0.00</baseImpExe>',
              '<montoIce>0.00</montoIce>',
              '<montoIva>' + _ats_n(iva) + '</montoIva>',
              '<valRetBien10>' + _ats_n(riva["10"]) + '</valRetBien10>',
              '<valRetServ20>' + _ats_n(riva["20"]) + '</valRetServ20>',
              '<valorRetBienes>' + _ats_n(riva["30"]) + '</valorRetBienes>',
              '<valRetServ50>' + _ats_n(riva["50"]) + '</valRetServ50>',
              '<valorRetServicios>' + _ats_n(riva["70"]) + '</valorRetServicios>',
              '<valRetServ100>' + _ats_n(riva["100"]) + '</valRetServ100>',
              '<valorRetencionNc>0.00</valorRetencionNc>',
              '<totbasesImpReemb>0.00</totbasesImpReemb>',
              '<pagoExterior>', '<pagoLocExt>01</pagoLocExt>',
              '<aplicConvDobTrib>NA</aplicConvDobTrib>',
              '<pagExtSujRetNorLeg>NA</pagExtSujRetNorLeg>', '</pagoExterior>',
              '<formasDePago>',
              '<formaPago>' + str(co.get("forma_pago") or "01").zfill(2) + '</formaPago>',
              '</formasDePago>']

        # retenciones en la fuente de renta
        rr = d["ret_renta"].get(cid, [])
        X.append('<air>')
        if rr:
            for r in rr:
                X += ['<detalleAir>',
                      '<codRetAir>' + str(r.get("codigo") or "332") + '</codRetAir>',
                      '<baseImpAir>' + _ats_n(r.get("base_imponible") or sub) + '</baseImpAir>',
                      '<porcentajeAir>' + _ats_n(r.get("porcentaje")) + '</porcentajeAir>',
                      '<valRetAir>' + _ats_n(r.get("valor_retenido")) + '</valRetAir>',
                      '</detalleAir>']
        else:
            # compra sin retención: el ATS la reporta con el concepto 332 al 0%
            X += ['<detalleAir>', '<codRetAir>332</codRetAir>',
                  '<baseImpAir>' + _ats_n(sub) + '</baseImpAir>',
                  '<porcentajeAir>0.00</porcentajeAir>',
                  '<valRetAir>0.00</valRetAir>', '</detalleAir>']
        X.append('</air>')

        # datos del comprobante de retención emitido
        doc = d["ret_doc"].get(cid)
        if doc:
            re_, rp, rs = _ats_split(doc.get("ret_numero"))
            aut = re.sub(r"\D", "", str(doc.get("ret_aut") or doc.get("ret_clave") or ""))
            if len(aut) >= 3:
                X += ['<estabRetencion1>' + re_ + '</estabRetencion1>',
                      '<ptoEmiRetencion1>' + rp + '</ptoEmiRetencion1>',
                      '<secRetencion1>' + rs + '</secRetencion1>',
                      '<autRetencion1>' + aut + '</autRetencion1>',
                      '<fechaEmiRet1>' + _ats_fecha(doc.get("ret_fecha")) + '</fechaEmiRet1>']
        X.append('</detalleCompras>')
    if d["compras"]:
        X.append('</compras>')

    # ─────────────────────────── VENTAS ────────────────────────────
    if grupos:
        X.append('<ventas>')
        for g in grupos:
            X += ['<detalleVentas>',
                  '<tpIdCliente>' + g["tid"] + '</tpIdCliente>',
                  '<idCliente>' + g["id"] + '</idCliente>',
                  '<parteRelVtas>NO</parteRelVtas>']
            # El DIMM rechaza <denoCli> cuando el tipo de identificación es
            # 04 (RUC) o 05 (cédula): "No debe indicar la razón o denominación
            # social del cliente". Solo se informa en 06 (pasaporte/exterior).
            if g["tid"] == "06" and g["nombre"]:
                X.append('<denoCli>' + g["nombre"] + '</denoCli>')
            X += ['<tipoComprobante>' + g["tipoComp"] + '</tipoComprobante>',
                  '<tipoEmision>E</tipoEmision>',
                  '<numeroComprobantes>' + str(g["n"]) + '</numeroComprobantes>',
                  '<baseNoGraIva>' + _ats_n(g["baseNoObj"]) + '</baseNoGraIva>',
                  '<baseImponible>' + _ats_n(g["base0"]) + '</baseImponible>',
                  '<baseImpGrav>' + _ats_n(g["baseGrav"]) + '</baseImpGrav>',
                  '<montoIva>' + _ats_n(g["iva"]) + '</montoIva>',
                  '<montoIce>0.00</montoIce>',
                  '<valorRetIva>' + _ats_n(g["retIva"]) + '</valorRetIva>',
                  '<valorRetRenta>' + _ats_n(g["retRenta"]) + '</valorRetRenta>',
                  '<formasDePago>']
            for f in (g["formas"] or ["01"]):
                X.append('<formaPago>' + f + '</formaPago>')
            X += ['</formasDePago>', '</detalleVentas>']
        X.append('</ventas>')

    # ──────────────── VENTAS POR ESTABLECIMIENTO ───────────────────
    X.append('<ventasEstablecimiento>')
    claves = sorted(est.keys())
    acum = 0.0
    for i, cod in enumerate(claves):
        # el último absorbe el centavo de redondeo para que cuadre exacto
        if i == len(claves) - 1:
            val = round(total_ventas - acum, 2)
        else:
            val = round(est[cod], 2); acum += val
        X += ['<ventaEst>', '<codEstab>' + cod + '</codEstab>',
              '<ventasEstab>' + _ats_n(val) + '</ventasEstab>',
              '<ivaComp>0.00</ivaComp>', '</ventaEst>']
    X.append('</ventasEstablecimiento>')

    # ────────────────────────── ANULADOS ───────────────────────────
    if d["anulados"]:
        X.append('<anulados>')
        for a in d["anulados"]:
            e, p, s = _ats_split(a.get("numero"))
            aut = re.sub(r"\D", "", str(a.get("autorizacion") or a.get("clave_acceso") or ""))
            X += ['<detalleAnulados>', '<tipoComprobante>18</tipoComprobante>',
                  '<establecimiento>' + e + '</establecimiento>',
                  '<puntoEmision>' + p + '</puntoEmision>',
                  '<secuencialInicio>' + s + '</secuencialInicio>',
                  '<secuencialFin>' + s + '</secuencialFin>',
                  '<autorizacion>' + (aut if len(aut) >= 3 else "000") + '</autorizacion>',
                  '</detalleAnulados>']
        X.append('</anulados>')

    X.append('</iva>')
    return "\n".join(X), "AT" + mes + str(anio) + ".xml"


def _ats_xml_bytes(eid, anio, mes):
    """El SRI espera el anexo en ISO-8859-1, no en UTF-8."""
    xml, fname = _ats_xml(eid, anio, mes)
    return xml.encode("ISO-8859-1", errors="replace"), fname


def _ats_zip(eid, anio, mes):
    """Arma el ATmmaaaa.zip listo para subir al portal SRI en Línea."""
    import zipfile, io
    data, fname = _ats_xml_bytes(eid, anio, mes)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(fname, data)
    buf.seek(0)
    return buf.getvalue(), fname.replace(".xml", ".zip")


def _ats_validar(eid, anio, mes):
    """Corre las mismas comprobaciones que hace el DIMM antes de subir."""
    d = _ats_datos(eid, anio, mes)
    emp = d["emp"]
    problemas = []; avisos = []

    ruc = re.sub(r"\D", "", str(emp.get("ruc") or ""))
    if not re.match(r"^[0-9]{10}001$", ruc):
        problemas.append("El RUC de la empresa (" + (ruc or "vacío") +
                         ") no cumple el formato que exige el anexo (13 dígitos terminados en 001).")
    if len(_ats_txt(emp.get("nombre"), 500)) < 5:
        problemas.append("La razón social queda con menos de 5 caracteres después de limpiarla.")

    grupos = _ats_agrupar_ventas(d["ventas"])
    total = round(sum(g["baseNoObj"] + g["base0"] + g["baseGrav"] for g in grupos), 2)
    if d["ventas"] and total <= 0:
        problemas.append("Hay " + str(len(d["ventas"])) + " ventas en el período pero la sumatoria "
                         "de bases da 0.00: revise que las facturas tengan subtotal.")
    claves = {}
    for g in grupos:
        k = (g["tid"], g["id"], g["tipoComp"])
        claves[k] = claves.get(k, 0) + 1
    for k, n in claves.items():
        if n > 1:
            problemas.append("Registros de venta duplicados para el cliente " + k[1] +
                             " con comprobante tipo " + k[2] + ".")

    malas = [g for g in grupos if g["tid"] == "05" and not _ats_ced_ok(g["id"])]
    for g in malas:
        problemas.append("La cédula " + g["id"] + " (" + (g["nombre"] or "sin nombre") +
                         ") no pasa el dígito verificador; el DIMM descarta esa venta y "
                         "la sumatoria se descuadra. Corrija el cliente en el módulo Clientes.")

    sin_aut = [co.get("numero") for co in d["compras"]
               if len(re.sub(r"\D", "", str(co.get("numero_autorizacion") or ""))) < 3]
    if sin_aut:
        problemas.append(str(len(sin_aut)) + " compras sin número de autorización "
                         "(ej.: " + str(sin_aut[0]) + "). El anexo lo exige.")
    sin_ruc = [co.get("numero") for co in d["compras"]
               if len(re.sub(r"\D", "", str(co.get("prov_ruc") or ""))) not in (10, 13)]
    if sin_ruc:
        problemas.append(str(len(sin_ruc)) + " compras cuyo proveedor no tiene RUC ni cédula válidos "
                         "(ej.: " + str(sin_ruc[0]) + ").")

    cf = [g for g in grupos if g["tid"] == "07"]
    if cf:
        avisos.append("Consumidor final consolidado en 1 registro con " + str(cf[0]["n"]) +
                      " comprobantes por " + _ats_n(cf[0]["base0"] + cf[0]["baseGrav"]) + ".")
    if not d["compras"]:
        avisos.append("No hay compras registradas en el período.")

    return {"ok": not problemas, "total_ventas": _ats_n(total),
            "registros_ventas": len(grupos), "registros_compras": len(d["compras"]),
            "anulados": len(d["anulados"]), "problemas": problemas, "avisos": avisos}


def _ats_xlsx(eid: int, anio: str, mes: str):
    """Genera el ATS en Excel con el formato de la plantilla del SRI (la que
    lee el programador/macro de Excel). Todas las hojas se llenan, incluida
    'Ventas Establecimiento', que antes quedaba vacía y hacía que la
    sumatoria de ventas saliera en 0.00 al exportar."""
    import openpyxl, io
    from openpyxl.styles import Font, PatternFill
    d = _ats_datos(eid, anio, mes)
    emp = d["emp"]; anio = d["anio"]; mes = d["mes"]

    HDRS = {
        "Informante": ["Identificacion Informante","Razón Social","Año","Mes","Numero Establecimientos","Total Ventas"],
        "Compras Detalladas": ["Código de compra","Código de Sustento","Tipo Identificación del Proveedor","Número de Identificación del Proveedor","Código del Tipo de Comprobante","Tipo de Proveedor","Razón o denominación social del proveedor","Parte Relacionada?","Fecha Registro","Establecimiento","Punto Emisión","Secuencial","Fecha Emisión","Número de autorización","Base Imponible no objeto de IVA","Base Imponible tarifa 0% de IVA","Base Imponible gravada","Base Excenta","Monto ICE","Monto IVA","Retencion Bienes 10%","Retencion Servicios 20 %","Retención de IVA 30% bienes","Retención IVA 50%","Retención de IVA 70% servicios","100% Retención de IVA","Total Bases Imponibles","Pago Local o al Exterior"],
        "Compras Formas Pago": ["Código de compra","Forma de Pago"],
        "Compras Retenciones": ["Código de compra","Código de retención","Base imponible","Porcentaje de retención","Valor retenido"],
        "Compras Reembolsos": ["Información de reembolsos (código documento 41)"],
        "Ventas Cliente": ["Codigo Venta","Tipo de Identificación del Cliente","No. de Identificación del Cliente","Es parte relacionada","Tipo de Cliente","Razón o denominación social del cliente","Código tipo de comprobante","Tipo de Emisión","No. de Comprobantes Emitidos","Base Imponible No objeto de IVA","Base Imponible tarifa 0% IVA","Base Imponible tarifa IVA diferente de 0%","Monto IVA","Monto ICE","Valor de IVA que le han retenido","Valor de Renta que le han retenido"],
        "Compensaciones Ventas": ["Código Módulo","Tipo de compensacion","Monto compensado"],
        "Formas de Cobro": ["Código Venta","Forma de Pago"],
        "Ventas Establecimiento": ["Código del Establecimiento","Ventas por establecimiento","ivaComp"],
        "Anulados": ["Código tipo de Comprobante anulado","Establecimiento","Punto Emisión","Secuencial Inicio","Secuencial Fin","Autorización"],
    }

    grupos = _ats_agrupar_ventas(d["ventas"])
    total_ventas = round(sum(g["baseNoObj"] + g["base0"] + g["baseGrav"] for g in grupos), 2)
    est = _ats_establecimientos(d["ventas"], emp)

    data = {}
    data["Informante"] = [[re.sub(r"\D", "", str(emp.get("ruc") or "")),
                           _ats_txt(emp.get("nombre"), 500), str(anio), mes,
                           str(max(1, len(est))).zfill(3), total_ventas]]

    cd = []; cfp = []; cr = []
    for i, co in enumerate(d["compras"], 1):
        cod = "C" + str(i)
        ruc = re.sub(r"\D", "", str(co.get("prov_ruc") or ""))
        tid = "01" if len(ruc) == 13 else ("02" if len(ruc) == 10 else "03")
        e, p, s = _ats_split(co.get("numero"))
        sub = round(float(co.get("subtotal") or 0), 2)
        ivav = round(float(co.get("iva") or 0), 2)
        baseGrav = sub if ivav > 0.005 else 0.0
        base0 = 0.0 if ivav > 0.005 else sub
        riva = {"10": 0.0, "20": 0.0, "30": 0.0, "50": 0.0, "70": 0.0, "100": 0.0}
        for r in d["ret_iva"].get(co.get("id"), []):
            pct = round(float(r.get("porcentaje") or 0), 2)
            k = "100" if pct >= 99 else ("70" if pct >= 65 else ("50" if pct >= 45
                else ("30" if pct >= 25 else ("20" if pct >= 15 else "10"))))
            riva[k] += round(float(r.get("valor_retenido") or 0), 2)
        cd.append([cod, str(co.get("sustento") or "01").zfill(2), tid, ruc, "01", "01",
                   _ats_txt(co.get("prov_nombre")), "NO",
                   _ats_fecha(co.get("fecha_registro") or co.get("fecha")), e, p, s,
                   _ats_fecha(co.get("fecha")),
                   re.sub(r"\D", "", str(co.get("numero_autorizacion") or "")),
                   0, base0, baseGrav, 0, 0, ivav,
                   riva["10"], riva["20"], riva["30"], riva["50"], riva["70"], riva["100"],
                   sub, "01"])
        cfp.append([cod, str(co.get("forma_pago") or "01").zfill(2)])
        rr = d["ret_renta"].get(co.get("id"), [])
        if rr:
            for r in rr:
                cr.append([cod, str(r.get("codigo") or "332"),
                           round(float(r.get("base_imponible") or sub), 2),
                           round(float(r.get("porcentaje") or 0), 2),
                           round(float(r.get("valor_retenido") or 0), 2)])
        else:
            cr.append([cod, "332", sub, 0, 0])
    data["Compras Detalladas"] = cd
    data["Compras Formas Pago"] = cfp
    data["Compras Retenciones"] = cr
    data["Compras Reembolsos"] = []

    vc = []; fco = []
    for i, g in enumerate(grupos, 1):
        cod = "V" + str(i)
        vc.append([cod, g["tid"], g["id"], "NO", "01",
                   (g["nombre"] if g["tid"] == "06" else ""),
                   g["tipoComp"], "E", g["n"],
                   round(g["baseNoObj"], 2), round(g["base0"], 2), round(g["baseGrav"], 2),
                   round(g["iva"], 2), 0, round(g["retIva"], 2), round(g["retRenta"], 2)])
        for f in (g["formas"] or ["01"]):
            fco.append([cod, f])
    data["Ventas Cliente"] = vc
    data["Formas de Cobro"] = fco
    data["Compensaciones Ventas"] = []

    # ── ESTA es la hoja que quedaba vacía y descuadraba el programador ──
    ve = []
    claves = sorted(est.keys()); acum = 0.0
    for i, cod in enumerate(claves):
        if i == len(claves) - 1:
            val = round(total_ventas - acum, 2)
        else:
            val = round(est[cod], 2); acum += val
        ve.append([cod, val, 0])
    data["Ventas Establecimiento"] = ve

    an = []
    for f in d["anulados"]:
        e, p, s = _ats_split(f.get("numero"))
        an.append(["18", e, p, s, s,
                   re.sub(r"\D", "", str(f.get("autorizacion") or f.get("clave_acceso") or ""))])
    data["Anulados"] = an

    start_rows = {"Informante": 2, "Compras Detalladas": 3, "Compras Retenciones": 2,
                  "Ventas Cliente": 2, "Anulados": 2, "Compras Formas Pago": 2,
                  "Compras Reembolsos": 2, "Compensaciones Ventas": 2,
                  "Formas de Cobro": 2, "Ventas Establecimiento": 2}

    # La plantilla del SRI con el programador es .xlsm: hay que abrirla con
    # keep_vba, si no las macros se pierden al guardar y no deja exportar.
    tpl = None; con_macros = False
    for nombre_tpl in ("Plantilla_ATS.xlsm", "plantilla_ats.xlsm", "Plantilla_ATS.xlsx",
                       "plantilla_ats.xlsx", "Plantilla_ATS_verza20235.xlsx"):
        p = BASE_DIR / nombre_tpl
        if p.exists():
            tpl = p; con_macros = p.suffix.lower() in (".xlsm", ".xltm"); break
    if tpl:
        wb = openpyxl.load_workbook(tpl, keep_vba=con_macros)
        for name in wb.sheetnames:
            ws = wb[name]; start = start_rows.get(name, 2)
            if ws.max_row >= start:
                try: ws.delete_rows(start, ws.max_row - start + 1)
                except Exception: pass
            for row in data.get(name, []):
                ws.append(row)
    else:
        wb = openpyxl.Workbook()
        hf = Font(bold=True, color="FFFFFF", size=10); hfill = PatternFill("solid", fgColor="1a56db")
        first = True
        for name, hdrs in HDRS.items():
            ws = wb.active if first else wb.create_sheet(name)
            if first: ws.title = name; first = False
            for j, h in enumerate(hdrs, 1):
                cell = ws.cell(1, j, h); cell.font = hf; cell.fill = hfill
                ws.column_dimensions[openpyxl.utils.get_column_letter(j)].width = max(12, min(40, len(h) + 2))
            for row in data.get(name, []):
                ws.append(row)

    buf = io.BytesIO(); wb.save(buf); buf.seek(0)
    ext = "xlsm" if con_macros else "xlsx"
    return buf, "ATS_" + re.sub(r"\D", "", str(emp.get("ruc") or "")) + "_" + str(anio) + "_" + mes + "." + ext

def _bodega_principal(c, eid):
    b = c.execute("SELECT id FROM bodegas WHERE empresa_id=? AND principal=1 ORDER BY id LIMIT 1", (eid,)).fetchone()
    if b: return b[0]
    b = c.execute("SELECT id FROM bodegas WHERE empresa_id=? ORDER BY id LIMIT 1", (eid,)).fetchone()
    if b: return b[0]
    c.execute("INSERT INTO bodegas (empresa_id,nombre,codigo,principal,estado,created_at) VALUES (?,?,?,?,?,?)",
              (eid, "Principal", "PRIN", 1, "ACTIVO", now_ec()))
    return c.execute("SELECT last_insert_rowid()").fetchone()[0]

def _stock_bodega_mov(c, eid, pid, bid, delta):
    if not bid: return
    row = c.execute("SELECT id FROM stock_bodega WHERE producto_id=? AND bodega_id=?", (pid, bid)).fetchone()
    if row:
        c.execute("UPDATE stock_bodega SET cantidad=cantidad+? WHERE producto_id=? AND bodega_id=?", (delta, pid, bid))
    else:
        c.execute("INSERT INTO stock_bodega (empresa_id,producto_id,bodega_id,cantidad) VALUES (?,?,?,?)", (eid, pid, bid, delta))

def _cxc_add_factura(c, eid, cli_id, fid, numero, total, fecha, uid):
    """Inserta el movimiento de cartera (cuentas por cobrar) de una factura a crédito,
    manteniendo el saldo acumulado por cliente."""
    last = c.execute("SELECT saldo FROM cuentas_cobrar WHERE empresa_id=? AND cliente_id=? ORDER BY id DESC LIMIT 1",
                     (eid, cli_id)).fetchone()
    saldo_ant = float(last[0]) if last else 0.0
    nuevo = round(saldo_ant + float(total), 2)
    c.execute("""INSERT INTO cuentas_cobrar (empresa_id,cliente_id,factura_id,tipo,concepto,monto,saldo,fecha,usuario_id,estado,referencia,created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        (eid, cli_id, fid, "FACTURA", "Factura " + str(numero), float(total), nuevo, fecha, uid, "PENDIENTE", str(numero), now_ec()))

# ════════════════════════════════════════════════════════════
# SUCURSALES
# Una sucursal amarra tres cosas: su establecimiento del SRI
# (001, 002…), su bodega y su punto de emisión. Con eso, cuando
# entra un usuario el sistema ya sabe con qué numerar, de qué
# bodega descontar el stock y qué puede ver.
# Todo esto solo actúa si la empresa activó "usa_sucursales";
# si no, el sistema se comporta exactamente como antes.
# ════════════════════════════════════════════════════════════

def _suc_activas(emp) -> bool:
    try:
        return int((emp or {}).get("usa_sucursales", 0) or 0) == 1
    except Exception:
        return False


def _suc_emp(c, eid):
    try:
        return rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
    except Exception:
        return {}


def _suc_del_usuario(c, eid, sess):
    """Sucursal a la que pertenece quien está usando el sistema.

    Devuelve None si la empresa no trabaja por sucursales, si el
    usuario es administrador sin sucursal asignada (ve todo), o si
    todavía no se le asignó ninguna.
    """
    emp = _suc_emp(c, eid)
    if not _suc_activas(emp):
        return None
    try:
        u = rd(c.execute("SELECT sucursal_id, rol FROM usuarios WHERE id=?",
                         (sess.get("usuario_id"),)).fetchone()) or {}
        sid = int(u.get("sucursal_id") or 0)
        if not sid:
            return None
        s = rd(c.execute("SELECT * FROM sucursales WHERE id=? AND empresa_id=?", (sid, eid)).fetchone())
        return s or None
    except Exception:
        return None


def _suc_ve_todo(c, eid, sess):
    """True si este usuario ve la información de todas las sucursales."""
    return _suc_del_usuario(c, eid, sess) is None


def _suc_bodega(c, eid, sess):
    """Bodega de la que se descuenta el stock para este usuario."""
    s = _suc_del_usuario(c, eid, sess)
    if s and int(s.get("bodega_id") or 0):
        try:
            b = c.execute("SELECT id FROM bodegas WHERE id=? AND empresa_id=?",
                          (int(s["bodega_id"]), eid)).fetchone()
            if b:
                return b[0]
        except Exception:
            pass
    return _bodega_principal(c, eid)


def _suc_por_codigo(c, eid, estab, pto):
    """Sucursal que corresponde a un establecimiento y punto dados.

    Sirve para marcar el comprobante del administrador, que no está
    atado a ninguna sucursal pero igual factura con un establecimiento.
    """
    try:
        s = c.execute("""SELECT id FROM sucursales WHERE empresa_id=? AND codigo=? AND pto_emi=?""",
                      (eid, str(estab).zfill(3), str(pto).zfill(3))).fetchone()
        if s:
            return int(s[0])
        s = c.execute("SELECT id FROM sucursales WHERE empresa_id=? AND codigo=? ORDER BY id LIMIT 1",
                      (eid, str(estab).zfill(3))).fetchone()
        return int(s[0]) if s else 0
    except Exception:
        return 0


def _suc_de_numero(c, eid, numero, clave=""):
    """Sucursal que corresponde a un comprobante, leída de su número.

    El número trae el establecimiento y el punto: 001-002-000000123 →
    establecimiento 001, punto 002. Si el número viniera incompleto se
    usa la clave de acceso, que lleva los mismos datos en las
    posiciones 24 a 30. Devuelve 0 si no hay una sucursal con ese
    establecimiento.
    """
    estab = pto = ""
    m = re.match(r"\s*(\d{3})-(\d{3})-", str(numero or ""))
    if m:
        estab, pto = m.group(1), m.group(2)
    elif len(str(clave or "")) == 49:
        estab, pto = str(clave)[24:27], str(clave)[27:30]
    if not estab:
        return 0
    try:
        return _suc_por_codigo(c, eid, estab, pto or "001")
    except Exception:
        return 0


def _suc_id_actual(c, eid, sess):
    s = _suc_del_usuario(c, eid, sess)
    return int(s["id"]) if s else 0


def _suc_filtro(c, eid, sess, alias="f"):
    """Trozo de SQL para que cada usuario vea solo lo de su sucursal."""
    s = _suc_del_usuario(c, eid, sess)
    if not s:
        return "", []
    return (" AND IFNULL(%s.sucursal_id,0)=?" % alias), [int(s["id"])]


def _suc_stock_en_bodega(c, eid, pid, bid):
    try:
        r = c.execute("SELECT cantidad FROM stock_bodega WHERE producto_id=? AND bodega_id=?",
                      (pid, bid)).fetchone()
        return float(r[0]) if r else 0.0
    except Exception:
        return 0.0


def _suc_validar_stock(c, eid, sess, items):
    """Revisa que haya existencias en la bodega de la sucursal.

    Devuelve "" si todo está bien, o el detalle de lo que falta. Solo
    se aplica cuando la empresa trabaja por sucursales con stock
    bloqueado: así una sucursal no vende lo que está en otra.
    """
    emp = _suc_emp(c, eid)
    if not _suc_activas(emp):
        return ""
    if not int(emp.get("suc_bloquea_stock", 1) or 0):
        return ""
    s = _suc_del_usuario(c, eid, sess)
    if not s:
        return ""
    bid = _suc_bodega(c, eid, sess)
    faltan = []
    pedido = {}
    for it in (items or []):
        pid = it.get("producto_id")
        if not pid:
            continue
        try:
            cant = float(it.get("cantidad", 1) or 0)
        except Exception:
            cant = 0
        if cant > 0:
            pedido[pid] = pedido.get(pid, 0) + cant
    for pid, cant in pedido.items():
        p = rd(c.execute("SELECT nombre, tipo FROM productos WHERE id=? AND empresa_id=?",
                         (pid, eid)).fetchone()) or {}
        if str(p.get("tipo", "PRODUCTO")).upper() == "SERVICIO":
            continue
        hay = _suc_stock_en_bodega(c, eid, pid, bid)
        if hay < cant:
            faltan.append("%s (pide %g, hay %g)" % (p.get("nombre", "producto " + str(pid)), cant, hay))
    if not faltan:
        return ""
    return ("No hay stock suficiente en la sucursal " + str(s.get("nombre") or "") + ": " +
            "; ".join(faltan[:6]) +
            ". Haga un traspaso desde otra sucursal o ajuste el inventario.")


def _suc_asegurar_bodega(c, eid, suc_id, nombre):
    """Cada sucursal necesita su bodega: si no tiene, se le crea."""
    s = rd(c.execute("SELECT * FROM sucursales WHERE id=? AND empresa_id=?", (suc_id, eid)).fetchone())
    if not s:
        return 0
    bid = int(s.get("bodega_id") or 0)
    if bid:
        b = c.execute("SELECT id FROM bodegas WHERE id=? AND empresa_id=?", (bid, eid)).fetchone()
        if b:
            return bid
    c.execute("""INSERT INTO bodegas (empresa_id,nombre,codigo,principal,estado,created_at)
                 VALUES (?,?,?,?,?,?)""",
              (eid, "Bodega " + (nombre or ("Sucursal " + str(suc_id))),
               "SUC" + str(s.get("codigo") or suc_id), 0, "ACTIVO", now_ec()))
    bid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
    c.execute("UPDATE sucursales SET bodega_id=? WHERE id=?", (bid, suc_id))
    return bid


def _suc_traspaso(c, eid, sess, origen_id, destino_id, items, notas=""):
    """Mueve mercadería de una bodega a otra y deja el rastro en el kardex."""
    if not origen_id or not destino_id or int(origen_id) == int(destino_id):
        raise ValueError("Elija una sucursal de origen y otra de destino distintas.")
    bo = _suc_asegurar_bodega(c, eid, int(origen_id), "")
    bd = _suc_asegurar_bodega(c, eid, int(destino_id), "")
    if not bo or not bd:
        raise ValueError("Alguna de las sucursales no tiene bodega configurada.")
    so = rd(c.execute("SELECT nombre FROM sucursales WHERE id=?", (int(origen_id),)).fetchone()) or {}
    sd = rd(c.execute("SELECT nombre FROM sucursales WHERE id=?", (int(destino_id),)).fetchone()) or {}
    # Primero se revisa que haya de todo: o se mueve completo, o no se mueve nada
    faltan = []
    for it in items:
        pid = it.get("producto_id")
        cant = float(it.get("cantidad", 0) or 0)
        if not pid or cant <= 0:
            continue
        hay = _suc_stock_en_bodega(c, eid, pid, bo)
        if hay < cant:
            p = rd(c.execute("SELECT nombre FROM productos WHERE id=?", (pid,)).fetchone()) or {}
            faltan.append("%s (pide %g, hay %g)" % (p.get("nombre", pid), cant, hay))
    if faltan:
        raise ValueError("En " + str(so.get("nombre", "origen")) + " no hay: " + "; ".join(faltan[:6]))

    fecha = today_ec()
    movidos = 0
    for it in items:
        pid = it.get("producto_id")
        cant = float(it.get("cantidad", 0) or 0)
        if not pid or cant <= 0:
            continue
        _stock_bodega_mov(c, eid, pid, bo, -cant)
        _stock_bodega_mov(c, eid, pid, bd, cant)
        for tipo, delta, bod, det in (("TRASPASO_SALIDA", -cant, bo, "Hacia " + str(sd.get("nombre", ""))),
                                      ("TRASPASO_INGRESO", cant, bd, "Desde " + str(so.get("nombre", "")))):
            saldo = _suc_stock_en_bodega(c, eid, pid, bod)
            c.execute("""INSERT INTO stock_movimientos
                (empresa_id,producto_id,tipo,cantidad,stock_antes,stock_despues,
                 referencia_id,referencia_tipo,notas,fecha,usuario_id,bodega_id)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                (eid, pid, tipo, delta, saldo - delta, saldo, 0, "TRASPASO",
                 (det + ((" · " + notas) if notas else "")), fecha, sess.get("usuario_id"), bod))
        movidos += 1
    return movidos


def _pto_emision_usuario(c, emp, sess):
    """Devuelve (establecimiento, punto de emisión) para numerar un documento.

    Así se arma el número  ESTABLECIMIENTO - PUNTO - SECUENCIAL:

      · ESTABLECIMIENTO lo da la SUCURSAL del usuario (Manta = 005).
        Si no tiene sucursal, el de la empresa.

      · PUNTO lo da la CAJA, que es el campo "Punto de emisión" de la
        ficha del usuario (caja 1 = 001, caja 2 = 002…). Una sucursal
        puede tener varias cajas y cada una numera por separado.
        Si el usuario no tiene punto propio, se usa el de la sucursal,
        y si tampoco, el de la empresa.

    Vale para facturas, notas de crédito, guías y liquidaciones.
    """
    estab = str((emp or {}).get("estab") or "001").zfill(3)[:3]
    pto = str((emp or {}).get("pto_emi") or "001").zfill(3)[:3]

    # ── El establecimiento: lo pone la sucursal ──
    suc = None
    try:
        suc = _suc_del_usuario(c, int((emp or {}).get("id") or 0), sess)
        if suc:
            if str(suc.get("codigo") or "").strip():
                estab = str(suc["codigo"]).zfill(3)[:3]
            if str(suc.get("pto_emi") or "").strip():
                pto = str(suc["pto_emi"]).zfill(3)[:3]   # punto por defecto del local
    except Exception:
        suc = None

    # ── El punto: lo pone la caja del usuario, y manda sobre el del local ──
    try:
        if sess and sess.get("usuario_id"):
            u = rd(c.execute("SELECT secuencial FROM usuarios WHERE id=?",
                             (sess.get("usuario_id"),)).fetchone())
            propio = str((u or {}).get("secuencial") or "").strip()
            if propio:
                pto = propio.zfill(3)[:3]
    except Exception:
        pass
    return estab, pto


def _nc_items_de_factura(c, eid, fac_id):
    """Ítems reales de la factura que se va a anular.

    Una nota de crédito de anulación debe reflejar lo mismo que la
    factura: si va en cero, no anula nada ante el SRI ni en el libro
    de ventas.
    """
    try:
        fac = rd(c.execute("SELECT * FROM facturas WHERE id=? AND empresa_id=?",
                           (int(fac_id), eid)).fetchone())
        if not fac:
            return []
        its = rl(c.execute("SELECT * FROM factura_items WHERE factura_id=? ORDER BY id",
                           (int(fac_id),)).fetchall())
        salida = []
        for it in its:
            salida.append({
                "codigo": it.get("codigo", "") or "",
                "descripcion": it.get("descripcion", "") or "",
                "cantidad": float(it.get("cantidad", 1) or 1),
                "precio_unitario": float(it.get("precio_unitario", 0) or 0),
                "descuento": float(it.get("descuento", 0) or 0),
                "subtotal": float(it.get("subtotal", 0) or 0),
                "producto_id": it.get("producto_id"),
            })
        if salida:
            return salida
        # Factura sin detalle guardado: un solo renglón por el subtotal
        sub = float(fac.get("subtotal", 0) or 0)
        if sub > 0:
            return [{"codigo": "", "descripcion": "Anulación de la factura " + str(fac.get("numero") or ""),
                     "cantidad": 1, "precio_unitario": sub, "descuento": 0, "subtotal": sub}]
    except Exception as ex:
        log.warning("No se pudieron copiar los ítems de la factura %s: %s", fac_id, ex)
    return []


def _siguiente_secuencial_factura(c, eid, estab, pto, sec_inicio=0):
    """Calcula el siguiente secuencial para la serie estab-pto, tomando el máximo
    real existente en facturas + 1 (robusto ante cargas masivas)."""
    prefix = str(estab).zfill(3) + "-" + str(pto).zfill(3) + "-"
    rows = c.execute("SELECT numero FROM facturas WHERE empresa_id=? AND numero LIKE ?", (eid, prefix + "%")).fetchall()
    mx = 0
    for r in rows:
        try:
            n = int(str(r[0]).rsplit("-", 1)[1])
            if n > mx: mx = n
        except Exception:
            pass
    sig = mx + 1
    if sig < int(sec_inicio or 0): sig = int(sec_inicio or 0)
    if sig < 1: sig = 1
    return sig

def _estab_de_numero(numero):
    """Devuelve el código de establecimiento (3 díg.) a partir del número 001-001-000000001."""
    s = (numero or "").strip()
    if "-" in s: return s.split("-")[0].zfill(3)
    return (s[:3] if len(s) >= 3 else s).zfill(3)

def _parse_txt_emitidos(txt):
    """Parsea el TXT de 'Comprobantes Emitidos Autorizados' del SRI.
    Es tolerante al orden de columnas y al separador: detecta automáticamente la
    CLAVE DE ACCESO (campo de 49 dígitos) y clasifica el tipo de comprobante."""
    import re
    out = []
    lines = (txt or "").replace("\r", "").split("\n")
    def _fnum(s):
        try: return round(float(str(s).replace(",", ".").strip() or 0), 2)
        except: return 0.0
    def _fdate(s):
        s = (s or "").strip().split(" ")[0]
        if "/" in s:
            p = s.split("/")
            if len(p) == 3: return p[2] + "-" + p[1].zfill(2) + "-" + p[0].zfill(2)
        return s
    for ln in lines:
        if not ln.strip(): continue
        # Separador: TAB, o si no hay, punto y coma o coma
        if "\t" in ln: cols = ln.split("\t")
        elif ";" in ln: cols = ln.split(";")
        else: cols = re.split(r"\s{2,}|,", ln)
        cols = [c.strip() for c in cols]
        # Saltar cabecera
        joined = " ".join(cols).upper()
        if "CLAVE" in joined and "ACCESO" in joined: continue
        if cols and cols[0].upper().startswith("COMPROBANTE"): continue
        # Detectar la CLAVE DE ACCESO: campo de exactamente 49 dígitos
        clave = ""
        for cval in cols:
            d = re.sub(r"\D", "", cval)
            if len(d) == 49:
                clave = d; break
        # Si no se halló en una columna limpia, buscar una secuencia de 49 dígitos
        # en cualquier parte de la línea (aunque venga pegada a otro texto/números)
        if not clave:
            m = re.search(r"(?<!\d)(\d{49})(?!\d)", ln)
            if m: clave = m.group(1)
        # Último intento: si hay un bloque de dígitos largo, tomar los que empiecen
        # con una fecha ddmmaaaa válida y midan 49
        if not clave:
            for chunk in re.findall(r"\d{40,}", re.sub(r"\D", "", ln)):
                for i in range(0, len(chunk) - 48):
                    cand = chunk[i:i+49]
                    dia = cand[0:2]; mesn = cand[2:4]
                    if "01" <= dia <= "31" and "01" <= mesn <= "12":
                        clave = cand; break
                if clave: break
        # Fechas (dd/mm/aaaa) y números presentes en la línea
        fechas = [c for c in cols if re.match(r"\d{2}/\d{2}/\d{4}", c.strip())]
        # Tipo de comprobante
        tipo = cols[0] if cols else ""
        upper = joined
        es_factura = ("FACTURA" in (tipo.upper())) or (clave[8:10] == "01" if len(clave) >= 10 else False)
        # El código de tipo está en la clave (posiciones 8-9): 01=Factura
        if len(clave) == 49:
            cod_doc = clave[8:10]
            es_factura = (cod_doc == "01")
        # Números monetarios: tomar los últimos 3 valores numéricos con decimales
        montos = []
        for c in cols:
            cc = c.replace(",", ".").strip()
            if re.match(r"^-?\d+\.\d{1,2}$", cc):
                try: montos.append(round(float(cc), 2))
                except: pass
        subtotal = iva = total = 0.0
        if len(montos) >= 3:
            subtotal, iva, total = montos[-3], montos[-2], montos[-1]
        elif len(montos) == 1:
            total = montos[0]
        # Serie del comprobante (nnn-nnn-nnnnnnnnn) si aparece, o derivada de la clave
        serie = ""
        for c in cols:
            if re.match(r"^\d{3}-\d{3}-\d{9}$", c.strip()): serie = c.strip(); break
        if not serie and len(clave) == 49:
            # clave: [fecha8][tipo2][ruc13][amb1][serie15=estab3+pto3+secuencial9]...
            estab = clave[24:27]; pto = clave[27:30]; sec = clave[30:39]
            serie = estab + "-" + pto + "-" + sec
        out.append({
            "tipo_doc": tipo, "serie": serie, "clave": clave,
            "fecha_aut": _fdate(fechas[0]) if fechas else "",
            "fecha": _fdate(fechas[-1]) if fechas else "",
            "subtotal": subtotal, "iva": iva, "total": total,
            "es_factura": es_factura,
        })
    return out

def _parse_txt_emitidos_OLD(txt):
    out = []
    lines = (txt or "").replace("\r", "").split("\n")
    def _fnum(s):
        try: return round(float(str(s).replace(",", ".").strip() or 0), 2)
        except: return 0.0
    def _fdate(s):
        s = (s or "").strip().split(" ")[0]
        if "/" in s:
            p = s.split("/")
            if len(p) == 3: return p[2] + "-" + p[1].zfill(2) + "-" + p[0].zfill(2)
        return s
    for ln in lines:
        if not ln.strip(): continue
        cols = ln.split("\t")
        if len(cols) < 8: continue
        tipo = (cols[0] or "").strip()
        if tipo.upper().startswith("COMPROBANTE"): continue  # cabecera
        es_factura = tipo.upper().startswith("FACTURA")
        out.append({
            "tipo_doc": tipo, "serie": (cols[1] or "").strip(), "clave": (cols[2] or "").strip(),
            "fecha_aut": _fdate(cols[3]), "fecha": _fdate(cols[4]),
            "subtotal": _fnum(cols[5]), "iva": _fnum(cols[6]), "total": _fnum(cols[7]),
            "es_factura": es_factura,
        })
    return out

def _parse_txt_compras(txt):
    """Parsea el TXT de 'Comprobantes recibidos' del SRI (TAB-separado, Latin-1).
    Devuelve una lista de facturas con sus montos, marcando cuáles son facturas/liquidaciones."""
    out = []
    lines = (txt or "").replace("\r", "").split("\n")
    if lines and lines[0].upper().startswith("RUC_EMISOR"):
        lines = lines[1:]
    for ln in lines:
        if not ln.strip():
            continue
        cols = ln.split("\t")
        if len(cols) < 11:
            continue
        tdoc = (cols[2] or "").strip()
        es_factura = tdoc.lower().startswith("factura") or "liquidaci" in tdoc.lower()
        ruc = (cols[0] or "").strip(); razon = (cols[1] or "").strip()
        serie = (cols[3] or "").strip(); clave = (cols[4] or "").strip()
        fem = (cols[6] or "").strip()
        try:
            subtotal = float((cols[8] or "0").strip() or 0)
            iva = float((cols[9] or "0").strip() or 0)
            total = float((cols[10] or "0").strip() or 0)
        except Exception:
            continue
        fe = fem
        if "/" in fem:
            pp = fem.split("/")
            if len(pp) == 3:
                fe = pp[2] + "-" + pp[1].zfill(2) + "-" + pp[0].zfill(2)
        out.append({"ruc": ruc, "razon": razon, "tipo_doc": tdoc, "serie": serie, "clave": clave,
                    "fecha": fe, "subtotal": round(subtotal, 2), "iva": round(iva, 2),
                    "total": round(total, 2), "es_factura": es_factura})
    return out

def _parse_comprobante_compra(xml_text):
    """Extrae datos de una factura electrónica (XML del SRI) para registrar una compra.
    Acepta el XML directo <factura> o envuelto en <autorizacion><comprobante>...</comprobante>."""
    import xml.etree.ElementTree as ET
    root = ET.fromstring((xml_text or "").strip())
    comp = None
    cnode = root.find('.//comprobante')
    if cnode is not None and cnode.text and '<' in cnode.text:
        comp = ET.fromstring(cnode.text.strip())
    if comp is None:
        comp = root if root.tag == 'factura' else root.find('.//factura')
    if comp is None:
        return None
    it = comp.find('infoTributaria'); inf = comp.find('infoFactura')
    if it is None or inf is None:
        return None
    def g(node, tag):
        if node is None: return ''
        n = node.find(tag); return n.text.strip() if (n is not None and n.text) else ''
    ruc = g(it,'ruc'); razon = g(it,'razonSocial')
    estab = g(it,'estab'); pto = g(it,'ptoEmi'); sec = g(it,'secuencial'); clave = g(it,'claveAcceso')
    fecha = g(inf,'fechaEmision')
    subtotal = float(g(inf,'totalSinImpuestos') or 0)
    total = float(g(inf,'importeTotal') or 0)
    iva = 0.0
    tci = inf.find('totalConImpuestos')
    if tci is not None:
        for ti in tci.findall('totalImpuesto'):
            if g(ti,'codigo') == '2':
                iva += float(g(ti,'valor') or 0)
    numaut = ''
    na = root.find('.//numeroAutorizacion')
    if na is not None and na.text: numaut = na.text.strip()
    if not numaut: numaut = clave
    fe = fecha
    if '/' in fecha:
        pp = fecha.split('/')
        if len(pp) == 3: fe = pp[2] + '-' + pp[1].zfill(2) + '-' + pp[0].zfill(2)
    numero = (estab or '001') + '-' + (pto or '001') + '-' + (sec or '').zfill(9)
    return {"ruc":ruc, "razon":razon, "numero":numero, "autorizacion":(numaut or clave),
            "clave":clave, "fecha":fe, "subtotal":round(subtotal,2), "iva":round(iva,2), "total":round(total,2)}

# ════════════════════════════════════════════════════════════════
#  LECTOR DE RIDE EN PDF  (ventas emitidas)
#  Cuando el portal del SRI está caído o el XML original ya no se
#  puede descargar, el RIDE en PDF es lo único que queda. De ahí se
#  sacan cliente, número, clave, fecha y los totales, en el mismo
#  formato que devuelve el lector de XML, para reusar la importación.
# ════════════════════════════════════════════════════════════════

def _ride_num(txt, patrones, dflt=0.0):
    """Primer número que aparezca después de alguna de las etiquetas."""
    for pat in patrones:
        m = re.search(pat + r"[^\d\-]{0,40}(-?[\d.,]+)", txt, re.IGNORECASE)
        if m:
            s = m.group(1).strip().rstrip(".,")
            # 1.234,56 (europeo) vs 1,234.56 (inglés)
            if "," in s and "." in s:
                s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") \
                    else s.replace(",", "")
            elif "," in s:
                s = s.replace(",", ".") if len(s.split(",")[-1]) <= 2 else s.replace(",", "")
            try:
                return float(s)
            except Exception:
                continue
    return dflt


def _ride_texto(pdf_bytes):
    try:
        import pdfplumber, io as _io
    except Exception:
        raise ValueError("Falta la librería pdfplumber. Cierre el sistema y ábralo "
                         "con INICIAR_SERVIDOR.bat para que se instale sola.")
    with pdfplumber.open(_io.BytesIO(pdf_bytes)) as pdf:
        return "\n".join([(p.extract_text() or "") for p in pdf.pages])


def _parse_ride_pdf(pdf_bytes, ruc_emisor=""):
    """Saca de un RIDE en PDF los mismos datos que el lector de XML.

    Devuelve None si el archivo no parece un RIDE de factura de venta.
    """
    try:
        txt = _ride_texto(pdf_bytes)
    except ValueError:
        raise
    except Exception:
        return None
    if not txt or len(txt) < 80:
        return None          # PDF escaneado o sin texto

    plano = re.sub(r"[ \t]+", " ", txt)
    sin_esp = re.sub(r"\s+", "", txt)

    # ── Clave de acceso: 49 dígitos ──
    clave = ""
    # Primero línea por línea: ahí viene suelta y es lo más confiable
    for ln in txt.split("\n"):
        t = re.sub(r"\s+", "", ln)
        if re.fullmatch(r"\d{49}", t):
            clave = t; break
    if not clave:
        # En el RIDE suele imprimirse dos veces seguidas: 98 dígitos pegados.
        m = re.search(r"\d{49,}", sin_esp)
        if m:
            clave = m.group(0)[:49]

    # ── Número del comprobante: 001-001-000000123 ──
    numero = ""
    for pat in (r"No\.?\s*[:\s]\s*(\d{3}-\d{3}-\d{9})",
                r"N[úu]mero[^\d]{0,20}(\d{3}-\d{3}-\d{9})",
                r"(\d{3}-\d{3}-\d{9})"):
        mm = re.search(pat, plano)
        if mm:
            numero = mm.group(1); break
    if not numero and len(clave) == 49:
        numero = clave[24:27] + "-" + clave[27:30] + "-" + clave[30:39]

    # ── Fecha de emisión ──
    fe = ""
    mf = re.search(r"Fecha\s*(?:y\s*hora\s*)?(?:de\s*)?Emisi[óo]n\s*[:\s]\s*(\d{2}[/-]\d{2}[/-]\d{4})",
                   plano, re.IGNORECASE)
    if mf:
        p = re.split(r"[/-]", mf.group(1)); fe = p[2] + "-" + p[1] + "-" + p[0]
    else:
        mf2 = re.search(r"Fecha\s*(?:y\s*hora\s*)?(?:de\s*)?Emisi[óo]n\s*[:\s]\s*(\d{4}-\d{2}-\d{2})",
                        plano, re.IGNORECASE)
        if mf2:
            fe = mf2.group(1)
        elif len(clave) == 49 and clave[:8].isdigit():
            fe = clave[4:8] + "-" + clave[2:4] + "-" + clave[0:2]

    # ── Comprador: razón social e identificación ──
    cli_nombre = ""; cli_ruc = ""
    mn = re.search(r"(?:Raz[óo]n\s*Social\s*/\s*Nombres\s*y\s*Apellidos|Raz[óo]n\s*Social"
                   r"|Nombres?\s*y\s*Apellidos|Cliente)\s*[:\s]\s*(.+)", plano, re.IGNORECASE)
    if mn:
        cli_nombre = mn.group(1).strip()
        cli_nombre = re.split(r"\s{2,}|\bRUC\b|\bC\.?I\.?\b|\bIdentificaci[óo]n\b|\bFecha\b|\bDirecci[óo]n\b",
                              cli_nombre)[0].strip(" :-")
    mi = re.search(r"(?:RUC\s*/\s*CI|RUC/CI|Identificaci[óo]n|C\.?I\.?\s*/\s*RUC|RUC|C[ée]dula)"
                   r"\s*[:\s]\s*(\d{10,13})", plano, re.IGNORECASE)
    if mi:
        cli_ruc = mi.group(1)
    # El RUC del emisor también aparece arriba: si coincide, no es el del cliente
    if cli_ruc and ruc_emisor and cli_ruc == str(ruc_emisor).strip():
        cli_ruc = ""
        for cand in re.findall(r"(?<!\d)(\d{13}|\d{10})(?!\d)", plano):
            if cand != str(ruc_emisor).strip():
                cli_ruc = cand; break
    if not cli_nombre:
        cli_nombre = "CONSUMIDOR FINAL"
    if not cli_ruc:
        cli_ruc = "9999999999999"

    # ── Totales ──
    sub_sin = _ride_num(plano, [r"Subtotal\s*Sin\s*Impuestos", r"Total\s*Sin\s*Impuestos"])
    base15 = _ride_num(plano, [r"Subtotal\s*1[52]\s*%", r"Subtotal\s*IVA\s*1[52]"])
    base5 = _ride_num(plano, [r"Subtotal\s*5\s*%"])
    base0 = _ride_num(plano, [r"Subtotal\s*0\s*%"])
    iva = _ride_num(plano, [r"IVA\s*1[52]\s*%", r"IVA\s*1[52]", r"\bIVA\b"])
    iva5 = _ride_num(plano, [r"IVA\s*5\s*%"])
    total = _ride_num(plano, [r"Valor\s*Total", r"Importe\s*Total", r"TOTAL\s*A\s*PAGAR", r"\bTOTAL\b"])
    desc = _ride_num(plano, [r"Descuentos?"])

    iva_tot = round(iva + iva5, 2)
    if sub_sin <= 0:
        sub_sin = round(base15 + base5 + base0, 2)
    if sub_sin <= 0 and total > 0:
        sub_sin = round(total - iva_tot, 2)
    if base15 <= 0 and base5 <= 0 and base0 <= 0:
        base15 = round(iva_tot / 0.15, 2) if iva_tot > 0 else 0.0
        base0 = round(sub_sin - base15, 2)
        if base0 < 0:
            base0 = 0.0
    if total <= 0:
        total = round(sub_sin + iva_tot, 2)

    # Sin número ni clave no sirve: probablemente no es un RIDE de factura
    if not numero and not clave:
        return None
    if total <= 0 and sub_sin <= 0:
        return None

    return {"cliente_ruc": cli_ruc, "cliente_nombre": cli_nombre[:300],
            "numero": numero, "clave": clave, "fecha": fe or today_ec(),
            "subtotal": round(sub_sin, 2), "base_15": round(base15 + base5, 2),
            "base_0": round(base0, 2), "iva": iva_tot, "total": round(total, 2),
            "descuento": round(desc, 2),
            "items": [{"codigo": "", "descripcion": "Venta según RIDE " + (numero or clave[-10:]),
                       "cantidad": 1, "precio_unitario": round(sub_sin, 2),
                       "descuento": 0, "subtotal": round(sub_sin, 2)}]}


def _parse_factura_venta_xml(xml_text):
    """Extrae datos de una factura electrónica de VENTA (XML del SRI) incluyendo el COMPRADOR
    y la separación de base gravada (15%) vs base 0%. Acepta XML directo o autorizado (CDATA)."""
    import xml.etree.ElementTree as ET
    try:
        root = ET.fromstring((xml_text or "").strip())
    except Exception:
        return None
    comp = None
    cnode = root.find('.//comprobante')
    if cnode is not None and cnode.text and '<' in cnode.text:
        try: comp = ET.fromstring(cnode.text.strip())
        except Exception: comp = None
    if comp is None:
        comp = root if root.tag == 'factura' else root.find('.//factura')
    if comp is None:
        return None
    it = comp.find('infoTributaria'); inf = comp.find('infoFactura')
    if it is None or inf is None:
        return None
    def g(node, tag):
        if node is None: return ''
        n = node.find(tag); return n.text.strip() if (n is not None and n.text) else ''
    estab = g(it,'estab'); pto = g(it,'ptoEmi'); sec = g(it,'secuencial'); clave = g(it,'claveAcceso')
    cli_ruc = g(inf,'identificacionComprador'); cli_nombre = g(inf,'razonSocialComprador')
    fecha = g(inf,'fechaEmision')
    subtotal = float(g(inf,'totalSinImpuestos') or 0)
    total = float(g(inf,'importeTotal') or 0)
    iva = 0.0; base_grav = 0.0; base_0 = 0.0
    tci = inf.find('totalConImpuestos')
    if tci is not None:
        for ti in tci.findall('totalImpuesto'):
            if g(ti,'codigo') == '2':
                val = float(g(ti,'valor') or 0)
                base = float(g(ti,'baseImponible') or 0)
                cp = g(ti,'codigoPorcentaje')
                iva += val
                if cp == '0' or (val == 0 and cp in ('0','6','7')):
                    base_0 += base
                else:
                    base_grav += base
    # Fallbacks si el XML no trae el desglose
    if base_grav == 0 and base_0 == 0:
        base_grav = round(iva / 0.15, 2) if iva > 0 else 0.0
        base_0 = round(subtotal - base_grav, 2)
        if base_0 < 0: base_0 = 0.0
    fe = fecha
    if '/' in fecha:
        pp = fecha.split('/')
        if len(pp) == 3: fe = pp[2] + '-' + pp[1].zfill(2) + '-' + pp[0].zfill(2)
    numero = (estab or '001') + '-' + (pto or '001') + '-' + (sec or '').zfill(9)
    # ── Detalles (productos facturados) para el RIDE ──
    items = []
    dets = comp.find('detalles')
    if dets is not None:
        for d in dets.findall('detalle'):
            cant = float(g(d,'cantidad') or 0)
            pu = float(g(d,'precioUnitario') or 0)
            desc_val = float(g(d,'descuento') or 0)
            total_lin = float(g(d,'precioTotalSinImpuesto') or (cant*pu - desc_val))
            items.append({
                "codigo": g(d,'codigoPrincipal') or g(d,'codigoAuxiliar') or '',
                "descripcion": g(d,'descripcion') or '',
                "cantidad": cant, "precio_unitario": pu,
                "descuento": desc_val, "subtotal": round(total_lin,2)})
    return {"cliente_ruc":cli_ruc, "cliente_nombre":cli_nombre, "numero":numero, "clave":clave,
            "fecha":fe, "subtotal":round(subtotal,2), "base_15":round(base_grav,2), "base_0":round(base_0,2),
            "iva":round(iva,2), "total":round(total,2), "items":items}

# ════════════════════════════════════════════════════════════════
#  RETENCIÓN ELECTRÓNICA (comprobante de retención, codDoc 07, v2.0.0)
# ════════════════════════════════════════════════════════════════
def _upd_ret(rid, **kw):
    if not kw: return
    c = db()
    sets = ", ".join(k + "=?" for k in kw)
    c.execute("UPDATE retenciones SET " + sets + " WHERE id=?", list(kw.values()) + [rid])
    c.commit(); c.close()

def _generar_xml_retencion(rid: int, eid: int):
    """Genera el XML del Comprobante de Retención conforme al esquema SRI 2.0.0."""
    c = db()
    r   = rd(c.execute("SELECT * FROM retenciones WHERE id=? AND empresa_id=?", (rid, eid)).fetchone())
    det = rl(c.execute("SELECT * FROM retencion_detalle WHERE retencion_id=? ORDER BY id", (rid,)).fetchall())
    emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
    comp = None
    if r and r.get("compra_id"):
        comp = rd(c.execute("SELECT * FROM compras WHERE id=? AND empresa_id=?", (r["compra_id"], eid)).fetchone())
    c.close()
    if not r:   raise ValueError("Retención no encontrada")
    if not emp: raise ValueError("Empresa no encontrada")
    if not det: raise ValueError("La retención no tiene líneas")

    num = (r["numero"] or "").strip()
    partes = num.split("-")
    sec = partes[-1].zfill(9) if partes else "000000001"
    ambiente = str(emp["ambiente"] or "1")

    # Clave de acceso con codDoc=07
    clave_ex = str(r.get("clave_acceso") or "")
    if len(clave_ex) == 49 and clave_ex.isdigit() and clave_ex[8:10] == "07":
        clave = clave_ex
    else:
        clave = _clave_sri(r["fecha"], emp["ruc"], ambiente,
                           emp["estab"] or "001", emp["pto_emi"] or "001", sec, cod_doc="07")
        _upd_ret(rid, clave_acceso=clave)

    root = ET.Element("comprobanteRetencion", id="comprobante", version="2.0.0")

    it = ET.SubElement(root, "infoTributaria")
    _t(it, "ambiente", ambiente); _t(it, "tipoEmision", "1")
    _t(it, "razonSocial", _lim(emp["nombre"] or "", 300))
    ncomm = (emp.get("nombre_comercial") or emp["nombre"] or "").strip()
    if ncomm and ncomm != emp["nombre"]:
        _t(it, "nombreComercial", _lim(ncomm, 300))
    _t(it, "ruc", (emp["ruc"] or "").strip())
    _t(it, "claveAcceso", clave); _t(it, "codDoc", "07")
    _t(it, "estab", str(emp["estab"] or "001").zfill(3)[:3])
    _t(it, "ptoEmi", str(emp["pto_emi"] or "001").zfill(3)[:3])
    _t(it, "secuencial", sec.zfill(9))
    _t(it, "dirMatriz", _lim(emp["direccion"] or "", 300))

    info = ET.SubElement(root, "infoCompRetencion")
    _t(info, "fechaEmision", fecha_xml(r["fecha"]))
    _t(info, "dirEstablecimiento", _lim(emp["direccion"] or "", 300))
    if emp.get("contribuyente_especial"):
        _t(info, "contribuyenteEspecial", str(emp["contribuyente_especial"]))
    _t(info, "obligadoContabilidad", (emp.get("obligado_contabilidad") or "NO").upper())
    ruc_prov = (r.get("proveedor_ruc") or "").strip()
    tipo_id = "01" if len(ruc_prov) == 13 else ("02" if len(ruc_prov) == 10 else "03")
    _t(info, "tipoIdentificacionSujetoRetenido", tipo_id)
    _t(info, "razonSocialSujetoRetenido", _lim(r.get("proveedor_nombre") or "", 300))
    _t(info, "identificacionSujetoRetenido", ruc_prov)
    f = r["fecha"] or ""
    _t(info, "periodoFiscal", (f[5:7] + "/" + f[0:4]) if len(f) >= 7 else "")

    docs = ET.SubElement(root, "docsSustento")
    ds = ET.SubElement(docs, "docSustento")
    _t(ds, "codSustento", "01")
    _t(ds, "codDocSustento", (r.get("doc_sustento_tipo") or "01"))
    numdoc = (r.get("doc_sustento_numero") or (comp.get("numero") if comp else "") or "").strip()
    _t(ds, "numDocSustento", numdoc.replace("-", "").zfill(15)[:15])
    fecha_sus = (comp.get("fecha") if comp else r["fecha"])
    _t(ds, "fechaEmisionDocSustento", fecha_xml(fecha_sus))
    _t(ds, "pagoLocExt", "01")
    tot_sin = (comp.get("subtotal") if comp else r.get("base_total")) or 0
    imp_tot = (comp.get("total") if comp else r.get("base_total")) or 0
    _t(ds, "totalSinImpuestos", _d(tot_sin))
    _t(ds, "importeTotal", _d(imp_tot))
    imps = ET.SubElement(ds, "impuestos")
    for d in det:
        im = ET.SubElement(imps, "impuesto")
        _t(im, "codigo", "2" if (d.get("tipo_impuesto") == "IVA") else "1")
        _t(im, "codigoRetencion", str(d.get("codigo") or ""))
        _t(im, "baseImponible", _d(d.get("base_imponible")))
        _t(im, "porcentajeRetener", _d(d.get("porcentaje")))
        _t(im, "valorRetenido", _d(d.get("valor_retenido")))

    _xml_prov_sistema(root, eid)
    xml_str = '<?xml version="1.0" encoding="UTF-8"?>' + ET.tostring(root, encoding="unicode")
    return xml_str, clave

def _procesar_retencion(rid: int, eid: int) -> dict:
    """Pipeline: XML 2.0.0 → firmar → enviar → autorizar (igual que NC/factura)."""
    c = db()
    emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
    r   = rd(c.execute("SELECT * FROM retenciones WHERE id=? AND empresa_id=?", (rid, eid)).fetchone())
    c.close()
    if not emp: return {"ok": False, "error": "Empresa no encontrada"}
    if not emp.get("facturacion_electronica"):
        return {"ok": False, "error": "Facturación electrónica no habilitada para esta empresa (Configuración)."}
    if not r: return {"ok": False, "error": "Retención no encontrada"}
    if r.get("estado_sri") == "AUTORIZADA" and r.get("autorizacion"):
        return {"ok": True, "ya_autorizada": True, "clave_acceso": r["clave_acceso"], "autorizacion": r["autorizacion"]}

    ambiente  = str(emp.get("ambiente") or "1")
    cert_path = str(emp.get("cert_path") or "")
    cert_pass = str(emp.get("cert_password") or "")
    comp_dir  = BASE_DIR / "comprobantes" / _dir_emp(eid)

    # 1) Generar XML
    try:
        xml_str, clave = _generar_xml_retencion(rid, eid)
        gp = comp_dir / "generados" / f"{clave}.xml"; gp.parent.mkdir(parents=True, exist_ok=True)
        gp.write_text(xml_str, encoding="utf-8")
        _slog(eid, rid, "RET_XML_GENERADO", "OK", clave[:20])
    except Exception as ex:
        _slog(eid, rid, "RET_XML_GENERADO", "ERROR", str(ex))
        return {"ok": False, "etapa": "generacion", "error": str(ex)}

    # 2) Firmar
    try:
        cert_path = str(_resolver_cert(emp, eid))
        xml_firmado = firmar_xml(xml_str, cert_path, cert_pass)
        fp = comp_dir / "firmados" / f"{clave}.xml"; fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(xml_firmado, encoding="utf-8")
        _slog(eid, rid, "RET_XML_FIRMADO", "OK")
    except Exception as ex:
        _slog(eid, rid, "RET_XML_FIRMADO", "ERROR", str(ex))
        _upd_ret(rid, estado_sri="ERROR_FIRMA")
        return {"ok": False, "etapa": "firma", "error": str(ex)}

    # 3) Enviar
    res_env = enviar_sri(xml_firmado, ambiente)
    _slog(eid, rid, "RET_ENVIO_SRI", res_env.get("estado", "?"), "", json.dumps(res_env, ensure_ascii=False))
    estado_env = res_env.get("estado", "")
    if estado_env == "DEVUELTA":
        err = _fmt_msgs_sri(res_env.get("mensajes", [])) or "El SRI rechazó el comprobante (DEVUELTA)"
        _upd_ret(rid, estado_sri="DEVUELTA")
        return {"ok": False, "etapa": "envio", "error": err, "mensajes": res_env.get("mensajes", [])}
    elif estado_env not in ("RECIBIDA", "DEVUELTA"):
        _upd_ret(rid, estado_sri="ERROR_ENVIO")
        return {"ok": False, "etapa": "envio", "error": f"Error de conexión con el SRI: {estado_env or 'sin respuesta'}"}

    # 4) Autorizar
    res_auth = None
    for intento, espera in enumerate([3, 5, 8, 12, 15], 1):
        time.sleep(espera)
        res_auth = autorizar_sri(clave, ambiente)
        _slog(eid, rid, f"RET_AUTORIZACION_{intento}", res_auth.get("estado", "?"))
        if res_auth.get("estado") in ("AUTORIZADO", "NO AUTORIZADO", "RECHAZADO"):
            break

    estado_auth = res_auth.get("estado", "DESCONOCIDO")
    if estado_auth == "AUTORIZADO":
        na = (res_auth.get("numero_autorizacion") or clave).strip()
        fa = res_auth.get("fecha_autorizacion") or now_ec()
        ap = comp_dir / "autorizados" / f"{clave}.xml"; ap.parent.mkdir(parents=True, exist_ok=True)
        if res_auth.get("comprobante"): 
            try: ap.write_text(res_auth["comprobante"], encoding="utf-8")
            except Exception: pass
        _upd_ret(rid, estado_sri="AUTORIZADA", autorizacion=na, fecha_autorizacion=fa)
        return {"ok": True, "clave_acceso": clave, "autorizacion": na, "fecha_autorizacion": fa}
    else:
        msgs = res_auth.get("mensajes", [])
        err = _fmt_msgs_sri(msgs) or f"Estado SRI: {estado_auth}"
        _upd_ret(rid, estado_sri=("NO_AUTORIZADA" if estado_auth in ("NO AUTORIZADO","RECHAZADO") else "PENDIENTE"))
        return {"ok": False, "etapa": "autorizacion", "error": err, "estado": estado_auth, "mensajes": msgs}

_CARP_CACHE = {}

def _sanitizar_carpeta(nombre):
    """Convierte el nombre de la empresa en un nombre de carpeta válido en Windows/Linux."""
    import unicodedata
    s = unicodedata.normalize("NFKD", str(nombre or "")).encode("ascii", "ignore").decode("ascii")
    s = s.upper()
    out = []
    for ch in s:
        if ch.isalnum(): out.append(ch)
        elif ch in " .-_": out.append("_")
    s = "".join(out)
    while "__" in s: s = s.replace("__", "_")
    s = s.strip("_")[:40].strip("_")
    return s

def _cert_fijar(eid, ruta):
    """Guarda en la base la ruta real encontrada, para no volver a buscarla."""
    try:
        if eid:
            c = db(); c.execute("UPDATE empresas SET cert_path=? WHERE id=?", (str(ruta), int(eid)))
            c.commit(); c.close()
            log.info("Certificado reubicado para empresa %s → %s", eid, ruta)
    except Exception as ex:
        log.warning("No se pudo actualizar cert_path: %s", ex)
    return Path(ruta)


def _cert_inventario():
    """Lista todos los .p12 que existen dentro de la instalación."""
    hallados = []
    for base in [BASE_DIR / "certificados", BASE_DIR]:
        try:
            if base.exists():
                for q in base.rglob("*.p12"):
                    if q.is_file() and q not in hallados:
                        hallados.append(q)
        except Exception:
            pass
    return hallados


def _resolver_cert(emp, eid=0):
    """Devuelve la ruta REAL del .p12 de la empresa.

    La ruta guardada en la base es absoluta, así que se rompe cuando la
    instalación se mueve de carpeta, se renombra la carpeta de la empresa o
    la base de datos se copia a otra PC. En esos casos el archivo suele
    seguir estando en la instalación: aquí se busca y se repara la ruta.

    Nunca toma el .p12 de OTRA empresa: solo acepta la carpeta propia o una
    coincidencia exacta de nombre de archivo.
    """
    emp = emp or {}
    ruta = str(emp.get("cert_path") or "").strip()
    try:
        eid = int(eid or emp.get("id") or 0)
    except Exception:
        eid = 0

    if ruta:
        p = Path(ruta)
        if p.exists():
            return p
        # Ruta relativa guardada por una versión antigua
        if not p.is_absolute():
            q = BASE_DIR / ruta
            if q.exists():
                return _cert_fijar(eid, q)
        # Mismo nombre de archivo dentro de esta instalación.
        # Ojo: si la base viene de Windows, la ruta trae "\\" y Path.name en
        # Linux devolvería la cadena completa; se separa a mano por ambos.
        nombre = ruta.replace("\\", "/").rstrip("/").split("/")[-1]
        if nombre:
            posibles = [BASE_DIR / "certificados" / _dir_emp(eid) / nombre,
                        BASE_DIR / "certificados" / nombre,
                        BASE_DIR / nombre]
            for q in posibles:
                try:
                    if q.exists():
                        return _cert_fijar(eid, q)
                except Exception:
                    pass
            try:
                for q in (BASE_DIR / "certificados").rglob(nombre):
                    if q.is_file():
                        return _cert_fijar(eid, q)
            except Exception:
                pass

    # Cualquier .p12 que esté en la carpeta PROPIA de la empresa
    propios = []
    if eid:
        try:
            carp = BASE_DIR / "certificados" / _dir_emp(eid)
            if carp.exists():
                propios = sorted([q for q in carp.glob("*.p12") if q.is_file()],
                                 key=lambda x: x.stat().st_mtime, reverse=True)
        except Exception:
            pass
    if len(propios) == 1:
        return _cert_fijar(eid, propios[0])
    if len(propios) > 1:
        raise FileNotFoundError(
            "Hay varios certificados en la carpeta de la empresa y no se sabe cuál usar: "
            + ", ".join(q.name for q in propios[:5])
            + ". Entra a Configuración → Facturación Electrónica y vuelve a subir el correcto.")

    # No se pudo resolver: mensaje con todo lo que sí existe
    otros = _cert_inventario()
    det = "El certificado .p12 de la empresa no está en esta computadora."
    if ruta:
        det += " La base de datos apunta a: " + ruta
        try:
            if not Path(ruta).parent.exists():
                det += " (esa carpeta tampoco existe)"
        except Exception:
            pass
    if otros:
        det += ". Sí se encontraron estos .p12 en la instalación: " + \
               ", ".join(str(q) for q in otros[:5])
        det += ". Si alguno es el de esta empresa, súbelo desde Configuración → Facturación Electrónica."
    else:
        det += ". No hay ningún archivo .p12 en " + str(BASE_DIR) + \
               ". Sube tu firma en Configuración → Facturación Electrónica."
    raise FileNotFoundError(det)


def _dir_emp(eid):
    """Nombre de la carpeta de la empresa (con su nombre real). Con caché."""
    eid = int(eid)
    if eid in _CARP_CACHE: return _CARP_CACHE[eid]
    carpeta = ""
    try:
        c = db()
        row = c.execute("SELECT carpeta FROM empresas WHERE id=?", (eid,)).fetchone()
        c.close()
        if row and (row[0] or "").strip(): carpeta = row[0].strip()
    except Exception:
        pass
    if not carpeta: carpeta = f"empresa_{eid}"
    _CARP_CACHE[eid] = carpeta
    return carpeta

def _renombrar_dirs_empresa(vieja, nueva):
    """Renombra comprobantes/<vieja> y certificados/<vieja> a <nueva> (con fusión si ya existe)."""
    import shutil
    for base in [BASE_DIR / "comprobantes", BASE_DIR / "certificados"]:
        src = base / vieja; dst = base / nueva
        try:
            if not src.exists(): continue
            if not dst.exists():
                src.rename(dst)
            else:
                for item in src.iterdir():
                    destino = dst / item.name
                    if not destino.exists():
                        shutil.move(str(item), str(destino))
                try: src.rmdir()
                except Exception: pass
        except Exception as ex:
            log.warning("No se pudo renombrar %s → %s: %s", src, dst, ex)

def _actualizar_rutas_empresa(conn, eid, vieja, nueva):
    """Actualiza las rutas guardadas en la BD (XML/RIDE/certificado) tras renombrar la carpeta."""
    tablas = [("facturas", ["xml_path","ride_path"]),
              ("notas_credito", ["xml_path","ride_path"]),
              ("guias_remision", ["xml_path","ride_path"]),
              ("liquidaciones_compra", ["xml_path","ride_path"])]
    for t, cols in tablas:
        for col in cols:
            try:
                conn.execute(f"UPDATE {t} SET {col}=REPLACE({col},?,?) WHERE empresa_id=? AND {col} LIKE ?",
                             (vieja, nueva, eid, f"%{vieja}%"))
            except Exception:
                pass
    try:
        conn.execute("UPDATE empresas SET cert_path=REPLACE(cert_path,?,?) WHERE id=? AND cert_path LIKE ?",
                     (vieja, nueva, eid, f"%{vieja}%"))
    except Exception:
        pass

def _migrar_carpetas_empresas(conn):
    """Asigna carpetas con nombre real a cada empresa y renombra las empresa_N existentes."""
    try:
        emps = conn.execute("SELECT id, nombre, IFNULL(carpeta,'') as carpeta FROM empresas ORDER BY id").fetchall()
    except Exception:
        return
    usadas = set()
    for e in emps:
        cpt = (e[2] or "").strip()
        if cpt: usadas.add(cpt)
    for e in emps:
        eid, nombre, carpeta = e[0], e[1], (e[2] or "").strip()
        vieja = f"empresa_{eid}"
        if not carpeta:
            base = _sanitizar_carpeta(nombre) or f"EMPRESA_{eid}"
            carpeta = base
            if carpeta in usadas: carpeta = f"{base}_{eid}"
            usadas.add(carpeta)
            _renombrar_dirs_empresa(vieja, carpeta)
            _actualizar_rutas_empresa(conn, eid, vieja, carpeta)
            conn.execute("UPDATE empresas SET carpeta=? WHERE id=?", (carpeta, eid))
            _CARP_CACHE.pop(eid, None)
            log.info("Carpeta de empresa %s: %s → %s", eid, vieja, carpeta)
        else:
            # Ya tiene carpeta asignada: si quedó una carpeta vieja empresa_N (p.ej. respaldo restaurado), fusionarla
            if (BASE_DIR / "comprobantes" / vieja).exists() or (BASE_DIR / "certificados" / vieja).exists():
                _renombrar_dirs_empresa(vieja, carpeta)
                _actualizar_rutas_empresa(conn, eid, vieja, carpeta)

def _mkdirs(eid):
    base = BASE_DIR / "comprobantes" / _dir_emp(eid)
    for s in ["generados","firmados","autorizados","rechazados","anulados","RIDE"]:
        (base / s).mkdir(parents=True, exist_ok=True)
    (BASE_DIR / "certificados" / _dir_emp(eid)).mkdir(parents=True, exist_ok=True)

def rd(r): return dict(r) if r else None
def rl(rs): return [dict(r) for r in (rs or [])]

# ════════════════════════════════════════════════════════════
# CLAVE DE ACCESO SRI (49 dígitos)
# ════════════════════════════════════════════════════════════
def clave_acceso(fecha: str, ruc: str, ambiente: str, estab: str, pto: str, sec: str, cod_doc: str = "01") -> str:
    """
    Genera la clave de acceso de 49 dígitos para el SRI.
    cod_doc: 01=Factura, 04=Nota de Crédito, 06=Guía de Remisión, etc.
    El campo cod_doc en la clave DEBE coincidir con el codDoc del XML.
    Error [58] ocurre cuando no coinciden.
    """
    f = fecha_xml(fecha).replace("/", "")          # ddmmyyyy
    cod = str(uuid.uuid4().int)[:8].zfill(8)
    c48 = (f + cod_doc.zfill(2) + ruc + ambiente + estab.zfill(3) + pto.zfill(3) + str(sec).zfill(9) + cod + "1")[:48]
    s = sum(int(c48[i]) * [2,3,4,5,6,7][(47-i) % 6] for i in range(48))
    r = 11 - (s % 11)
    v = r if r <= 9 else (0 if r == 11 else 1)
    return c48 + str(v)

# ════════════════════════════════════════════════════════════
# GENERACIÓN XML SRI v2.31
# ════════════════════════════════════════════════════════════
def _t(parent, tag, text=""):
    el = ET.SubElement(parent, tag)
    el.text = str(text)
    return el

def _d(v): return f"{float(v or 0):.2f}"

# Códigos SRI Ecuador (CORREGIDOS):
# 04=RUC, 05=Cédula, 06=Pasaporte, 07=Consumidor Final, 08=ID Exterior
TIPOS_ID = {"04":"RUC","05":"Cédula","06":"Pasaporte","07":"Consumidor Final","08":"ID Exterior"}


def _iva_pct_doc(doc):
    """% IVA REAL del documento, derivado de sus totales guardados.
    Evita rechazos del SRI cuando el comprobante es 0% (o 5%/8%) pero
    la empresa tiene configurado 15% por defecto."""
    try:
        sub = float(doc.get("subtotal") or 0); iva = float(doc.get("iva") or 0)
    except Exception:
        sub = 0.0; iva = 0.0
    if iva <= 0.005 or sub <= 0:
        return 0.0
    ratio = iva / sub * 100.0
    return float(min((15.0, 12.0, 8.0, 5.0), key=lambda x: abs(x - ratio)))

# ════════════════════════════════════════════════════════════
# RUC DEL PROVEEDOR DEL SISTEMA EN infoAdicional
# Resolución SRI NAC-DGERCGC26-00000027 (R.O. 28-jul-2026)
# Todo comprobante electrónico debe llevar, en la sección de
# información adicional, el RUC del proveedor del software.
# ════════════════════════════════════════════════════════════
PROV_SISTEMA_RUC_DEFAULT   = "0993394602001"    # DAVI&LOZA S.A.S.
PROV_SISTEMA_CAMPO_DEFAULT = "RUC Proveedor"    # nombre del campoAdicional


def _prov_sistema(eid: int) -> tuple:
    """Devuelve (nombre_del_campo, ruc) del proveedor del sistema para esa empresa."""
    nombre, ruc = PROV_SISTEMA_CAMPO_DEFAULT, PROV_SISTEMA_RUC_DEFAULT
    try:
        c = db()
        r = rd(c.execute("SELECT prov_sistema_campo, prov_sistema_ruc FROM empresas WHERE id=?",
                         (eid,)).fetchone()) or {}
        c.close()
        if str(r.get("prov_sistema_campo") or "").strip():
            nombre = str(r["prov_sistema_campo"]).strip()
        if str(r.get("prov_sistema_ruc") or "").strip():
            ruc = str(r["prov_sistema_ruc"]).strip()
    except Exception as ex:
        log.warning("No se pudo leer el proveedor del sistema (%s); se usa el valor por defecto", ex)
    return nombre[:300], ruc[:300]


def _xml_prov_sistema(root, eid: int):
    """Agrega <campoAdicional nombre="RUC Proveedor">…</campoAdicional> al comprobante.

    Crea <infoAdicional> si el comprobante todavía no la tiene. Si el campo ya
    existe (por ejemplo al regenerar el XML) se actualiza en vez de duplicarse.
    """
    nombre, ruc = _prov_sistema(eid)
    if not ruc:
        return
    try:
        ia = root.find("infoAdicional")
        if ia is None:
            ia = ET.SubElement(root, "infoAdicional")
        for ca in ia.findall("campoAdicional"):
            if str(ca.get("nombre") or "").strip().lower() == nombre.strip().lower():
                ca.text = ruc
                return
        ca = ET.SubElement(ia, "campoAdicional")
        ca.set("nombre", nombre)
        ca.text = ruc
    except Exception as ex:
        log.warning("No se pudo agregar el RUC del proveedor al XML: %s", ex)


def _cod_pct_sri(pct):
    """Código de porcentaje SRI: 0=0%, 2=12%, 4=15%, 5=5%, 8=8%"""
    return {15: "4", 12: "2", 8: "8", 5: "5"}.get(int(round(float(pct or 0))), "0")

def generar_xml(fid: int, eid: int) -> tuple[str, str]:
    conn = db()
    f = rd(conn.execute("""
        SELECT f.*, c.nombre as cli_nombre, c.ruc_cedula, c.tipo_identificacion,
               c.email as cli_email, c.direccion as cli_dir, c.telefono as cli_tel
        FROM facturas f LEFT JOIN clientes c ON f.cliente_id=c.id
        WHERE f.id=? AND f.empresa_id=?""", (fid, eid)).fetchone())
    items = rl(conn.execute("SELECT * FROM factura_items WHERE factura_id=?", (fid,)).fetchall())
    emp = rd(conn.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
    conn.close()

    if not f or not emp:
        raise ValueError(f"Factura {fid} o empresa {eid} no encontrada")

    sec      = f["numero"].split("-")[-1]
    # Estab y punto de emisión REALES del número (respetan el punto del usuario que lo creó)
    _parts = str(f["numero"]).split("-")
    estab_doc = (_parts[0] if len(_parts) == 3 else (emp["estab"] or "001")).zfill(3)[:3]
    pto_doc   = (_parts[1] if len(_parts) == 3 else (emp["pto_emi"] or "001")).zfill(3)[:3]
    ambiente = emp["ambiente"] or "1"

    # Reutilizar clave existente (no regenerar en reintentos)
    if f["clave_acceso"] and len(str(f["clave_acceso"])) == 49:
        clave = f["clave_acceso"]
        log.info("Reutilizando clave: %s...", clave[:20])
    else:
        clave = clave_acceso(f["fecha"], emp["ruc"], ambiente, estab_doc, pto_doc, sec)
        c2 = db(); c2.execute("UPDATE facturas SET clave_acceso=? WHERE id=?", (clave, fid)); c2.commit(); c2.close()

    root = ET.Element("factura", id="comprobante", version="2.1.0")

    # infoTributaria
    it = ET.SubElement(root, "infoTributaria")
    _t(it, "ambiente",        ambiente)
    _t(it, "tipoEmision",     "1")
    _t(it, "razonSocial",     emp["nombre"] or "")
    _t(it, "nombreComercial", emp["nombre_comercial"] or emp["nombre"] or "")
    _t(it, "ruc",             emp["ruc"] or "")
    _t(it, "claveAcceso",     clave)
    _t(it, "codDoc",          "01")
    _t(it, "estab",           estab_doc)
    _t(it, "ptoEmi",          pto_doc)
    _t(it, "secuencial",      str(sec).zfill(9))
    _t(it, "dirMatriz",       emp["direccion"] or "")

    # infoFactura
    info = ET.SubElement(root, "infoFactura")
    _t(info, "fechaEmision",      fecha_xml(f["fecha"]))
    _t(info, "dirEstablecimiento", emp["direccion"] or "")
    if emp["contribuyente_especial"]:
        _t(info, "contribuyenteEspecial", emp["contribuyente_especial"])
    _t(info, "obligadoContabilidad", emp["obligado_contabilidad"] or "NO")

    # Tipo identificación comprador (CORREGIDO)
    tipo_id = f["tipo_identificacion"] or "05"
    ruc_ced = (f["ruc_cedula"] or "").strip()
    if tipo_id == "07" or not ruc_ced:
        tipo_id = "07"; ruc_ced = "9999999999999"; cli_nombre = "CONSUMIDOR FINAL"
    else:
        cli_nombre = f["cli_nombre"] or "CONSUMIDOR FINAL"

    _t(info, "tipoIdentificacionComprador", tipo_id)
    _t(info, "razonSocialComprador",        cli_nombre)
    _t(info, "identificacionComprador",     ruc_ced)
    # ── Totales calculados EXACTAMENTE como valida el SRI (desde los ítems) ──
    iva_pct = _iva_pct_doc(f)
    # Cada ítem lleva su propia tarifa: el SRI exige un <totalImpuesto> por
    # cada codigoPorcentaje presente en la factura (15%, 0%, etc.).
    items, _grupos = _tarifas_factura(None, fid, items, f)
    iva_total_xml  = round(sum(g["iva"] for g in _grupos.values()), 2)
    base_total_xml = round(sum(g["base"] for g in _grupos.values()), 2)
    importe_total_xml = round(base_total_xml + iva_total_xml, 2)

    _t(info, "totalSinImpuestos",           _d(base_total_xml))
    _t(info, "totalDescuento",              _d(f["descuento"] or 0))

    tic = ET.SubElement(info, "totalConImpuestos")
    for _tar in sorted(_grupos.keys()):
        _g = _grupos[_tar]
        ti = ET.SubElement(tic, "totalImpuesto")
        _t(ti, "codigo",           "2")
        _t(ti, "codigoPorcentaje", _cod_pct_sri(_tar))
        _t(ti, "baseImponible",    _d(_g["base"]))
        _t(ti, "valor",            _d(_g["iva"]))

    _t(info, "propina",      "0.00")
    _t(info, "importeTotal", _d(importe_total_xml))
    _t(info, "moneda",       "DOLAR")

    pagos = ET.SubElement(info, "pagos")
    pago  = ET.SubElement(pagos, "pago")
    fp_code = str(f.get("forma_pago","01") or "01")
    _t(pago, "formaPago", fp_code)
    _t(pago, "total",       _d(importe_total_xml))
    _t(pago, "plazo",       "0")
    _t(pago, "unidadTiempo","dias")

    # detalles
    dets = ET.SubElement(root, "detalles")
    for it2 in items:
        det = ET.SubElement(dets, "detalle")
        _t(det, "codigoPrincipal",          it2["codigo"] or it2["descripcion"][:25])
        _t(det, "descripcion",              it2["descripcion"])
        _t(det, "cantidad",                 _d(it2["cantidad"]))
        _t(det, "precioUnitario",           _d(it2["precio_unitario"]))
        _t(det, "descuento",                _d(it2["descuento"] or 0))
        _t(det, "precioTotalSinImpuesto",   _d(it2["subtotal"]))
        imps = ET.SubElement(det, "impuestos")
        imp  = ET.SubElement(imps, "impuesto")
        _tar_it = float(it2.get("_tarifa", iva_pct))
        _t(imp, "codigo",           "2")
        _t(imp, "codigoPorcentaje", _cod_pct_sri(_tar_it))
        _t(imp, "tarifa",           _d(_tar_it))
        _t(imp, "baseImponible",    _d(it2["subtotal"]))
        _t(imp, "valor",            _d(round(float(it2.get("_iva", 0)), 2)))

    # infoAdicional — solo si hay datos
    campos = [(n, v) for n, v in [
        ("email",         f.get("cli_email","") or ""),
        ("telefono",      f.get("cli_tel","")   or ""),
        ("observaciones", f.get("notas","")      or ""),
    ] if str(v).strip()]
    if campos:
        adic = ET.SubElement(root, "infoAdicional")
        for nombre, valor in campos:
            ca = ET.SubElement(adic, "campoAdicional", nombre=nombre)
            ca.text = str(valor).strip()

    _xml_prov_sistema(root, eid)
    xml_str = '<?xml version="1.0" encoding="UTF-8"?>' + ET.tostring(root, encoding="unicode")
    return xml_str, clave

# ════════════════════════════════════════════════════════════
# FIRMA DIGITAL XAdES-BES (C14N correcto para SRI Ecuador)
# ════════════════════════════════════════════════════════════
def _c14n(xml_bytes: bytes) -> bytes:
    """Canonicalización C14N inclusiva usando lxml."""
    from lxml import etree as lx
    import io
    doc = lx.fromstring(xml_bytes)
    buf = io.BytesIO()
    doc.getroottree().write_c14n(buf, exclusive=False, with_comments=False)
    return buf.getvalue()

def _issuer(cert) -> str:
    """X509IssuerName RFC2253 en el orden del certificado (DER)."""
    OID = {
        "2.5.4.3":"CN","2.5.4.6":"C","2.5.4.7":"L","2.5.4.8":"ST",
        "2.5.4.9":"STREET","2.5.4.10":"O","2.5.4.11":"OU",
        "2.5.4.5":"SERIALNUMBER","2.5.4.42":"GN","2.5.4.4":"SN",
        "1.2.840.113549.1.9.1":"emailAddress",
    }
    parts = []
    for rdn in cert.issuer.rdns:
        for a in rdn:
            k = OID.get(a.oid.dotted_string, a.oid.dotted_string)
            v = str(a.value)
            for ch, esc in [("\\","\\\\"),(",","\\,"),("+","\\+"),
                             ('"','\\"'),("<","\\<"),(">","\\>"),(";","\\;")]:
                v = v.replace(ch, esc)
            parts.append(f"{k}={v}")
    return ",".join(parts)

def firmar_xml(xml_str: str, cert_path: str, cert_password: str) -> str:
    """
    Firma XAdES-BES para el SRI Ecuador.

    FIX CRÍTICO — enveloped-signature transform:
    El SRI al validar toma el documento COMPLETO (que ya incluye <ds:Signature>)
    y calcula el digest del elemento id="comprobante".
    Si la Reference NO declara la transform "enveloped-signature", el SRI
    incluye el bloque <ds:Signature> en el cálculo → digest diferente → FIRMA INVALIDA.
    Con la transform, el SRI remueve <ds:Signature> antes de hashear, obteniendo
    el mismo resultado que nosotros calculamos sobre el XML sin firma.
    """
    from lxml import etree as lx

    # Cargar P12
    with open(cert_path, "rb") as fh:
        p12 = fh.read()
    priv, cert, _ = pkcs12.load_key_and_certificates(
        p12, cert_password.encode() if cert_password else None, default_backend()
    )
    cert_der = cert.public_bytes(serialization.Encoding.DER)
    cert_b64 = base64.b64encode(cert_der).decode()

    # IDs únicos
    uid    = uuid.uuid4().hex
    sig_id = f"Signature-{uid}"
    sp_id  = f"Signature-{uid}-SignedProperties"
    sv_id  = f"SignatureValue-{uid}"
    ki_id  = f"KeyInfo-{uid}"
    now    = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    # Quitar declaración XML
    xml_body = xml_str.strip()
    if xml_body.startswith("<?xml"):
        xml_body = xml_body[xml_body.index("?>") + 2:].lstrip()

    # 1. Digest del documento (sobre XML SIN firma — la transform enveloped lo sincroniza)
    doc_dig = base64.b64encode(hashlib.sha1(_c14n(xml_body.encode())).digest()).decode()
    log.debug("doc_digest=%s", doc_dig)

    # 2. Digest del certificado e IssuerName
    cert_dig    = base64.b64encode(hashlib.sha1(cert_der).digest()).decode()
    issuer_name = _issuer(cert)
    serial      = str(cert.serial_number)
    log.debug("issuer=%s serial=%s", issuer_name, serial)

    # 3. SignedProperties → C14N → digest
    sp = (
        f'<xades:SignedProperties'
        f' xmlns:xades="http://uri.etsi.org/01903/v1.3.2#"'
        f' xmlns:ds="http://www.w3.org/2000/09/xmldsig#"'
        f' Id="{sp_id}">'
        f'<xades:SignedSignatureProperties>'
        f'<xades:SigningTime>{now}</xades:SigningTime>'
        f'<xades:SigningCertificate><xades:Cert>'
        f'<xades:CertDigest>'
        f'<ds:DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>'
        f'<ds:DigestValue>{cert_dig}</ds:DigestValue>'
        f'</xades:CertDigest>'
        f'<xades:IssuerSerial>'
        f'<ds:X509IssuerName>{issuer_name}</ds:X509IssuerName>'
        f'<ds:X509SerialNumber>{serial}</ds:X509SerialNumber>'
        f'</xades:IssuerSerial>'
        f'</xades:Cert></xades:SigningCertificate>'
        f'</xades:SignedSignatureProperties>'
        f'</xades:SignedProperties>'
    )
    sp_dig = base64.b64encode(hashlib.sha1(_c14n(sp.encode())).digest()).decode()
    log.debug("sp_digest=%s", sp_dig)

    # 4. SignedInfo con transform enveloped-signature en la Reference del documento
    #    ESTO ES EL FIX: sin esta transform el SRI falla con FIRMA INVALIDA
    si = (
        f'<ds:SignedInfo xmlns:ds="http://www.w3.org/2000/09/xmldsig#">'
        f'<ds:CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>'
        f'<ds:SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"/>'
        f'<ds:Reference URI="#comprobante">'
        f'<ds:Transforms>'
        f'<ds:Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"/>'
        f'</ds:Transforms>'
        f'<ds:DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>'
        f'<ds:DigestValue>{doc_dig}</ds:DigestValue>'
        f'</ds:Reference>'
        f'<ds:Reference Type="http://uri.etsi.org/01903#SignedProperties" URI="#{sp_id}">'
        f'<ds:DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>'
        f'<ds:DigestValue>{sp_dig}</ds:DigestValue>'
        f'</ds:Reference>'
        f'</ds:SignedInfo>'
    )
    si_c14n   = _c14n(si.encode())
    sig_bytes = priv.sign(si_c14n, asym_padding.PKCS1v15(), hashes.SHA1())
    sig_b64   = base64.b64encode(sig_bytes).decode()

    # Verificación local
    try:
        cert.public_key().verify(sig_bytes, si_c14n, asym_padding.PKCS1v15(), hashes.SHA1())
        log.info("✓ Verificación local firma OK")
    except InvalidSignature:
        raise ValueError("Firma inválida localmente — revisar certificado o contraseña")

    # Módulo y exponente RSA
    pub   = priv.public_key().public_numbers()
    n_b64 = base64.b64encode(pub.n.to_bytes((pub.n.bit_length()+7)//8,"big")).decode()
    e_b64 = base64.b64encode(pub.e.to_bytes((pub.e.bit_length()+7)//8,"big")).decode()

    # 5. Bloque <ds:Signature> completo (SignedInfo en forma C14N)
    bloque = (
        f'<ds:Signature xmlns:ds="http://www.w3.org/2000/09/xmldsig#" Id="{sig_id}">'
        f'{si_c14n.decode()}'
        f'<ds:SignatureValue Id="{sv_id}">{sig_b64}</ds:SignatureValue>'
        f'<ds:KeyInfo Id="{ki_id}">'
        f'<ds:X509Data><ds:X509Certificate>{cert_b64}</ds:X509Certificate></ds:X509Data>'
        f'<ds:KeyValue><ds:RSAKeyValue>'
        f'<ds:Modulus>{n_b64}</ds:Modulus>'
        f'<ds:Exponent>{e_b64}</ds:Exponent>'
        f'</ds:RSAKeyValue></ds:KeyValue>'
        f'</ds:KeyInfo>'
        f'<ds:Object><xades:QualifyingProperties'
        f' xmlns:xades="http://uri.etsi.org/01903/v1.3.2#" Target="#{sig_id}">'
        f'{sp}'
        f'</xades:QualifyingProperties></ds:Object>'
        f'</ds:Signature>'
    )

    # Detectar el tag raíz para insertar la firma correctamente
    # Detectar el tag raíz para insertar la firma correctamente
    # CRÍTICO: Si el tag no está en la lista, la firma no se inserta → Error [39]
    for closing_tag in ["</factura>", "</notaCredito>", "</guiaRemision>", "</liquidacionCompra>"]:
        if closing_tag in xml_body:
            xml_firmado = xml_body.replace(closing_tag, bloque + closing_tag, 1)
            break
    else:
        xml_firmado = xml_body  # fallback
    return '<?xml version="1.0" encoding="UTF-8"?>' + xml_firmado

# ════════════════════════════════════════════════════════════
# WEBSERVICE SRI (SOAP)
# ════════════════════════════════════════════════════════════
def _soap(url: str, body: str, timeout=30) -> str:
    import ssl
    ctx = ssl.create_default_context()
    # El SRI a veces tiene cadena de certificados incompleta; ser tolerante para no bloquear la consulta
    try:
        req = urllib.request.Request(
            url, data=body.encode(), method="POST",
            headers={"Content-Type": "text/xml; charset=UTF-8", "SOAPAction": "",
                     "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) DavilozaSoft/3.6"},
        )
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
            return r.read().decode()
    except ssl.SSLError:
        ctx2 = ssl.create_default_context()
        ctx2.check_hostname = False
        ctx2.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(
            url, data=body.encode(), method="POST",
            headers={"Content-Type": "text/xml; charset=UTF-8", "SOAPAction": "",
                     "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) DavilozaSoft/3.6"},
        )
        with urllib.request.urlopen(req, timeout=timeout, context=ctx2) as r:
            return r.read().decode()

def _parse_sri(xml: str) -> dict:
    """
    Parsea la respuesta SOAP del SRI para todos los tipos de comprobante.

    ESTRUCTURA REAL del SRI (descubierta tras análisis):
    - Recepción OK:  <estado>RECIBIDA</estado>
    - Recepción mal: <estado>DEVUELTA</estado> + <mensajes>
    - Autorización con comprobante:
        <numeroComprobantes>1</numeroComprobantes>
        <autorizacion><estado>AUTORIZADO</estado><numeroAutorizacion>...</numeroAutorizacion>
    - Autorización SIN comprobante (NC/Guía no encontrada):
        <numeroComprobantes>0</numeroComprobantes>
        <autorizaciones/>   ← vacío, SIN nodo <estado> → antes daba DESCONOCIDO
    """
    res = {
        "estado":              "DESCONOCIDO",
        "mensajes":            [],
        "numero_autorizacion": None,
        "fecha_autorizacion":  None,
        "numero_comprobantes": -1,
        "raw_xml":             xml[:4000],
    }
    if not xml or not xml.strip():
        res["estado"] = "SIN_RESPUESTA"
        return res
    try:
        root = ET.fromstring(xml)

        # ── 1. Estado directo (recepción) ─────────────────────
        e = root.find(".//{*}estado")
        if e is not None and e.text:
            res["estado"] = e.text.strip()

        # ── 2. numeroComprobantes ──────────────────────────────
        nc_el = root.find(".//{*}numeroComprobantes")
        if nc_el is not None and nc_el.text:
            try: res["numero_comprobantes"] = int(nc_el.text.strip())
            except: pass

        # ── 3. Datos dentro de <autorizacion> ─────────────────
        for auth in root.findall(".//{*}autorizacion"):
            est_el = auth.find("{*}estado") or auth.find("estado")
            if est_el is not None and est_el.text:
                res["estado"] = est_el.text.strip()

            na_el = auth.find("{*}numeroAutorizacion") or auth.find("numeroAutorizacion")
            if na_el is not None and na_el.text and na_el.text.strip():
                res["numero_autorizacion"] = na_el.text.strip()

            fa_el = auth.find("{*}fechaAutorizacion") or auth.find("fechaAutorizacion")
            if fa_el is not None and fa_el.text and fa_el.text.strip():
                res["fecha_autorizacion"] = fa_el.text.strip()

        # ── 4. Mensajes de error ───────────────────────────────
        for blq in root.findall(".//{*}mensajes"):
            for m in blq:
                def g(t):
                    el = m.find(f"{{*}}{t}") or m.find(t)
                    return (el.text or "").strip() if el is not None else ""
                msg_txt = g("mensaje")
                if msg_txt:
                    res["mensajes"].append({
                        "tipo":          g("tipo"),
                        "identificador": g("identificador"),
                        "mensaje":       msg_txt,
                        "info":          g("informacionAdicional"),
                    })

        # ── 5. Resolver estado cuando SRI no lo devuelve ──────
        if res["estado"] == "DESCONOCIDO":
            if res["numero_comprobantes"] == 0:
                # SRI respondió pero sin comprobantes → no está autorizado
                res["estado"] = "NO AUTORIZADO"
                if not res["mensajes"]:
                    res["mensajes"].append({
                        "tipo": "INFO", "identificador": "0",
                        "mensaje": "Comprobante no encontrado en el SRI (numeroComprobantes=0)",
                        "info": "El comprobante fue recibido pero aún no está autorizado, o fue rechazado. Verifica en srienlinea.sri.gob.ec"
                    })
            elif res["mensajes"]:
                res["estado"] = "NO AUTORIZADO"

        # ── 6. Normalizar ─────────────────────────────────────
        res["estado"] = (res.get("estado") or "DESCONOCIDO").strip().upper()
        log.info("SRI: estado=%s comp=%s auth=%s msgs=%d",
                 res["estado"], res["numero_comprobantes"],
                 bool(res.get("numero_autorizacion")), len(res["mensajes"]))

    except Exception as ex:
        res["estado"] = "ERROR_PARSE"
        res["error_parse"] = str(ex)
        log.error("Error parseando SRI: %s | xml=%s", ex, xml[:150])
    return res


def enviar_sri(xml_firmado: str, ambiente: str) -> dict:
    b64 = base64.b64encode(xml_firmado.encode()).decode()
    soap = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"'
        ' xmlns:ec="http://ec.gob.sri.ws.recepcion"><soapenv:Header/><soapenv:Body>'
        f'<ec:validarComprobante><xml>{b64}</xml></ec:validarComprobante>'
        '</soapenv:Body></soapenv:Envelope>'
    )
    try: return _parse_sri(_soap(SRI[ambiente]["recepcion"], soap))
    except Exception as ex: return {"estado":"ERROR_CONEXION","mensaje":str(ex),"mensajes":[]}

def autorizar_sri(clave: str, ambiente: str) -> dict:
    soap = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"'
        ' xmlns:ec="http://ec.gob.sri.ws.autorizacion"><soapenv:Header/><soapenv:Body>'
        f'<ec:autorizacionComprobante><claveAccesoComprobante>{clave}</claveAccesoComprobante></ec:autorizacionComprobante>'
        '</soapenv:Body></soapenv:Envelope>'
    )
    try: return _parse_sri(_soap(SRI[ambiente]["autorizacion"], soap))
    except Exception as ex: return {"estado":"ERROR_CONEXION","mensaje":str(ex),"mensajes":[]}

def _consultar_autorizacion_sri(clave: str, ambiente: str, timeout=12):
    """Consulta al SRI y devuelve un dict con todos los detalles:
    {xml, estado, numero_comprobantes, mensajes[], error_conexion, raw_inicio}"""
    soap = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"'
        ' xmlns:ec="http://ec.gob.sri.ws.autorizacion"><soapenv:Header/><soapenv:Body>'
        f'<ec:autorizacionComprobante><claveAccesoComprobante>{clave}</claveAccesoComprobante></ec:autorizacionComprobante>'
        '</soapenv:Body></soapenv:Envelope>'
    )
    out = {"xml": None, "estado": "", "numero_comprobantes": None, "mensajes": [], "error_conexion": "", "raw_inicio": ""}
    try:
        raw = _soap(SRI[ambiente]["autorizacion"], soap, timeout=timeout)
    except Exception as ex:
        out["error_conexion"] = str(ex); return out
    out["raw_inicio"] = raw[:400]
    try:
        root = ET.fromstring(raw)
    except Exception as ex:
        out["error_conexion"] = "Respuesta no válida del SRI: " + str(ex); return out
    nc = root.find(".//{*}numeroComprobantes")
    if nc is not None and nc.text: out["numero_comprobantes"] = nc.text.strip()
    for m in root.findall(".//{*}mensaje"):
        ident = m.find("{*}identificador"); msj = m.find("{*}mensaje"); adic = m.find("{*}informacionAdicional")
        texto = " ".join(x.text.strip() for x in [ident, msj, adic] if x is not None and x.text)
        if texto: out["mensajes"].append(texto)
    for auth in root.findall(".//{*}autorizacion"):
        e = auth.find("{*}estado") or auth.find("estado")
        if e is not None and e.text: out["estado"] = e.text.strip()
        comp = auth.find("{*}comprobante") or auth.find("comprobante")
        if comp is not None and comp.text and "<" in comp.text:
            out["xml"] = comp.text.strip(); return out
    comp = root.find(".//{*}comprobante")
    if comp is not None and comp.text and "<" in comp.text:
        out["xml"] = comp.text.strip()
    return out

def _descargar_comprobante_sri(clave: str, ambiente: str):
    """Devuelve (xml_text|None, estado, mensaje) usando la consulta detallada."""
    d = _consultar_autorizacion_sri(clave, ambiente)
    if d["error_conexion"]:
        return (None, "ERROR_CONEXION", d["error_conexion"])
    if d["xml"]:
        return (d["xml"], d["estado"] or "AUTORIZADO", "")
    # Sin comprobante: armar mensaje explicativo con lo que dijo el SRI
    detalles = []
    if d["estado"]: detalles.append("estado SRI: " + d["estado"])
    if d["numero_comprobantes"] is not None: detalles.append("comprobantes: " + d["numero_comprobantes"])
    if d["mensajes"]: detalles.append("; ".join(d["mensajes"][:2]))
    return (None, d["estado"] or "NO_DISPONIBLE", " · ".join(detalles))

def _descargar_comprobante_sri_OLD(clave: str, ambiente: str):
    """Consulta la autorización del SRI por clave de acceso y devuelve el XML del comprobante
    (la factura interna). Devuelve (xml_text|None, estado, mensaje)."""
    soap = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"'
        ' xmlns:ec="http://ec.gob.sri.ws.autorizacion"><soapenv:Header/><soapenv:Body>'
        f'<ec:autorizacionComprobante><claveAccesoComprobante>{clave}</claveAccesoComprobante></ec:autorizacionComprobante>'
        '</soapenv:Body></soapenv:Envelope>'
    )
    try:
        raw = _soap(SRI[ambiente]["autorizacion"], soap, timeout=12)
    except Exception as ex:
        return (None, "ERROR_CONEXION", str(ex))
    try:
        root = ET.fromstring(raw)
    except Exception as ex:
        return (None, "ERROR_XML", str(ex))
    estado = ""
    for auth in root.findall(".//{*}autorizacion"):
        e = auth.find("{*}estado") or auth.find("estado")
        if e is not None and e.text: estado = e.text.strip()
        comp = auth.find("{*}comprobante") or auth.find("comprobante")
        if comp is not None and comp.text and "<" in comp.text:
            return (comp.text.strip(), estado or "AUTORIZADO", "")
    # Fallback: buscar comprobante en cualquier parte
    comp = root.find(".//{*}comprobante")
    if comp is not None and comp.text and "<" in comp.text:
        return (comp.text.strip(), estado or "AUTORIZADO", "")
    # Sin comprobante: recoger primer mensaje
    msg = ""
    m = root.find(".//{*}mensaje")
    if m is not None and m.text: msg = m.text.strip()
    return (None, estado or "NO_DISPONIBLE", msg)

# ════════════════════════════════════════════════════════════
# PIPELINE FACTURACIÓN ELECTRÓNICA
# ════════════════════════════════════════════════════════════
def _slog(eid, fid, accion, resultado, msg="", detalle=""):
    try:
        c = db(); c.execute("INSERT INTO sri_log (empresa_id,factura_id,fecha,accion,resultado,mensaje,detalle) VALUES (?,?,?,?,?,?,?)",
                            (eid,fid,now_ec(),accion,resultado,msg,str(detalle)[:3000])); c.commit(); c.close()
    except: pass

def _upd(fid, **kw):
    sql = ", ".join(f"{k}=?" for k in kw)
    c = db(); c.execute(f"UPDATE facturas SET {sql} WHERE id=?", list(kw.values())+[fid]); c.commit(); c.close()

def _validar_datos_emisor(emp) -> str:
    """Revisa los datos que el SRI exige del emisor antes de firmar.

    Devuelve "" si está todo bien, o el mensaje de lo que falta. Evita
    el error 35 (ARCHIVO NO CUMPLE ESTRUCTURA XML), que aparece cuando
    un campo obligatorio va vacío en el comprobante.
    """
    emp = emp or {}
    faltan = []
    if not str(emp.get("ruc") or "").strip():
        faltan.append("el RUC")
    if not str(emp.get("nombre") or "").strip():
        faltan.append("la razón social")
    if not str(emp.get("direccion") or "").strip():
        faltan.append("la dirección (el SRI la exige como dirMatriz)")
    if not str(emp.get("estab") or "").strip():
        faltan.append("el establecimiento")
    if not str(emp.get("pto_emi") or "").strip():
        faltan.append("el punto de emisión")
    if not str(emp.get("ambiente") or "").strip():
        faltan.append("el ambiente (Pruebas o Producción)")
    if not faltan:
        return ""
    if len(faltan) == 1:
        detalle = faltan[0]
    else:
        detalle = ", ".join(faltan[:-1]) + " y " + faltan[-1]
    return ("Faltan datos de la empresa: " + detalle + ". "
            "Vaya a Configuración → Datos de la empresa, complételos y guarde. "
            "Sin eso el SRI devuelve el comprobante con el error 35.")


def procesar_fe(fid: int, eid: int) -> dict:
    c = db()
    emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
    fac = rd(c.execute("SELECT * FROM facturas WHERE id=? AND empresa_id=?", (fid,eid)).fetchone())
    c.close()

    if not emp or not emp.get("facturacion_electronica"):
        return {"ok":False,"error":"Facturación electrónica no habilitada en Configuración"}
    _falta = _validar_datos_emisor(emp)
    if _falta:
        return {"ok":False,"etapa":"datos","error":_falta}
    if not fac:
        return {"ok":False,"error":f"Factura {fid} no encontrada"}
    if fac.get("estado_sri") == "AUTORIZADA" and fac.get("autorizacion"):
        return {"ok":True,"clave_acceso":fac["clave_acceso"],"autorizacion":fac["autorizacion"],
                "fecha_autorizacion":fac["fecha_autorizacion"],"ambiente":emp.get("ambiente","1"),"ya_autorizada":True}

    ambiente  = emp.get("ambiente","1")
    cert_path = emp.get("cert_path","")
    cert_pass = emp.get("cert_password","")
    comp      = BASE_DIR / "comprobantes" / _dir_emp(eid)
    comp.mkdir(parents=True, exist_ok=True)

    # ── Paso 1: Generar XML ──────────────────────────────────
    try:
        xml_str, clave = generar_xml(fid, eid)
        p = comp / "generados" / f"{clave}.xml"; p.parent.mkdir(exist_ok=True)
        p.write_text(xml_str, encoding="utf-8")
        _upd(fid, xml_path=str(p))
        _slog(eid, fid, "GENERAR_XML", "OK", clave[:20])
    except Exception as ex:
        _slog(eid, fid, "GENERAR_XML", "ERROR", str(ex))
        return {"ok":False,"etapa":"generacion","error":str(ex)}

    # ── Paso 2: Firmar ───────────────────────────────────────
    try:
        cert_path = str(_resolver_cert(emp, eid))
        xml_firmado = firmar_xml(xml_str, cert_path, cert_pass)
        fp = comp / "firmados" / f"{clave}.xml"; fp.parent.mkdir(exist_ok=True)
        fp.write_text(xml_firmado, encoding="utf-8")
        _slog(eid, fid, "FIRMAR_XML", "OK", Path(cert_path).name)
    except Exception as ex:
        _slog(eid, fid, "FIRMAR_XML", "ERROR", str(ex))
        _upd(fid, estado_sri="ERROR_FIRMA")
        return {"ok":False,"etapa":"firma","error":str(ex)}

    # ── Paso 3: Enviar al SRI ────────────────────────────────
    # EN_PROCESO_SRI: si el SRI ya lo recibió antes, NO se reenvía.
    # Reenviar una clave ya registrada hace que el SRI la devuelva y
    # el comprobante quedaba marcado como rechazado sin motivo.
    _ya_recibido = str(fac.get("estado_sri") or "").upper() in ("RECIBIDA", "EN_PROCESO")
    if _ya_recibido:
        log.info("El SRI ya había recibido %s; solo se consulta la autorización", clave[:20])
        res_env = {"estado": "RECIBIDA", "mensajes": [], "reenviado": False}
    else:
        _upd(fid, estado_sri="ENVIANDO")
        res_env = enviar_sri(xml_firmado, ambiente)
    _slog(eid, fid, "ENVIAR_SRI", res_env.get("estado","?"),
          (res_env.get("mensajes") or [{}])[0].get("mensaje",""),
          json.dumps(res_env, ensure_ascii=False))

    est_env = res_env.get("estado","")
    if est_env not in ["RECIBIDA","DEVUELTA"]:
        _upd(fid, estado_sri="ERROR_ENVIO")
        return {"ok":False,"etapa":"envio","error":est_env or "Error de conexión",
                "mensajes":res_env.get("mensajes",[]),"detalle":res_env}

    if est_env == "DEVUELTA":
        msgs = res_env.get("mensajes",[])
        duplicada = any("43" in m.get("identificador","") or
                        "registrado" in (m.get("mensaje","")+m.get("info","")).lower()
                        for m in msgs)
        if not duplicada and msgs:
            _upd(fid, estado_sri="DEVUELTA")
            return {"ok":False,"etapa":"envio","estado_sri":"DEVUELTA",
                    "error":"Comprobante DEVUELTO por el SRI",
                    "mensajes":msgs,"detalle":res_env}

    # ── Paso 4: Autorizar (con reintentos) ───────────────────
    _esperas = [3,5,8,12,20,30]
    for i, espera in enumerate(_esperas, 1):
        log.info("Consulta autorización %d/%d (espera %ds)", i, len(_esperas), espera)
        time.sleep(espera)
        res_auth = autorizar_sri(clave, ambiente)
        _slog(eid, fid, f"AUTORIZAR_{i}", res_auth.get("estado","?"),
              (res_auth.get("mensajes") or [{}])[0].get("mensaje",""),
              json.dumps(res_auth, ensure_ascii=False))
        estado = res_auth.get("estado","")
        if estado == "AUTORIZADO": break
        if estado in ["NO AUTORIZADO","RECHAZADO"]: break

    if res_auth.get("estado") == "AUTORIZADO":
        num_auth  = res_auth.get("numero_autorizacion") or clave
        fech_auth = res_auth.get("fecha_autorizacion")  or now_ec()
        _upd(fid, estado="AUTORIZADA", estado_sri="AUTORIZADA",
             autorizacion=num_auth, fecha_autorizacion=fech_auth)
        try:
            dst = comp / "autorizados" / f"{clave}.xml"; dst.parent.mkdir(exist_ok=True)
            if fp.exists(): fp.rename(dst)
        except: pass
        ride = _generar_ride(fid, eid, clave, num_auth, fech_auth, emp)
        log.info("✓ AUTORIZADA fac=%s auth=%s...", fid, num_auth[:20])
        _envio_auto_correo(eid, "factura", fid)
        return {"ok":True,"clave_acceso":clave,"autorizacion":num_auth,
                "fecha_autorizacion":fech_auth,"ambiente":ambiente,"ride":ride}
    else:
        msgs = res_auth.get("mensajes",[])
        err  = " | ".join(f"[{m.get('identificador') or m.get('tipo','')}] {m.get('mensaje','')} {m.get('info','')}" for m in msgs).strip("| ") or f"Estado: {res_auth.get('estado','')}"
        # ¿El SRI lo rechazó, o simplemente todavía no lo procesa?
        _est_a = str(res_auth.get("estado","")).upper()
        _pendiente = (_est_a in ("", "EN PROCESAMIENTO", "PPROCESAMIENTO", "PROCESANDO")
                      or "no encontrado" in err.lower()
                      or "numerocomprobantes=0" in err.lower().replace(" ", ""))
        if _pendiente:
            # Recibido pero aún sin autorizar: NO es un rechazo.
            _upd(fid, estado_sri="EN_PROCESO")
            return {"ok":False,"etapa":"autorizacion","estado_sri":"EN_PROCESO",
                    "en_proceso":True,"clave_acceso":clave,
                    "error":("El SRI recibió el comprobante pero todavía no lo autoriza. "
                             "No se perdió nada y NO hay que volver a emitirlo: espere unos "
                             "minutos y pulse Reintentar, que solo vuelve a consultar con la "
                             "misma clave. En fin de mes el SRI suele demorar más."),
                    "mensajes":msgs,"detalle":res_auth}
        _upd(fid, estado_sri="NO_AUTORIZADA")
        try:
            dst = comp / "rechazados" / f"{clave}.xml"; dst.parent.mkdir(exist_ok=True)
            if fp.exists(): fp.rename(dst)
        except: pass
        return {"ok":False,"etapa":"autorizacion","estado_sri":res_auth.get("estado",""),
                "error":err,"mensajes":msgs,"detalle":res_auth,"clave_acceso":clave}

# ════════════════════════════════════════════════════════════
# RIDE (Representación Impresa)
# ════════════════════════════════════════════════════════════


def _ride_css() -> str:
    """CSS compartido para todos los RIDEs — formato idéntico al SRI Ecuador oficial"""
    return """
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:Arial,Helvetica,sans-serif;font-size:10px;color:#000;background:#fff}
.page{width:210mm;margin:0 auto;padding:6mm 8mm}
.cab{display:flex;border:1px solid #000;min-height:90px}
.cab-logo{width:28%;border-right:1px solid #000;padding:8px;display:flex;align-items:center;justify-content:center}
.cab-logo img{max-width:100%;max-height:80px;width:auto;height:auto;object-fit:contain;display:block;margin:0 auto}
.cab-emisor{width:44%;border-right:1px solid #000;padding:7px 9px;text-align:center;display:flex;flex-direction:column;justify-content:center}
.cab-emisor .rs{font-size:12px;font-weight:bold;margin-bottom:4px;line-height:1.3}
.cab-emisor .d{font-size:9px;margin:1px 0;line-height:1.4}
.cab-right{width:28%;padding:7px 9px;display:flex;flex-direction:column;gap:2px}
.cab-right .tipo{font-size:11px;font-weight:bold;text-align:center;border:1px solid #000;padding:3px;margin-bottom:4px}
.cab-right .num{font-size:10px;font-weight:bold;text-align:center;margin-bottom:5px;font-family:monospace;letter-spacing:0.5px}
.cab-right .d{font-size:8.5px;margin:1px 0}
.cab-right .d b{font-weight:bold}
.clave-sec{border:1px solid #000;border-top:none;padding:5px 8px;text-align:center}
.clave-lbl{font-weight:bold;font-size:9px;text-align:left;margin-bottom:3px}
.clave-num{font-family:monospace;font-size:8.5px;word-break:break-all;letter-spacing:0.3px;text-align:center;margin-top:3px}
.amb-warn{border:1px solid #c8a000;border-top:none;background:#fffbcc;padding:3px 8px;font-size:9px;font-weight:bold;color:#856404;text-align:center}
.buy-sec{border:1px solid #000;border-top:none}
.buy-row{display:flex}
.buy-row+.buy-row{border-top:1px solid #ccc}
.buy-cell{flex:1;padding:4px 7px;border-right:1px solid #ccc}
.buy-cell:last-child{border-right:none}
.buy-cell.w2{flex:2}
.bc-lbl{font-size:7.5px;font-weight:bold;color:#444;text-transform:uppercase;letter-spacing:0.3px;margin-bottom:1px}
.bc-val{font-size:10px;font-weight:bold}
.items-wrap{border:1px solid #000;border-top:none}
table.it{width:100%;border-collapse:collapse}
table.it thead tr{background:#222;color:#fff}
table.it th{padding:5px 6px;font-size:8.5px;font-weight:bold;text-align:left}
table.it th.r{text-align:right}
table.it td{padding:4px 6px;font-size:9px;border-bottom:1px solid #eee;vertical-align:top}
table.it td.r{text-align:right}
table.it td.det{font-size:8px;color:#555;font-style:italic}
table.it tr:nth-child(even) td{background:#f8f8f8}
.bot{display:flex;border:1px solid #000;border-top:none}
.bot-left{flex:1;border-right:1px solid #000;padding:7px 9px}
.bot-right{width:230px;padding:7px 9px}
.sec-ttl{font-weight:bold;font-size:9px;border-bottom:1px solid #ccc;padding-bottom:3px;margin-bottom:5px}
.ia-row{display:flex;gap:8px;font-size:9px;padding:2px 0}
.ia-lbl{font-weight:bold;min-width:80px;color:#444}
.fp-row{display:flex;justify-content:space-between;font-size:9px;padding:2px 0;border-bottom:1px dotted #ddd}
.tot-row{display:flex;justify-content:space-between;font-size:9px;padding:2px 0;border-bottom:1px dotted #ddd}
.tot-row.grand{border-top:2px solid #000;border-bottom:none;margin-top:3px;padding-top:4px;font-size:12px;font-weight:bold}
.tot-lbl{color:#333}
.tot-val{font-family:monospace;font-weight:600}
.footer{margin-top:5px;font-size:8px;color:#777;text-align:center;border-top:1px solid #ddd;padding-top:4px}
@media print{@page{size:A4;margin:5mm} .page{width:100%;padding:2mm 4mm}}
"""


def _html_to_pdf(html_content: str, pdf_path) -> bool:
    """Convierte HTML a PDF usando xhtml2pdf"""
    try:
        from xhtml2pdf import pisa
        import io
        pdf_path = Path(pdf_path)
        pdf_path.parent.mkdir(parents=True, exist_ok=True)
        # Asegurar encoding correcto
        # Rellenar celdas vacías para evitar error NoneType en reportlab
        import re as _re
        html_fixed = _re.sub(r'<td([^>]*)>\s*</td>', r'<td>&nbsp;</td>', html_content)
        html_fixed = _re.sub(r'<th([^>]*)>\s*</th>', r'<th>&nbsp;</th>', html_fixed)
        html_bytes = html_fixed.encode("utf-8")
        result_file = open(str(pdf_path), "w+b")
        status = pisa.CreatePDF(src=io.BytesIO(html_bytes), dest=result_file, encoding="utf-8")
        result_file.close()
        if status.err:
            log.warning("xhtml2pdf reporto %d error(es)", status.err)
        sz = pdf_path.stat().st_size if pdf_path.exists() else 0
        if sz > 500:
            log.info("PDF OK: %s (%d KB)", pdf_path.name, sz//1024)
            return True
        log.warning("PDF vacio o corrupto: %d bytes", sz)
        return False
    except ImportError:
        log.info("xhtml2pdf no instalado")
        return False
    except Exception as ex:
        log.error("Error generando PDF: %s", ex, exc_info=True)
        return False

        return False

def _ride_prov_row(eid) -> str:
    """Fila 'RUC Proveedor: 0993394602001' para los RIDE con hoja de estilos."""
    try:
        nombre, ruc = _prov_sistema(eid)
        if not ruc:
            return ""
        return ('<div class="ia-row"><span class="ia-lbl">' + nombre +
                ':</span><span>' + ruc + '</span></div>')
    except Exception:
        return ""


def _ride_prov_html(eid) -> str:
    """Misma información, para el RIDE de factura que se arma con tablas."""
    try:
        nombre, ruc = _prov_sistema(eid)
        if not ruc:
            return ""
        return "<b>" + nombre + ":</b> " + ruc + "<br/>"
    except Exception:
        return ""


def _ride_guardar_pdf(html, pdf_path, doc=None, items=None, emp=None, titulo="FACTURA"):
    """Deja el PDF del RIDE en disco SIEMPRE que se pueda.

    Primero intenta xhtml2pdf (respeta el diseño del RIDE). Si no está
    instalado o falla, arma el PDF con reportlab, que ya es dependencia fija
    del sistema. Así la carpeta RIDE nunca se queda solo con los .html.
    """
    pdf_path = Path(pdf_path)
    # Un unico formato para todos los comprobantes: se arma siempre con
    # _ride_pdf_bytes. Antes se intentaba primero xhtml2pdf y cada tipo de
    # documento salia con un diseno distinto.
    try:
        if doc is not None:
            b = _ride_pdf_bytes(doc, items or [], emp or {}, titulo)
            if b:
                pdf_path.parent.mkdir(parents=True, exist_ok=True)
                pdf_path.write_bytes(b)
                log.info("RIDE PDF: %s (%d KB)", pdf_path.name, len(b)//1024)
                return str(pdf_path)
    except Exception as ex:
        log.warning("RIDE unificado fallo (%s); se intenta con xhtml2pdf", ex)
    try:
        if _html_to_pdf(html, pdf_path):
            return str(pdf_path)
    except Exception as ex:
        log.warning("xhtml2pdf tampoco pudo: %s", ex)
    try:
        if doc is None:
            return ""
        b = _ride_pdf_bytes(doc, items or [], emp or {}, titulo)
        if b:
            pdf_path.parent.mkdir(parents=True, exist_ok=True)
            pdf_path.write_bytes(b)
            log.info("RIDE PDF (reportlab): %s (%d KB)", pdf_path.name, len(b)//1024)
            return str(pdf_path)
    except Exception as ex:
        log.error("No se pudo generar el PDF del RIDE: %s", ex)
    return ""


def _ride_ruta_pdf(eid, clave, prefijo=""):
    """Ruta del PDF del RIDE para una clave de acceso."""
    nombre = (prefijo + "_" if prefijo else "") + str(clave) + ".pdf"
    return BASE_DIR / "comprobantes" / _dir_emp(eid) / "RIDE" / nombre


def _ride_datos_doc(eid, tipo, did):
    """Carga (doc, items, emp, titulo, prefijo, generador) para un comprobante."""
    tipo = (tipo or "fac").lower()
    c = db()
    emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
    doc, items, titulo, prefijo = None, [], "FACTURA", ""
    if tipo in ("fac", "factura"):
        doc = rd(c.execute("""SELECT f.*, cl.nombre as cli_nombre, cl.ruc_cedula,
                   cl.email as cli_email, cl.direccion as cli_dir
                   FROM facturas f LEFT JOIN clientes cl ON f.cliente_id=cl.id
                   WHERE f.id=? AND f.empresa_id=?""", (did, eid)).fetchone())
        if doc: items = rl(c.execute("SELECT * FROM factura_items WHERE factura_id=? ORDER BY id", (did,)).fetchall())
        titulo, prefijo = "FACTURA", ""
    elif tipo in ("nc", "nota_credito"):
        doc = rd(c.execute("""SELECT n.*, cl.nombre as cli_nombre, cl.ruc_cedula,
                   cl.email as cli_email, cl.direccion as cli_dir
                   FROM notas_credito n LEFT JOIN clientes cl ON n.cliente_id=cl.id
                   WHERE n.id=? AND n.empresa_id=?""", (did, eid)).fetchone())
        if doc: items = rl(c.execute("SELECT * FROM nota_credito_items WHERE nota_id=? ORDER BY id", (did,)).fetchall())
        titulo, prefijo = "NOTA DE CRÉDITO", "NC"
    elif tipo in ("gr", "guia"):
        doc = rd(c.execute("""SELECT g.*, cl.nombre as cli_nombre, cl.ruc_cedula,
                   cl.email as cli_email, cl.direccion as cli_dir
                   FROM guias_remision g LEFT JOIN clientes cl ON g.cliente_id=cl.id
                   WHERE g.id=? AND g.empresa_id=?""", (did, eid)).fetchone())
        if doc: items = rl(c.execute("SELECT * FROM guia_items WHERE guia_id=? ORDER BY id", (did,)).fetchall())
        titulo, prefijo = "GUÍA DE REMISIÓN", "GR"
    elif tipo in ("lc", "liquidacion"):
        doc = rd(c.execute("SELECT * FROM liquidaciones_compra WHERE id=? AND empresa_id=?", (did, eid)).fetchone())
        if doc: items = rl(c.execute("SELECT * FROM liquidacion_items WHERE liquidacion_id=? ORDER BY id", (did,)).fetchall())
        titulo, prefijo = "LIQUIDACIÓN DE COMPRA", "LC"
    c.close()
    return doc, items, emp, titulo, prefijo


def _ride_pdf_asegurar(eid, tipo, did):
    """Devuelve (bytes_pdf, nombre_archivo, error). Genera el PDF si falta y lo
    deja guardado en la carpeta RIDE de la empresa."""
    doc, items, emp, titulo, prefijo = _ride_datos_doc(eid, tipo, did)
    if not doc:
        return None, "", "Comprobante no encontrado"
    clave = str(doc.get("clave_acceso") or "").strip()
    num = str(doc.get("numero") or did)
    nombre_dl = "RIDE_" + (prefijo + "_" if prefijo else "") + num.replace("/", "-") + ".pdf"
    if not clave:
        return None, "", ("El comprobante todavía no tiene clave de acceso. "
                          "Primero debe procesarse en el SRI.")
    ruta = _ride_ruta_pdf(eid, clave, prefijo)
    if ruta.exists() and ruta.stat().st_size > 500:
        return ruta.read_bytes(), nombre_dl, ""
    # Regenerar el RIDE (crea el .html) y luego el PDF
    try:
        if tipo in ("fac", "factura"):
            _generar_ride(did, eid, clave, doc.get("autorizacion", ""), doc.get("fecha_autorizacion", ""), emp)
        elif tipo in ("nc", "nota_credito"):
            _generar_ride_nc(did, eid, clave, doc.get("autorizacion", ""), doc.get("fecha_autorizacion", ""), emp)
        elif tipo in ("gr", "guia"):
            _generar_ride_guia(did, eid, clave, doc.get("autorizacion", ""), doc.get("fecha_autorizacion", ""), emp)
        elif tipo in ("lc", "liquidacion"):
            _generar_ride_liquidacion(did, eid, doc, items, emp)
    except Exception as ex:
        log.warning("No se pudo regenerar el RIDE: %s", ex)
    if ruta.exists() and ruta.stat().st_size > 500:
        return ruta.read_bytes(), nombre_dl, ""
    # Último recurso: PDF directo con reportlab
    b = _ride_pdf_bytes(doc, items, emp, titulo)
    if b:
        try:
            ruta.parent.mkdir(parents=True, exist_ok=True)
            ruta.write_bytes(b)
        except Exception:
            pass
        return b, nombre_dl, ""
    return None, "", ("No se pudo generar el PDF. Falta la librería reportlab: "
                      "cierra el sistema y vuelve a abrirlo con INICIAR_SERVIDOR.bat "
                      "para que se instale sola.")


# ════════════════════════════════════════════════════════════
# DESGLOSE DE IVA
# Dos cosas distintas que suelen confundirse:
#  · tarifa por ítem  → cada producto puede grabar 15%, 5%, 0%…
#                       Antes se aplicaba UNA sola tarifa a toda la
#                       factura, así que un exento mezclado con uno
#                       gravado salía mal.
#  · precio con IVA incluido → la empresa digita el precio final y
#                       el sistema lo parte en base + IVA.
# El interruptor de lo segundo es por empresa: empresas.precios_incluyen_iva
# ════════════════════════════════════════════════════════════

def _fiva(v, dv=0.0):
    """Convierte a número sin reventar (safe_float es local del handler POST)."""
    try:
        if v is None or v == "":
            return dv
        return float(v)
    except Exception:
        return dv


def _emp_incluye_iva(emp) -> bool:
    try:
        return bool(int((emp or {}).get("precios_incluyen_iva", 0) or 0))
    except Exception:
        return False


def _tarifa_producto(c, eid, pid, emp):
    """Tarifa de IVA de un producto. Si no existe, la de la empresa."""
    por_defecto = _fiva((emp or {}).get("iva_porcentaje", 15), 15)
    if not pid:
        return por_defecto
    try:
        p = rd(c.execute("SELECT graba_iva, iva_porcentaje FROM productos WHERE id=? AND empresa_id=?",
                         (pid, eid)).fetchone())
    except Exception:
        p = None
    if not p:
        return por_defecto
    if int(p.get("graba_iva", 1) or 0) == 0:
        return 0.0
    t = _fiva(p.get("iva_porcentaje"), por_defecto)
    return t if t > 0 else 0.0


def _tarifa_item(c, eid, it, emp):
    """Tarifa del ítem: la que venga explícita, si no la del producto."""
    for k in ("iva_tarifa", "iva_porcentaje", "tarifa"):
        if it.get(k) not in (None, ""):
            try:
                v = float(it[k])
                if v >= 0:
                    return v
            except Exception:
                pass
    if str(it.get("graba_iva", "")) == "0":
        return 0.0
    return _tarifa_producto(c, eid, it.get("producto_id"), emp)


def _desglosar_items(c, eid, items, emp, incluye_iva=None):
    """Calcula base, IVA y total de cada ítem y los totales del documento.

    Devuelve (items_calculados, totales). Cada ítem sale SIEMPRE con
    precio_unitario y subtotal SIN IVA, que es lo que exige el SRI en el XML.
    """
    if incluye_iva is None:
        incluye_iva = _emp_incluye_iva(emp)
    salida, por_tarifa = [], {}
    for it in (items or []):
        it = dict(it)
        cant = _fiva(it.get("cantidad", 1), 1)
        pu   = _fiva(it.get("precio_unitario", 0))
        desc = _fiva(it.get("descuento", 0))
        tar  = _tarifa_item(c, eid, it, emp)
        factor = 1.0 + (tar / 100.0)
        if incluye_iva and tar > 0:
            # El precio digitado trae el IVA adentro: se lo saca
            pu_neto = round(pu / factor, 6)
            bruto   = round(cant * pu - desc, 6)
            base    = round(bruto / factor, 2)
            desc_neto = round(desc / factor, 2)
        else:
            pu_neto = round(pu, 6)
            base    = round(cant * pu - desc, 2)
            desc_neto = round(desc, 2)
        if base < 0:
            base = 0.0
        iva_val = round(base * tar / 100.0, 2)
        it.update({"cantidad": cant, "precio_unitario": pu_neto,
                   "descuento": desc_neto, "subtotal": base,
                   "iva_tarifa": tar, "iva_valor": iva_val,
                   "total_con_iva": round(base + iva_val, 2)})
        salida.append(it)
        g = por_tarifa.setdefault(tar, {"base": 0.0, "iva": 0.0})
        g["base"] = round(g["base"] + base, 2)
        g["iva"]  = round(g["iva"] + iva_val, 2)
    base_t = round(sum(g["base"] for g in por_tarifa.values()), 2)
    iva_t  = round(sum(g["iva"] for g in por_tarifa.values()), 2)
    tot = {
        "subtotal": base_t,
        "iva": iva_t,
        "total": round(base_t + iva_t, 2),
        "descuento": round(sum(_fiva(x.get("descuento", 0)) for x in salida), 2),
        "por_tarifa": {("%g" % k): v for k, v in sorted(por_tarifa.items())},
        "base_gravada": round(sum(v["base"] for k, v in por_tarifa.items() if k > 0), 2),
        "base_cero": round(sum(v["base"] for k, v in por_tarifa.items() if k <= 0), 2),
        "incluye_iva": bool(incluye_iva),
    }
    return salida, tot


def _tarifas_factura(c, fid, items, emp):
    """Agrupa los ítems guardados de una factura por tarifa, para XML y RIDE.

    Si la factura es anterior a la v3.16.0 sus ítems no tienen tarifa
    guardada (-1): en ese caso se usa la tarifa del documento, igual que antes.
    """
    por_defecto = _iva_pct_doc(emp) if callable(globals().get("_iva_pct_doc")) else 15.0
    grupos, salida = {}, []
    for it in items:
        it = dict(it)
        try:
            t = float(it.get("iva_tarifa", -1))
        except Exception:
            t = -1.0
        if t < 0:
            t = por_defecto
        base = round(_fiva(it.get("subtotal", 0)), 2)
        val = it.get("iva_valor")
        iva = round(_fiva(val), 2) if val not in (None, "") and _fiva(val) > 0 \
              else round(base * t / 100.0, 2)
        it["_tarifa"] = t
        it["_iva"] = iva
        salida.append(it)
        g = grupos.setdefault(t, {"base": 0.0, "iva": 0.0})
        g["base"] = round(g["base"] + base, 2)
        g["iva"]  = round(g["iva"] + iva, 2)
    return salida, grupos


# ════════════════════════════════════════════════════════════
# SELLO DIGITAL
# La empresa sube la FOTO de su sello de caucho sobre papel y el
# sistema le quita el fondo, dejando solo la tinta con el fondo
# transparente. Después ese PNG se estampa sobre cualquier PDF.
# Es un módulo aparte de la firma electrónica: el sello NO tiene
# valor legal por sí solo, es la imagen; la validez la da la firma.
# ════════════════════════════════════════════════════════════

SELLO_MAX_PX = 1400          # lado máximo del PNG guardado
SELLO_POSICIONES = ("sup-izq", "sup-der", "inf-izq", "inf-der", "centro")


def _sello_pil():
    """Carga Pillow o explica cómo instalarlo."""
    try:
        from PIL import Image, ImageChops, ImageEnhance
        return {"Image": Image, "ImageChops": ImageChops, "ImageEnhance": ImageEnhance}
    except Exception:
        raise ValueError("Falta la librería Pillow en esta computadora. "
                         "Cierra el sistema y ábrelo con INICIAR_SERVIDOR.bat "
                         "para que se instale sola.")


def _sello_recortar(img_bytes: bytes, op: dict):
    """Quita el fondo de la foto del sello y devuelve un PNG transparente.

    Modos:
      · claro — todo lo que sea claro (papel) se vuelve transparente.
               Sirve para cualquier color de tinta, incluida la negra.
      · color — sólo se conserva lo que tenga color. Elimina también
               las sombras grises del papel, pero no sirve para sellos
               en tinta negra o gris.
    """
    P = _sello_pil()
    Image = P["Image"]; ImageEnhance = P["ImageEnhance"]
    import io as _io

    op = op or {}
    modo   = str(op.get("modo", "claro") or "claro").lower()
    umbral = int(_fiva(op.get("umbral"), 215))            # 120-250
    suave  = max(1, int(_fiva(op.get("suavidad"), 45)))   # ancho del degradado
    forma  = str(op.get("forma", "auto") or "auto").lower()
    satur  = _fiva(op.get("saturacion"), 1.35)
    contr  = _fiva(op.get("contraste"), 1.15)
    margen = int(_fiva(op.get("margen"), 6))

    try:
        im = Image.open(_io.BytesIO(img_bytes))
    except Exception as ex:
        raise ValueError("No se pudo leer la imagen: " + str(ex))
    im = im.convert("RGBA")
    if max(im.size) > SELLO_MAX_PX:
        f = SELLO_MAX_PX / float(max(im.size))
        im = im.resize((max(1, int(im.size[0] * f)), max(1, int(im.size[1] * f))), Image.LANCZOS)

    an, al = im.size
    px = im.load()
    solido = max(0, umbral - suave)

    for y in range(al):
        for x in range(an):
            r, g, b, a = px[x, y]
            if a == 0:
                continue
            luz = max(r, g, b)
            mn  = min(r, g, b)
            sat = luz - mn                       # 0 = gris puro
            if modo == "color":
                # Conserva la tinta con color; descarta papel y sombras grises
                fuerza = max(sat - 22, 0) * 6
                if luz > umbral:
                    fuerza = min(fuerza, max(0, (255 - luz) * 8))
                nuevo = max(0, min(255, int(fuerza)))
            else:
                # Conserva todo lo que sea más oscuro que el papel
                if luz >= umbral:
                    nuevo = 0
                elif luz <= solido:
                    nuevo = 255
                else:
                    nuevo = int(255 * (umbral - luz) / float(umbral - solido))
            px[x, y] = (r, g, b, int(nuevo * (a / 255.0)))

    # Recorte a lo que quedó visible
    caja = im.getbbox()
    if not caja:
        raise ValueError("No quedó nada visible. Baja el umbral o usa el modo 'claro'.")
    x0, y0, x1, y1 = caja
    x0 = max(0, x0 - margen); y0 = max(0, y0 - margen)
    x1 = min(an, x1 + margen); y1 = min(al, y1 + margen)
    im = im.crop((x0, y0, x1, y1))

    # Forma circular: los sellos de caucho suelen ser redondos y así se
    # elimina cualquier resto de papel en las esquinas.
    if forma in ("circulo", "círculo", "redondo"):
        from PIL import ImageDraw
        an2, al2 = im.size
        lado = min(an2, al2)
        mascara = Image.new("L", (an2, al2), 0)
        d = ImageDraw.Draw(mascara)
        cx, cy = an2 / 2.0, al2 / 2.0
        rad = lado / 2.0
        d.ellipse([cx - rad, cy - rad, cx + rad, cy + rad], fill=255)
        alfa = im.getchannel("A")
        from PIL import ImageChops
        im.putalpha(ImageChops.multiply(alfa, mascara))
        caja = im.getbbox()
        if caja:
            im = im.crop(caja)

    # Realce: la foto de un sello suele salir lavada
    if satur and satur != 1.0:
        rgb = ImageEnhance.Color(im.convert("RGB")).enhance(satur)
        im = Image.merge("RGBA", (*rgb.split(), im.getchannel("A")))
    if contr and contr != 1.0:
        rgb = ImageEnhance.Contrast(im.convert("RGB")).enhance(contr)
        im = Image.merge("RGBA", (*rgb.split(), im.getchannel("A")))

    sal = _io.BytesIO()
    im.save(sal, format="PNG", optimize=True)
    return sal.getvalue(), im.size


def _sello_ruta(eid):
    d = BASE_DIR / "sellos" / _dir_emp(eid)
    d.mkdir(parents=True, exist_ok=True)
    return d / "sello.png"


def _sello_config(emp):
    """Configuración del sello con sus valores por defecto."""
    emp = emp or {}
    return {
        "activo":    int(_fiva(emp.get("sello_activo"), 0)) == 1,
        "posicion":  str(emp.get("sello_pos") or "inf-der"),
        "escala":    _fiva(emp.get("sello_escala"), 1.0) or 1.0,
        "opacidad":  _fiva(emp.get("sello_opacidad"), 0.9) or 0.9,
        "pagina":    str(emp.get("sello_pagina") or "ultima"),
    }


def _sello_caja(W, H, posicion, an_px, al_px, escala):
    """Ubicación y tamaño del sello en puntos PDF."""
    base = min(W, H) * 0.22 * max(0.2, min(escala, 4.0))
    prop = (al_px / float(an_px)) if an_px else 1.0
    an = base
    al = base * prop
    if al > min(W, H) * 0.6:
        al = min(W, H) * 0.6
        an = al / prop if prop else al
    m = 26.0
    pos = (posicion or "inf-der").lower()
    if pos == "sup-izq":   x, y = m, H - al - m
    elif pos == "sup-der": x, y = W - an - m, H - al - m
    elif pos == "inf-izq": x, y = m, m
    elif pos == "centro":  x, y = (W - an) / 2.0, (H - al) / 2.0
    else:                  x, y = W - an - m, m
    return x, y, an, al


def _sellar_pdf_bytes(pdf_bytes: bytes, png_bytes: bytes, op: dict):
    """Estampa el PNG del sello sobre el PDF y devuelve el PDF nuevo."""
    if not pdf_bytes[:5] == b"%PDF-":
        raise ValueError("El archivo no es un PDF válido.")
    if not png_bytes:
        raise ValueError("La empresa todavía no tiene un sello cargado.")
    try:
        from pypdf import PdfReader, PdfWriter
    except Exception:
        raise ValueError("Falta la librería pypdf en esta computadora. "
                         "Cierra el sistema y ábrelo con INICIAR_SERVIDOR.bat.")
    from reportlab.pdfgen import canvas as _canvas
    from reportlab.lib.utils import ImageReader
    from PIL import Image
    import io as _io

    op = op or {}
    posicion = str(op.get("posicion", "inf-der") or "inf-der")
    escala   = _fiva(op.get("escala"), 1.0) or 1.0
    opac     = max(0.05, min(_fiva(op.get("opacidad"), 0.9) or 0.9, 1.0))
    pagina   = str(op.get("pagina", "ultima") or "ultima").lower()

    img = Image.open(_io.BytesIO(png_bytes)).convert("RGBA")
    an_px, al_px = img.size

    lector = PdfReader(_io.BytesIO(pdf_bytes))
    total = len(lector.pages)
    if pagina == "todas":
        objetivo = set(range(total))
    elif pagina in ("primera", "1"):
        objetivo = {0}
    else:
        try:
            n = int(pagina)
            objetivo = {max(0, min(total - 1, n - 1))}
        except Exception:
            objetivo = {total - 1}

    escritor = PdfWriter()
    for i, pag in enumerate(lector.pages):
        if i in objetivo:
            W = float(pag.mediabox.width); H = float(pag.mediabox.height)
            x, y, an, al = _sello_caja(W, H, posicion, an_px, al_px, escala)
            buf = _io.BytesIO()
            cv = _canvas.Canvas(buf, pagesize=(W, H))
            cv.saveState()
            try:
                cv.setFillAlpha(opac); cv.setStrokeAlpha(opac)
            except Exception:
                pass
            cv.drawImage(ImageReader(img), x, y, width=an, height=al, mask="auto")
            cv.restoreState()
            cv.showPage(); cv.save(); buf.seek(0)
            capa = PdfReader(buf).pages[0]
            pag.merge_page(capa)
        escritor.add_page(pag)
    sal = _io.BytesIO()
    escritor.write(sal)
    return sal.getvalue()


def _generar_ride(fid, eid, clave, autorizacion, fecha_auth, emp):
    c = db()
    f = rd(c.execute("""SELECT f.*, cl.nombre as cli_nombre, cl.ruc_cedula,
        cl.email as cli_email, cl.telefono as cli_tel, cl.celular as cli_cel,
        cl.direccion as cli_dir, cl.tipo_identificacion, u.nombre as usuario_nombre
        FROM facturas f LEFT JOIN clientes cl ON f.cliente_id=cl.id
        LEFT JOIN usuarios u ON f.usuario_id=u.id
        WHERE f.id=? AND f.empresa_id=?""", (fid, eid)).fetchone())
    items = rl(c.execute("SELECT * FROM factura_items WHERE factura_id=?", (fid,)).fetchall())
    c.close()
    if not f: return ""
    fac = f
    logo_b64 = emp.get("logo_base64","") or ""
    logo_img = '<img src="'+logo_b64+'" style="max-height:80px;max-width:180px"/>' if logo_b64 else ""
    iva_pct = _iva_pct_doc(f)
    sub = float(f["subtotal"]); iva_v = float(f["iva"]); tot = float(f["total"])
    notas_f = f.get("notas","") or ""
    cli_email = f.get("cli_email","") or ""
    fp_map = {"01":"Sin Utilizacion del Sist. Financiero","15":"Compensacion de Deudas","16":"Tarjeta de Debito","17":"Dinero Electronico","18":"Tarjeta Prepago","19":"Tarjeta de Credito","20":"Otros con Utilizacion del Sist. Financiero","21":"Endoso de Titulos"}
    fp_lbl = fp_map.get(str(f.get("forma_pago","01") or "01"), "Sin Utilizacion del Sist. Financiero")
    amb = "PRODUCCION" if emp.get("ambiente")=="2" else "PRUEBAS"
    bc_uri = barcode_data_uri(clave, 30)
    irows = ""
    for it in items:
        ca = "%.2f" % float(it.get("cantidad",1))
        pu = "%.6f" % float(it.get("precio_unitario",0))
        ds = "$%.2f" % float(it.get("descuento",0))
        st = "$%.2f" % float(it.get("subtotal",0))
        irows += ('<tr><td style="border:1px solid #ccc;padding:4px;text-align:center;font-size:9px">'+str(it.get("codigo","") or "&nbsp;")+'</td>'
            '<td style="border:1px solid #ccc;padding:4px;text-align:center;font-size:9px">'+ca+'</td>'
            '<td style="border:1px solid #ccc;padding:4px;font-size:9px">'+str(it.get("descripcion",""))+'</td>'
            '<td style="border:1px solid #ccc;padding:4px;font-size:9px">&nbsp;</td>'
            '<td style="border:1px solid #ccc;padding:4px;text-align:right;font-size:9px">'+pu+'</td>'
            '<td style="border:1px solid #ccc;padding:4px;text-align:right;font-size:9px">'+ds+'</td>'
            '<td style="border:1px solid #ccc;padding:4px;text-align:right;font-size:9px">'+st+'</td></tr>')
    s2 = "$%.2f" % sub; iv2 = "$%.2f" % iva_v; t2 = "$%.2f" % tot; ip = "%.0f" % iva_pct
    # Subtotales por tarifa, tomados de los ítems (una factura puede mezclar
    # 15% y 0%). En facturas anteriores a la v3.16.0 los ítems no traen tarifa
    # guardada y todo cae en la tarifa del documento, igual que antes.
    _its_r, _grp_r = _tarifas_factura(None, fid, items, f)
    def _gr(t):
        return "$%.2f" % float(_grp_r.get(t, {}).get("base", 0.0))
    def _gi(t):
        return "$%.2f" % float(_grp_r.get(t, {}).get("iva", 0.0))
    _sub_pral = _gr(iva_pct); _iva_pral = _gi(iva_pct)
    _sub_5 = _gr(5.0); _iva_5 = _gi(5.0)
    _sub_0 = _gr(0.0)
    _desc_r = "$%.2f" % float(f.get("descuento") or 0)
    html = ('<!DOCTYPE html><html><head><meta charset="UTF-8"><title>RIDE '+f["numero"]+'</title>'
        '<style>@page{size:A4;margin:10mm}body{font-family:Arial,sans-serif;font-size:10px;color:#000;margin:0;padding:0}'
        'table{border-collapse:collapse}'
        '.hb{background-color:#1a56db;color:white;font-weight:bold;padding:5px 8px;font-size:9px;border:1px solid #1a56db;text-align:center}'
        '.tb{background-color:#1a56db;color:white;font-weight:bold;padding:5px 8px;font-size:11px}'
        '</style></head><body>'
        '<table width="100%" cellpadding="0" cellspacing="0"><tr>'
        '<td width="38%" style="vertical-align:top;border:2px solid #333;padding:10px;text-align:center">'
        +logo_img+
        '<div style="font-size:9px;line-height:1.5;text-align:left;margin-top:6px">'
        '<b style="font-size:10px">'+str(emp.get("nombre",""))+'</b><br/>'
        '<b>RUC:</b> '+str(emp.get("ruc",""))+'<br/>'
        '<b>Matriz:</b> '+str(emp.get("ciudad",""))+ ' / '+str(emp.get("direccion",""))+'<br/>'
        +('Telefono: '+str(emp.get("telefono",""))+'<br/>' if emp.get("telefono") else '')+
        '<b>Obl. contabilidad:</b> '+str(emp.get("obligado_contabilidad","NO"))+'</div></td>'
        '<td width="62%" style="vertical-align:top;border:2px solid #333;border-left:none;padding:0">'
        '<table width="100%" cellpadding="0" cellspacing="0">'
        '<tr><td style="padding:6px 10px;border-bottom:1px solid #333;background:#f5f5f5">'
        '<b style="font-size:14px">FACTURA</b>'
        '<span style="float:right;font-size:13px;font-weight:bold">No. '+f["numero"]+'</span></td></tr>'
        '<tr><td style="padding:6px 10px;font-size:9px;line-height:1.6">'
        '<b>N. de Autorizacion:</b><br/>'
        '<span style="font-family:monospace;font-size:7.5px">'+str(autorizacion)+'</span><br/>'
        '<b>Fecha y hora de Autorizacion:</b><br/>'+str(fecha_auth)+'<br/>'
        '<b>Ambiente:</b> '+amb+' &nbsp; <b>Emision:</b> NORMAL</td></tr>'
        '<tr><td style="padding:6px 10px;border-top:1px solid #ccc;text-align:center">'
        '<span style="font-size:8px;color:#666"><b>Clave de Acceso:</b></span><br/>'
        '<img src="'+bc_uri+'" width="320" height="35" style="margin:3px 0"/><br/>'
        '<span style="font-family:monospace;font-size:7px;letter-spacing:1px;color:#444">'+clave+'</span>'
        '</td></tr></table></td></tr></table>'
        '<table width="100%" cellpadding="0" cellspacing="0"><tr>'
        '<td width="65%" style="border:2px solid #333;border-top:none;padding:5px 8px;font-size:9px">'
        '<span style="color:#666;font-size:8px">Razon Social:</span><br/><b style="font-size:10px">'+str(f.get("cli_nombre",""))+'</b></td>'
        '<td width="35%" style="border:2px solid #333;border-top:none;border-left:none;padding:5px 8px;font-size:9px">'
        '<span style="color:#666;font-size:8px">RUC/CI:</span><br/><b style="font-size:10px">'+str(f.get("ruc_cedula",""))+'</b></td></tr>'
        '<tr><td style="border:1px solid #999;border-top:none;padding:4px 8px;font-size:9px">'
        '<span style="color:#666;font-size:8px">Direccion:</span> '+str(f.get("cli_dir",""))+'</td>'
        '<td style="border:1px solid #999;border-top:none;border-left:none;padding:4px 8px;font-size:9px">'
        '<span style="color:#666;font-size:8px">Telefono:</span> '+str(f.get("cli_tel",""))+'</td></tr>'
        '<tr><td style="border:1px solid #999;border-top:none;padding:4px 8px;font-size:9px">'
        '<span style="color:#666;font-size:8px">Fecha Emision:</span> <b>'+str(f.get("fecha",""))+'</b></td>'
        '<td style="border:1px solid #999;border-top:none;border-left:none;padding:4px 8px;font-size:9px">'
        '<span style="color:#666;font-size:8px">Correo:</span> '+cli_email+'</td></tr></table>'
        '<table width="100%" cellpadding="0" cellspacing="0"><tr>'
        '<th class="hb" width="10%">Codigo Principal</th><th class="hb" width="8%">Cantidad</th>'
        '<th class="hb">Descripcion</th><th class="hb" width="10%">Detalles Adicionales</th>'
        '<th class="hb" width="12%">Precio Unitario</th><th class="hb" width="9%">Descuento</th>'
        '<th class="hb" width="10%">Total</th></tr>'
        +irows+'</table>'
        '<table width="100%" cellpadding="0" cellspacing="0"><tr>'
        '<td width="55%" style="border:1px solid #333;padding:6px;font-size:9px;vertical-align:top">'
        '<b>Informacion Adicional</b><br/>'+(notas_f+'<br/>' if notas_f else '')+
        _ride_prov_html(eid)+
        '<br/><b>Formas de pago</b>'
        '<table width="100%"><tr>'
        '<td style="font-size:9px">'+fp_lbl+'</td>'
        '<td style="font-size:9px;text-align:right">'+t2+'</td>'
        '<td style="font-size:9px;text-align:right">0 dias</td></tr></table></td>'
        '<td width="45%" style="border:1px solid #333;border-left:none;padding:0;vertical-align:top;font-size:9px">'
        '<table width="100%">'
        '<tr><td style="padding:3px 6px;border-bottom:1px solid #eee">Subtotal Sin Impuestos:</td><td style="padding:3px 6px;text-align:right;border-bottom:1px solid #eee">'+s2+'</td></tr>'
        '<tr><td style="padding:3px 6px;border-bottom:1px solid #eee">Subtotal '+ip+'%:</td><td style="padding:3px 6px;text-align:right;border-bottom:1px solid #eee">'+_sub_pral+'</td></tr>'
        '<tr><td style="padding:3px 6px;border-bottom:1px solid #eee">Subtotal 5%:</td><td style="padding:3px 6px;text-align:right;border-bottom:1px solid #eee">'+_sub_5+'</td></tr>'
        '<tr><td style="padding:3px 6px;border-bottom:1px solid #eee">Subtotal 0%:</td><td style="padding:3px 6px;text-align:right;border-bottom:1px solid #eee">'+_sub_0+'</td></tr>'
        '<tr><td style="padding:3px 6px;border-bottom:1px solid #eee">Subtotal No Objeto IVA:</td><td style="padding:3px 6px;text-align:right;border-bottom:1px solid #eee">$0.00</td></tr>'
        '<tr><td style="padding:3px 6px;border-bottom:1px solid #eee">Descuentos:</td><td style="padding:3px 6px;text-align:right;border-bottom:1px solid #eee">'+_desc_r+'</td></tr>'
        '<tr><td style="padding:3px 6px;border-bottom:1px solid #eee">ICE:</td><td style="padding:3px 6px;text-align:right;border-bottom:1px solid #eee">$0.00</td></tr>'
        '<tr><td style="padding:3px 6px;border-bottom:1px solid #eee">IVA '+ip+'%:</td><td style="padding:3px 6px;text-align:right;border-bottom:1px solid #eee">'+_iva_pral+'</td></tr>'
        '<tr><td style="padding:3px 6px;border-bottom:1px solid #eee">IVA 5%:</td><td style="padding:3px 6px;text-align:right;border-bottom:1px solid #eee">'+_iva_5+'</td></tr>'
        '<tr><td style="padding:3px 6px;border-bottom:1px solid #eee">Servicio %:</td><td style="padding:3px 6px;text-align:right;border-bottom:1px solid #eee">$0.00</td></tr>'
        '<tr><td class="tb">Valor Total:</td><td class="tb" style="text-align:right">'+t2+'</td></tr>'
        '</table></td></tr></table>'
        '<p style="text-align:center;font-size:8px;color:#999;margin-top:6px;border-top:1px solid #eee;padding-top:4px">'
        +str(emp.get("nombre",""))+' | RUC: '+str(emp.get("ruc",""))+' | Comprobante Electronico autorizado por el SRI Ecuador</p>'
        '</body></html>')
    ride_p = BASE_DIR / "comprobantes" / _dir_emp(eid) / "RIDE" / f"{clave}.html"
    ride_p.parent.mkdir(parents=True, exist_ok=True)
    ride_p.write_text(html, encoding="utf-8")
    pdf_p = ride_p.with_suffix(".pdf")
    _ride_guardar_pdf(html, pdf_p, f, items, emp, "FACTURA")
    _upd(fid, ride_path=str(ride_p))
    return str(ride_p)




def _generar_ride_nc(nid, eid, clave, autorizacion, fecha_auth, emp) -> str:
    """RIDE Nota de Crédito — mismo formato oficial SRI"""
    c = db()
    n = rd(c.execute("""SELECT nc.*, cl.nombre as cli_nombre, cl.ruc_cedula,
                        cl.email as cli_email, cl.direccion as cli_dir,
                        cl.telefono as cli_tel, cl.celular as cli_cel, cl.tipo_identificacion
                        FROM notas_credito nc LEFT JOIN clientes cl ON nc.cliente_id=cl.id
                        WHERE nc.id=?""", (nid,)).fetchone())
    items = rl(c.execute("SELECT * FROM nota_credito_items WHERE nota_id=?", (nid,)).fetchall())
    c.close()
    if not n: return ""

    amb       = "PRUEBAS" if (emp.get("ambiente","1")) == "1" else "PRODUCCION"
    logo_b64  = emp.get("logo_base64","") or ""
    logo_html = f'<img src="{logo_b64}" style="max-height:80px;max-width:250px;object-fit:contain"/>' if logo_b64 else ""
    iva_pct   = _iva_pct_doc(n)
    subtotal  = float(n["subtotal"])
    iva_val   = float(n["iva"])
    total     = float(n["total"])
    tipo_id_lbl = {"04":"RUC","05":"Cédula","06":"Pasaporte","07":"Consumidor Final","08":"ID Exterior"}.get(
        n.get("tipo_identificacion","05"), "RUC/Cédula")

    filas = ""
    for it in items:
        filas += f"""<tr>
          <td>{it.get('codigo','') or ''}</td>
          <td class="r">{float(it['cantidad']):.4f}</td>
          <td>{it['descripcion']}</td>
          <td class="det"></td>
          <td class="r">{float(it['precio_unitario']):.6f}</td>
          <td class="r">${float(it.get('descuento') or 0):.2f}</td>
          <td class="r">${float(it['subtotal']):.2f}</td>
        </tr>"""

    html = f"""<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8">
<title>RIDE NC - {n['numero']}</title>
<style>{_ride_css()}</style>
</head><body><div class="page">
<div class="cab">
  <div class="cab-logo">{logo_html}</div>
  <div class="cab-emisor">
    <div class="rs">{emp.get('nombre','')}</div>
    <div class="d"><b>RUC:</b> {emp.get('ruc','')}</div>
    <div class="d"><b>Matriz:</b> {emp.get('ciudad','')} / {emp.get('direccion','')}</div>
    {'<div class="d"><b>Correo:</b> ' + emp.get('email','') + '</div>' if emp.get('email') else ''}
    {'<div class="d"><b>Teléfono:</b> ' + emp.get('telefono','') + '</div>' if emp.get('telefono') else ''}
    <div class="d"><b>Obligado a llevar contabilidad:</b> {emp.get('obligado_contabilidad','NO')}</div>
  </div>
  <div class="cab-right">
    <div class="tipo">NOTA DE CRÉDITO</div>
    <div class="num">No. {n['numero']}</div>
    <div class="d"><b>Número de Autorización:</b></div>
    <div class="d" style="font-family:monospace;font-size:7.5px;word-break:break-all">{autorizacion}</div>
    <div class="d" style="margin-top:3px"><b>Fecha y hora de Autorización:</b></div>
    <div class="d">{fecha_auth}</div>
    <div class="d" style="margin-top:3px"><b>Ambiente:</b> {amb}</div>
    <div class="d"><b>Emisión:</b> NORMAL</div>
    <div class="d"><b>Fact. Ref.:</b> {n.get('factura_ref_numero','—')}</div>
  </div>
</div>
<div class="clave-sec">
  <div class="clave-lbl">Clave de Acceso:</div>
  <div style="text-align:center;margin:3px 0">
    <img src="{barcode_data_uri(clave, 42)}" style="max-width:100%;height:auto"/>
  </div>
  <div class="clave-num">{clave}</div>
</div>
{'<div class="amb-warn">⚠ AMBIENTE DE PRUEBAS — No válido como documento tributario</div>' if amb=='PRUEBAS' else ''}
<div class="buy-sec">
  <div class="buy-row">
    <div class="buy-cell w2"><div class="bc-lbl">Razón Social / Nombres y Apellidos</div><div class="bc-val">{n.get('cli_nombre','')}</div></div>
    <div class="buy-cell"><div class="bc-lbl">{tipo_id_lbl}</div><div class="bc-val">{n.get('ruc_cedula','')}</div></div>
    <div class="buy-cell"><div class="bc-lbl">Fecha Emisión</div><div class="bc-val">{n['fecha']}</div></div>
  </div>
  <div class="buy-row">
    <div class="buy-cell"><div class="bc-lbl">Cod. Doc. Modificado</div><div class="bc-val">01</div></div>
    <div class="buy-cell w2"><div class="bc-lbl">Num. Doc. Modificado</div><div class="bc-val">{n.get('factura_ref_numero','')}</div></div>
    <div class="buy-cell"><div class="bc-lbl">Motivo</div><div class="bc-val">{n.get('motivo','')}</div></div>
  </div>
</div>
<div class="items-wrap">
<table class="it">
  <thead><tr>
    <th style="width:11%">Código Principal</th>
    <th class="r" style="width:8%">Cantidad</th>
    <th style="width:24%">Descripción</th>
    <th style="width:13%">Detalles Adicionales</th>
    <th class="r" style="width:12%">Precio Unitario</th>
    <th class="r" style="width:9%">Descuento</th>
    <th class="r" style="width:11%">Total</th>
  </tr></thead>
  <tbody>{filas}</tbody>
</table>
</div>
<div class="bot">
  <div class="bot-left">
    <div class="sec-ttl">Información Adicional</div>
    {_ride_prov_row(eid)}
    <div class="ia-row"><span class="ia-lbl">Tipo NC:</span><span>{n.get('tipo','')}</span></div>
    <div class="ia-row"><span class="ia-lbl">Motivo:</span><span>{n.get('motivo','')}</span></div>
    <div class="sec-ttl" style="margin-top:8px">Valor Modificado</div>
    <div class="fp-row"><span>Valor modificación</span><span>${total:.2f}</span></div>
  </div>
  <div class="bot-right">
    <div class="tot-row"><span class="tot-lbl">Subtotal Sin Impuestos:</span><span class="tot-val">${subtotal:.2f}</span></div>
    <div class="tot-row"><span class="tot-lbl">Subtotal {iva_pct:.0f}%:</span><span class="tot-val">${subtotal:.2f}</span></div>
    <div class="tot-row"><span class="tot-lbl">Subtotal 0%:</span><span class="tot-val">$0.00</span></div>
    <div class="tot-row"><span class="tot-lbl">Descuentos:</span><span class="tot-val">$0.00</span></div>
    <div class="tot-row"><span class="tot-lbl">ICE:</span><span class="tot-val">$0.00</span></div>
    <div class="tot-row"><span class="tot-lbl">IVA {iva_pct:.0f}%:</span><span class="tot-val">${iva_val:.2f}</span></div>
    <div class="tot-row grand"><span class="tot-lbl">Valor Total NC:</span><span class="tot-val">${total:.2f}</span></div>
  </div>
</div>
<div class="footer">{emp.get('nombre','')} | RUC: {emp.get('ruc','')} | Nota de Crédito Electrónica autorizada por el SRI Ecuador</div>
</div></body></html>"""

    ride_p = BASE_DIR / "comprobantes" / _dir_emp(eid) / "RIDE" / f"NC_{clave}.html"
    ride_p.parent.mkdir(parents=True, exist_ok=True)
    ride_p.write_text(html, encoding="utf-8")
    pdf_p = ride_p.with_suffix(".pdf")
    _ride_guardar_pdf(html, pdf_p, n, items, emp, "NOTA DE CRÉDITO")
    _upd_nc(nid, ride_path=str(ride_p))
    return str(ride_p)


def _generar_ride_guia(gid, eid, clave, autorizacion, fecha_auth, emp) -> str:
    """RIDE Guía de Remisión — formato oficial SRI A4"""
    c = db()
    g = rd(c.execute("""SELECT gr.*, cl.nombre as cli_nombre, cl.ruc_cedula,
                        cl.email as cli_email, cl.direccion as cli_dir
                        FROM guias_remision gr LEFT JOIN clientes cl ON gr.cliente_id=cl.id
                        WHERE gr.id=?""", (gid,)).fetchone())
    items = rl(c.execute("SELECT * FROM guia_items WHERE guia_id=?", (gid,)).fetchall())
    c.close()
    if not g: return ""

    amb       = "PRUEBAS" if (emp.get("ambiente","1")) == "1" else "PRODUCCION"
    logo_b64  = emp.get("logo_base64","") or ""
    logo_html = f'<img src="{logo_b64}" style="max-height:80px;max-width:250px;object-fit:contain"/>' if logo_b64 else ""

    filas = ""
    for it in items:
        filas += f"""<tr>
          <td>{it.get('codigo','') or ''}</td>
          <td class="r">{float(it['cantidad']):.4f}</td>
          <td>{it['descripcion']}</td>
          <td class="det"></td>
        </tr>"""

    html = f"""<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8">
<title>RIDE GR - {g['numero']}</title>
<style>{_ride_css()}
.gr-sec{{border:1px solid #000;border-top:none;padding:6px 9px}}
.gr-row{{display:flex;gap:6px;margin-bottom:3px;font-size:9px;flex-wrap:wrap}}
.gr-lbl{{font-weight:bold;min-width:110px;color:#444;flex-shrink:0}}
</style>
</head><body><div class="page">
<div class="cab">
  <div class="cab-logo">{logo_html}</div>
  <div class="cab-emisor">
    <div class="rs">{emp.get('nombre','')}</div>
    <div class="d"><b>RUC:</b> {emp.get('ruc','')}</div>
    <div class="d"><b>Matriz:</b> {emp.get('ciudad','')} / {emp.get('direccion','')}</div>
    {'<div class="d"><b>Correo:</b> ' + emp.get('email','') + '</div>' if emp.get('email') else ''}
    {'<div class="d"><b>Teléfono:</b> ' + emp.get('telefono','') + '</div>' if emp.get('telefono') else ''}
    <div class="d"><b>Obligado a llevar contabilidad:</b> {emp.get('obligado_contabilidad','NO')}</div>
  </div>
  <div class="cab-right">
    <div class="tipo">GUÍA DE REMISIÓN</div>
    <div class="num">No. {g['numero']}</div>
    <div class="d"><b>Número de Autorización:</b></div>
    <div class="d" style="font-family:monospace;font-size:7.5px;word-break:break-all">{autorizacion}</div>
    <div class="d" style="margin-top:3px"><b>Fecha y hora de Autorización:</b></div>
    <div class="d">{fecha_auth}</div>
    <div class="d" style="margin-top:3px"><b>Ambiente:</b> {amb}</div>
    <div class="d"><b>Emisión:</b> NORMAL</div>
  </div>
</div>
<div class="clave-sec">
  <div class="clave-lbl">Clave de Acceso:</div>
  <div style="text-align:center;margin:3px 0">
    <img src="{barcode_data_uri(clave, 42)}" style="max-width:100%;height:auto"/>
  </div>
  <div class="clave-num">{clave}</div>
</div>
{'<div class="amb-warn">⚠ AMBIENTE DE PRUEBAS — No válido como documento tributario</div>' if amb=='PRUEBAS' else ''}
<div class="buy-sec">
  <div class="buy-row">
    <div class="buy-cell w2"><div class="bc-lbl">Razón Social Destinatario</div><div class="bc-val">{g.get('cli_nombre','')}</div></div>
    <div class="buy-cell"><div class="bc-lbl">RUC/Cédula</div><div class="bc-val">{g.get('ruc_cedula','')}</div></div>
    <div class="buy-cell"><div class="bc-lbl">Fecha Inicio Traslado</div><div class="bc-val">{g.get('fecha_inicio','')}</div></div>
  </div>
  <div class="buy-row">
    <div class="buy-cell w2"><div class="bc-lbl">Dirección Destino</div><div class="bc-val">{g.get('dir_destino','')}</div></div>
    <div class="buy-cell"><div class="bc-lbl">Fecha Fin Traslado</div><div class="bc-val">{g.get('fecha_fin','')}</div></div>
    <div class="buy-cell"><div class="bc-lbl">Doc. Sustento</div><div class="bc-val">{g.get('factura_ref_numero','—')}</div></div>
  </div>
</div>
<div class="gr-sec">
  <div class="gr-row"><span class="gr-lbl">Motivo de traslado:</span><span>{g.get('motivo_traslado','')}</span>
    <span class="gr-lbl" style="margin-left:20px">Ruta:</span><span>{g.get('ruta','')}</span></div>
  <div class="gr-row"><span class="gr-lbl">Dirección de partida:</span><span>{g.get('dir_partida','')}</span></div>
</div>
<div class="gr-sec" style="border-top:1px solid #ccc">
  <b style="font-size:9px">DATOS DEL TRANSPORTISTA</b>
  <div class="gr-row" style="margin-top:4px">
    <span class="gr-lbl">RUC Transportista:</span><span>{g.get('transportista_ruc','')}</span>
    <span class="gr-lbl" style="margin-left:10px">Nombre:</span><span>{g.get('transportista_nombre','')}</span>
    <span class="gr-lbl" style="margin-left:10px">Placa:</span>
    <span style="font-size:14px;font-weight:bold;letter-spacing:2px">{g.get('placa','')}</span>
  </div>
</div>
<div class="items-wrap" style="border-top:1px solid #000">
<table class="it">
  <thead><tr>
    <th style="width:14%">Código Principal</th>
    <th class="r" style="width:10%">Cantidad</th>
    <th style="width:42%">Descripción de la Mercadería</th>
    <th style="width:22%">Detalles Adicionales</th>
  </tr></thead>
  <tbody>{filas}</tbody>
</table>
</div>
<div class="bot">
  <div class="bot-left">
    <div class="sec-ttl">Información Adicional</div>
    {_ride_prov_row(eid)}
    {f'<div class="ia-row"><span class="ia-lbl">Observaciones:</span><span>{g.get("notas","")}</span></div>' if g.get("notas") else ''}
    <div class="ia-row"><span class="ia-lbl">Dir. Partida:</span><span>{g.get('dir_partida','')}</span></div>
    <div class="ia-row"><span class="ia-lbl">Dir. Destino:</span><span>{g.get('dir_destino','')}</span></div>
  </div>
  <div class="bot-right">
    <div style="text-align:center;padding:12px 8px">
      <div style="font-size:9px;font-weight:bold;margin-bottom:3px">Firma y Sello del Transportista</div>
      <div style="border-bottom:1px solid #000;width:90%;margin:0 auto;height:40px"></div>
      <div style="font-size:8px;margin-top:3px;color:#555">{g.get('transportista_nombre','')}</div>
      <div style="font-size:9px;font-weight:bold;margin-top:12px;margin-bottom:3px">Firma y Sello del Destinatario</div>
      <div style="border-bottom:1px solid #000;width:90%;margin:0 auto;height:40px"></div>
      <div style="font-size:8px;margin-top:3px;color:#555">{g.get('cli_nombre','')}</div>
    </div>
  </div>
</div>
<div class="footer">{emp.get('nombre','')} | RUC: {emp.get('ruc','')} | Guía de Remisión Electrónica autorizada por el SRI Ecuador</div>
</div></body></html>"""

    ride_p = BASE_DIR / "comprobantes" / _dir_emp(eid) / "RIDE" / f"GR_{clave}.html"
    ride_p.parent.mkdir(parents=True, exist_ok=True)
    ride_p.write_text(html, encoding="utf-8")
    _ride_guardar_pdf(html, ride_p.with_suffix(".pdf"), g, items, emp, "GUÍA DE REMISIÓN")
    try:
        _upd_guia(gid, ride_path=str(ride_p))
    except Exception:
        pass
    return str(ride_p)

# ════════════════════════════════════════════════════════════

# ════════════════════════════════════════════════════════════
# NOTA DE CRÉDITO  — XML v1.1.0 + Pipeline SRI  (codDoc=04)
# Conforme al esquema XSD oficial SRI Ecuador v2.31
# ════════════════════════════════════════════════════════════

def _d2(v) -> str:
    """Formatea decimal con exactamente 2 decimales (requerido por SRI)"""
    return f"{float(v):.2f}"

def _d6(v) -> str:
    """Formatea decimal con exactamente 6 decimales (para cantidades y precios)"""
    return f"{float(v):.6f}"

def _lim(s: str, n: int) -> str:
    """Trunca string al límite del XSD y elimina caracteres inválidos XML"""
    s = (s or "").strip()
    # Reemplazar caracteres que el SRI rechaza
    for bad, good in [('&','&amp;'),('<','&lt;'),('\n',' '),('\r',' '),('\t',' ')]:
        s = s.replace(bad, good)
    return s[:n]

def _clave_sri(fecha: str, ruc: str, ambiente: str,
               estab: str, pto: str, sec: str, cod_doc: str) -> str:
    """
    Genera clave de acceso de 49 dígitos según especificación SRI:
    [ddmmyyyy(8)] [codDoc(2)] [ruc(13)] [ambiente(1)] [serie(6)] [secuencial(9)] [codigo(8)] [tipoEmision(1)] [verificador(1)]
    """
    f   = fecha_xml(fecha).replace("/", "")          # ddmmyyyy
    cod = str(uuid.uuid4().int)[:8].zfill(8)          # código numérico aleatorio
    serie = (str(estab).zfill(3) + str(pto).zfill(3))[:6]
    c48 = (f + cod_doc.zfill(2) + ruc + ambiente
           + serie + str(sec).zfill(9) + cod + "1")[:48]
    # Verificador módulo 11
    s = sum(int(c48[i]) * [2,3,4,5,6,7][(47-i) % 6] for i in range(48))
    r = 11 - (s % 11)
    v = r if r <= 9 else (0 if r == 11 else 1)
    return c48 + str(v)


def _upd_nc(nid, **kw):
    """Actualiza campos de una nota de crédito"""
    sql = ", ".join(f"{k}=?" for k in kw)
    c = db()
    c.execute(f"UPDATE notas_credito SET {sql} WHERE id=?", list(kw.values()) + [nid])
    c.commit(); c.close()


def _upd_guia(gid, **kw):
    """Actualiza campos de una guía de remisión"""
    sql = ", ".join(f"{k}=?" for k in kw)
    c = db()
    c.execute(f"UPDATE guias_remision SET {sql} WHERE id=?", list(kw.values()) + [gid])
    c.commit(); c.close()


def _generar_xml_nc(nid: int, eid: int) -> tuple[str, str]:
    """
    Genera XML de Nota de Crédito conforme al esquema XSD SRI v1.1.0
    
    Reglas críticas del SRI:
    - contribuyenteEspecial: OMITIR si está vacío (tag vacío = rechazo)
    - valorModificacion: es el TOTAL de la NC (subtotal + IVA)
    - codigoPorcentaje: 4=15%, 2=12%, 0=0%, 6=No objeto IVA, 7=Exento IVA
    - numDocModificado: debe tener formato NNN-NNN-NNNNNNNNN
    - Los decimales de cantidad/precio: 6 decimales
    - Los decimales de valores monetarios: 2 decimales
    """
    c = db()
    n = rd(c.execute("""
        SELECT nc.*, 
               cl.nombre as cli_nombre, cl.ruc_cedula,
               cl.tipo_identificacion, cl.email as cli_email,
               cl.direccion as cli_dir, cl.telefono as cli_tel
        FROM notas_credito nc
        LEFT JOIN clientes cl ON nc.cliente_id = cl.id
        WHERE nc.id = ? AND nc.empresa_id = ?
    """, (nid, eid)).fetchone())
    items = rl(c.execute(
        "SELECT * FROM nota_credito_items WHERE nota_id = ? ORDER BY id",
        (nid,)
    ).fetchall())
    emp = rd(c.execute("SELECT * FROM empresas WHERE id = ?", (eid,)).fetchone())
    c.close()

    if not n: raise ValueError(f"Nota de crédito {nid} no encontrada")
    if not emp: raise ValueError(f"Empresa {eid} no encontrada")
    if not items: raise ValueError("La nota de crédito no tiene ítems")

    # ── Secuencial ────────────────────────────────────────────
    num = (n["numero"] or "").strip()
    # Formato: NC001-001-000000001 o 001-001-000000001
    partes = num.replace("NC","").split("-")
    sec = partes[-1].zfill(9) if partes else "000000001"

    ambiente = str(emp["ambiente"] or "1")

    # ── Clave de acceso ───────────────────────────────────────
    clave_ok = False
    clave_existente = str(n.get("clave_acceso") or "")
    if len(clave_existente) == 49 and clave_existente.isdigit():
        # Verificar que cod_doc sea 04 (posiciones 8-9 base-0)
        if clave_existente[8:10] == "04":
            clave = clave_existente
            clave_ok = True
        else:
            log.warning("NC %d: clave con cod_doc=%s, regenerando con 04",
                        nid, clave_existente[8:10])
    if not clave_ok:
        clave = _clave_sri(n["fecha"], emp["ruc"], ambiente,
                           emp["estab"] or "001", emp["pto_emi"] or "001",
                           sec, cod_doc="04")
        _upd_nc(nid, clave_acceso=clave)
        log.info("NC %d: nueva clave de acceso generada con codDoc=04", nid)

    # ── IVA ───────────────────────────────────────────────────
    iva_pct   = _iva_pct_doc(n)
    # codigoPorcentaje: 4=15%, 2=12%, 0=0%, 5=5%, 8=8%
    cod_pct   = _cod_pct_sri(iva_pct)

    # ── Construir XML ─────────────────────────────────────────
    root = ET.Element("notaCredito", id="comprobante", version="1.1.0")

    # ── infoTributaria ────────────────────────────────────────
    it = ET.SubElement(root, "infoTributaria")
    _t(it, "ambiente",       ambiente)
    _t(it, "tipoEmision",    "1")
    _t(it, "razonSocial",    _lim(emp["nombre"] or "", 300))
    nc_comercial = (emp.get("nombre_comercial") or emp["nombre"] or "").strip()
    if nc_comercial and nc_comercial != emp["nombre"]:
        _t(it, "nombreComercial", _lim(nc_comercial, 300))
    _t(it, "ruc",            (emp["ruc"] or "").strip())
    _t(it, "claveAcceso",    clave)
    _t(it, "codDoc",         "04")
    _t(it, "estab",          str(emp["estab"] or "001").zfill(3)[:3])
    _t(it, "ptoEmi",         str(emp["pto_emi"] or "001").zfill(3)[:3])
    _t(it, "secuencial",     sec.zfill(9))
    _t(it, "dirMatriz",      _lim(emp["direccion"] or "", 300))

    # ── infoNotaCredito ───────────────────────────────────────
    info = ET.SubElement(root, "infoNotaCredito")

    _t(info, "fechaEmision",       fecha_xml(n["fecha"]))
    _t(info, "dirEstablecimiento", _lim(emp["direccion"] or "", 300))

    # Identificación del comprador
    tipo_id = (n.get("tipo_identificacion") or "05").strip()
    ruc_ced = (n.get("ruc_cedula") or "").strip()

    # Validar y normalizar identificación
    if not ruc_ced or ruc_ced in ("9999999999999","0000000000000",""):
        tipo_id = "07"; ruc_ced = "9999999999999"
    elif len(ruc_ced) == 10 and ruc_ced.isdigit():
        tipo_id = "05"   # Cédula
    elif len(ruc_ced) == 13 and ruc_ced.isdigit():
        tipo_id = "04"   # RUC
    elif tipo_id == "06":
        pass             # Pasaporte — usar como está
    else:
        # Longitud inválida — usar consumidor final
        log.warning("NC %d: identificación inválida (%s), usando consumidor final", nid, ruc_ced)
        tipo_id = "07"; ruc_ced = "9999999999999"

    _t(info, "tipoIdentificacionComprador", tipo_id)
    _t(info, "razonSocialComprador",
       _lim(n.get("cli_nombre") or "CONSUMIDOR FINAL", 300))
    _t(info, "identificacionComprador", ruc_ced)

    # contribuyenteEspecial: SOLO si tiene valor — tag vacío rechaza
    cont_esp = str(emp.get("contribuyente_especial") or "").strip()
    if cont_esp:
        _t(info, "contribuyenteEspecial", cont_esp[:300])

    _t(info, "obligadoContabilidad",
       "SI" if str(emp.get("obligado_contabilidad","NO")).upper() in ("SI","SÍ","YES") else "NO")

    # Documento sustento
    _t(info, "codDocModificado",      "01")  # 01 = Factura

    # Número documento: debe ser NNN-NNN-NNNNNNNNN
    num_doc = (n.get("factura_ref_numero") or "").strip()
    if not num_doc or not re.match(r'^\d{3}-\d{3}-\d{9}$', num_doc):
        if num_doc and "-" in num_doc:
            # Intentar normalizar
            partes_nd = num_doc.replace("FAC","").strip().split("-")
            if len(partes_nd) >= 3:
                num_doc = f"{partes_nd[0].zfill(3)}-{partes_nd[1].zfill(3)}-{partes_nd[2].zfill(9)}"
            else:
                num_doc = "001-001-000000001"
        else:
            num_doc = "001-001-000000001"
    _t(info, "numDocModificado",      num_doc)
    _t(info, "fechaEmisionDocSustento", fecha_xml(n["fecha"]))

    # Totales
    subtotal = round(float(n.get("subtotal") or 0), 2)
    iva_val  = round(float(n.get("iva") or 0), 2)
    total    = round(float(n.get("total") or 0), 2)

    _t(info, "totalSinImpuestos", _d2(subtotal))
    _t(info, "valorModificacion", _d2(total))    # TOTAL con IVA
    _t(info, "moneda",            "DOLAR")

    # ORDEN EXACTO XSD SRI infoNotaCredito v1.1.0:
    # totalSinImpuestos → valorModificacion → moneda → totalConImpuestos → motivo
    #
    # IMPORTANTE: En NC el nodo se llama <totalConImpuestos>/<totalImpuesto>
    # (diferente a Factura que usa <impuestos>/<impuesto>)
    # El campo <tarifa> NO va en totalImpuesto de NC
    # El campo <descuento> NO va en totalImpuesto de NC
    totalConImps = ET.SubElement(info, "totalConImpuestos")
    totalImp     = ET.SubElement(totalConImps, "totalImpuesto")
    _t(totalImp, "codigo",           "2")       # 2 = IVA
    _t(totalImp, "codigoPorcentaje", cod_pct)   # 4=15% | 2=12% | 0=0%
    _t(totalImp, "baseImponible",    _d2(subtotal))
    _t(totalImp, "valor",            _d2(iva_val))

    # motivo al final de infoNotaCredito (orden del XSD)
    _t(info, "motivo", _lim(n.get("motivo") or "Nota de crédito", 300))

    # ── detalles ──────────────────────────────────────────────
    dets_el = ET.SubElement(root, "detalles")
    for it2 in items:
        det     = ET.SubElement(dets_el, "detalle")

        # codigoInterno: max 25 chars, sin caracteres especiales
        cod_int = str(it2.get("codigo") or "").strip()
        if not cod_int:
            cod_int = str(it2.get("descripcion") or "")[:25]
        cod_int = re.sub(r'[^a-zA-Z0-9\-_./]', '', cod_int)[:25] or "001"

        _t(det, "codigoInterno",         cod_int)
        _t(det, "descripcion",           _lim(it2["descripcion"], 300))
        _t(det, "cantidad",              _d6(it2["cantidad"]))
        _t(det, "precioUnitario",        _d6(it2["precio_unitario"]))
        _t(det, "descuento",             _d2(float(it2.get("descuento") or 0)))
        _t(det, "precioTotalSinImpuesto",_d2(float(it2["subtotal"])))

        # Impuestos del detalle
        imps_det = ET.SubElement(det, "impuestos")
        imp_d    = ET.SubElement(imps_det, "impuesto")
        _t(imp_d, "codigo",           "2")
        _t(imp_d, "codigoPorcentaje", cod_pct)
        _t(imp_d, "tarifa",           str(iva_pct))
        _t(imp_d, "baseImponible",    _d2(float(it2["subtotal"])))
        val_iva_d = round(float(it2["subtotal"]) * iva_pct / 100, 2)
        _t(imp_d, "valor",            _d2(val_iva_d))

    # ── infoAdicional (opcional) ──────────────────────────────
    ia_campos = []
    email = (n.get("cli_email") or "").strip()
    tel   = (n.get("cli_tel") or "").strip()
    if email: ia_campos.append(("email", email[:300]))
    if tel:   ia_campos.append(("telefono", tel[:300]))

    if ia_campos:
        ia_el = ET.SubElement(root, "infoAdicional")
        for nombre, valor in ia_campos[:3]:  # máx 3 campos
            cam = ET.SubElement(ia_el, "campoAdicional")
            cam.set("nombre", nombre)
            cam.text = valor

    _xml_prov_sistema(root, eid)
    xml_str = '<?xml version="1.0" encoding="UTF-8"?>' + \
              ET.tostring(root, encoding="unicode")
    return xml_str, clave


def _procesar_nc(nid: int, eid: int) -> dict:
    """
    Pipeline completo de Nota de Crédito:
    1. Generar XML conforme XSD SRI v1.1.0
    2. Firmar con XAdES-BES (enveloped-signature)
    3. Enviar al WebService de recepción SRI
    4. Consultar WebService de autorización SRI
    5. Actualizar estado en BD
    """
    c   = db()
    emp = rd(c.execute("SELECT * FROM empresas WHERE id = ?", (eid,)).fetchone())
    nc  = rd(c.execute(
        "SELECT * FROM notas_credito WHERE id = ? AND empresa_id = ?", (nid, eid)
    ).fetchone())
    c.close()

    if not emp:
        return {"ok": False, "error": "Empresa no encontrada"}
    if not emp.get("facturacion_electronica"):
        return {"ok": False, "error": "Facturación electrónica no está habilitada para esta empresa. Actívala en Configuración."}
    if not nc:
        return {"ok": False, "error": f"Nota de crédito #{nid} no encontrada"}

    # Si ya está autorizada, devolver la autorización existente
    if (nc.get("estado_sri") == "AUTORIZADA" and
            nc.get("autorizacion") and nc.get("autorizacion") != nc.get("clave_acceso")):
        return {
            "ok": True, "ya_autorizada": True,
            "clave_acceso":      nc["clave_acceso"],
            "autorizacion":      nc["autorizacion"],
            "fecha_autorizacion": nc["fecha_autorizacion"],
        }

    ambiente  = str(emp.get("ambiente") or "1")
    cert_path = str(emp.get("cert_path") or "")
    cert_pass = str(emp.get("cert_password") or "")
    comp_dir  = BASE_DIR / "comprobantes" / _dir_emp(eid)

    # ── PASO 1: Generar XML ───────────────────────────────────
    try:
        xml_str, clave = _generar_xml_nc(nid, eid)
        gp = comp_dir / "generados" / f"{clave}.xml"
        gp.parent.mkdir(parents=True, exist_ok=True)
        gp.write_text(xml_str, encoding="utf-8")
        _slog(eid, nid, "NC_XML_GENERADO", "OK", clave[:20])
        log.info("NC %d: XML generado OK, clave=%s", nid, clave[:20])
    except Exception as ex:
        _slog(eid, nid, "NC_XML_GENERADO", "ERROR", str(ex))
        log.error("NC %d: Error generando XML: %s", nid, ex)
        return {"ok": False, "etapa": "generacion", "error": str(ex)}

    # ── PASO 2: Firmar XML ────────────────────────────────────
    try:
        cert_path = str(_resolver_cert(emp, eid))
        xml_firmado = firmar_xml(xml_str, cert_path, cert_pass)
        fp = comp_dir / "firmados" / f"{clave}.xml"
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(xml_firmado, encoding="utf-8")
        _slog(eid, nid, "NC_XML_FIRMADO", "OK")
        log.info("NC %d: XML firmado OK", nid)
    except Exception as ex:
        _slog(eid, nid, "NC_XML_FIRMADO", "ERROR", str(ex))
        _upd_nc(nid, estado_sri="ERROR_FIRMA")
        return {"ok": False, "etapa": "firma", "error": str(ex)}

    # ── PASO 3: Enviar al SRI ─────────────────────────────────
    res_env = enviar_sri(xml_firmado, ambiente)
    _slog(eid, nid, "NC_ENVIO_SRI",
          res_env.get("estado", "?"), "", json.dumps(res_env, ensure_ascii=False))
    log.info("NC %d: envío SRI estado=%s msgs=%d",
             nid, res_env.get("estado"), len(res_env.get("mensajes", [])))

    estado_env = res_env.get("estado", "")

    if estado_env == "DEVUELTA":
        # El SRI rechazó el XML — mostrar errores detallados
        msgs = res_env.get("mensajes", [])
        err  = _fmt_msgs_sri(msgs) or "El SRI rechazó el comprobante (DEVUELTA)"
        _upd_nc(nid, estado_sri="DEVUELTA")
        return {
            "ok":       False,
            "etapa":    "envio",
            "error":    err,
            "mensajes": msgs,
            "raw_xml":  res_env.get("raw_xml", ""),
            "detalle":  res_env,
        }
    elif estado_env not in ("RECIBIDA", "DEVUELTA"):
        _upd_nc(nid, estado_sri="ERROR_ENVIO")
        return {
            "ok":      False,
            "etapa":   "envio",
            "error":   f"Error de conexión con el SRI: {estado_env or 'sin respuesta'}",
            "mensajes": res_env.get("mensajes", []),
            "raw_xml": res_env.get("raw_xml", ""),
        }

    # ── PASO 4: Consultar autorización ────────────────────────
    # El SRI puede tardar hasta 60 segundos en procesar
    res_auth = None
    tiempos_espera = [3, 5, 8, 12, 15]  # Total ~43 segundos

    for intento, espera in enumerate(tiempos_espera, 1):
        time.sleep(espera)
        res_auth = autorizar_sri(clave, ambiente)
        _slog(eid, nid, f"NC_AUTORIZACION_{intento}",
              res_auth.get("estado", "?"), "", json.dumps(res_auth, ensure_ascii=False))
        log.info("NC %d: intento %d autorización — estado=%s comp=%s",
                 nid, intento, res_auth.get("estado"),
                 res_auth.get("numero_comprobantes"))
        if res_auth.get("estado") in ("AUTORIZADO", "NO AUTORIZADO", "RECHAZADO"):
            break

    # ── PASO 5: Procesar resultado ────────────────────────────
    estado_auth = res_auth.get("estado", "DESCONOCIDO")

    if estado_auth == "AUTORIZADO":
        na = (res_auth.get("numero_autorizacion") or "").strip()
        fa =  res_auth.get("fecha_autorizacion") or now_ec()

        # NOTA IMPORTANTE: En PRODUCCIÓN el SRI puede devolver el mismo
        # numero de clave de acceso como numeroAutorizacion — esto es VÁLIDO.
        # Solo bloqueamos si NO hay absolutamente ningún número de autorización.
        if not na:
            # El SRI dijo AUTORIZADO pero no entregó ningún número
            # En este caso usamos la clave de acceso como autorización (comportamiento oficial)
            na = clave
            log.warning("NC %d: SRI AUTORIZADO sin numeroAutorizacion explícito, usando clave de acceso", nid)

        # ✅ Autorizado correctamente
        _upd_nc(nid,
                estado="AUTORIZADA", estado_sri="AUTORIZADA",
                autorizacion=na, fecha_autorizacion=fa)
        _envio_auto_correo(eid, "nc", nid)

        # Mover XML firmado → autorizados
        try:
            dst = comp_dir / "autorizados" / f"{clave}.xml"
            dst.parent.mkdir(parents=True, exist_ok=True)
            if fp.exists(): fp.rename(dst)
        except Exception as ex:
            log.warning("NC %d: no pudo mover XML autorizado: %s", nid, ex)

        # Aplicar efecto en Cuentas por Cobrar
        _aplicar_nc_cxc(nid, eid)

        # Generar RIDE
        try:
            emp_r = rd(db().execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
            _generar_ride_nc(nid, eid, clave, na, fa, emp_r)
        except Exception as ex:
            log.warning("NC %d: no pudo generar RIDE: %s", nid, ex)

        log.info("NC %d: AUTORIZADA — auth=%s", nid, na[:20])
        return {
            "ok":               True,
            "clave_acceso":     clave,
            "autorizacion":     na,
            "fecha_autorizacion": fa,
        }

    else:
        # NO AUTORIZADO o RECHAZADO
        msgs   = res_auth.get("mensajes", [])
        raw    = res_auth.get("raw_xml", "")[:3000]
        n_comp = res_auth.get("numero_comprobantes", -1)

        if n_comp == 0:
            err = ("El SRI no encontró el comprobante (numeroComprobantes=0). "
                   "El XML fue recibido pero fue rechazado en validación. "
                   "Verifica en https://srienlinea.sri.gob.ec con la clave de acceso: " + clave)
        elif msgs:
            err = _fmt_msgs_sri(msgs)
        elif estado_auth == "DESCONOCIDO":
            err = ("El SRI no respondió con un estado claro después de varios intentos. "
                   "Verifica manualmente en https://srienlinea.sri.gob.ec")
        else:
            err = f"Estado SRI: {estado_auth}"

        _upd_nc(nid, estado_sri="NO_AUTORIZADA")

        # Mover a rechazados
        try:
            dst = comp_dir / "rechazados" / f"{clave}.xml"
            dst.parent.mkdir(parents=True, exist_ok=True)
            if fp.exists(): fp.rename(dst)
        except: pass

        log.warning("NC %d: NO AUTORIZADA — estado=%s err=%s", nid, estado_auth, err[:100])
        return {
            "ok":       False,
            "etapa":    "autorizacion",
            "error":    err,
            "mensajes": msgs,
            "raw_xml":  raw,
            "detalle":  res_auth,
        }


def _aplicar_nc_cxc(nid: int, eid: int):
    """Registra el efecto de la NC autorizada en Cuentas por Cobrar"""
    try:
        c  = db()
        nc = rd(c.execute("SELECT * FROM notas_credito WHERE id = ?", (nid,)).fetchone())
        if not nc or not nc.get("cliente_id"):
            c.close(); return
        cid = nc["cliente_id"]
        last = rd(c.execute(
            "SELECT saldo FROM cuentas_cobrar WHERE empresa_id=? AND cliente_id=? ORDER BY id DESC LIMIT 1",
            (eid, cid)
        ).fetchone())
        saldo_ant = float(last["saldo"]) if last else 0.0
        nuevo_saldo = round(saldo_ant - float(nc["total"]), 2)
        c.execute("""
            INSERT INTO cuentas_cobrar
              (empresa_id, cliente_id, nota_credito_id, tipo, concepto,
               monto, saldo, fecha, usuario_id, estado, referencia, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
        """, [eid, cid, nid, "NOTA_CREDITO",
              f"NC {nc['numero']} — {nc.get('motivo','Nota de crédito')}",
              -float(nc["total"]), nuevo_saldo,
              nc["fecha"], nc.get("usuario_id"), "APLICADA", nc["numero"], now_ec()])
        c.commit(); c.close()
        log.info("NC %d: aplicada en CxC cliente %d, nuevo saldo=%.2f", nid, cid, nuevo_saldo)
    except Exception as ex:
        log.warning("NC %d: error aplicando en CxC: %s", nid, ex)


def _fmt_msgs_sri(msgs: list) -> str:
    """Formatea los mensajes del SRI para mostrar al usuario"""
    if not msgs: return ""
    partes = []
    for m in msgs:
        cod = m.get("identificador") or m.get("tipo") or ""
        msg = m.get("mensaje") or ""
        inf = m.get("info") or ""
        parte = f"[{cod}] {msg}"
        if inf: parte += f" — {inf}"
        partes.append(parte)
    return " | ".join(partes)


# ════════════════════════════════════════════════════════════
# GUÍA DE REMISIÓN  — XML v1.1.0 + Pipeline SRI  (codDoc=06)
# Conforme al esquema XSD oficial SRI Ecuador v2.31
# ════════════════════════════════════════════════════════════

def _generar_xml_guia(gid: int, eid: int) -> tuple[str, str]:
    """
    Genera XML de Guía de Remisión conforme al esquema XSD SRI v1.1.0
    
    Reglas críticas del SRI:
    - contribuyenteEspecial: OMITIR si está vacío
    - docAduaneroUnico: OMITIR completamente (solo exportación)
    - numAutDocSustento: OMITIR si está vacío
    - ruta: OMITIR si está vacía
    - codDocSustento/numDocSustento: solo si hay documento de sustento
    - rucTransportista: debe ser 13 dígitos si tipo=04 (RUC)
    """
    c    = db()
    g    = rd(c.execute("""
        SELECT gr.*,
               cl.nombre as cli_nombre, cl.ruc_cedula,
               cl.tipo_identificacion, cl.email as cli_email,
               cl.direccion as cli_dir
        FROM guias_remision gr
        LEFT JOIN clientes cl ON gr.cliente_id = cl.id
        WHERE gr.id = ? AND gr.empresa_id = ?
    """, (gid, eid)).fetchone())
    items = rl(c.execute(
        "SELECT * FROM guia_items WHERE guia_id = ? ORDER BY id",
        (gid,)
    ).fetchall())
    emp  = rd(c.execute("SELECT * FROM empresas WHERE id = ?", (eid,)).fetchone())
    c.close()

    if not g:   raise ValueError(f"Guía de remisión {gid} no encontrada")
    if not emp: raise ValueError(f"Empresa {eid} no encontrada")
    if not items: raise ValueError("La guía no tiene ítems de mercadería")

    # ── Secuencial ────────────────────────────────────────────
    num    = (g["numero"] or "").strip()
    partes = num.replace("GR","").replace("GUA","").split("-")
    sec    = partes[-1].zfill(9) if partes else "000000001"
    ambiente = str(emp["ambiente"] or "1")

    # ── Clave de acceso ───────────────────────────────────────
    clave_ok = False
    clave_existente = str(g.get("clave_acceso") or "")
    if len(clave_existente) == 49 and clave_existente.isdigit():
        if clave_existente[8:10] == "06":
            clave = clave_existente
            clave_ok = True
        else:
            log.warning("GR %d: clave con cod_doc=%s, regenerando con 06",
                        gid, clave_existente[8:10])
    if not clave_ok:
        clave = _clave_sri(g["fecha_inicio"], emp["ruc"], ambiente,
                           emp["estab"] or "001", emp["pto_emi"] or "001",
                           sec, cod_doc="06")
        _upd_guia(gid, clave_acceso=clave)
        log.info("GR %d: nueva clave generada con codDoc=06", gid)

    # ── Construir XML ─────────────────────────────────────────
    root = ET.Element("guiaRemision", id="comprobante", version="1.1.0")

    # ── infoTributaria ────────────────────────────────────────
    it = ET.SubElement(root, "infoTributaria")
    _t(it, "ambiente",       ambiente)
    _t(it, "tipoEmision",    "1")
    _t(it, "razonSocial",    _lim(emp["nombre"] or "", 300))
    nc_com = (emp.get("nombre_comercial") or emp["nombre"] or "").strip()
    if nc_com and nc_com != emp["nombre"]:
        _t(it, "nombreComercial", _lim(nc_com, 300))
    _t(it, "ruc",        (emp["ruc"] or "").strip())
    _t(it, "claveAcceso", clave)
    _t(it, "codDoc",     "06")
    _t(it, "estab",      str(emp["estab"] or "001").zfill(3)[:3])
    _t(it, "ptoEmi",     str(emp["pto_emi"] or "001").zfill(3)[:3])
    _t(it, "secuencial", sec.zfill(9))
    _t(it, "dirMatriz",  _lim(emp["direccion"] or "", 300))

    # ── infoGuiaRemision ──────────────────────────────────────
    info = ET.SubElement(root, "infoGuiaRemision")

    _t(info, "dirEstablecimiento",  _lim(emp["direccion"] or "", 300))
    _t(info, "dirPartida",
       _lim(g.get("dir_partida") or emp["direccion"] or "", 300))

    # Transportista — nombre y RUC
    trans_nombre = _lim(g.get("transportista_nombre") or emp["nombre"] or "", 300)
    _t(info, "razonSocialTransportista", trans_nombre)
    _t(info, "tipoIdentificacionTransportista", "04")  # RUC del transportista

    # RUC del transportista: debe ser exactamente 13 dígitos
    trans_ruc = re.sub(r'\D', '', str(g.get("transportista_ruc") or ""))
    if len(trans_ruc) == 10:
        trans_ruc = trans_ruc + "001"   # Cédula → completar a RUC
    if len(trans_ruc) != 13 or not trans_ruc.isdigit():
        trans_ruc = re.sub(r'\D', '', emp["ruc"] or "")
        log.warning("GR %d: RUC transportista inválido, usando RUC emisor", gid)
    _t(info, "rucTransportista", trans_ruc)

    _t(info, "obligadoContabilidad",
       "SI" if str(emp.get("obligado_contabilidad","NO")).upper() in ("SI","SÍ") else "NO")

    # contribuyenteEspecial: SOLO si tiene valor
    cont_esp = str(emp.get("contribuyente_especial") or "").strip()
    if cont_esp:
        _t(info, "contribuyenteEspecial", cont_esp[:300])

    _t(info, "fechaIniTransporte", fecha_xml(g["fecha_inicio"]))
    _t(info, "fechaFinTransporte", fecha_xml(g.get("fecha_fin") or g["fecha_inicio"]))
    _t(info, "placa", _lim(g.get("placa") or "", 20))

    # ── destinatarios ─────────────────────────────────────────
    dests_el = ET.SubElement(root, "destinatarios")
    dest     = ET.SubElement(dests_el, "destinatario")

    # Identificación del destinatario
    tipo_dest = (g.get("tipo_identificacion") or "05").strip()
    ruc_dest  = re.sub(r'\s', '', str(g.get("ruc_cedula") or ""))
    nom_dest  = _lim(g.get("cli_nombre") or "CONSUMIDOR FINAL", 300)

    if not ruc_dest:
        # Sin identificación — usar RUC del emisor
        tipo_dest = "04"
        ruc_dest  = re.sub(r'\D', '', emp["ruc"] or "")
        log.info("GR %d: sin identificación destinatario, usando RUC emisor", gid)
    elif len(ruc_dest) == 10 and ruc_dest.isdigit():
        tipo_dest = "05"   # Cédula ecuatoriana
    elif len(ruc_dest) == 13 and ruc_dest.isdigit():
        tipo_dest = "04"   # RUC
    else:
        # Identificación inválida — usar RUC del emisor
        log.warning("GR %d: identificación destinatario inválida (%s), usando emisor",
                    gid, ruc_dest)
        tipo_dest = "04"
        ruc_dest  = re.sub(r'\D', '', emp["ruc"] or "")

    _t(dest, "identificacionDestinatario", ruc_dest)
    _t(dest, "razonSocialDestinatario",    nom_dest)
    _t(dest, "dirDestinatario",            _lim(g.get("dir_destino") or "", 300))
    _t(dest, "motivoTraslado",             _lim(g.get("motivo_traslado") or "VENTA", 300))

    # ruta: OMITIR si está vacía
    ruta = _lim(g.get("ruta") or "", 300)
    if ruta:
        _t(dest, "ruta", ruta)

    # Documento de sustento: SOLO si hay factura de referencia
    fac_ref = (g.get("factura_ref_numero") or "").strip()
    if fac_ref and len(fac_ref) >= 5:
        # Validar formato NNN-NNN-NNNNNNNNN
        if not re.match(r'^\d{3}-\d{3}-\d{9}$', fac_ref):
            pnd = fac_ref.replace("FAC","").strip().split("-")
            if len(pnd) >= 3:
                fac_ref = f"{pnd[0].zfill(3)}-{pnd[1].zfill(3)}-{pnd[2].zfill(9)}"
        _t(dest, "codDocSustento",          "01")  # 01 = Factura
        _t(dest, "numDocSustento",          fac_ref)
        _t(dest, "fechaEmisionDocSustento", fecha_xml(g["fecha_inicio"]))
        # numAutDocSustento: OMITIR si no hay número de autorización del doc sustento
        # (docAduaneroUnico y codEstabDestino se omiten — no son requeridos)

    # ── detalles de mercadería ────────────────────────────────
    dets_dest = ET.SubElement(dest, "detalles")
    for itg in items:
        d = ET.SubElement(dets_dest, "detalle")

        cod_int = re.sub(r'[^a-zA-Z0-9\-_./]', '',
                         str(itg.get("codigo") or "").strip())[:25]
        if not cod_int:
            cod_int = re.sub(r'[^a-zA-Z0-9\-_]', '',
                             str(itg["descripcion"])[:25]) or "001"

        _t(d, "codigoInterno", cod_int)
        _t(d, "descripcion",   _lim(itg["descripcion"], 300))

        # cantidad: decimal con hasta 6 decimales
        cant = float(itg["cantidad"])
        _t(d, "cantidad", _d6(cant))

    _xml_prov_sistema(root, eid)
    xml_str = '<?xml version="1.0" encoding="UTF-8"?>' + \
              ET.tostring(root, encoding="unicode")
    return xml_str, clave


def _procesar_guia(gid: int, eid: int) -> dict:
    """
    Pipeline completo de Guía de Remisión:
    1. Generar XML conforme XSD SRI v1.1.0
    2. Firmar con XAdES-BES
    3. Enviar al WebService SRI
    4. Consultar autorización SRI
    5. Actualizar estado en BD
    """
    c    = db()
    emp  = rd(c.execute("SELECT * FROM empresas WHERE id = ?", (eid,)).fetchone())
    guia = rd(c.execute(
        "SELECT * FROM guias_remision WHERE id = ? AND empresa_id = ?", (gid, eid)
    ).fetchone())
    c.close()

    if not emp:
        return {"ok": False, "error": "Empresa no encontrada"}
    if not emp.get("facturacion_electronica"):
        return {"ok": False, "error": "Facturación electrónica no habilitada. Actívala en Configuración."}
    if not guia:
        return {"ok": False, "error": f"Guía de remisión #{gid} no encontrada"}

    # Si ya está autorizada con auth real, devolver
    if (guia.get("estado_sri") == "AUTORIZADA" and
            guia.get("autorizacion") and
            guia.get("autorizacion") != guia.get("clave_acceso")):
        return {
            "ok": True, "ya_autorizada": True,
            "clave_acceso":      guia["clave_acceso"],
            "autorizacion":      guia["autorizacion"],
            "fecha_autorizacion": guia["fecha_autorizacion"],
        }

    ambiente  = str(emp.get("ambiente") or "1")
    cert_path = str(emp.get("cert_path") or "")
    cert_pass = str(emp.get("cert_password") or "")
    comp_dir  = BASE_DIR / "comprobantes" / _dir_emp(eid)

    # ── PASO 1: Generar XML ───────────────────────────────────
    try:
        xml_str, clave = _generar_xml_guia(gid, eid)
        gp = comp_dir / "generados" / f"{clave}.xml"
        gp.parent.mkdir(parents=True, exist_ok=True)
        gp.write_text(xml_str, encoding="utf-8")
        _slog(eid, gid, "GR_XML_GENERADO", "OK", clave[:20])
        log.info("GR %d: XML generado OK, clave=%s", gid, clave[:20])
    except Exception as ex:
        _slog(eid, gid, "GR_XML_GENERADO", "ERROR", str(ex))
        log.error("GR %d: Error generando XML: %s", gid, ex)
        return {"ok": False, "etapa": "generacion", "error": str(ex)}

    # ── PASO 2: Firmar XML ────────────────────────────────────
    try:
        cert_path = str(_resolver_cert(emp, eid))
        xml_firmado = firmar_xml(xml_str, cert_path, cert_pass)
        fp = comp_dir / "firmados" / f"{clave}.xml"
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(xml_firmado, encoding="utf-8")
        _slog(eid, gid, "GR_XML_FIRMADO", "OK")
        log.info("GR %d: XML firmado OK", gid)
    except Exception as ex:
        _slog(eid, gid, "GR_XML_FIRMADO", "ERROR", str(ex))
        _upd_guia(gid, estado_sri="ERROR_FIRMA")
        return {"ok": False, "etapa": "firma", "error": str(ex)}

    # ── PASO 3: Enviar al SRI ─────────────────────────────────
    res_env = enviar_sri(xml_firmado, ambiente)
    _slog(eid, gid, "GR_ENVIO_SRI",
          res_env.get("estado", "?"), "", json.dumps(res_env, ensure_ascii=False))
    log.info("GR %d: envío SRI estado=%s", gid, res_env.get("estado"))

    estado_env = res_env.get("estado", "")

    if estado_env == "DEVUELTA":
        msgs = res_env.get("mensajes", [])
        err  = _fmt_msgs_sri(msgs) or "El SRI rechazó el comprobante (DEVUELTA)"
        _upd_guia(gid, estado_sri="DEVUELTA")
        return {
            "ok":       False,
            "etapa":    "envio",
            "error":    err,
            "mensajes": msgs,
            "raw_xml":  res_env.get("raw_xml", ""),
            "detalle":  res_env,
        }
    elif estado_env not in ("RECIBIDA", "DEVUELTA"):
        _upd_guia(gid, estado_sri="ERROR_ENVIO")
        return {
            "ok":    False,
            "etapa": "envio",
            "error": f"Error de conexión con el SRI: {estado_env or 'sin respuesta'}",
            "raw_xml": res_env.get("raw_xml", ""),
        }

    # ── PASO 4: Consultar autorización ────────────────────────
    res_auth = None
    for intento, espera in enumerate([3, 5, 8, 12, 15], 1):
        time.sleep(espera)
        res_auth = autorizar_sri(clave, ambiente)
        _slog(eid, gid, f"GR_AUTORIZACION_{intento}",
              res_auth.get("estado", "?"), "", json.dumps(res_auth, ensure_ascii=False))
        log.info("GR %d: intento %d — estado=%s comp=%s",
                 gid, intento, res_auth.get("estado"),
                 res_auth.get("numero_comprobantes"))
        if res_auth.get("estado") in ("AUTORIZADO", "NO AUTORIZADO", "RECHAZADO"):
            break

    # ── PASO 5: Procesar resultado ────────────────────────────
    estado_auth = res_auth.get("estado", "DESCONOCIDO")

    if estado_auth == "AUTORIZADO":
        na = (res_auth.get("numero_autorizacion") or "").strip()
        fa =  res_auth.get("fecha_autorizacion") or now_ec()

        # NOTA: En PRODUCCIÓN el SRI puede retornar la clave de acceso
        # como numeroAutorizacion — esto es comportamiento oficial y válido.
        if not na:
            na = clave
            log.warning("GR %d: SRI AUTORIZADO sin numeroAutorizacion explícito, usando clave de acceso", gid)

        _upd_guia(gid,
                  estado="AUTORIZADA", estado_sri="AUTORIZADA",
                  autorizacion=na, fecha_autorizacion=fa)
        _envio_auto_correo(eid, "guia", gid)

        try:
            dst = comp_dir / "autorizados" / f"{clave}.xml"
            dst.parent.mkdir(parents=True, exist_ok=True)
            if fp.exists(): fp.rename(dst)
        except Exception as ex:
            log.warning("GR %d: no pudo mover XML: %s", gid, ex)

        try:
            emp_r = rd(db().execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
            _generar_ride_guia(gid, eid, clave, na, fa, emp_r)
        except Exception as ex:
            log.warning("GR %d: no pudo generar RIDE: %s", gid, ex)

        log.info("GR %d: AUTORIZADA — auth=%s", gid, na[:20])
        return {
            "ok":               True,
            "clave_acceso":     clave,
            "autorizacion":     na,
            "fecha_autorizacion": fa,
        }

    else:
        msgs   = res_auth.get("mensajes", [])
        raw    = res_auth.get("raw_xml", "")[:3000]
        n_comp = res_auth.get("numero_comprobantes", -1)

        if n_comp == 0:
            err = ("El SRI no encontró el comprobante (numeroComprobantes=0). "
                   "El XML fue rechazado en validación interna del SRI. "
                   "Verifica en https://srienlinea.sri.gob.ec con la clave: " + clave)
        elif msgs:
            err = _fmt_msgs_sri(msgs)
        elif estado_auth == "DESCONOCIDO":
            err = "El SRI no respondió con estado claro. Verifica en https://srienlinea.sri.gob.ec"
        else:
            err = f"Estado SRI: {estado_auth}"

        _upd_guia(gid, estado_sri="NO_AUTORIZADA")

        try:
            dst = comp_dir / "rechazados" / f"{clave}.xml"
            dst.parent.mkdir(parents=True, exist_ok=True)
            if fp.exists(): fp.rename(dst)
        except: pass

        log.warning("GR %d: NO AUTORIZADA — %s", gid, err[:100])
        return {
            "ok":       False,
            "etapa":    "autorizacion",
            "error":    err,
            "mensajes": msgs,
            "raw_xml":  raw,
            "detalle":  res_auth,
        }


# ════════════════════════════════════════════════════════════
# ENVÍO DE CORREO
# ════════════════════════════════════════════════════════════

# ════════════════════════════════════════════════════════════
# LIQUIDACIÓN DE COMPRA — XML v1.1.0 + Pipeline SRI (codDoc=03)
# Conforme al esquema XSD oficial SRI Ecuador v2.31 Anexo 17
#
# Cuándo se emite:
# a) Compras a personas naturales no inscritas en el RUC
#    que por su nivel cultural no pueden emitir comprobantes
# b) Servicios prestados en Ecuador por sociedades extranjeras
#    sin domicilio ni establecimiento permanente
# c) Compras de bienes muebles y servicios de empleados
#    en relación de dependencia
# NOTA: NO se permite "Consumidor Final" — se requiere identificación
# ════════════════════════════════════════════════════════════

def _upd_liq(lid, **kw):
    sql = ", ".join(f"{k}=?" for k in kw)
    c = db()
    c.execute(f"UPDATE liquidaciones_compra SET {sql} WHERE id=?", list(kw.values()) + [lid])
    c.commit(); c.close()


def _generar_xml_liquidacion(lid: int, eid: int) -> tuple[str, str]:
    """
    Genera XML de Liquidación de Compra conforme al XSD SRI v1.1.0
    codDoc = 03

    Estructura infoLiquidacionCompra:
    fechaEmision → dirEstablecimiento → contribuyenteEspecial(si aplica)
    → obligadoContabilidad → tipoIdentificacionProveedor
    → razonSocialProveedor → identificacionProveedor
    → direccionProveedor(opcional) → totalSinImpuestos
    → totalDescuento → totalConImpuestos → importeTotal
    → moneda → pagos
    """
    c   = db()
    liq = rd(c.execute("""
        SELECT * FROM liquidaciones_compra
        WHERE id = ? AND empresa_id = ?
    """, (lid, eid)).fetchone())
    items = rl(c.execute(
        "SELECT * FROM liquidacion_items WHERE liquidacion_id = ? ORDER BY id",
        (lid,)
    ).fetchall())
    emp = rd(c.execute("SELECT * FROM empresas WHERE id = ?", (eid,)).fetchone())
    c.close()

    if not liq: raise ValueError(f"Liquidación #{lid} no encontrada")
    if not emp:  raise ValueError(f"Empresa {eid} no encontrada")
    if not items: raise ValueError("La liquidación no tiene ítems")

    # ── Secuencial ────────────────────────────────────────────
    num    = (liq["numero"] or "").strip()
    partes = num.replace("LC","").replace("LQ","").split("-")
    sec    = partes[-1].zfill(9) if partes else "000000001"
    ambiente = str(emp["ambiente"] or "1")

    # ── Clave de acceso (codDoc=03) ───────────────────────────
    clave_ok = False
    clave_ex = str(liq.get("clave_acceso") or "")
    if len(clave_ex) == 49 and clave_ex.isdigit() and clave_ex[8:10] == "03":
        clave = clave_ex; clave_ok = True
    if not clave_ok:
        clave = _clave_sri(liq["fecha"], emp["ruc"], ambiente,
                           emp["estab"] or "001", emp["pto_emi"] or "001",
                           sec, cod_doc="03")
        _upd_liq(lid, clave_acceso=clave)

    # ── IVA ───────────────────────────────────────────────────
    iva_pct = _iva_pct_doc(liq)
    cod_pct = _cod_pct_sri(iva_pct)

    # ── Construir XML ─────────────────────────────────────────
    root = ET.Element("liquidacionCompra", id="comprobante", version="1.1.0")

    # infoTributaria
    it = ET.SubElement(root, "infoTributaria")
    _t(it, "ambiente",      ambiente)
    _t(it, "tipoEmision",   "1")
    _t(it, "razonSocial",   _lim(emp["nombre"] or "", 300))
    nc = (emp.get("nombre_comercial") or emp["nombre"] or "").strip()
    if nc and nc != emp["nombre"]: _t(it, "nombreComercial", _lim(nc, 300))
    _t(it, "ruc",           emp["ruc"] or "")
    _t(it, "claveAcceso",   clave)
    _t(it, "codDoc",        "03")
    _t(it, "estab",         str(emp["estab"] or "001").zfill(3)[:3])
    _t(it, "ptoEmi",        str(emp["pto_emi"] or "001").zfill(3)[:3])
    _t(it, "secuencial",    sec.zfill(9))
    _t(it, "dirMatriz",     _lim(emp["direccion"] or "", 300))

    # infoLiquidacionCompra
    info = ET.SubElement(root, "infoLiquidacionCompra")
    _t(info, "fechaEmision",          fecha_xml(liq["fecha"]))
    _t(info, "dirEstablecimiento",    _lim(emp["direccion"] or "", 300))

    cont_esp = str(emp.get("contribuyente_especial") or "").strip()
    if cont_esp: _t(info, "contribuyenteEspecial", cont_esp[:300])

    _t(info, "obligadoContabilidad",
       "SI" if str(emp.get("obligado_contabilidad","NO")).upper() in ("SI","SÍ") else "NO")

    # Proveedor — NUNCA consumidor final en liquidación de compra
    tipo_prov = (liq.get("proveedor_tipo_id") or "05").strip()
    id_prov   = re.sub(r'\s', '', str(liq.get("proveedor_identificacion") or ""))
    rs_prov   = _lim(liq.get("proveedor_razon_social") or "", 300)

    # Validar identificación del proveedor
    if len(id_prov) == 10 and id_prov.isdigit():
        tipo_prov = "05"   # Cédula
    elif len(id_prov) == 13 and id_prov.isdigit():
        tipo_prov = "04"   # RUC (inusual en liquidaciones pero posible)
    elif tipo_prov == "06":
        pass               # Pasaporte — usar tal cual
    elif not id_prov:
        raise ValueError("La liquidación debe tener identificación del proveedor")

    _t(info, "tipoIdentificacionProveedor", tipo_prov)
    _t(info, "razonSocialProveedor",        rs_prov)
    _t(info, "identificacionProveedor",     id_prov)

    dir_prov = _lim(liq.get("proveedor_direccion") or "", 300)
    if dir_prov: _t(info, "direccionProveedor", dir_prov)

    # Totales
    subtotal  = round(float(liq.get("subtotal") or 0), 2)
    iva_val   = round(float(liq.get("iva") or 0), 2)
    total     = round(float(liq.get("total") or 0), 2)
    descuento = round(sum(float(it2.get("descuento") or 0) for it2 in items), 2)

    _t(info, "totalSinImpuestos", _d2(subtotal))
    _t(info, "totalDescuento",    _d2(descuento))

    # totalConImpuestos (igual que en NC)
    tci  = ET.SubElement(info, "totalConImpuestos")
    ti   = ET.SubElement(tci, "totalImpuesto")
    _t(ti, "codigo",           "2")
    _t(ti, "codigoPorcentaje", cod_pct)
    _t(ti, "baseImponible",    _d2(subtotal))
    _t(ti, "valor",            _d2(iva_val))

    _t(info, "importeTotal", _d2(total))
    _t(info, "moneda",       "DOLAR")

    # Pagos
    pagos = ET.SubElement(info, "pagos")
    pago  = ET.SubElement(pagos, "pago")
    fp_lc = str(liq.get("forma_pago","01") or "01")
    _t(pago, "formaPago", fp_lc)
    _t(pago, "total",     _d2(total))
    _t(pago, "plazo",     "0")
    _t(pago, "unidadTiempo", "dias")

    # Detalles
    dets = ET.SubElement(root, "detalles")
    for it2 in items:
        det = ET.SubElement(dets, "detalle")
        cod_int = re.sub(r'[^a-zA-Z0-9\-_./]', '',
                         str(it2.get("codigo") or "").strip())[:25] or "001"
        _t(det, "codigoPrincipal",           cod_int)
        _t(det, "descripcion",               _lim(it2["descripcion"], 300))
        _t(det, "cantidad",                  _d6(it2["cantidad"]))
        _t(det, "precioUnitario",            _d6(it2["precio_unitario"]))
        _t(det, "descuento",                 _d2(float(it2.get("descuento") or 0)))
        _t(det, "precioTotalSinImpuesto",    _d2(float(it2["subtotal"])))

        imp_d  = ET.SubElement(det, "impuestos")
        imp    = ET.SubElement(imp_d, "impuesto")
        _t(imp, "codigo",           "2")
        _t(imp, "codigoPorcentaje", cod_pct)
        _t(imp, "tarifa",           str(iva_pct))
        _t(imp, "baseImponible",    _d2(float(it2["subtotal"])))
        _t(imp, "valor",            _d2(round(float(it2["subtotal"]) * iva_pct / 100, 2)))

    # infoAdicional
    email_prov = (liq.get("proveedor_email") or "").strip()
    motivo     = (liq.get("motivo") or "").strip()
    ia_campos  = []
    if email_prov: ia_campos.append(("email", email_prov[:300]))
    if motivo:     ia_campos.append(("motivo", motivo[:300]))
    if ia_campos:
        ia = ET.SubElement(root, "infoAdicional")
        for nombre, valor in ia_campos[:3]:
            cam = ET.SubElement(ia, "campoAdicional")
            cam.set("nombre", nombre); cam.text = valor

    _xml_prov_sistema(root, eid)
    xml_str = '<?xml version="1.0" encoding="UTF-8"?>' + \
              ET.tostring(root, encoding="unicode")
    return xml_str, clave


def _generar_ride_liquidacion(lid, eid, liq, items, emp) -> str:
    """RIDE Liquidación de Compra — formato oficial SRI A4"""
    amb      = "PRUEBAS" if str(emp.get("ambiente","1"))=="1" else "PRODUCCION"
    logo     = emp.get("logo_base64","") or ""
    iva_pct  = float(emp.get("iva_porcentaje",15))
    subtotal = float(liq.get("subtotal",0))
    iva_val  = float(liq.get("iva",0))
    total    = float(liq.get("total",0))
    clave    = liq.get("clave_acceso","")
    auth     = liq.get("autorizacion","")
    fa       = liq.get("fecha_autorizacion","")

    filas = ""
    for it in items:
        filas += f"""<tr>
          <td>{it.get('codigo','') or ''}</td>
          <td class="r">{float(it['cantidad']):.4f}</td>
          <td>{it['descripcion']}</td>
          <td class="det"></td>
          <td class="r">{float(it['precio_unitario']):.6f}</td>
          <td class="r">${float(it.get('descuento') or 0):.2f}</td>
          <td class="r">${float(it['subtotal']):.2f}</td>
        </tr>"""

    tipo_id_lbl = {"04":"RUC","05":"Cédula","06":"Pasaporte"}.get(
        liq.get("proveedor_tipo_id","05"),"Cédula")

    html = f"""<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8">
<title>RIDE LC - {liq['numero']}</title>
<style>{_ride_css()}</style>
</head><body><div class="page">
<div class="cab">
  <div class="cab-logo">{'<img src="'+logo+'"/>' if logo else ''}</div>
  <div class="cab-emisor">
    <div class="rs">{emp.get('nombre','')}</div>
    <div class="d"><b>RUC:</b> {emp.get('ruc','')}</div>
    <div class="d"><b>Dirección:</b> {emp.get('direccion','')}</div>
    {'<div class="d"><b>Teléfono:</b> '+emp.get('telefono','')+'</div>' if emp.get('telefono') else ''}
    <div class="d"><b>Obligado a llevar contabilidad:</b> {emp.get('obligado_contabilidad','NO')}</div>
  </div>
  <div class="cab-right">
    <div class="tipo">LIQUIDACIÓN DE COMPRA</div>
    <div class="num">No. {liq['numero']}</div>
    <div class="d"><b>Número de Autorización:</b></div>
    <div class="d" style="font-family:monospace;font-size:7.5px;word-break:break-all">{auth}</div>
    <div class="d"><b>Fecha Autorización:</b> {fa}</div>
    <div class="d"><b>Ambiente:</b> {amb}</div>
    <div class="d"><b>Emisión:</b> NORMAL</div>
  </div>
</div>
<div class="clave-sec">
  <div class="clave-lbl">Clave de Acceso:</div>
  <div style="text-align:center;margin:3px 0">
    <img src="{barcode_data_uri(clave,42)}" style="max-width:100%;height:auto"/>
  </div>
  <div class="clave-num">{clave}</div>
</div>
{'<div class="amb-warn">⚠ AMBIENTE DE PRUEBAS — No válido como documento tributario</div>' if amb=='PRUEBAS' else ''}
<div class="buy-sec">
  <div class="buy-row">
    <div class="buy-cell w2"><div class="bc-lbl">Razón Social del Proveedor</div>
      <div class="bc-val">{liq.get('proveedor_razon_social','')}</div></div>
    <div class="buy-cell"><div class="bc-lbl">{tipo_id_lbl}</div>
      <div class="bc-val">{liq.get('proveedor_identificacion','')}</div></div>
    <div class="buy-cell"><div class="bc-lbl">Fecha Emisión</div>
      <div class="bc-val">{liq.get('fecha','')}</div></div>
  </div>
  <div class="buy-row">
    <div class="buy-cell w2"><div class="bc-lbl">Dirección del Proveedor</div>
      <div class="bc-val">{liq.get('proveedor_direccion','')}</div></div>
    <div class="buy-cell"><div class="bc-lbl">Motivo</div>
      <div class="bc-val">{liq.get('motivo','')}</div></div>
    <div class="buy-cell"><div class="bc-lbl">Forma de Pago</div>
      <div class="bc-val">{liq.get('forma_pago','EFECTIVO')}</div></div>
  </div>
</div>
<div class="items-wrap"><table class="it">
  <thead><tr>
    <th style="width:11%">Código</th><th class="r" style="width:8%">Cantidad</th>
    <th style="width:24%">Descripción</th><th style="width:13%">Detalles Adic.</th>
    <th class="r" style="width:12%">P.Unitario</th>
    <th class="r" style="width:9%">Descuento</th><th class="r" style="width:11%">Total</th>
  </tr></thead>
  <tbody>{filas}</tbody>
</table></div>
<div class="bot">
  <div class="bot-left">
    <div class="sec-ttl">Información Adicional</div>
    {_ride_prov_row(eid)}
    <div class="ia-row"><span class="ia-lbl">Proveedor:</span><span>{liq.get('proveedor_razon_social','')}</span></div>
    {'<div class="ia-row"><span class="ia-lbl">Email:</span><span>'+liq.get('proveedor_email','')+'</span></div>' if liq.get('proveedor_email') else ''}
    <div class="sec-ttl" style="margin-top:8px">Formas de Pago</div>
    <div class="fp-row"><span>Sin Utilización del Sistema Financiero</span><span>${total:.2f}</span><span>0 días</span></div>
  </div>
  <div class="bot-right">
    <div class="tot-row"><span class="tot-lbl">Subtotal Sin Impuestos:</span><span class="tot-val">${subtotal:.2f}</span></div>
    <div class="tot-row"><span class="tot-lbl">Subtotal {iva_pct:.0f}%:</span><span class="tot-val">${subtotal:.2f}</span></div>
    <div class="tot-row"><span class="tot-lbl">Subtotal 0%:</span><span class="tot-val">$0.00</span></div>
    <div class="tot-row"><span class="tot-lbl">Descuentos:</span><span class="tot-val">$0.00</span></div>
    <div class="tot-row"><span class="tot-lbl">ICE:</span><span class="tot-val">$0.00</span></div>
    <div class="tot-row"><span class="tot-lbl">IVA {iva_pct:.0f}%:</span><span class="tot-val">${iva_val:.2f}</span></div>
    <div class="tot-row grand"><span class="tot-lbl">Importe Total:</span><span class="tot-val">${total:.2f}</span></div>
  </div>
</div>
<div class="footer">{emp.get('nombre','')} | RUC: {emp.get('ruc','')} | Liquidación de Compra autorizada por el SRI Ecuador</div>
</div></body></html>"""

    # Guardar RIDE en disco para adjuntar en correos
    clave = liq.get("clave_acceso","")
    if clave:
        ride_p = BASE_DIR / "comprobantes" / _dir_emp(eid) / "RIDE" / f"LC_{clave}.html"
        ride_p.parent.mkdir(parents=True, exist_ok=True)
        ride_p.write_text(html, encoding="utf-8")
        _ride_guardar_pdf(html, ride_p.with_suffix(".pdf"), liq, items, emp, "LIQUIDACIÓN DE COMPRA")
        _upd_liq(lid, ride_path=str(ride_p))
        log.info("RIDE Liquidación guardado: %s", ride_p.name)

    return html


def _procesar_liquidacion(lid: int, eid: int) -> dict:
    """Pipeline completo Liquidación de Compra → SRI"""
    c   = db()
    emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
    liq = rd(c.execute(
        "SELECT * FROM liquidaciones_compra WHERE id=? AND empresa_id=?", (lid, eid)
    ).fetchone())
    c.close()

    if not emp: return {"ok":False,"error":"Empresa no encontrada"}
    if not emp.get("facturacion_electronica"):
        return {"ok":False,"error":"Facturación electrónica no habilitada"}
    if not liq: return {"ok":False,"error":f"Liquidación #{lid} no encontrada"}

    if (liq.get("estado_sri") == "AUTORIZADA" and liq.get("autorizacion")
            and liq["autorizacion"] != liq.get("clave_acceso","")):
        return {"ok":True,"ya_autorizada":True,
                "clave_acceso":liq["clave_acceso"],
                "autorizacion":liq["autorizacion"],
                "fecha_autorizacion":liq["fecha_autorizacion"]}

    ambiente  = str(emp.get("ambiente") or "1")
    cert_path = str(emp.get("cert_path") or "")
    cert_pass = str(emp.get("cert_password") or "")
    comp_dir  = BASE_DIR / "comprobantes" / _dir_emp(eid)

    # Paso 1: Generar XML
    try:
        xml_str, clave = _generar_xml_liquidacion(lid, eid)
        gp = comp_dir / "generados" / f"{clave}.xml"
        gp.parent.mkdir(parents=True, exist_ok=True)
        gp.write_text(xml_str, encoding="utf-8")
        _slog(eid, lid, "LC_XML_GENERADO", "OK", clave[:20])
    except Exception as ex:
        _slog(eid, lid, "LC_XML_GENERADO", "ERROR", str(ex))
        return {"ok":False,"etapa":"generacion","error":str(ex)}

    # Paso 2: Firmar
    try:
        cert_path = str(_resolver_cert(emp, eid))
        xml_firmado = firmar_xml(xml_str, cert_path, cert_pass)
        fp = comp_dir / "firmados" / f"{clave}.xml"
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(xml_firmado, encoding="utf-8")
        _slog(eid, lid, "LC_XML_FIRMADO", "OK")
    except Exception as ex:
        _slog(eid, lid, "LC_XML_FIRMADO", "ERROR", str(ex))
        _upd_liq(lid, estado_sri="ERROR_FIRMA")
        return {"ok":False,"etapa":"firma","error":str(ex)}

    # Paso 3: Enviar
    res_env = enviar_sri(xml_firmado, ambiente)
    _slog(eid, lid, "LC_ENVIO_SRI", res_env.get("estado","?"), "", json.dumps(res_env))
    if res_env.get("estado") == "DEVUELTA":
        msgs = res_env.get("mensajes", [])
        _upd_liq(lid, estado_sri="DEVUELTA")
        return {"ok":False,"etapa":"envio","error":_fmt_msgs_sri(msgs),
                "mensajes":msgs,"raw_xml":res_env.get("raw_xml","")}
    elif res_env.get("estado") not in ("RECIBIDA","DEVUELTA"):
        _upd_liq(lid, estado_sri="ERROR_ENVIO")
        return {"ok":False,"etapa":"envio","error":f"Error SRI: {res_env.get('estado','')}"}

    # Paso 4: Autorizar
    for intento, espera in enumerate([3,5,8,12,15], 1):
        time.sleep(espera)
        res_auth = autorizar_sri(clave, ambiente)
        _slog(eid, lid, f"LC_AUTH_{intento}", res_auth.get("estado","?"), "",
              json.dumps(res_auth))
        if res_auth.get("estado") in ("AUTORIZADO","NO AUTORIZADO","RECHAZADO"): break

    estado_auth = res_auth.get("estado","DESCONOCIDO")
    if estado_auth == "AUTORIZADO":
        na = (res_auth.get("numero_autorizacion") or "").strip() or clave
        fa = res_auth.get("fecha_autorizacion") or now_ec()
        _upd_liq(lid, estado="AUTORIZADA", estado_sri="AUTORIZADA",
                 autorizacion=na, fecha_autorizacion=fa)
        _envio_auto_correo(eid, "liquidacion", lid)
        try:
            dst = comp_dir/"autorizados"/f"{clave}.xml"; dst.parent.mkdir(exist_ok=True)
            if fp.exists(): fp.rename(dst)
        except: pass
        return {"ok":True,"clave_acceso":clave,"autorizacion":na,"fecha_autorizacion":fa}
    else:
        msgs = res_auth.get("mensajes",[])
        n_comp = res_auth.get("numero_comprobantes",-1)
        if n_comp == 0:
            err = ("SRI no encontró el comprobante (numeroComprobantes=0). "
                   f"Verifica en srienlinea.sri.gob.ec con clave: {clave}")
        elif msgs: err = _fmt_msgs_sri(msgs)
        else: err = f"Estado SRI: {estado_auth}"
        _upd_liq(lid, estado_sri="NO_AUTORIZADA")
        return {"ok":False,"etapa":"autorizacion","error":err,
                "mensajes":msgs,"raw_xml":res_auth.get("raw_xml","")[:3000]}


def _email_html(doc: dict, emp: dict, tipo: str = "factura") -> str:
    """Genera el cuerpo HTML del correo — diseño profesional con RIDE incrustado."""
    nombre_emp = emp.get("nombre","") or "DAVI&LOZA SOFT"
    ruc_emp    = emp.get("ruc","")
    logo_b64   = emp.get("logo_base64","") or ""
    logo_tag   = (f'<img src="{logo_b64}" alt="{nombre_emp}" style="max-height:60px;max-width:200px;object-fit:contain;">'
                  if logo_b64 else
                  f'<div style="font-size:22px;font-weight:700;color:#1a56db">{nombre_emp}</div>')

    # Datos según tipo de documento
    if tipo == "factura":
        tipo_lbl     = "Factura Electrónica"
        numero       = doc.get("numero","")
        cli_nombre   = doc.get("cli_nombre","Cliente")
        total        = f"${float(doc.get('total',0)):.2f}"
        fecha        = doc.get("fecha","")
        auth         = doc.get("autorizacion","") or doc.get("clave_acceso","")
        asunto_extra = f"por ${float(doc.get('total',0)):.2f}"
    elif tipo == "nc":
        tipo_lbl     = "Nota de Crédito"
        numero       = doc.get("numero","")
        cli_nombre   = doc.get("cli_nombre","Cliente")
        total        = f"${float(doc.get('total',0)):.2f}"
        fecha        = doc.get("fecha","")
        auth         = doc.get("autorizacion","") or doc.get("clave_acceso","")
        asunto_extra = f"— {doc.get('motivo','Nota de crédito')}"
    elif tipo == "guia":
        tipo_lbl     = "Guía de Remisión"
        numero       = doc.get("numero","")
        cli_nombre   = doc.get("cli_nombre","Destinatario")
        total        = "—"
        fecha        = doc.get("fecha_inicio","")
        auth         = doc.get("autorizacion","") or doc.get("clave_acceso","")
        asunto_extra = f"— {doc.get('motivo_traslado','Traslado')}"
    else:  # liquidacion
        tipo_lbl     = "Liquidación de Compra"
        numero       = doc.get("numero","")
        cli_nombre   = doc.get("proveedor_razon_social","Proveedor")
        total        = f"${float(doc.get('total',0)):.2f}"
        fecha        = doc.get("fecha","")
        auth         = doc.get("autorizacion","") or doc.get("clave_acceso","")
        asunto_extra = f"por ${float(doc.get('total',0)):.2f}"

    # Formatear fecha legible
    try:
        from datetime import datetime as _dt
        dt = _dt.strptime(fecha[:10], "%Y-%m-%d")
        meses = ["enero","febrero","marzo","abril","mayo","junio",
                 "julio","agosto","septiembre","octubre","noviembre","diciembre"]
        fecha_leg = f"{dt.day} de {meses[dt.month-1]} de {dt.year}"
    except:
        fecha_leg = fecha

    color_total = "#1a56db" if tipo != "nc" else "#dc2626"

    return f"""<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{tipo_lbl} {numero} — {nombre_emp}</title></head>
<body style="margin:0;padding:0;background:#f4f6f9;font-family:'Segoe UI',Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f6f9;padding:30px 0">
  <tr><td align="center">
    <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.08)">

      <!-- ENCABEZADO -->
      <tr><td style="background:linear-gradient(135deg,#1a56db,#1e40af);padding:28px 32px;text-align:center">
        <div style="color:#fff;font-size:12px;opacity:.8;margin-bottom:4px;text-transform:uppercase;letter-spacing:1px">Facturación Electrónica SRI Ecuador</div>
        <div style="color:#fff;font-size:22px;font-weight:700;letter-spacing:1px">DAVI&LOZA SOFT</div>
      </td></tr>

      <!-- LOGO Y EMPRESA -->
      <tr><td style="padding:24px 32px 14px;text-align:center;border-bottom:1px solid #e8ecf0">
        <div style="margin-bottom:10px">{logo_tag}</div>
        <div style="color:#374151;font-size:17px;font-weight:600">{nombre_emp}</div>
        <div style="color:#6b7280;font-size:12px;margin-top:3px">RUC: {ruc_emp}</div>
      </td></tr>

      <!-- DESTINATARIO Y TIPO -->
      <tr><td style="padding:22px 32px 14px;text-align:center">
        <p style="color:#4b5563;font-size:15px;margin:0 0 4px">Estimado/a</p>
        <p style="color:#111827;font-size:19px;font-weight:600;margin:0 0 14px">{cli_nombre}</p>
        <p style="color:#4b5563;font-size:14px;margin:0">Se adjunta su</p>
        <p style="color:{color_total};font-size:17px;font-weight:700;margin:4px 0 0">{tipo_lbl}</p>
      </td></tr>

      <!-- NÚMERO DE DOCUMENTO -->
      <tr><td style="padding:0 32px 14px">
        <div style="background:#f0f4ff;border:1.5px solid #c7d7fc;border-radius:10px;padding:16px 24px;text-align:center">
          <div style="color:#4b5563;font-size:11px;text-transform:uppercase;letter-spacing:.5px;margin-bottom:5px">Número de {tipo_lbl}</div>
          <div style="color:#1a56db;font-size:20px;font-weight:700;font-family:monospace;letter-spacing:1px">{numero}</div>
        </div>
      </td></tr>

      <!-- FECHA Y MONTO -->
      <tr><td style="padding:0 32px 14px">
        <table width="100%" cellpadding="0" cellspacing="0">
          <tr>
            <td style="background:#f9fafb;border-radius:8px;padding:14px;text-align:center;width:48%">
              <div style="color:#6b7280;font-size:11px;margin-bottom:3px;text-transform:uppercase;letter-spacing:.5px">Fecha de emisión</div>
              <div style="color:#111827;font-size:14px;font-weight:600">{fecha_leg}</div>
            </td>
            <td width="4%"></td>
            <td style="background:{color_total};border-radius:8px;padding:14px;text-align:center;width:48%">
              <div style="color:rgba(255,255,255,.8);font-size:11px;margin-bottom:3px;text-transform:uppercase;letter-spacing:.5px">{'Valor' if tipo!='guia' else 'Traslado'}</div>
              <div style="color:#fff;font-size:24px;font-weight:700">{total}</div>
            </td>
          </tr>
        </table>
      </td></tr>

      <!-- AUTORIZACIÓN SRI -->
      {f'''<tr><td style="padding:0 32px 14px">
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:12px 16px">
          <div style="color:#15803d;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;margin-bottom:5px">✓ Autorizado por el SRI</div>
          <div style="color:#374151;font-size:10px;font-family:monospace;word-break:break-all;line-height:1.5">{auth}</div>
        </div>
      </td></tr>''' if auth else ''}

      <!-- SEPARADOR -->
      <tr><td style="padding:0 32px"><hr style="border:none;border-top:1px solid #e8ecf0;margin:0"></td></tr>

      <!-- NOTAS -->
      <tr><td style="padding:18px 32px;text-align:center">
        <p style="color:#4b5563;font-size:14px;line-height:1.7;margin:0">
          Este comprobante electrónico es emitido conforme a la normativa del SRI Ecuador.
        </p>
        <div style="background:#f0f4ff;border:1px solid #c7d7fc;border-radius:8px;padding:14px 18px;margin:14px 0;text-align:left">
          <div style="color:#1a56db;font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px">📎 Archivos adjuntos en este correo</div>
          <div style="color:#374151;font-size:13px;line-height:1.9">
            📄 <strong>RIDE_{tipo_lbl.replace(' ','_')}_{numero.replace('-','_')}.html</strong> — Representación impresa del comprobante<br>
            📋 <strong>XML_{tipo_lbl.replace(' ','_')}_{numero.replace('-','_')}.xml</strong> — Documento electrónico para contabilidad
          </div>
        </div>
        <p style="color:#4b5563;font-size:13px;margin:6px 0 0">
          Verificar en:
          <a href="https://srienlinea.sri.gob.ec" style="color:#1a56db;text-decoration:none;font-weight:600">srienlinea.sri.gob.ec</a>
        </p>
      </td></tr>

      <!-- PIE -->
      <tr><td style="background:#f9fafb;border-top:1px solid #e8ecf0;padding:16px 32px;text-align:center">
        <div style="color:#6b7280;font-size:11px;line-height:1.7">
          {nombre_emp} &nbsp;|&nbsp; RUC: {ruc_emp}<br>
          <span style="color:#9ca3af">Generado por DAVI&LOZA SOFT v3 · Facturación Electrónica SRI Ecuador</span>
        </div>
      </td></tr>

    </table>
  </td></tr>
</table>
</body></html>"""


def _enviar_smtp(msg, emp: dict) -> dict:
    """Envía un email usando la configuración SMTP de la empresa."""
    sh = str(emp.get("smtp_host","") or "").strip()
    sp = int(emp.get("smtp_port",587) or 587)
    su = str(emp.get("smtp_user","") or "").strip()
    ss = str(emp.get("smtp_pass","") or "").strip()
    if not sh or not su or not ss:
        return {"ok":False,"error":"Configura el servidor SMTP en Configuración → Correo Electrónico"}
    try:
        ctx = ssl.create_default_context()
        if sp == 465:
            with smtplib.SMTP_SSL(sh, sp, context=ctx, timeout=15) as s:
                s.login(su, ss); s.sendmail(msg["From"], msg["To"].split(","), msg.as_string())
        else:
            with smtplib.SMTP(sh, sp, timeout=15) as s:
                s.ehlo(); s.starttls(context=ctx); s.login(su, ss)
                s.sendmail(msg["From"], msg["To"].split(","), msg.as_string())
        dest = msg["To"]
        log.info("✉ Correo enviado a %s", dest)
        return {"ok":True,"mensaje":f"Correo enviado correctamente a {dest}"}
    except smtplib.SMTPAuthenticationError:
        return {"ok":False,"error":"Error de autenticación SMTP — verifica usuario y contraseña. Para Gmail usa 'Contraseña de aplicación'."}
    except smtplib.SMTPConnectError:
        sh2 = emp.get("smtp_host","")
        sp2 = emp.get("smtp_port","")
        return {"ok":False,"error":f"No se pudo conectar a {sh2}:{sp2}. Verifica servidor y puerto."}
    except Exception as ex:
        return {"ok":False,"error":f"Error SMTP: {ex}"}


def _ride_fmt(v, dec=2):
    try:
        return ("%." + str(dec) + "f") % float(v or 0)
    except Exception:
        return "0.00"


def _ride_pdf_bytes(doc, items, emp, titulo="FACTURA"):
    """RIDE en PDF: un solo formato para TODOS los comprobantes.

    Diseño clásico del SRI: a la izquierda los datos del emisor y a la
    derecha, en su propio recuadro, el RUC, el tipo de comprobante, el
    número, la autorización y la clave de acceso con su código de barras.
    Sirve para factura, nota de crédito, guía de remisión y liquidación de
    compra, y es el mismo PDF que se adjunta en el correo.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.units import mm
        from reportlab.lib import colors
        from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle,
                                        Paragraph, Spacer, KeepTogether)
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.graphics.barcode import code128
        import io as _io
    except Exception as ex:
        log.info("reportlab no disponible (%s); se adjuntará el RIDE en HTML", ex)
        return None

    try:
        doc = dict(doc or {})
        emp = dict(emp or {})
        items = [dict(x) for x in (items or [])]

        def _e(v):
            s = str(v if v is not None else "")
            return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

        AZUL   = colors.HexColor("#1c3d6e")   # azul institucional
        AZUL_C = colors.HexColor("#E8EEF7")   # fondo suave de cabeceras
        BORDE  = colors.HexColor("#1c3d6e")
        GRIS   = colors.HexColor("#555555")
        LINEA  = colors.HexColor("#B9C4D4")

        st_emp  = ParagraphStyle("emp",  fontName="Helvetica-Bold", fontSize=12, leading=14.5, textColor=AZUL)
        st_n    = ParagraphStyle("n",    fontName="Helvetica",      fontSize=8,  leading=11)
        st_b    = ParagraphStyle("b",    fontName="Helvetica-Bold", fontSize=8,  leading=11)
        st_et   = ParagraphStyle("et",   fontName="Helvetica-Bold", fontSize=7.5, leading=10, textColor=AZUL)
        st_sm   = ParagraphStyle("sm",   fontName="Helvetica",      fontSize=7,  leading=9,  textColor=GRIS)
        st_tit  = ParagraphStyle("tit",  fontName="Helvetica-Bold", fontSize=14, leading=17, textColor=AZUL)
        st_r    = ParagraphStyle("r",    fontName="Helvetica",      fontSize=8,  leading=11, alignment=2)
        st_rb   = ParagraphStyle("rb",   fontName="Helvetica-Bold", fontSize=8,  leading=11, alignment=2)
        st_cl   = ParagraphStyle("cl",   fontName="Helvetica",      fontSize=6.5, leading=8.5, alignment=1)
        st_cab  = ParagraphStyle("cab",  fontName="Helvetica-Bold", fontSize=7.5, leading=9.5,
                                 alignment=1, textColor=colors.white)

        buf = _io.BytesIO()
        pdf = SimpleDocTemplate(buf, pagesize=A4, leftMargin=14 * mm, rightMargin=14 * mm,
                                topMargin=12 * mm, bottomMargin=12 * mm,
                                title=str(titulo) + " " + str(doc.get("numero") or ""))
        el = []
        ANCHO = 182 * mm
        IZQ, DER = ANCHO * 0.46, ANCHO * 0.54

        clave = str(doc.get("clave_acceso") or "").strip()
        aut = str(doc.get("autorizacion") or "").strip() or clave
        amb = "PRODUCCIÓN" if str(emp.get("ambiente") or "2") == "2" else "PRUEBAS"

        # ══ Cuadro izquierdo: el emisor ══
        izq = [Paragraph(_e(emp.get("nombre", "")), st_emp), Spacer(1, 2 * mm)]
        izq.append(Paragraph("Dir Matriz: " + _e(emp.get("direccion", "") or "—"), st_n))
        suc = _e(doc.get("sucursal_direccion", "") or emp.get("direccion_sucursal", "") or "")
        izq.append(Paragraph("Dir Sucursal: " + (suc if suc else "—"), st_n))
        izq.append(Paragraph("Contribuyente Especial Nro: " +
                             _e(emp.get("contribuyente_especial", "") or "—"), st_n))
        izq.append(Paragraph("Obligado a llevar contabilidad: " +
                             ("SÍ" if int(emp.get("obligado_contabilidad", 0) or 0) else "NO"), st_n))

        # ══ Cuadro derecho: el documento ══
        der = [Paragraph("R.U.C.: " + _e(emp.get("ruc", "")), st_b), Spacer(1, 1.5 * mm),
               Paragraph(_e(titulo), st_tit), Spacer(1, 1 * mm),
               Paragraph("No. " + _e(doc.get("numero", "")), st_b), Spacer(1, 2 * mm),
               Paragraph("NÚMERO DE AUTORIZACIÓN:", st_et),
               Paragraph(_e(aut), st_n), Spacer(1, 1.5 * mm)]
        fa = str(doc.get("fecha_autorizacion") or "")
        if fa:
            der.append(Paragraph("FECHA AUTORIZACIÓN: " + _e(fa), st_n))
        der.append(Paragraph("AMBIENTE: " + amb + "        EMISIÓN: Normal", st_n))
        der.append(Spacer(1, 2 * mm))
        if clave:
            der.append(Paragraph("CLAVE DE ACCESO:", st_et))
            try:
                bc = code128.Code128(clave, barHeight=11 * mm, barWidth=0.30, humanReadable=False)
                tbc = Table([[bc]], colWidths=[DER - 12 * mm])
                tbc.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER"),
                                         ("LEFTPADDING", (0, 0), (-1, -1), 0),
                                         ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                                         ("TOPPADDING", (0, 0), (-1, -1), 2),
                                         ("BOTTOMPADDING", (0, 0), (-1, -1), 0)]))
                der.append(tbc)
            except Exception:
                pass
            der.append(Paragraph(_e(clave), st_cl))

        cab = Table([[izq, der]], colWidths=[IZQ, DER])
        cab.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("BOX", (0, 0), (0, 0), 0.8, BORDE),
            ("BOX", (1, 0), (1, 0), 0.8, BORDE),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
            ("RIGHTPADDING", (0, 0), (-1, -1), 8),
            ("TOPPADDING", (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8)]))
        el.append(cab)
        el.append(Spacer(1, 3 * mm))

        # ══ Receptor ══
        nom_rec = (doc.get("cli_nombre") or doc.get("proveedor_razon_social")
                   or doc.get("transportista_nombre") or "")
        id_rec = (doc.get("ruc_cedula") or doc.get("proveedor_ruc")
                  or doc.get("transportista_ruc") or "")
        rec = [Paragraph("Razón Social / Nombres y Apellidos: <b>" + _e(nom_rec) + "</b>", st_n),
               Paragraph("Identificación: <b>" + _e(id_rec) + "</b>", st_n),
               Paragraph("Fecha Emisión: <b>" + _e(str(doc.get("fecha", ""))[:10]) + "</b>", st_n)]
        for campo, etq in (("cli_dir", "Dirección"), ("cli_telefono", "Teléfono"),
                           ("cli_email", "Correo")):
            v = str(doc.get(campo) or "").strip()
            if v:
                rec.append(Paragraph(_e(etq) + ": " + _e(v), st_n))
        trec = Table([[rec]], colWidths=[ANCHO])
        trec.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.8, BORDE),
                                  ("LEFTPADDING", (0, 0), (-1, -1), 8),
                                  ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                                  ("TOPPADDING", (0, 0), (-1, -1), 6),
                                  ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
        el.append(trec)

        # ══ Nota de crédito: documento que modifica ══
        if str(doc.get("factura_ref_numero") or "").strip():
            mod = [Paragraph("Comprobante que se modifica: <b>FACTURA - " +
                             _e(doc.get("factura_ref_numero")) + "</b>", st_n)]
            if str(doc.get("factura_ref_fecha") or "").strip():
                mod.append(Paragraph("Fecha Emisión (Comprobante a modificar): " +
                                     _e(str(doc.get("factura_ref_fecha"))[:10]), st_n))
            if str(doc.get("motivo") or "").strip():
                mod.append(Paragraph("Razón de Modificación: <b>" + _e(doc.get("motivo")) + "</b>", st_n))
            tmod = Table([[mod]], colWidths=[ANCHO])
            tmod.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.8, BORDE),
                                      ("LEFTPADDING", (0, 0), (-1, -1), 8),
                                      ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                                      ("TOPPADDING", (0, 0), (-1, -1), 6),
                                      ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
            el.append(Spacer(1, 2 * mm))
            el.append(tmod)
        el.append(Spacer(1, 3 * mm))

        # ══ Detalle ══
        encab = ["Cód.\nPrincipal", "Cód.\nAuxiliar", "Cant.", "Descripción",
                 "Detalle\nAdicional", "Precio Unit.", "Descuento", "Precio Total"]
        filas = [[Paragraph(h, st_cab) for h in encab]]
        for it in items:
            filas.append([
                Paragraph(_e(it.get("codigo", "") or ""), st_n),
                Paragraph(_e(it.get("codigo_auxiliar", "") or ""), st_n),
                Paragraph(_ride_fmt(it.get("cantidad"), 4), st_r),
                Paragraph(_e(it.get("descripcion", "") or ""), st_n),
                Paragraph(_e(it.get("detalle_adicional", "") or ""), st_n),
                Paragraph(_ride_fmt(it.get("precio_unitario"), 4), st_r),
                Paragraph(_ride_fmt(it.get("descuento"), 4), st_r),
                Paragraph(_ride_fmt(it.get("subtotal")), st_r)])
        tdet = Table(filas, repeatRows=1,
                     colWidths=[ANCHO * 0.09, ANCHO * 0.09, ANCHO * 0.08, ANCHO * 0.29,
                                ANCHO * 0.12, ANCHO * 0.11, ANCHO * 0.10, ANCHO * 0.12])
        tdet.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), AZUL),
            ("GRID", (0, 0), (-1, -1), 0.5, LINEA),
            ("BOX", (0, 0), (-1, -1), 0.8, BORDE),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F6F8FB")])]))
        el.append(tdet)
        el.append(Spacer(1, 3 * mm))

        # ══ Pie: forma de pago e información a la izquierda, totales a la derecha ══
        izq2 = []
        fp = str(doc.get("forma_pago_txt") or doc.get("forma_pago") or "").strip()
        if fp:
            tfp = Table([[Paragraph("Forma de pago", st_cab), Paragraph("Valor", st_cab)],
                         [Paragraph(_e(fp), st_n),
                          Paragraph(_ride_fmt(doc.get("total")), st_r)]],
                        colWidths=[ANCHO * 0.36, ANCHO * 0.16])
            tfp.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), AZUL),
                ("GRID", (0, 0), (-1, -1), 0.5, LINEA),
                ("BOX", (0, 0), (-1, -1), 0.8, BORDE),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
            izq2.append(tfp)
            izq2.append(Spacer(1, 2 * mm))
        info = [Paragraph("Información Adicional", st_cab)]
        hay_info = False
        for campo, etq in (("cli_dir", "Dirección"), ("cli_email", "Email"),
                           ("cli_telefono", "Teléfono"), ("notas", "Información")):
            v = str(doc.get(campo) or "").strip()
            if v:
                info.append(Paragraph("<b>" + _e(etq) + ":</b> " + _e(v), st_n))
                hay_info = True
        if not hay_info:
            info.append(Paragraph(" ", st_n))
        tinf = Table([[x] for x in info], colWidths=[ANCHO * 0.52])
        tinf.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), AZUL),
            ("BOX", (0, 0), (-1, -1), 0.8, BORDE),
            ("LINEBELOW", (0, 0), (-1, 0), 0.5, LINEA),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
        izq2.append(tinf)

        tot = [("SUBTOTAL 15%", doc.get("base_15", doc.get("subtotal_15"))),
               ("SUBTOTAL 5%", doc.get("base_5", doc.get("subtotal_5"))),
               ("SUBTOTAL 0%", doc.get("base_0", doc.get("subtotal_0"))),
               ("SUBTOTAL NO OBJETO IVA", doc.get("base_no_objeto")),
               ("SUBTOTAL EXENTO IVA", doc.get("base_exento")),
               ("SUBTOTAL SIN IMPUESTOS", doc.get("subtotal")),
               ("TOTAL DESCUENTO", doc.get("descuento")),
               ("ICE", doc.get("ice")),
               ("IVA 15%", doc.get("iva")),
               ("IVA 5%", doc.get("iva_5")),
               ("IRBPNR", doc.get("irbpnr")),
               ("PROPINA", doc.get("propina")),
               ("VALOR TOTAL", doc.get("total"))]
        ftot = []
        for etq, val in tot:
            ultimo = etq == "VALOR TOTAL"
            ftot.append([Paragraph(etq, st_b if ultimo else st_n),
                         Paragraph(_ride_fmt(val), st_rb if ultimo else st_r)])
        ttot = Table(ftot, colWidths=[ANCHO * 0.30, ANCHO * 0.16])
        ttot.setStyle(TableStyle([
            ("GRID", (0, 0), (-1, -1), 0.5, LINEA),
            ("BOX", (0, 0), (-1, -1), 0.8, BORDE),
            ("BACKGROUND", (0, len(ftot) - 1), (-1, len(ftot) - 1), AZUL_C),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            ("TOPPADDING", (0, 0), (-1, -1), 2.5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5)]))

        pie = Table([[izq2, ttot]], colWidths=[ANCHO * 0.53, ANCHO * 0.47])
        pie.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                                 ("LEFTPADDING", (0, 0), (-1, -1), 0),
                                 ("RIGHTPADDING", (0, 0), (0, 0), 6)]))
        el.append(pie)
        el.append(Spacer(1, 5 * mm))

        el.append(Paragraph(_e(emp.get("nombre", "")) + " | RUC: " + _e(emp.get("ruc", "")) +
                            " | Comprobante Electrónico autorizado por el SRI Ecuador", st_sm))

        pdf.build(el)
        return buf.getvalue()
    except Exception as ex:
        log.error("No se pudo armar el RIDE en PDF: %s", ex, exc_info=True)
        return None


def _adjuntar_ride_y_xml(msg, doc: dict, prefijo: str = "FAC"):
    """
    Adjunta el RIDE (HTML) y el XML al mensaje de correo.
    Busca el RIDE con todos los posibles nombres de archivo.
    Si no existe, lo regenera automáticamente.
    """
    clave = doc.get("clave_acceso","")
    eid   = doc.get("empresa_id","")
    num   = (doc.get("numero","") or "").replace("-","_")
    if not clave or not eid:
        return

    # ── PRIMERO: intentar adjuntar el RIDE en PDF ────────────
    pdf_adjuntado = False
    try:
        c_pdf = db()
        emp_pdf = rd(c_pdf.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
        items_pdf = []; doc_pdf = dict(doc); titulo = "FACTURA"
        if prefijo == "FAC":
            f_r = rd(c_pdf.execute("SELECT f.*, c.nombre as cliente_nombre, c.ruc_cedula as cliente_ruc, c.direccion as cliente_direccion, c.email as cliente_email FROM facturas f LEFT JOIN clientes c ON f.cliente_id=c.id WHERE f.clave_acceso=?", (clave,)).fetchone())
            if f_r:
                doc_pdf.update(f_r)
                items_pdf = rl(c_pdf.execute("SELECT * FROM factura_items WHERE factura_id=?", (f_r["id"],)).fetchall())
        elif prefijo == "NC":
            titulo = "NOTA DE CRÉDITO"
            n_r = rd(c_pdf.execute("SELECT n.*, c.nombre as cliente_nombre, c.ruc_cedula as cliente_ruc FROM notas_credito n LEFT JOIN clientes c ON n.cliente_id=c.id WHERE n.clave_acceso=?", (clave,)).fetchone())
            if n_r:
                doc_pdf.update(n_r)
                items_pdf = rl(c_pdf.execute("SELECT * FROM nota_credito_items WHERE nota_id=?", (n_r["id"],)).fetchall())
        elif prefijo == "LC":
            titulo = "LIQUIDACIÓN DE COMPRA"
            l_r = rd(c_pdf.execute("SELECT * FROM liquidaciones_compra WHERE clave_acceso=?", (clave,)).fetchone())
            if l_r:
                doc_pdf.update(l_r)
                items_pdf = rl(c_pdf.execute("SELECT * FROM liquidacion_items WHERE liquidacion_id=?", (l_r["id"],)).fetchall())
        elif prefijo == "GR":
            titulo = "GUÍA DE REMISIÓN"
        c_pdf.close()
        pdf_bytes = _ride_pdf_bytes(doc_pdf, items_pdf, emp_pdf, titulo)
        if pdf_bytes:
            pdf_part = MIMEBase("application","pdf")
            pdf_part.set_payload(pdf_bytes)
            encoders.encode_base64(pdf_part)
            pdf_part.add_header("Content-Disposition","attachment",
                                filename=f"RIDE_{prefijo}_{num}.pdf")
            msg.attach(pdf_part)
            log.info("RIDE PDF adjuntado: RIDE_%s_%s.pdf (%d KB)", prefijo, num, len(pdf_bytes)//1024)
            pdf_adjuntado = True
    except Exception as ex:
        log.warning("RIDE PDF falló, se usará HTML: %s", ex)

    # ── Adjuntar RIDE como archivo HTML (solo si no hubo PDF) ──
    ride_dir = BASE_DIR / "comprobantes" / _dir_emp(eid) / "RIDE"
    ride_dir.mkdir(parents=True, exist_ok=True)

    # Buscar con todos los posibles nombres (sin prefijo, con NC_, GR_, LC_)
    candidatos = [
        ride_dir / f"{clave}.html",
        ride_dir / f"NC_{clave}.html",
        ride_dir / f"GR_{clave}.html",
        ride_dir / f"LC_{clave}.html",
    ]
    # También intentar desde ride_path guardado en el doc
    ride_path_guardado = doc.get("ride_path","")
    if ride_path_guardado:
        candidatos.insert(0, Path(ride_path_guardado))

    ride_encontrado = pdf_adjuntado  # si ya va el PDF, no adjuntar también el HTML
    for cand in candidatos:
        if cand.exists():
            try:
                ride_bytes = cand.read_bytes()
                ride_part  = MIMEBase("text","html")
                ride_part.set_payload(ride_bytes)
                encoders.encode_base64(ride_part)
                ride_part.add_header(
                    "Content-Disposition", "attachment",
                    filename=f"RIDE_{prefijo}_{num}.html")
                ride_part.add_header("Content-Type","text/html",
                                     name=f"RIDE_{prefijo}_{num}.html")
                msg.attach(ride_part)
                log.info("RIDE adjuntado: %s", cand.name)
                ride_encontrado = True
                break
            except Exception as ex:
                log.warning("No se pudo adjuntar RIDE: %s", ex)

    if not ride_encontrado:
        # Intentar regenerar el RIDE automáticamente antes de adjuntar
        log.info("RIDE no encontrado, intentando regenerar para clave=%s", clave[:20])
        try:
            emp_r = rd(db().execute("SELECT * FROM empresas WHERE id=?",(eid,)).fetchone())
            ride_html = None
            if prefijo == "FAC":
                fid_r = rd(db().execute("SELECT id FROM facturas WHERE clave_acceso=?",(clave,)).fetchone())
                if fid_r: _generar_ride(fid_r["id"], eid, clave, doc.get("autorizacion",""), doc.get("fecha_autorizacion",""), emp_r)
            elif prefijo == "NC":
                nid_r = rd(db().execute("SELECT id FROM notas_credito WHERE clave_acceso=?",(clave,)).fetchone())
                if nid_r: _generar_ride_nc(nid_r["id"], eid, clave, doc.get("autorizacion",""), doc.get("fecha_autorizacion",""), emp_r)
            elif prefijo == "GR":
                gid_r = rd(db().execute("SELECT id FROM guias_remision WHERE clave_acceso=?",(clave,)).fetchone())
                if gid_r: _generar_ride_guia(gid_r["id"], eid, clave, doc.get("autorizacion",""), doc.get("fecha_autorizacion",""), emp_r)
            elif prefijo == "LC":
                lid_r = rd(db().execute("SELECT id FROM liquidaciones_compra WHERE clave_acceso=?",(clave,)).fetchone())
                if lid_r:
                    items_r = rl(db().execute("SELECT * FROM liquidacion_items WHERE liquidacion_id=? ORDER BY id",(lid_r["id"],)).fetchall())
                    _generar_ride_liquidacion(lid_r["id"], eid, doc, items_r, emp_r)
            # Reintentar adjuntar después de regenerar
            for cand in candidatos:
                if cand.exists():
                    ride_bytes = cand.read_bytes()
                    ride_part = MIMEBase("text","html")
                    ride_part.set_payload(ride_bytes)
                    encoders.encode_base64(ride_part)
                    ride_part.add_header("Content-Disposition","attachment",filename=f"RIDE_{prefijo}_{num}.html")
                    msg.attach(ride_part)
                    log.info("RIDE regenerado y adjuntado: %s", cand.name)
                    break
        except Exception as ex:
            log.warning("No se pudo regenerar RIDE: %s", ex)

    # ── Adjuntar XML ──────────────────────────────────────────
    for sub in ["autorizados", "firmados"]:
        xp = BASE_DIR / "comprobantes" / _dir_emp(eid) / sub / f"{clave}.xml"
        if xp.exists():
            try:
                xml_part = MIMEBase("application", "xml")
                xml_part.set_payload(xp.read_bytes())
                encoders.encode_base64(xml_part)
                xml_part.add_header(
                    "Content-Disposition", "attachment",
                    filename=f"XML_{prefijo}_{num}.xml")
                msg.attach(xml_part)
                log.info("XML adjuntado: %s", xp.name)
                break
            except Exception as ex:
                log.warning("No se pudo adjuntar XML: %s", ex)


def _envio_auto_correo(eid: int, tipo: str, doc_id: int):
    """Si la empresa tiene activado el envío automático y SMTP configurado,
    envía el correo del comprobante recién AUTORIZADO en un hilo aparte
    (no demora la respuesta de autorización). tipo: factura|nc|guia|liquidacion"""
    def _worker():
        try:
            c = db()
            emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
            if not emp or not emp.get("envio_auto_correo"):
                c.close(); return
            if not (emp.get("smtp_host") and emp.get("smtp_user") and emp.get("smtp_pass")):
                c.close(); log.info("Envío auto omitido: SMTP sin configurar"); return
            doc = None; dest = ""; fn = None
            if tipo == "factura":
                doc = rd(c.execute("""SELECT f.*, cl.email as cli_email, cl.nombre as cli_nombre
                    FROM facturas f LEFT JOIN clientes cl ON f.cliente_id=cl.id WHERE f.id=?""",(doc_id,)).fetchone())
                dest = (doc or {}).get("cli_email","") or ""; fn = enviar_correo
            elif tipo == "nc":
                doc = rd(c.execute("""SELECT nc.*, cl.email as cli_email, cl.nombre as cli_nombre
                    FROM notas_credito nc LEFT JOIN clientes cl ON nc.cliente_id=cl.id WHERE nc.id=?""",(doc_id,)).fetchone())
                dest = (doc or {}).get("cli_email","") or ""; fn = enviar_correo_nc
            elif tipo == "guia":
                doc = rd(c.execute("""SELECT gr.*, cl.email as cli_email, cl.nombre as cli_nombre
                    FROM guias_remision gr LEFT JOIN clientes cl ON gr.cliente_id=cl.id WHERE gr.id=?""",(doc_id,)).fetchone())
                dest = (doc or {}).get("cli_email","") or ""; fn = enviar_correo_guia
            elif tipo == "liquidacion":
                doc = rd(c.execute("SELECT * FROM liquidaciones_compra WHERE id=?", (doc_id,)).fetchone())
                dest = (doc or {}).get("proveedor_email","") or ""; fn = enviar_correo_liquidacion
            c.close()
            if not doc:
                log.info("Envío auto: documento %s #%s no encontrado", tipo, doc_id); return
            if not dest:
                log.info("Envío auto omitido (%s #%s): el destinatario no tiene correo registrado", tipo, doc_id); return
            r = fn(doc, emp, dest)
            if r.get("ok"): log.info("✉ Envío automático OK (%s #%s) → %s", tipo, doc_id, dest)
            else: log.warning("✉ Envío automático FALLÓ (%s #%s): %s", tipo, doc_id, r.get("error",""))
        except Exception as ex:
            log.warning("Envío automático error (%s #%s): %s", tipo, doc_id, ex)
    try:
        threading.Thread(target=_worker, daemon=True).start()
    except Exception as ex:
        log.warning("No se pudo lanzar el envío automático: %s", ex)

def enviar_correo_nc(nc: dict, emp: dict, destino: str) -> dict:
    """Envía correo de una NOTA DE CRÉDITO — adjunta RIDE.html + XML."""
    sf = str(emp.get("smtp_from","") or emp.get("smtp_user","")).strip()
    msg = MIMEMultipart("mixed")
    msg["From"]    = f"{emp.get('nombre','')} <{sf}>"
    msg["To"]      = destino
    msg["Subject"] = f"{nc['numero']} — Nota de Crédito de {emp.get('nombre','')}"

    alt = MIMEMultipart("alternative")
    plain = (f"Estimado/a {nc.get('cli_nombre','Cliente')},\n\n"
             f"Se ha emitido la Nota de Crédito {nc['numero']}.\n"
             f"Motivo: {nc.get('motivo','')}\n\n"
             f"Adjuntos:\n"
             f"  • RIDE_{nc['numero'].replace('-','_')}.html — Representación impresa\n"
             f"  • XML_{nc['numero'].replace('-','_')}.xml  — Documento electrónico\n\n"
             f"Autorización SRI: {nc.get('autorizacion','—')}\n\n"
             f"Saludos,\n{emp.get('nombre','')}")
    alt.attach(MIMEText(plain, "plain", "utf-8"))
    alt.attach(MIMEText(_email_html(nc, emp, "nc"), "html", "utf-8"))
    msg.attach(alt)
    _adjuntar_ride_y_xml(msg, nc, "NC")
    return _enviar_smtp(msg, emp)


def enviar_correo_guia(gr: dict, emp: dict, destino: str) -> dict:
    """Envía correo de una GUÍA DE REMISIÓN — adjunta RIDE.html + XML."""
    sf = str(emp.get("smtp_from","") or emp.get("smtp_user","")).strip()
    msg = MIMEMultipart("mixed")
    msg["From"]    = f"{emp.get('nombre','')} <{sf}>"
    msg["To"]      = destino
    msg["Subject"] = f"{gr['numero']} — Guía de Remisión de {emp.get('nombre','')}"

    alt = MIMEMultipart("alternative")
    plain = (f"Estimado/a {gr.get('cli_nombre','Destinatario')},\n\n"
             f"Se adjunta la Guía de Remisión {gr['numero']}.\n"
             f"Motivo: {gr.get('motivo_traslado','')}\n\n"
             f"Adjuntos:\n"
             f"  • RIDE_{gr['numero'].replace('-','_')}.html — Representación impresa\n"
             f"  • XML_{gr['numero'].replace('-','_')}.xml  — Documento electrónico\n\n"
             f"Autorización SRI: {gr.get('autorizacion','—')}\n\n"
             f"Saludos,\n{emp.get('nombre','')}")
    alt.attach(MIMEText(plain, "plain", "utf-8"))
    alt.attach(MIMEText(_email_html(gr, emp, "guia"), "html", "utf-8"))
    msg.attach(alt)
    _adjuntar_ride_y_xml(msg, gr, "GR")
    return _enviar_smtp(msg, emp)


def enviar_correo_liquidacion(liq: dict, emp: dict, destino: str) -> dict:
    """Envía correo de una LIQUIDACIÓN DE COMPRA — adjunta RIDE.html + XML."""
    sf = str(emp.get("smtp_from","") or emp.get("smtp_user","")).strip()
    msg = MIMEMultipart("mixed")
    msg["From"]    = f"{emp.get('nombre','')} <{sf}>"
    msg["To"]      = destino
    msg["Subject"] = f"{liq['numero']} — Liquidación de Compra de {emp.get('nombre','')}"

    alt = MIMEMultipart("alternative")
    plain = (f"Estimado/a {liq.get('proveedor_razon_social','Proveedor')},\n\n"
             f"Se adjunta la Liquidación de Compra {liq['numero']} "
             f"por ${float(liq.get('total',0)):.2f}.\n\n"
             f"Adjuntos:\n"
             f"  • RIDE_{liq['numero'].replace('-','_')}.html — Representación impresa\n"
             f"  • XML_{liq['numero'].replace('-','_')}.xml  — Documento electrónico\n\n"
             f"Autorización SRI: {liq.get('autorizacion','—')}\n\n"
             f"Saludos,\n{emp.get('nombre','')}")
    alt.attach(MIMEText(plain, "plain", "utf-8"))
    alt.attach(MIMEText(_email_html(liq, emp, "liquidacion"), "html", "utf-8"))
    msg.attach(alt)
    _adjuntar_ride_y_xml(msg, liq, "LC")
    return _enviar_smtp(msg, emp)
    """Genera el cuerpo HTML del correo — diseño profesional."""
    nombre_emp   = emp.get("nombre","") or "DAVI&LOZA SOFT"
    ruc_emp      = emp.get("ruc","")
    logo_b64     = emp.get("logo_base64","") or ""
    logo_tag     = (f'<img src="{logo_b64}" alt="{nombre_emp}" style="max-height:60px;max-width:200px;object-fit:contain;">'
                    if logo_b64 else
                    f'<div style="font-size:22px;font-weight:700;color:#1a56db;letter-spacing:1px">{nombre_emp}</div>')
    cli_nombre   = fac.get("cli_nombre","Cliente")
    numero       = fac.get("numero","")
    total        = f"${float(fac.get('total',0)):.2f}"
    fecha        = fac.get("fecha","")
    auth         = fac.get("autorizacion","") or fac.get("clave_acceso","")
    clave        = fac.get("clave_acceso","")

    # Formatear fecha legible
    try:
        from datetime import datetime
        dt = datetime.strptime(fecha, "%Y-%m-%d")
        meses = ["enero","febrero","marzo","abril","mayo","junio",
                 "julio","agosto","septiembre","octubre","noviembre","diciembre"]
        fecha_leg = f"{dt.day} de {meses[dt.month-1]} de {dt.year}"
    except:
        fecha_leg = fecha

    return f"""<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Factura {numero} — {nombre_emp}</title></head>
<body style="margin:0;padding:0;background:#f4f6f9;font-family:'Segoe UI',Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f6f9;padding:30px 0">
  <tr><td align="center">
    <table width="580" cellpadding="0" cellspacing="0" style="max-width:580px;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.08)">

      <!-- ENCABEZADO AZUL -->
      <tr><td style="background:linear-gradient(135deg,#1a56db,#1e40af);padding:28px 32px;text-align:center">
        <div style="color:#fff;font-size:13px;opacity:.85;margin-bottom:4px;text-transform:uppercase;letter-spacing:1px">Facturación Electrónica</div>
        <div style="color:#fff;font-size:24px;font-weight:700;letter-spacing:1px">DAVI&LOZA SOFT</div>
      </td></tr>

      <!-- LOGO EMPRESA -->
      <tr><td style="padding:28px 32px 16px;text-align:center;border-bottom:1px solid #e8ecf0">
        <div style="margin-bottom:12px">{logo_tag}</div>
        <div style="color:#374151;font-size:18px;font-weight:600">{nombre_emp}</div>
        <div style="color:#6b7280;font-size:13px;margin-top:4px">RUC: {ruc_emp}</div>
      </td></tr>

      <!-- SALUDO Y MENSAJE -->
      <tr><td style="padding:28px 32px 16px;text-align:center">
        <p style="color:#374151;font-size:16px;margin:0 0 6px">Estimado/a</p>
        <p style="color:#111827;font-size:20px;font-weight:600;margin:0 0 16px">{cli_nombre}</p>
        <p style="color:#4b5563;font-size:15px;margin:0">Has recibido una factura electrónica de</p>
        <p style="color:#1a56db;font-size:16px;font-weight:600;margin:6px 0 0">{nombre_emp}</p>
      </td></tr>

      <!-- NÚMERO DE FACTURA -->
      <tr><td style="padding:0 32px">
        <div style="background:#f0f4ff;border:1.5px solid #c7d7fc;border-radius:10px;padding:18px 24px;text-align:center">
          <div style="color:#4b5563;font-size:13px;text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px">Número de factura</div>
          <div style="color:#1a56db;font-size:22px;font-weight:700;font-family:monospace;letter-spacing:1px">{numero}</div>
        </div>
      </td></tr>

      <!-- FECHA Y MONTO -->
      <tr><td style="padding:20px 32px">
        <table width="100%" cellpadding="0" cellspacing="0">
          <tr>
            <td style="background:#f9fafb;border-radius:8px;padding:16px;text-align:center;width:48%">
              <div style="color:#6b7280;font-size:12px;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px">Fecha de emisión</div>
              <div style="color:#111827;font-size:15px;font-weight:600">{fecha_leg}</div>
            </td>
            <td width="4%"></td>
            <td style="background:#1a56db;border-radius:8px;padding:16px;text-align:center;width:48%">
              <div style="color:#93c5fd;font-size:12px;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px">Valor total</div>
              <div style="color:#fff;font-size:26px;font-weight:700">{total}</div>
            </td>
          </tr>
        </table>
      </td></tr>

      <!-- AUTORIZACIÓN SRI -->
      <tr><td style="padding:0 32px 20px">
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:14px 18px">
          <div style="color:#15803d;font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px">
            ✓ Autorizado por el SRI
          </div>
          <div style="color:#374151;font-size:11px;font-family:monospace;word-break:break-all;line-height:1.5">{auth}</div>
        </div>
      </td></tr>

      <!-- SEPARADOR -->
      <tr><td style="padding:0 32px"><hr style="border:none;border-top:1px solid #e8ecf0;margin:0"></td></tr>

      <!-- TEXTO ADICIONAL -->
      <tr><td style="padding:20px 32px;text-align:center">
        <p style="color:#4b5563;font-size:14px;line-height:1.7;margin:0">
          Este comprobante electrónico es válido como respaldo de su transacción.<br>
          Adjuntamos el archivo XML oficial para su contabilidad.
        </p>
        <p style="color:#4b5563;font-size:14px;margin:12px 0 0">
          Puede verificar este comprobante en
          <a href="https://srienlinea.sri.gob.ec" style="color:#1a56db;text-decoration:none;font-weight:600">srienlinea.sri.gob.ec</a>
        </p>
      </td></tr>

      <!-- PIE -->
      <tr><td style="background:#f9fafb;border-top:1px solid #e8ecf0;padding:20px 32px;text-align:center">
        <div style="color:#6b7280;font-size:12px;line-height:1.6">
          {nombre_emp} &nbsp;|&nbsp; RUC: {ruc_emp}<br>
          <span style="color:#9ca3af">Este correo fue generado automáticamente por DAVI&LOZA SOFT v3</span>
        </div>
      </td></tr>

    </table>
  </td></tr>
</table>
</body></html>"""


def enviar_correo(fac: dict, emp: dict, destino: str) -> dict:
    sh = str(emp.get("smtp_host","") or "").strip()
    sp = int(emp.get("smtp_port",587) or 587)
    su = str(emp.get("smtp_user","") or "").strip()
    ss = str(emp.get("smtp_pass","") or "").strip()
    sf = str(emp.get("smtp_from","") or su).strip()
    if not sh or not su or not ss:
        return {"ok":False,"error":"Configura el servidor SMTP en Configuración → Correo Electrónico"}

    # Armar correo con HTML + plain text de respaldo
    msg = MIMEMultipart("mixed")
    msg["From"]    = f"{emp.get('nombre','')} <{sf}>"
    msg["To"]      = destino
    msg["Subject"] = f"Factura {fac['numero']} — {emp.get('nombre','')}"

    # Alternativa: texto plano + HTML
    alt = MIMEMultipart("alternative")
    plain = (f"Estimado/a {fac.get('cli_nombre','Cliente')},\n\n"
             f"Adjunto su factura electrónica {fac['numero']} por ${float(fac['total']):.2f}.\n\n"
             f"Autorización SRI: {fac.get('autorizacion','—')}\n"
             f"Clave de acceso: {fac.get('clave_acceso','—')}\n\n"
             f"Saludos,\n{emp.get('nombre','')}")
    alt.attach(MIMEText(plain, "plain", "utf-8"))
    alt.attach(MIMEText(_email_html(fac, emp), "html", "utf-8"))
    msg.attach(alt)

    # Adjuntar RIDE en PDF + XML (función unificada)
    try:
        _adjuntar_ride_y_xml(msg, fac, "FAC")
    except Exception as ex:
        log.warning("No se pudieron adjuntar los archivos de la factura: %s", ex)

    try:
        ctx = ssl.create_default_context()
        if sp == 465:
            with smtplib.SMTP_SSL(sh, sp, context=ctx, timeout=15) as s:
                s.login(su, ss); s.sendmail(sf, [destino], msg.as_string())
        else:
            with smtplib.SMTP(sh, sp, timeout=15) as s:
                s.ehlo(); s.starttls(context=ctx); s.login(su, ss)
                s.sendmail(sf, [destino], msg.as_string())
        log.info("✉ Correo enviado a %s", destino)
        return {"ok":True,"mensaje":f"Correo enviado a {destino}"}
    except smtplib.SMTPAuthenticationError:
        return {"ok":False,"error":"Error de autenticación SMTP — revisa usuario y contraseña"}
    except Exception as ex:
        return {"ok":False,"error":f"Error SMTP: {ex}"}

# ════════════════════════════════════════════════════════════
# COMPROBANTES DE COMPRA/VENTA — PDF, Excel, WhatsApp y Correo  (v3.11.0)
# ════════════════════════════════════════════════════════════

def _cv_fdmy(s) -> str:
    """2026-08-24 → 24/08/2026."""
    s = str(s or "")
    p = s.split("-")
    return (p[2] + "/" + p[1] + "/" + p[0]) if len(p) == 3 else s


def _cv_esc(v) -> str:
    """Escapa texto para el mini-HTML de reportlab (&, <, >)."""
    return (str(v if v is not None else "")
            .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def _cv_n2(v) -> str:
    try:
        return f"{float(v or 0):,.2f}"
    except Exception:
        return "0.00"


def _cv_tel_wa(tel: str) -> str:
    """Normaliza un teléfono ecuatoriano al formato internacional de wa.me (5939XXXXXXXX)."""
    d = "".join(ch for ch in str(tel or "") if ch.isdigit())
    if not d:
        return ""
    if d.startswith("593"):
        return d
    if d.startswith("0"):
        return "593" + d[1:]
    if len(d) == 9 and d.startswith("9"):
        return "593" + d
    return d


def _cv_cargar(eid: int, cvid: int) -> dict:
    """Devuelve el comprobante CV con su detalle y los datos de la empresa."""
    c = db()
    r = rd(c.execute("SELECT * FROM comprobantes_cv WHERE id=? AND empresa_id=?", (cvid, eid)).fetchone())
    if not r:
        c.close()
        raise ValueError("Comprobante no encontrado")
    r["detalle"] = rl(c.execute("SELECT * FROM comprobante_cv_det WHERE comprobante_id=? ORDER BY id",
                                (cvid,)).fetchall())
    r["empresa"] = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
    c.close()
    return r


def _cv_nombre_archivo(cv: dict, ext: str) -> str:
    num = str(cv.get("numero", "") or "SN").replace("/", "-").replace(" ", "")
    return f"Comprobante_{num}.{ext}"


def _cv_texto_wa(cv: dict) -> str:
    """Mensaje de WhatsApp con el resumen del comprobante."""
    e = cv.get("empresa", {}) or {}
    L = []
    L.append("*" + str(e.get("nombre", "") or "") + "*")
    if e.get("ruc"):
        L.append("RUC: " + str(e.get("ruc")))
    L.append("")
    L.append("Estimado/a " + (str(cv.get("cliente_nombre", "") or "cliente")) + ",")
    L.append("Le compartimos el detalle de su *Comprobante de Compra/Venta "
             + str(cv.get("numero", "")) + "*:")
    L.append("")
    L.append("Fecha: " + _cv_fdmy(cv.get("fecha_emision")))
    if cv.get("documento"):
        L.append("Documento: " + str(cv.get("documento")))
    L.append("")
    for d in (cv.get("detalle") or [])[:20]:
        cant = float(d.get("cantidad", 0) or 0)
        nom = str(d.get("bien_servicio", "") or d.get("detalle", "") or "")
        L.append("• " + f"{cant:g}" + " x " + nom + " — $" + _cv_n2(d.get("subtotal")))
    if len(cv.get("detalle") or []) > 20:
        L.append("• ... y " + str(len(cv["detalle"]) - 20) + " ítem(s) más")
    L.append("")
    L.append("Subtotal: $" + _cv_n2(float(cv.get("subtotal_15", 0) or 0)
                                    + float(cv.get("subtotal_5", 0) or 0)
                                    + float(cv.get("subtotal_0", 0) or 0)))
    iva = float(cv.get("iva_15", 0) or 0) + float(cv.get("iva_5", 0) or 0)
    if iva:
        L.append("IVA: $" + _cv_n2(iva))
    if float(cv.get("total_abono", 0) or 0):
        L.append("Abonos: $" + _cv_n2(cv.get("total_abono")))
    L.append("*TOTAL: $" + _cv_n2(cv.get("total")) + "*")
    L.append("Saldo pendiente: $" + _cv_n2(cv.get("saldo")))
    L.append("")
    if cv.get("descripcion"):
        L.append(str(cv.get("descripcion")))
        L.append("")
    L.append("Gracias por su preferencia.")
    if e.get("telefono"):
        L.append("Contacto: " + str(e.get("telefono")))
    return "\n".join(L)


# ── PDF ──────────────────────────────────────────────────────
def _cv_pdf_bytes(cv: dict) -> bytes:
    """Genera el comprobante CV en PDF con reportlab. Lanza excepción si no está disponible."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle, Paragraph,
                                    Spacer, HRFlowable, Image)
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    import io as _io

    e = cv.get("empresa", {}) or {}
    buf = _io.BytesIO()
    pdf = SimpleDocTemplate(buf, pagesize=A4, leftMargin=13 * mm, rightMargin=13 * mm,
                            topMargin=12 * mm, bottomMargin=12 * mm,
                            title="Comprobante " + str(cv.get("numero", "")),
                            author=str(e.get("nombre", "")))
    ss = getSampleStyleSheet()
    st_t = ParagraphStyle("t", parent=ss["Normal"], fontSize=14, leading=17,
                          fontName="Helvetica-Bold", alignment=1)
    st_n = ParagraphStyle("n", parent=ss["Normal"], fontSize=8, leading=10.5)
    st_b = ParagraphStyle("b", parent=ss["Normal"], fontSize=8, leading=10.5, fontName="Helvetica-Bold")
    st_r = ParagraphStyle("r", parent=ss["Normal"], fontSize=8, leading=10.5, alignment=2)
    st_c = ParagraphStyle("c", parent=ss["Normal"], fontSize=7.5, leading=9.5, alignment=1)
    st_d = ParagraphStyle("d", parent=ss["Normal"], fontSize=7.5, leading=9.5)
    st_dr = ParagraphStyle("dr", parent=ss["Normal"], fontSize=7.5, leading=9.5, alignment=2)
    st_sm = ParagraphStyle("s", parent=ss["Normal"], fontSize=7, leading=9,
                           textColor=colors.HexColor("#666666"), alignment=1)
    el = []

    # ── Encabezado: logo + datos de la empresa ──
    logo_cell = Paragraph(_cv_esc(e.get("nombre", "")), st_b)
    try:
        lb = str(e.get("logo_base64", "") or "")
        if lb.startswith("data:image"):
            raw = base64.b64decode(lb.split(",", 1)[1])
            logo_cell = Image(_io.BytesIO(raw), width=38 * mm, height=16 * mm, kind="proportional")
    except Exception:
        pass
    der = [Paragraph("<b>" + _cv_esc(e.get("nombre", "")) + "</b>", st_r)]
    if e.get("ruc"):
        der.append(Paragraph("RUC: " + _cv_esc(e.get("ruc")), st_r))
    if e.get("direccion"):
        der.append(Paragraph(_cv_esc(e.get("direccion")), st_r))
    if e.get("telefono"):
        der.append(Paragraph("Tel: " + _cv_esc(e.get("telefono")), st_r))
    der.append(Paragraph("Usuario: " + _cv_esc(cv.get("usuario_nombre", "")), st_r))
    der.append(Paragraph("Impreso: " + _cv_fdmy(today_ec()), st_r))
    head = Table([[logo_cell, der]], colWidths=[85 * mm, 99 * mm])
    head.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                              ("LEFTPADDING", (0, 0), (-1, -1), 0),
                              ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    el.append(head)
    el.append(Spacer(1, 3 * mm))
    el.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor("#999999")))
    el.append(Spacer(1, 3 * mm))
    titulo = "COMPROBANTE DE COMPRA/VENTA: " + _cv_esc(cv.get("numero", ""))
    if int(cv.get("anulado", 0) or 0):
        titulo += "  (ANULADO)"
    el.append(Paragraph(titulo, st_t))
    el.append(Spacer(1, 4 * mm))

    # ── Datos de cabecera ──
    def _fila(lbl, val, lbl2=None, val2=None):
        if lbl2 is None:
            return [Paragraph(lbl, st_b), Paragraph(_cv_esc(val), st_n), "", ""]
        return [Paragraph(lbl, st_b), Paragraph(_cv_esc(val), st_n),
                Paragraph(lbl2, st_b), Paragraph(_cv_esc(val2), st_n)]

    cab = [
        _fila("Fecha de emisión:", _cv_fdmy(cv.get("fecha_emision")),
              "Vencimiento:", str(cv.get("vencimiento_dias", 0) or 0) + " días"),
        _fila("Documento:", cv.get("documento"), "Estado:", cv.get("estado")),
        _fila("Cliente:", cv.get("cliente_nombre"), "CI / RUC:", cv.get("cliente_ci")),
        _fila("Teléfonos:", cv.get("telefonos"), "Correo:", cv.get("cliente_email")),
        _fila("Vendedor:", cv.get("vendedor"), "Bodega:", cv.get("bodega")),
        _fila("Dirección:", cv.get("direccion")),
    ]
    tcab = Table(cab, colWidths=[26 * mm, 66 * mm, 24 * mm, 68 * mm])
    tcab.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#999999")),
        ("INNERGRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#dddddd")),
        ("SPAN", (1, 5), (3, 5)),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
    el.append(tcab)
    el.append(Spacer(1, 4 * mm))

    # ── Detalle de bienes/servicios ──
    el.append(Paragraph("<b><i>Bienes / Servicios</i></b>", st_n))
    el.append(Spacer(1, 1.5 * mm))
    data = [[Paragraph("<b>Cantidad</b>", st_c), Paragraph("<b>Código</b>", st_c),
             Paragraph("<b>Bien/Servicio</b>", st_c), Paragraph("<b>Detalle</b>", st_c),
             Paragraph("<b>Precio</b>", st_c), Paragraph("<b>Ret IR</b>", st_c),
             Paragraph("<b>% desc</b>", st_c), Paragraph("<b>Abono</b>", st_c),
             Paragraph("<b>Subtotal</b>", st_c)]]
    for d in (cv.get("detalle") or []):
        cant = float(d.get("cantidad", 0) or 0)
        ab = float(d.get("abono", 0) or 0)
        data.append([
            Paragraph(f"{cant:g} " + _cv_esc(d.get("unidad", "") or "Unid."), st_c),
            Paragraph(_cv_esc(d.get("codigo", "")), st_d),
            Paragraph(_cv_esc(d.get("bien_servicio", "")), st_d),
            Paragraph(_cv_esc(d.get("detalle", "")), st_d),
            Paragraph("$" + _cv_n2(d.get("precio")), st_dr),
            Paragraph(_cv_esc(d.get("ret_ir", "")), st_c),
            Paragraph(_cv_n2(d.get("desc_pct")) + "%", st_c),
            Paragraph(("$" + _cv_n2(ab)) if ab else "", st_dr),
            Paragraph("$" + _cv_n2(d.get("subtotal")), st_dr)])
    tdet = Table(data, colWidths=[17 * mm, 16 * mm, 42 * mm, 40 * mm, 18 * mm,
                                  12 * mm, 13 * mm, 15 * mm, 21 * mm], repeatRows=1)
    tdet.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#999999")),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f2f2f2")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3),
        ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5)]))
    el.append(tdet)
    el.append(Spacer(1, 5 * mm))

    # ── Descripción + totales ──
    tot_rows = [
        [Paragraph("Subtotal 15%:", st_r), Paragraph("$" + _cv_n2(cv.get("subtotal_15")), st_r)],
        [Paragraph("Subtotal 5%:", st_r), Paragraph("$" + _cv_n2(cv.get("subtotal_5")), st_r)],
        [Paragraph("Subtotal 0%:", st_r), Paragraph("$" + _cv_n2(cv.get("subtotal_0")), st_r)],
        [Paragraph("IVA 15%:", st_r), Paragraph("$" + _cv_n2(cv.get("iva_15")), st_r)],
        [Paragraph("IVA 5%:", st_r), Paragraph("$" + _cv_n2(cv.get("iva_5")), st_r)],
        [Paragraph("Abonos:", st_r), Paragraph("$" + _cv_n2(cv.get("total_abono")), st_r)],
        [Paragraph("<b>TOTAL:</b>", st_r), Paragraph("<b>$" + _cv_n2(cv.get("total")) + "</b>", st_r)],
        [Paragraph("Saldo:", st_r), Paragraph("$" + _cv_n2(cv.get("saldo")), st_r)],
    ]
    ttot = Table(tot_rows, colWidths=[38 * mm, 30 * mm])
    ttot.setStyle(TableStyle([
        ("LINEABOVE", (0, 6), (-1, 6), 0.7, colors.HexColor("#333333")),
        ("TOPPADDING", (0, 0), (-1, -1), 1.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 1.5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 2)]))
    desc = _cv_esc(cv.get("descripcion", "")).replace("\n", "<br/>")
    bloque = Table([[Paragraph("<b>Descripción:</b><br/>" + desc, st_d), ttot]],
                   colWidths=[116 * mm, 68 * mm])
    bloque.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                                ("LEFTPADDING", (0, 0), (-1, -1), 0),
                                ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    el.append(bloque)
    el.append(Spacer(1, 16 * mm))

    # ── Firmas ──
    firmas = Table([[Paragraph("Elaborado por:", st_c), "", Paragraph("Aprobado por:", st_c),
                     "", Paragraph("Revisado por:", st_c)]],
                   colWidths=[52 * mm, 13 * mm, 52 * mm, 13 * mm, 52 * mm])
    firmas.setStyle(TableStyle([
        ("LINEABOVE", (0, 0), (0, 0), 0.7, colors.HexColor("#333333")),
        ("LINEABOVE", (2, 0), (2, 0), 0.7, colors.HexColor("#333333")),
        ("LINEABOVE", (4, 0), (4, 0), 0.7, colors.HexColor("#333333")),
        ("TOPPADDING", (0, 0), (-1, -1), 3)]))
    el.append(firmas)
    el.append(Spacer(1, 6 * mm))
    pie = _cv_esc(e.get("nombre", "")) + ((" · RUC " + _cv_esc(e.get("ruc"))) if e.get("ruc") else "")
    el.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#cccccc")))
    el.append(Spacer(1, 1.5 * mm))
    el.append(Paragraph(pie + " · Generado por DAVI&amp;LOZA SOFT", st_sm))

    pdf.build(el)
    return buf.getvalue()


# ── Excel de un comprobante ──────────────────────────────────
def _cv_xlsx_bytes(cv: dict) -> bytes:
    import openpyxl, io as _io
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

    e = cv.get("empresa", {}) or {}
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Comprobante"
    fina = Side(style="thin", color="999999")
    bd = Border(left=fina, right=fina, top=fina, bottom=fina)
    az = PatternFill("solid", fgColor="1E3A5F")
    gr = PatternFill("solid", fgColor="F2F2F2")
    bl = Font(bold=True)
    bw = Font(bold=True, color="FFFFFF")

    ws.merge_cells("A1:I1")
    ws["A1"] = str(e.get("nombre", "") or "")
    ws["A1"].font = Font(bold=True, size=14)
    ws.merge_cells("A2:I2")
    ws["A2"] = ("RUC: " + str(e.get("ruc", "") or "") + "   ·   "
                + str(e.get("direccion", "") or "") + "   ·   " + str(e.get("telefono", "") or ""))
    ws.merge_cells("A3:I3")
    ws["A3"] = ("COMPROBANTE DE COMPRA/VENTA: " + str(cv.get("numero", "") or "")
                + ("  (ANULADO)" if int(cv.get("anulado", 0) or 0) else ""))
    ws["A3"].font = Font(bold=True, size=12)
    ws["A3"].alignment = Alignment(horizontal="center")

    f = 5
    cab = [("Fecha de emisión", _cv_fdmy(cv.get("fecha_emision"))),
           ("Vencimiento (días)", cv.get("vencimiento_dias", 0)),
           ("Documento", cv.get("documento", "")),
           ("Estado", cv.get("estado", "")),
           ("Cliente", cv.get("cliente_nombre", "")),
           ("CI / RUC", cv.get("cliente_ci", "")),
           ("Teléfonos", cv.get("telefonos", "")),
           ("Correo", cv.get("cliente_email", "")),
           ("Vendedor", cv.get("vendedor", "")),
           ("Bodega", cv.get("bodega", "")),
           ("Dirección", cv.get("direccion", ""))]
    for k, v in cab:
        ws.cell(row=f, column=1, value=k).font = bl
        ws.cell(row=f, column=2, value=v)
        f += 1

    f += 1
    enc = ["Cantidad", "Unidad", "Código", "Bien/Servicio", "Detalle",
           "Precio", "Ret IR", "% desc", "Abono", "Subtotal"]
    for j, h in enumerate(enc, 1):
        cel = ws.cell(row=f, column=j, value=h)
        cel.font = bw
        cel.fill = az
        cel.border = bd
        cel.alignment = Alignment(horizontal="center")
    f += 1
    for d in (cv.get("detalle") or []):
        vals = [float(d.get("cantidad", 0) or 0), str(d.get("unidad", "") or "Unid."),
                str(d.get("codigo", "") or ""), str(d.get("bien_servicio", "") or ""),
                str(d.get("detalle", "") or ""), float(d.get("precio", 0) or 0),
                str(d.get("ret_ir", "") or ""), float(d.get("desc_pct", 0) or 0),
                float(d.get("abono", 0) or 0), float(d.get("subtotal", 0) or 0)]
        for j, v in enumerate(vals, 1):
            cel = ws.cell(row=f, column=j, value=v)
            cel.border = bd
            if j in (6, 9, 10):
                cel.number_format = '"$"#,##0.00'
        f += 1

    f += 1
    tots = [("Subtotal 15%", cv.get("subtotal_15", 0)), ("Subtotal 5%", cv.get("subtotal_5", 0)),
            ("Subtotal 0%", cv.get("subtotal_0", 0)), ("IVA 15%", cv.get("iva_15", 0)),
            ("IVA 5%", cv.get("iva_5", 0)), ("Abonos", cv.get("total_abono", 0)),
            ("TOTAL", cv.get("total", 0)), ("Saldo", cv.get("saldo", 0))]
    for k, v in tots:
        cel = ws.cell(row=f, column=9, value=k)
        cel.font = bl
        cel.alignment = Alignment(horizontal="right")
        c2 = ws.cell(row=f, column=10, value=float(v or 0))
        c2.number_format = '"$"#,##0.00'
        c2.border = bd
        if k == "TOTAL":
            cel.fill = gr
            c2.fill = gr
            c2.font = bl
        f += 1

    f += 1
    ws.cell(row=f, column=1, value="Descripción:").font = bl
    ws.cell(row=f + 1, column=1, value=str(cv.get("descripcion", "") or ""))

    for j, w in enumerate([11, 9, 13, 30, 30, 11, 9, 9, 11, 13], 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(j)].width = w
    ws.freeze_panes = "A" + str(6 + len(cab) + 2)

    out = _io.BytesIO()
    wb.save(out)
    return out.getvalue()


# ── Excel del listado del periodo ────────────────────────────
def _cv_lista_xlsx_bytes(eid: int, f_ini: str, f_fin: str):
    import openpyxl, io as _io
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

    c = db()
    emp = rd(c.execute("SELECT nombre,ruc FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
    rows = rl(c.execute("""SELECT * FROM comprobantes_cv
        WHERE empresa_id=? AND fecha_emision>=? AND fecha_emision<=?
        ORDER BY fecha_emision, id""", (eid, f_ini, f_fin)).fetchall())
    dets = {}
    for r in rows:
        dets[r["id"]] = rl(c.execute("SELECT * FROM comprobante_cv_det WHERE comprobante_id=? ORDER BY id",
                                     (r["id"],)).fetchall())
    c.close()

    wb = openpyxl.Workbook()
    fina = Side(style="thin", color="999999")
    bd = Border(left=fina, right=fina, top=fina, bottom=fina)
    az = PatternFill("solid", fgColor="1E3A5F")
    bw = Font(bold=True, color="FFFFFF")
    bl = Font(bold=True)

    # Hoja 1: resumen
    ws = wb.active
    ws.title = "Comprobantes"
    ws.merge_cells("A1:M1")
    ws["A1"] = (str(emp.get("nombre", "") or "") + " — Comprobantes de Compra/Venta del "
                + _cv_fdmy(f_ini) + " al " + _cv_fdmy(f_fin))
    ws["A1"].font = Font(bold=True, size=13)
    enc = ["Número", "Fecha", "Documento", "Cliente", "CI/RUC", "Teléfonos", "Vendedor",
           "Estado", "Subtotal", "IVA", "Total", "Abonos", "Saldo"]
    for j, h in enumerate(enc, 1):
        cel = ws.cell(row=3, column=j, value=h)
        cel.font = bw
        cel.fill = az
        cel.border = bd
        cel.alignment = Alignment(horizontal="center")
    f = 4
    t_sub = t_iva = t_tot = t_ab = t_sal = 0.0
    for r in rows:
        sub = (float(r.get("subtotal_15", 0) or 0) + float(r.get("subtotal_5", 0) or 0)
               + float(r.get("subtotal_0", 0) or 0))
        iva = float(r.get("iva_15", 0) or 0) + float(r.get("iva_5", 0) or 0)
        anu = int(r.get("anulado", 0) or 0)
        vals = [str(r.get("numero", "") or ""), _cv_fdmy(r.get("fecha_emision")),
                str(r.get("documento", "") or ""), str(r.get("cliente_nombre", "") or ""),
                str(r.get("cliente_ci", "") or ""), str(r.get("telefonos", "") or ""),
                str(r.get("vendedor", "") or ""),
                ("ANULADO" if anu else str(r.get("estado", "") or "")),
                sub, iva, float(r.get("total", 0) or 0),
                float(r.get("total_abono", 0) or 0), float(r.get("saldo", 0) or 0)]
        for j, v in enumerate(vals, 1):
            cel = ws.cell(row=f, column=j, value=v)
            cel.border = bd
            if j >= 9:
                cel.number_format = '"$"#,##0.00'
        if not anu:
            t_sub += sub; t_iva += iva
            t_tot += float(r.get("total", 0) or 0)
            t_ab += float(r.get("total_abono", 0) or 0)
            t_sal += float(r.get("saldo", 0) or 0)
        f += 1
    ws.cell(row=f, column=8, value="TOTALES").font = bl
    for j, v in zip([9, 10, 11, 12, 13], [t_sub, t_iva, t_tot, t_ab, t_sal]):
        cel = ws.cell(row=f, column=j, value=round(v, 2))
        cel.font = bl
        cel.number_format = '"$"#,##0.00'
        cel.border = bd
    for j, w in enumerate([15, 12, 14, 30, 14, 16, 14, 12, 13, 12, 13, 12, 13], 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(j)].width = w
    ws.freeze_panes = "A4"

    # Hoja 2: detalle línea por línea
    ws2 = wb.create_sheet("Detalle")
    enc2 = ["Número", "Fecha", "Cliente", "Cantidad", "Unidad", "Código", "Bien/Servicio",
            "Detalle", "Precio", "% desc", "Abono", "IVA %", "Subtotal"]
    for j, h in enumerate(enc2, 1):
        cel = ws2.cell(row=1, column=j, value=h)
        cel.font = bw
        cel.fill = az
        cel.border = bd
        cel.alignment = Alignment(horizontal="center")
    f = 2
    for r in rows:
        for d in dets.get(r["id"], []):
            vals = [str(r.get("numero", "") or ""), _cv_fdmy(r.get("fecha_emision")),
                    str(r.get("cliente_nombre", "") or ""),
                    float(d.get("cantidad", 0) or 0), str(d.get("unidad", "") or "Unid."),
                    str(d.get("codigo", "") or ""), str(d.get("bien_servicio", "") or ""),
                    str(d.get("detalle", "") or ""), float(d.get("precio", 0) or 0),
                    float(d.get("desc_pct", 0) or 0), float(d.get("abono", 0) or 0),
                    float(d.get("iva_tarifa", 0) or 0), float(d.get("subtotal", 0) or 0)]
            for j, v in enumerate(vals, 1):
                cel = ws2.cell(row=f, column=j, value=v)
                cel.border = bd
                if j in (9, 11, 13):
                    cel.number_format = '"$"#,##0.00'
            f += 1
    for j, w in enumerate([15, 12, 26, 10, 9, 13, 28, 28, 11, 9, 11, 8, 13], 1):
        ws2.column_dimensions[openpyxl.utils.get_column_letter(j)].width = w
    ws2.freeze_panes = "A2"

    out = _io.BytesIO()
    wb.save(out)
    fname = "Comprobantes_CV_" + str(f_ini).replace("-", "") + "_" + str(f_fin).replace("-", "") + ".xlsx"
    return out.getvalue(), fname


# ── Correo ───────────────────────────────────────────────────
def _cv_email_html(cv: dict) -> str:
    e = cv.get("empresa", {}) or {}
    filas = ""
    for d in (cv.get("detalle") or []):
        cant = float(d.get("cantidad", 0) or 0)
        filas += ("<tr>"
                  "<td style=\"padding:6px 8px;border-bottom:1px solid #eee;font-size:12px\">"
                  + f"{cant:g}" + " " + _cv_esc(d.get("unidad", "")) + "</td>"
                  "<td style=\"padding:6px 8px;border-bottom:1px solid #eee;font-size:12px\">"
                  + _cv_esc(d.get("bien_servicio", "")) + "<br><span style=\"color:#888;font-size:11px\">"
                  + _cv_esc(d.get("detalle", "")) + "</span></td>"
                  "<td style=\"padding:6px 8px;border-bottom:1px solid #eee;font-size:12px;text-align:right\">$"
                  + _cv_n2(d.get("precio")) + "</td>"
                  "<td style=\"padding:6px 8px;border-bottom:1px solid #eee;font-size:12px;text-align:right\">$"
                  + _cv_n2(d.get("subtotal")) + "</td></tr>")
    return ("<html><body style=\"margin:0;background:#f4f6f8;font-family:Arial,Helvetica,sans-serif\">"
            "<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\"><tr><td align=\"center\" style=\"padding:24px 12px\">"
            "<table width=\"620\" cellpadding=\"0\" cellspacing=\"0\" style=\"background:#fff;border-radius:10px;overflow:hidden;border:1px solid #e5e7eb\">"
            "<tr><td style=\"background:#1E3A5F;padding:20px 28px;color:#fff\">"
            "<div style=\"font-size:17px;font-weight:bold\">" + _cv_esc(e.get("nombre", "")) + "</div>"
            "<div style=\"font-size:12px;opacity:.85\">RUC: " + _cv_esc(e.get("ruc", "")) + "</div></td></tr>"
            "<tr><td style=\"padding:24px 28px\">"
            "<p style=\"font-size:14px;color:#111;margin:0 0 12px\">Estimado/a <b>"
            + _cv_esc(cv.get("cliente_nombre", "") or "cliente") + "</b>,</p>"
            "<p style=\"font-size:13px;color:#374151;margin:0 0 16px\">Adjuntamos el "
            "<b>Comprobante de Compra/Venta " + _cv_esc(cv.get("numero", "")) + "</b> "
            "emitido el " + _cv_fdmy(cv.get("fecha_emision")) + " en formato PDF y Excel.</p>"
            "<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border:1px solid #e5e7eb;border-radius:6px\">"
            "<tr style=\"background:#f9fafb\">"
            "<th style=\"padding:8px;font-size:11px;text-align:left;color:#6b7280\">CANT.</th>"
            "<th style=\"padding:8px;font-size:11px;text-align:left;color:#6b7280\">BIEN / SERVICIO</th>"
            "<th style=\"padding:8px;font-size:11px;text-align:right;color:#6b7280\">PRECIO</th>"
            "<th style=\"padding:8px;font-size:11px;text-align:right;color:#6b7280\">SUBTOTAL</th></tr>"
            + filas + "</table>"
            "<table width=\"100%\" style=\"margin-top:14px\"><tr><td style=\"text-align:right;font-size:13px;color:#374151\">"
            "IVA: $" + _cv_n2(float(cv.get("iva_15", 0) or 0) + float(cv.get("iva_5", 0) or 0)) + "<br>"
            "<span style=\"font-size:17px;font-weight:bold;color:#111\">TOTAL: $" + _cv_n2(cv.get("total")) + "</span><br>"
            "<span style=\"font-size:12px;color:#6b7280\">Saldo pendiente: $" + _cv_n2(cv.get("saldo")) + "</span>"
            "</td></tr></table>"
            "<p style=\"font-size:12px;color:#6b7280;margin:18px 0 0\">Gracias por su preferencia.</p>"
            "</td></tr>"
            "<tr><td style=\"background:#f9fafb;border-top:1px solid #e8ecf0;padding:14px 28px;text-align:center;"
            "font-size:11px;color:#6b7280\">" + _cv_esc(e.get("nombre", ""))
            + " &nbsp;|&nbsp; Generado por DAVI&amp;LOZA SOFT</td></tr>"
            "</table></td></tr></table></body></html>")


def enviar_correo_cv(cv: dict, destino: str, mensaje: str = "", con_excel: bool = True) -> dict:
    """Envía el comprobante CV por correo con el PDF (y opcionalmente el Excel) adjunto."""
    e = cv.get("empresa", {}) or {}
    sf = str(e.get("smtp_from", "") or e.get("smtp_user", "")).strip()
    msg = MIMEMultipart("mixed")
    msg["From"] = f"{e.get('nombre','')} <{sf}>"
    msg["To"] = destino
    msg["Subject"] = ("Comprobante de Compra/Venta " + str(cv.get("numero", ""))
                      + " — " + str(e.get("nombre", "")))

    alt = MIMEMultipart("alternative")
    plain = (mensaje.strip() + "\n\n") if mensaje.strip() else ""
    plain += (f"Estimado/a {cv.get('cliente_nombre','cliente')},\n\n"
              f"Adjuntamos el Comprobante de Compra/Venta {cv.get('numero','')} "
              f"emitido el {_cv_fdmy(cv.get('fecha_emision'))}.\n\n"
              f"TOTAL: ${_cv_n2(cv.get('total'))}\n"
              f"Saldo pendiente: ${_cv_n2(cv.get('saldo'))}\n\n"
              f"Saludos,\n{e.get('nombre','')}")
    alt.attach(MIMEText(plain, "plain", "utf-8"))
    html = _cv_email_html(cv)
    if mensaje.strip():
        html = html.replace("<p style=\"font-size:13px;color:#374151;margin:0 0 16px\">",
                            "<p style=\"font-size:13px;color:#374151;margin:0 0 12px;white-space:pre-line\">"
                            + _cv_esc(mensaje.strip()).replace("\n", "<br>")
                            + "</p><p style=\"font-size:13px;color:#374151;margin:0 0 16px\">", 1)
    alt.attach(MIMEText(html, "html", "utf-8"))
    msg.attach(alt)

    try:
        pdf = _cv_pdf_bytes(cv)
        part = MIMEBase("application", "pdf")
        part.set_payload(pdf)
        encoders.encode_base64(part)
        part.add_header("Content-Disposition", "attachment", filename=_cv_nombre_archivo(cv, "pdf"))
        msg.attach(part)
    except Exception as ex:
        log.warning("No se pudo adjuntar el PDF del comprobante CV: %s", ex)

    if con_excel:
        try:
            xls = _cv_xlsx_bytes(cv)
            part = MIMEBase("application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            part.set_payload(xls)
            encoders.encode_base64(part)
            part.add_header("Content-Disposition", "attachment", filename=_cv_nombre_archivo(cv, "xlsx"))
            msg.attach(part)
        except Exception as ex:
            log.warning("No se pudo adjuntar el Excel del comprobante CV: %s", ex)

    return _enviar_smtp(msg, e)


# ════════════════════════════════════════════════════════════
# FIRMA ELECTRÓNICA DE PDF (PAdES)  —  v3.12.0
# Usa el mismo certificado .p12 que ya se guarda para el SRI.
# Requiere pyHanko:  pip install pyhanko
# ════════════════════════════════════════════════════════════

FIRMA_TSA_DEFAULT = "http://tsa.sri.gob.ec/tsa"   # sello de tiempo (opcional)


def _firma_pyhanko():
    """Devuelve los módulos de pyHanko o None si no está instalado."""
    try:
        from pyhanko.sign import signers, fields, timestamps
        from pyhanko.pdf_utils.incremental_writer import IncrementalPdfFileWriter
        from pyhanko.pdf_utils.reader import PdfFileReader
        from pyhanko import stamp
        from pyhanko.pdf_utils import text
        return {"signers": signers, "fields": fields, "timestamps": timestamps,
                "IncrementalPdfFileWriter": IncrementalPdfFileWriter,
                "PdfFileReader": PdfFileReader, "stamp": stamp, "text": text}
    except Exception as ex:
        log.info("pyHanko no disponible (%s)", ex)
        return None


def _firma_p12_bytes(emp: dict):
    """Lee el .p12 de la empresa desde disco. Devuelve (bytes, password)."""
    try:
        p = _resolver_cert(emp, emp.get("id") or 0)
    except FileNotFoundError as ex:
        raise ValueError(str(ex))
    return p.read_bytes(), str(emp.get("cert_password", "") or "")


def _firma_datos_cert(emp: dict) -> dict:
    """Extrae del .p12 los datos del firmante (nombre, cédula, emisor, vigencia)."""
    p12b, pwd = _firma_p12_bytes(emp)
    try:
        priv, cert, _ = pkcs12.load_key_and_certificates(
            p12b, pwd.encode() if pwd else None, default_backend())
    except Exception:
        raise ValueError("No se pudo abrir la firma. Revisa que la contraseña "
                         "guardada en Configuración sea la correcta.")
    if cert is None:
        raise ValueError("El archivo .p12 no contiene un certificado válido.")

    def _attr(nombre, oid):
        try:
            v = cert.subject.get_attributes_for_oid(oid)
            return str(v[0].value) if v else ""
        except Exception:
            return ""

    from cryptography.x509.oid import NameOID
    cn = _attr("cn", NameOID.COMMON_NAME)
    ci = _attr("sn", NameOID.SERIAL_NUMBER)
    org = _attr("o", NameOID.ORGANIZATION_NAME)
    if not ci:
        # Algunas entidades ponen la cédula en el pseudónimo o en el propio CN
        m = re.search(r"\b(\d{10}(?:\d{3})?)\b", cn)
        ci = m.group(1) if m else ""
    try:
        emisor = ""
        v = cert.issuer.get_attributes_for_oid(NameOID.COMMON_NAME)
        emisor = str(v[0].value) if v else ""
    except Exception:
        emisor = ""
    try:
        desde = cert.not_valid_before_utc
        hasta = cert.not_valid_after_utc
    except Exception:
        desde = cert.not_valid_before
        hasta = cert.not_valid_after
    ahora = datetime.datetime.now(desde.tzinfo) if desde.tzinfo else datetime.datetime.now()
    return {"nombre": cn, "cedula": ci, "organizacion": org, "emisor": emisor,
            "valido_desde": desde.strftime("%d/%m/%Y"),
            "valido_hasta": hasta.strftime("%d/%m/%Y"),
            "vigente": bool(desde <= ahora <= hasta),
            "dias_restantes": max(0, (hasta - ahora).days)}


def _firma_caja(W: float, H: float, posicion: str, con_qr: bool = False):
    """Calcula el rectángulo del sello visible según la posición pedida."""
    an, al, m = (268.0, 76.0, 24.0) if con_qr else (200.0, 62.0, 28.0)
    pos = (posicion or "inf-der").lower()
    if pos == "inf-izq":
        x = m
        y = m
    elif pos == "sup-der":
        x = W - an - m
        y = H - al - m
    elif pos == "sup-izq":
        x = m
        y = H - al - m
    elif pos == "inf-centro":
        x = (W - an) / 2.0
        y = m
    else:  # inf-der
        x = W - an - m
        y = m
    x = max(2.0, min(x, W - an - 2))
    y = max(2.0, min(y, H - al - 2))
    # pyHanko exige coordenadas enteras cuando el sello lleva QR
    return (int(x), int(y), int(x + an), int(y + al))


def _firma_qr_texto(datos: dict, emp: dict, razon: str, lugar: str) -> str:
    """Contenido del QR en modo 'datos' — mismo estilo que FirmaEC."""
    L = ["Firmado electronicamente por:", datos.get("nombre", "")]
    if emp.get("ruc"):
        L.append("RUC: " + str(emp.get("ruc")))
    elif datos.get("cedula"):
        L.append("CI: " + datos["cedula"])
    if razon:
        L.append("Razon: " + razon)
    if lugar:
        L.append("Localizacion: " + lugar)
    L.append("Fecha: " + datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S"))
    if datos.get("emisor"):
        L.append("Emisor: " + datos["emisor"])
    L.append("Validar en: https://www.firmadigital.gob.ec")
    return "\n".join([x for x in L if x])


def _firma_token_nuevo() -> str:
    return secrets.token_hex(5).upper()


def _firma_registrar(eid: int, token: str, info: dict):
    """Guarda el registro de la firma para que el QR pueda consultarlo."""
    try:
        c = db()
        c.execute("""INSERT OR REPLACE INTO firmas_pdf
            (empresa_id,token,archivo,firmante,cedula,ruc_empresa,razon,ubicacion,
             sha256,firmado_en,usuario_id,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (eid, token, info.get("archivo",""), info.get("firmante",""),
             info.get("cedula",""), info.get("ruc_empresa",""), info.get("razon",""),
             info.get("ubicacion",""), info.get("sha256",""), info.get("firmado_en",""),
             info.get("usuario_id"), now_ec()))
        c.commit(); c.close()
    except Exception as ex:
        log.warning("No se pudo registrar la firma %s: %s", token, ex)


def _firma_pdf_bytes(pdf_bytes: bytes, emp: dict, opciones: dict):
    """Firma un PDF con el certificado de la empresa (PAdES, sello visible)."""
    ph = _firma_pyhanko()
    if not ph:
        raise ValueError("Falta la librería pyHanko en esta computadora. "
                         "Abre una consola y ejecuta:  pip install pyhanko")
    if not pdf_bytes[:5] == b"%PDF-":
        raise ValueError("El archivo no es un PDF válido.")

    signers = ph["signers"]; fields = ph["fields"]; stamp = ph["stamp"]
    text = ph["text"]; timestamps = ph["timestamps"]
    IncrementalPdfFileWriter = ph["IncrementalPdfFileWriter"]
    PdfFileReader = ph["PdfFileReader"]
    import io as _io

    p12b, pwd = _firma_p12_bytes(emp)
    datos = _firma_datos_cert(emp)
    if not datos["vigente"]:
        raise ValueError("La firma electrónica está vencida (venció el "
                         + datos["valido_hasta"] + "). Renuévala antes de firmar.")
    try:
        signer = signers.SimpleSigner.load_pkcs12_data(p12b, [], pwd.encode() if pwd else None)
    except Exception as ex:
        raise ValueError("No se pudo cargar la firma: " + str(ex))

    # ── Página, tamaño y nombre de campo libre (permite varias firmas) ──
    r = PdfFileReader(_io.BytesIO(pdf_bytes))
    npag = int(r.root["/Pages"]["/Count"])
    usados = set()
    try:
        for s in r.embedded_signatures:
            usados.add(str(s.field_name))
    except Exception:
        pass
    n = 1
    while ("Firma_DAVILOZA_" + str(n)) in usados:
        n += 1
    campo = "Firma_DAVILOZA_" + str(n)

    pag = str(opciones.get("pagina", "ultima")).lower()
    if pag == "primera":
        idx = 0
    elif pag == "todas":
        idx = npag - 1   # el sello visible va en la última; la firma cubre todo el archivo
    else:
        try:
            idx = max(0, min(npag - 1, int(pag) - 1))
        except Exception:
            idx = npag - 1

    try:
        kid = r.root["/Pages"]["/Kids"][idx].get_object()
        mb = [float(x) for x in kid["/MediaBox"]]
        W, H = mb[2] - mb[0], mb[3] - mb[1]
    except Exception:
        W, H = 595.28, 841.89

    visible = bool(opciones.get("visible", True))
    modo_qr = str(opciones.get("qr", "no")).lower()      # no | datos | enlace
    if not visible:
        modo_qr = "no"
    caja = _firma_caja(W, H, str(opciones.get("posicion", "inf-der")),
                       modo_qr != "no") if visible else (0, 0, 0, 0)

    w = IncrementalPdfFileWriter(_io.BytesIO(pdf_bytes))
    fields.append_signature_field(w, fields.SigFieldSpec(
        sig_field_name=campo, box=caja, on_page=idx))

    razon = str(opciones.get("razon", "") or "Documento firmado electrónicamente")
    lugar = str(opciones.get("ubicacion", "") or (emp.get("ciudad", "") or "Ecuador"))

    # ── Contenido del QR ──
    token = ""
    qr_valor = ""
    if modo_qr == "enlace":
        token = _firma_token_nuevo()
        base = str(opciones.get("url_base", "") or "").rstrip("/")
        if not base:
            base = "http://localhost:7845"
        qr_valor = base + "/v?t=" + token
    elif modo_qr == "datos":
        qr_valor = _firma_qr_texto(datos, emp, razon, lugar)

    estilo = None
    if visible:
        ruc_txt = str(emp.get("ruc", "") or "")
        linea_id = ("RUC: " + ruc_txt) if ruc_txt else (("CI: " + datos["cedula"]) if datos["cedula"] else "")
        cuerpo = "FIRMADO ELECTRONICAMENTE POR:\n" + (datos["nombre"] or "")[:38]
        if linea_id:
            cuerpo += "\n" + linea_id
        cuerpo += "\nFecha: %(ts)s"
        if razon:
            cuerpo += "\nRazon: " + razon[:34]
        if modo_qr == "enlace":
            cuerpo += "\nCodigo: " + token
        else:
            cuerpo += "\nValidar en: firmadigital.gob.ec"
        if modo_qr == "no":
            estilo = stamp.TextStampStyle(
                stamp_text=cuerpo,
                border_width=1,
                text_box_style=text.TextBoxStyle(font_size=6),
                timestamp_format="%d/%m/%Y %H:%M")
        else:
            estilo = stamp.QRStampStyle(
                stamp_text=cuerpo,
                border_width=1,
                text_box_style=text.TextBoxStyle(font_size=6),
                timestamp_format="%d/%m/%Y %H:%M")

    meta = signers.PdfSignatureMetadata(
        field_name=campo, reason=razon, location=lugar,
        name=datos["nombre"] or str(emp.get("nombre", "")))

    tsa = None
    url_tsa = str(opciones.get("tsa_url", "") or "").strip()
    if opciones.get("con_tsa") and url_tsa:
        try:
            tsa = timestamps.HTTPTimeStamper(url_tsa)
        except Exception as ex:
            log.warning("TSA no disponible (%s); se firma sin sello de tiempo", ex)
            tsa = None

    params = {"url": qr_valor} if qr_valor else None
    pdf_signer = signers.PdfSigner(meta, signer=signer, stamp_style=estilo,
                                   timestamper=tsa)
    out = _io.BytesIO()
    try:
        pdf_signer.sign_pdf(w, output=out, appearance_text_params=params)
    except Exception as ex:
        if tsa is not None:
            # Reintento sin sello de tiempo: la máquina puede no tener internet
            log.warning("Falló la firma con TSA (%s); reintentando sin sello de tiempo", ex)
            w2 = IncrementalPdfFileWriter(_io.BytesIO(pdf_bytes))
            fields.append_signature_field(w2, fields.SigFieldSpec(
                sig_field_name=campo, box=caja, on_page=idx))
            out = _io.BytesIO()
            signers.PdfSigner(meta, signer=signer, stamp_style=estilo).sign_pdf(
                w2, output=out, appearance_text_params=params)
        else:
            raise
    firmado = out.getvalue()

    info = {"token": token, "qr": qr_valor, "modo_qr": modo_qr,
            "sha256": hashlib.sha256(firmado).hexdigest(),
            "firmante": datos["nombre"], "cedula": datos["cedula"],
            "ruc_empresa": str(emp.get("ruc","") or ""), "razon": razon,
            "ubicacion": lugar,
            "firmado_en": datetime.datetime.now().strftime("%d/%m/%Y %H:%M")}
    return firmado, info




def _firma_pagina_verificacion(token: str) -> str:
    """HTML público que se abre al escanear el QR de una firma."""
    def esc(v):
        return (str(v if v is not None else "")
                .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))

    reg = None
    emp = None
    if token:
        try:
            c = db()
            reg = rd(c.execute("SELECT * FROM firmas_pdf WHERE token=?", (token,)).fetchone())
            if reg:
                emp = rd(c.execute("SELECT nombre,ruc FROM empresas WHERE id=?",
                                   (reg["empresa_id"],)).fetchone()) or {}
            c.close()
        except Exception as ex:
            log.warning("Verificación de firma %s: %s", token, ex)

    css = ("*{box-sizing:border-box}body{margin:0;background:#eef2f7;font-family:-apple-system,"
           "Segoe UI,Roboto,Arial,sans-serif;color:#111;padding:18px}"
           ".w{max-width:520px;margin:0 auto;background:#fff;border-radius:14px;overflow:hidden;"
           "box-shadow:0 6px 24px rgba(15,35,70,.12)}"
           ".h{background:#1E3A5F;color:#fff;padding:20px 22px}"
           ".h b{font-size:18px}.h div{font-size:12px;opacity:.85;margin-top:2px}"
           ".ok{background:#dcfce7;color:#15803d;padding:12px 22px;font-weight:700;font-size:14px}"
           ".bad{background:#fee2e2;color:#b91c1c;padding:12px 22px;font-weight:700;font-size:14px}"
           ".b{padding:18px 22px}"
           ".r{display:flex;gap:10px;padding:9px 0;border-bottom:1px solid #eef1f5;font-size:13px}"
           ".r span{color:#6b7280;min-width:112px;flex-shrink:0}"
           ".r b{font-weight:600;word-break:break-word}"
           ".hash{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:10px;color:#374151;"
           "background:#f6f8fa;padding:8px;border-radius:6px;word-break:break-all;margin-top:4px}"
           ".n{font-size:12px;color:#4b5563;line-height:1.6;margin:14px 0 0}"
           ".btn{display:block;text-align:center;background:#1E3A5F;color:#fff;text-decoration:none;"
           "padding:12px;border-radius:8px;font-weight:600;font-size:14px;margin-top:14px}"
           ".f{background:#f9fafb;border-top:1px solid #eef1f5;padding:12px 22px;text-align:center;"
           "font-size:11px;color:#6b7280}")

    if not token:
        cuerpo = ('<div class="bad">Falta el código de verificación</div>'
                  '<div class="b"><p class="n">El enlace no incluye ningún código. '
                  'Vuelve a escanear el código QR del documento.</p></div>')
    elif not reg:
        cuerpo = ('<div class="bad">Código no encontrado: ' + esc(token) + '</div>'
                  '<div class="b"><p class="n">Este código no corresponde a ningún documento firmado '
                  'registrado en este sistema. Verifica que escaneaste el QR correcto, o que estás '
                  'consultando el servidor de la empresa que emitió el documento.</p></div>')
    else:
        filas = [("Documento", reg.get("archivo","")),
                 ("Firmado por", reg.get("firmante","")),
                 ("Identificación", reg.get("cedula","") or "—"),
                 ("Empresa", (emp or {}).get("nombre","") or "—"),
                 ("RUC", reg.get("ruc_empresa","") or "—"),
                 ("Fecha de firma", reg.get("firmado_en","")),
                 ("Razón", reg.get("razon","") or "—"),
                 ("Ubicación", reg.get("ubicacion","") or "—"),
                 ("Código", token)]
        cuerpo = '<div class="ok">✓ Firma registrada en el sistema</div><div class="b">'
        for k, v in filas:
            cuerpo += '<div class="r"><span>' + esc(k) + '</span><b>' + esc(v) + '</b></div>'
        if reg.get("sha256"):
            cuerpo += ('<p class="n" style="margin-top:14px"><b>Huella digital del archivo (SHA-256)</b><br>'
                       'El PDF firmado debe tener exactamente esta huella. Si no coincide, el archivo fue '
                       'modificado después de firmarse.</p><div class="hash">'
                       + esc(reg.get("sha256")) + '</div>')
        cuerpo += ('<p class="n"><b>Importante:</b> esta página confirma que la firma fue emitida por este '
                   'sistema y muestra sus datos. Para la validación legal completa del certificado, sube el '
                   'PDF al validador oficial del Estado ecuatoriano.</p>'
                   '<a class="btn" href="https://www.firmadigital.gob.ec" target="_blank" '
                   'rel="noopener">Validar en firmadigital.gob.ec</a></div>')

    return ("<!doctype html><html lang=\"es\"><head><meta charset=\"utf-8\">"
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            "<title>Verificación de firma electrónica</title><style>" + css + "</style></head><body>"
            "<div class=\"w\"><div class=\"h\"><b>Verificación de firma electrónica</b>"
            "<div>" + esc((emp or {}).get("nombre","") or "DAVI&LOZA SOFT") + "</div></div>"
            + cuerpo +
            "<div class=\"f\">Generado por DAVI&amp;LOZA SOFT</div></div></body></html>")


def _firma_pdf_info(pdf_bytes: bytes) -> dict:
    """Lista las firmas ya embebidas en un PDF."""
    ph = _firma_pyhanko()
    if not ph:
        return {"ok": False, "error": "pyHanko no está instalado"}
    import io as _io
    try:
        r = ph["PdfFileReader"](_io.BytesIO(pdf_bytes))
        fs = []
        for s in r.embedded_signatures:
            item = {"campo": str(s.field_name), "firmante": "", "fecha": ""}
            try:
                item["firmante"] = str(s.signer_cert.subject.native.get("common_name", "") or "")
            except Exception:
                pass
            try:
                if s.self_reported_timestamp:
                    item["fecha"] = s.self_reported_timestamp.strftime("%d/%m/%Y %H:%M")
            except Exception:
                pass
            fs.append(item)
        return {"ok": True, "paginas": int(r.root["/Pages"]["/Count"]), "firmas": fs}
    except Exception as ex:
        return {"ok": False, "error": str(ex)}


# ════════════════════════════════════════════════════════════
# API HTTP
# ════════════════════════════════════════════════════════════
class API(BaseHTTPRequestHandler):
    def log_message(self, *_): pass

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin",  "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")

    def _j(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Content-Length", len(body))
        self._cors(); self.end_headers(); self.wfile.write(body)

    def _auth(self) -> dict | None:
        return sesion_get(self.headers.get("Authorization","").replace("Bearer ","").strip())

    def do_OPTIONS(self):
        self.send_response(200); self._cors(); self.end_headers()

    # ── GET ──────────────────────────────────────────────────
    def do_GET(self):
        try:
            p  = urlparse(self.path).path
            qs = parse_qs(urlparse(self.path).query)

            # ── favicon: responder siempre (evita 401 en la consola) ──
            if p == "/favicon.ico":
                for alt in ["iconos/icon-192.png", "icono.ico", "logo.png"]:
                    fp = BASE_DIR / alt
                    if fp.exists():
                        data = fp.read_bytes()
                        self.send_response(200)
                        self.send_header("Content-Type", "image/x-icon" if alt.endswith(".ico") else "image/png")
                        self.send_header("Content-Length", str(len(data)))
                        self.send_header("Cache-Control", "max-age=86400")
                        self._cors(); self.end_headers(); self.wfile.write(data); return
                self.send_response(204); self._cors(); self.end_headers(); return

            # ── PWA: servir manifest, service worker e iconos ──
            # Permite que Chrome instale el sistema como app con icono D&L.
            # toma.html es la pantalla del celular para la toma física:
            # se sirve sin sesión porque ahí mismo está el login.
            if p in ("/manifest.json", "/sw.js", "/toma.html", "/cargando.html") or p.startswith("/iconos/"):
                nombre = p.lstrip("/")
                base = Path(BASE_DIR).resolve()
                f_path = (base / nombre).resolve()
                # Seguridad: nunca servir archivos fuera de la carpeta del sistema
                if str(f_path).startswith(str(base)) and f_path.exists() and f_path.is_file():
                    ext = f_path.suffix.lower()
                    mime = {".json": "application/json; charset=utf-8",
                            ".js":   "application/javascript; charset=utf-8",
                            ".html": "text/html; charset=utf-8",
                            ".png":  "image/png"}.get(ext, "application/octet-stream")
                    content = f_path.read_bytes()
                    self.send_response(200)
                    self.send_header("Content-Type", mime)
                    self.send_header("Content-Length", str(len(content)))
                    if p == "/sw.js":
                        self.send_header("Service-Worker-Allowed", "/")
                    self._cors(); self.end_headers(); self.wfile.write(content)
                    return
                # ── Respaldos si el archivo no está en disco ──
                if p == "/manifest.json":
                    content = PWA_MANIFEST.encode()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Content-Length", str(len(content)))
                    self._cors(); self.end_headers(); self.wfile.write(content); return
                if p == "/sw.js":
                    content = PWA_SW.encode()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/javascript; charset=utf-8")
                    self.send_header("Content-Length", str(len(content)))
                    self.send_header("Service-Worker-Allowed", "/")
                    self._cors(); self.end_headers(); self.wfile.write(content); return
                if p.startswith("/iconos/"):
                    # Fallback: usar el logo del sistema como icono
                    for alt in ["logo.png", "icono.ico"]:
                        f_alt = base / alt
                        if f_alt.exists():
                            content = f_alt.read_bytes()
                            self.send_response(200)
                            self.send_header("Content-Type", "image/png" if alt.endswith(".png") else "image/x-icon")
                            self.send_header("Content-Length", str(len(content)))
                            self._cors(); self.end_headers(); self.wfile.write(content); return
                self._j({"error": nombre + " no encontrado. Copia manifest.json, sw.js y la carpeta iconos junto a index.html"}, 404)
                return

            # ── Servir archivos estáticos (index.html, CONECTAR_AL_SERVIDOR.html) ──
            # Esto permite que otras PCs abran el sistema desde http://IP:7845/
            if p in ("/", "/index.html", ""):
                f_path = BASE_DIR / "index.html"
                content = None
                if f_path.exists():
                    content = f_path.read_bytes()
                elif getattr(sys, "frozen", False):
                    # Como .exe: usar la copia incluida en el empaquetado
                    _mp = Path(getattr(sys, "_MEIPASS", BASE_DIR)) / "index.html"
                    if _mp.exists():
                        content = _mp.read_bytes()
                if content is not None:
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(content)))
                    # Nunca cachear el index: garantiza que tras actualizar NO quede la versión vieja
                    self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
                    self.send_header("Pragma", "no-cache")
                    self.send_header("Expires", "0")
                    self._cors(); self.end_headers(); self.wfile.write(content)
                    return
                self._j({"error": "index.html no encontrado. Coloca index.html junto a servidor/"}, 404)
                return

            if p == "/CONECTAR_AL_SERVIDOR.html":
                f_path = BASE_DIR / "CONECTAR_AL_SERVIDOR.html"
                if f_path.exists():
                    content = f_path.read_bytes()
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(content)))
                    self._cors(); self.end_headers(); self.wfile.write(content)
                    return

            if p == "/api/actualizacion":
                """¿Hay una versión nueva del programa? No instala nada."""
                try:
                    import actualizador as _act
                    info = _act.consultar_version(APP_VERSION)
                except Exception as ex:
                    info = {"ok": False, "error": str(ex)}
                return self._j(info)

            if p == "/api/status":
                lic = estado_licencia()
                try:
                    c = db()
                    n_emp = c.execute("SELECT COUNT(*) FROM empresas WHERE activa=1").fetchone()[0]
                    nombre_emp = c.execute("SELECT nombre FROM empresas WHERE activa=1 LIMIT 1").fetchone()
                    c.close()
                except: n_emp = 0; nombre_emp = None
                return self._j({
                    "ok":       True,
                    "sistema":  "DAVI&LOZA SOFT",
                    "version":  APP_VERSION,
                    "features": ["extracto_banco","importaciones","reportes_sri","ride_pdf","lector_txt_49","iva_derivado"],
                    "ruta_servidor": os.path.abspath(__file__),
                    "fecha":    today_ec(),
                    "hora":     now_ec().split()[1],
                    "empresa":  nombre_emp[0] if nombre_emp else "Sin empresa",
                    "empresas": n_emp,
                    "licencia": lic.get("activa", False),
                })

            # ── Licencia (sin autenticación, se necesita antes del login) ──
            if p == "/api/licencia":
                c = db()
                # Obtener primer RUC registrado para validar licencia
                emp = rd(c.execute("SELECT ruc FROM empresas LIMIT 1").fetchone())
                c.close()
                ruc = emp["ruc"] if emp else ""
                return self._j(estado_licencia(ruc))

            if p == "/api/machine_id":
                return self._j(generar_codigo_maquina())

            if p == "/api/generar_licencia_code":
                # Generar licencia en el servidor (garantiza mismo HMAC)
                qs_data = parse_qs(urlparse(self.path).query)
                mid = qs_data.get("mid",[""])[0].strip()
                dias = int(qs_data.get("dias",["365"])[0])
                clave = qs_data.get("key",[""])[0].strip()
                if not mid or not clave:
                    return self._j({"ok":False,"error":"Faltan parametros"})
                if clave != _LIC_SECRET:
                    return self._j({"ok":False,"error":"Clave maestra incorrecta"})
                expira = (datetime.datetime.now(TZ_EC).replace(tzinfo=None) + datetime.timedelta(days=dias)).strftime("%Y%m%d")
                payload = f"{mid}:*:{expira}:{clave}"
                h = hmac.new(clave.encode(), payload.encode(), hashlib.sha256).hexdigest()
                code = h[:16].upper()
                lic = f"{code[:4]}-{code[4:8]}-{code[8:12]}-{code[12:16]}"
                meta = base64.b64encode(f"{mid}|*|{expira}".encode()).decode().rstrip("=")
                full = f"{lic}.{meta}"
                exp_fmt = f"{expira[:4]}-{expira[4:6]}-{expira[6:]}"
                return self._j({"ok":True,"licencia":full,"expira":exp_fmt,"maquina":mid})

            if p == "/api/keepalive":
                _last_ping[0] = time.time(); _ping_active[0] = True
                return self._j({"ok":True,"ts":now_ec()})

            # Buscar contribuyente por RUC/cédula (sin auth)
            if p == "/api/buscar_contribuyente":
                qs_data = parse_qs(urlparse(self.path).query)
                ruc = qs_data.get("ruc",[""])[0].strip()
                if not ruc or len(ruc) < 10:
                    return self._j({"encontrado":False})
                c = db()
                cli = rd(c.execute("SELECT nombre,email,telefono,celular,direccion,tipo_identificacion FROM clientes WHERE ruc_cedula=? LIMIT 1",(ruc,)).fetchone())
                if cli:
                    c.close()
                    return self._j({"encontrado":True,"fuente":"local","nombre":cli["nombre"],
                        "email":cli.get("email",""),"telefono":cli.get("telefono",""),
                        "celular":cli.get("celular",""),"direccion":cli.get("direccion",""),
                        "tipo_identificacion":cli.get("tipo_identificacion","05")})
                prov = rd(c.execute("SELECT nombre,email,telefono,celular,direccion,tipo_identificacion FROM proveedores WHERE ruc_cedula=? LIMIT 1",(ruc,)).fetchone())
                c.close()
                if prov:
                    return self._j({"encontrado":True,"fuente":"local","nombre":prov["nombre"],
                        "email":prov.get("email",""),"telefono":prov.get("telefono",""),
                        "celular":prov.get("celular",""),"direccion":prov.get("direccion",""),
                        "tipo_identificacion":prov.get("tipo_identificacion","04")})
                # Consultar SRI (múltiples endpoints)
                try:
                    import urllib.request, ssl
                    ctx = ssl.create_default_context()
                    ctx.check_hostname = False
                    ctx.verify_mode = ssl.CERT_NONE
                    headers = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64)","Accept":"application/json"}
                    sri_data = {}
                    # Endpoint 1: Catastro contribuyente
                    for url_sri in [
                        "https://srienlinea.sri.gob.ec/sri-catastro-sujeto-servicio-internet/rest/ConsolidadoContribuyente/obtenerPorNumerosRuc?numeroRuc="+ruc,
                        "https://srienlinea.sri.gob.ec/movil-servicios/api/v1.0/deudas/porIdentificacion/"+ruc,
                    ]:
                        try:
                            req = urllib.request.Request(url_sri, headers=headers)
                            with urllib.request.urlopen(req, timeout=8, context=ctx) as resp:
                                d = json.loads(resp.read())
                                if isinstance(d, list) and d:
                                    d = d[0]
                                # Extraer campos según estructura
                                if "contribuyente" in d:
                                    c = d["contribuyente"]
                                    sri_data["nombre"] = c.get("nombreComercial","") or c.get("razonSocial","")
                                elif "nombreComercial" in d or "razonSocial" in d:
                                    sri_data["nombre"] = d.get("nombreComercial","") or d.get("razonSocial","")
                                if "desActEconomica" in d:
                                    sri_data["actividad"] = d.get("desActEconomica","")
                                if "obligado" in d:
                                    sri_data["obligado"] = "SI" if d.get("obligado") else "NO"
                                if sri_data.get("nombre"):
                                    break
                        except: continue
                    if sri_data.get("nombre"):
                        tipo_id = "04" if len(ruc)==13 else "05"
                        return self._j({"encontrado":True,"fuente":"sri",
                            "nombre":sri_data["nombre"],
                            "tipo_identificacion":tipo_id,
                            "actividad":sri_data.get("actividad",""),
                            "obligado":sri_data.get("obligado","")})
                except Exception as ex:
                    log.debug("SRI lookup: %s", ex)
                return self._j({"encontrado":False})

            if p == "/GENERAR_LICENCIAS.html":
                gp = BASE_DIR / "GENERAR_LICENCIAS.html"
                if gp.exists():
                    self.send_response(200)
                    self.send_header("Content-Type","text/html; charset=utf-8")
                    self._cors(); self.end_headers()
                    self.wfile.write(gp.read_bytes())
                    return
                return self._j({"error":"Archivo no encontrado"},404)

            # ── Verificación pública de una firma por QR (sin login) ──
            if p == "/v":
                tk = (parse_qs(urlparse(self.path).query).get("t",[""])[0] or "").strip().upper()
                pagina = _firma_pagina_verificacion(tk)
                body = pagina.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type","text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self._cors(); self.end_headers(); self.wfile.write(body)
                return

            sess = self._auth()
            # Las etiquetas <img> del navegador no pueden mandar la cabecera
            # de autorización, así que para imágenes se acepta el token por
            # la dirección (?t=...). Sin token sigue sin servir nada.
            if not sess and p in ("/api/producto_foto", "/api/qr"):
                _tk = (qs.get("t", [""])[0] or "").strip()
                if _tk:
                    sess = sesion_obtener(_tk) if "sesion_obtener" in globals() else SESSIONS.get(_tk)
                    if sess and sess.get("expires", 0) < time.time():
                        sess = None
            if p in ("/api/producto_foto", "/api/qr") and not sess:
                self.send_response(401); self._cors(); self.end_headers(); return

            if p == "/api/mis_empresas":
                if not sess: return self._j({"error":"No autenticado"},401)
                c = db()
                rows = rl(c.execute("""SELECT e.*, ue.rol as mi_rol FROM empresas e
                    JOIN usuario_empresa ue ON e.id=ue.empresa_id
                    WHERE ue.usuario_id=? AND e.activa=1 ORDER BY e.nombre""", (sess["usuario_id"],)).fetchall())
                c.close(); return self._j(rows)

            if not sess: return self._j({"error":"No autenticado"},401)
            eid = sess["empresa_id"]

            if p == "/api/empresa":
                c = db(); e = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()); c.close()
                return self._j(e or {})

            elif p == "/api/clientes":
                q = qs.get("q",[""])[0]; c = db()
                rows = rl(c.execute("SELECT * FROM clientes WHERE empresa_id=?" +
                    (" AND (nombre LIKE ? OR ruc_cedula LIKE ?)" if q else "") + " ORDER BY nombre",
                    (eid,) + ((f"%{q}%",f"%{q}%") if q else ())).fetchall())
                c.close(); return self._j(rows)

            elif p == "/api/productos":
                q = qs.get("q",[""])[0]; c = db()
                rows = rl(c.execute("SELECT * FROM productos WHERE empresa_id=? AND activo=1" +
                    (" AND (nombre LIKE ? OR codigo LIKE ?)" if q else "") + " ORDER BY nombre",
                    (eid,) + ((f"%{q}%",f"%{q}%") if q else ())).fetchall())
                # Si el usuario pertenece a una sucursal, el stock que ve es el
                # de SU bodega. El total de la empresa viaja aparte, para que
                # la matriz pueda seguir viendo el consolidado.
                try:
                    _mia = _suc_del_usuario(c, eid, sess)
                    if _mia:
                        _bid = _suc_bodega(c, eid, sess)
                        _por_bod = {}
                        for _r in c.execute("SELECT producto_id, cantidad FROM stock_bodega WHERE bodega_id=?",
                                            (_bid,)).fetchall():
                            _por_bod[_r[0]] = float(_r[1] or 0)
                        for _p in rows:
                            _p["stock_empresa"] = _p.get("stock")
                            _p["stock"] = _por_bod.get(_p["id"], 0.0)
                            _p["sucursal"] = _mia.get("nombre", "")
                except Exception as _ex:
                    log.warning("stock por sucursal: %s", _ex)
                c.close(); return self._j(rows)

            elif p == "/api/facturas":
                q = qs.get("q",[""])[0]; est = qs.get("estado",[""])[0]
                f_ini = qs.get("fecha_ini",[""])[0]; f_fin = qs.get("fecha_fin",[""])[0]
                c = db()
                sql = """SELECT f.*, c.nombre as cli_nombre, c.email as cli_email,
                         u.nombre as usuario_nombre
                         FROM facturas f LEFT JOIN clientes c ON f.cliente_id=c.id
                         LEFT JOIN usuarios u ON f.usuario_id=u.id WHERE f.empresa_id=?"""
                params = [eid]
                # Sucursales: el usuario de un local solo ve sus comprobantes
                _fs, _ps = _suc_filtro(c, eid, sess, "f")
                if _fs: sql += _fs; params += _ps
                if q: sql += " AND (f.numero LIKE ? OR c.nombre LIKE ?)"; params += [f"%{q}%",f"%{q}%"]
                if est:
                    if est == "DEVUELTA":
                        sql += " AND f.estado_sri IN ('DEVUELTA','NO_AUTORIZADA')"
                    else:
                        sql += " AND f.estado=?"; params.append(est)
                if f_ini: sql += " AND f.fecha>=?"; params.append(f_ini)
                if f_fin: sql += " AND f.fecha<=?"; params.append(f_fin)
                sql += " ORDER BY f.id DESC"
                # Tope opcional de filas: la pantalla pide las últimas N para no
                # ahogar al navegador; las exportaciones no mandan "limite" y
                # siguen recibiendo todo. Los totales se calculan sobre TODO.
                try:
                    lim = int(qs.get("limite", ["0"])[0] or 0)
                except Exception:
                    lim = 0
                todas = rl(c.execute(sql, params).fetchall())
                rows = todas[:lim] if lim > 0 else todas
                c.close(); # Calcular totales
                tot_sub = sum(float(r.get("subtotal",0)) for r in todas if r.get("estado") != "ANULADA")
                tot_iva = sum(float(r.get("iva",0)) for r in todas if r.get("estado") != "ANULADA")
                tot_total = sum(float(r.get("total",0)) for r in todas if r.get("estado") != "ANULADA")
                return self._j({"facturas":rows,
                                "total_registros":len(todas),
                                "mostradas":len(rows),
                                "totales":{"subtotal":tot_sub,"iva":tot_iva,"total":tot_total,
                                           "count":len([r for r in todas if r.get("estado")!="ANULADA"])}})

            elif p == "/api/factura":
                fid = int(qs.get("id",[0])[0]); c = db()
                f = rd(c.execute("""SELECT f.*, c.nombre as cli_nombre, c.ruc_cedula,
                                   c.email as cli_email, c.telefono as cli_tel,
                                   c.direccion as cli_dir, c.tipo_identificacion,
                                   u.nombre as usuario_nombre
                                   FROM facturas f LEFT JOIN clientes c ON f.cliente_id=c.id
                                   LEFT JOIN usuarios u ON f.usuario_id=u.id
                                   WHERE f.id=? AND f.empresa_id=?""", (fid,eid)).fetchone())
                items = rl(c.execute("SELECT * FROM factura_items WHERE factura_id=?", (fid,)).fetchall())
                logs  = rl(c.execute("SELECT * FROM sri_log WHERE factura_id=? ORDER BY id DESC LIMIT 15", (fid,)).fetchall())
                c.close(); return self._j({**(f or {}), "items":items, "sri_log":logs})

            elif p == "/api/siguiente_numero":
                tipo = qs.get("tipo",["factura"])[0]
                c = db(); e = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
                campo_sec = {"factura":"sec_inicio_fac","nc":"sec_inicio_nc","guia":"sec_inicio_gr","liquidacion":"sec_inicio_lc"}.get(tipo,"sec_inicio_fac")
                sec_custom = int(e.get(campo_sec) or 0)
                # El numero que se muestra tiene que salir del MISMO lugar que
                # el que se guarda al facturar: la sucursal del usuario manda.
                # Antes aqui se tomaba el establecimiento de la empresa con el
                # punto del usuario, y por eso el formulario mostraba 001-005
                # mientras la factura real salia con otro numero.
                estab, pto = _pto_emision_usuario(c, e, sess)
                if tipo == "factura":
                    sec = _siguiente_secuencial_factura(c, eid, estab, pto, sec_custom)
                else:
                    sec = e["secuencial_actual"] or 1
                    if sec_custom > 0 and sec_custom >= sec: sec = sec_custom
                c.close()
                return self._j({"numero":f"{estab}-{pto}-{str(sec).zfill(9)}","secuencial":sec})

            elif p == "/api/reportes":
                anio   = qs.get("anio",[str(datetime.datetime.now(TZ_EC).year)])[0]
                f_ini  = qs.get("fecha_ini",[""])[0]
                f_fin  = qs.get("fecha_fin",[""])[0]
                filtro = qs.get("filtro",[""])[0].strip()
                c = db()
                meses = []
                for m in range(1,13):
                    ms = f"{anio}-{m:02d}"
                    r = rd(c.execute("""SELECT COALESCE(SUM(total),0) as total, COUNT(*) as n
                        FROM facturas WHERE empresa_id=? AND strftime('%Y-%m',fecha)=?
                        AND estado NOT IN ('ANULADA','RECHAZADA')""", (eid,ms)).fetchone())
                    meses.append({"mes":m,"total":r["total"],"n":r["n"]})
                top = rl(c.execute("""SELECT cl.nombre, SUM(f.total) as total, COUNT(*) as n
                    FROM facturas f JOIN clientes cl ON f.cliente_id=cl.id
                    WHERE f.empresa_id=? AND f.estado NOT IN ('ANULADA','RECHAZADA')
                    AND strftime('%Y',f.fecha)=? GROUP BY cl.id ORDER BY total DESC LIMIT 5""",(eid,anio)).fetchall())
                rango = None
                if f_ini and f_fin:
                    rr = rd(c.execute("""SELECT COALESCE(SUM(total),0) as total,COUNT(*) as n,
                        COALESCE(SUM(subtotal),0) as subtotal,COALESCE(SUM(iva),0) as iva
                        FROM facturas WHERE empresa_id=? AND fecha>=? AND fecha<=?
                        AND estado NOT IN ('ANULADA','RECHAZADA')""",(eid,f_ini,f_fin)).fetchone())
                    top_r = rl(c.execute("""SELECT cl.nombre,SUM(f.total) as total,COUNT(*) as n
                        FROM facturas f JOIN clientes cl ON f.cliente_id=cl.id
                        WHERE f.empresa_id=? AND f.estado NOT IN ('ANULADA','RECHAZADA')
                        AND f.fecha>=? AND f.fecha<=? GROUP BY cl.id ORDER BY total DESC LIMIT 10""",(eid,f_ini,f_fin)).fetchall())
                    rows_r = rl(c.execute("""SELECT f.*,cl.nombre as cli_nombre FROM facturas f
                        LEFT JOIN clientes cl ON f.cliente_id=cl.id
                        WHERE f.empresa_id=? AND f.fecha>=? AND f.fecha<=?
                        AND f.estado NOT IN ('ANULADA','RECHAZADA')"""
                        + (" AND cl.nombre LIKE ?" if filtro else "")
                        + " ORDER BY f.fecha",
                        (eid,f_ini,f_fin,f"%{filtro}%") if filtro else (eid,f_ini,f_fin)).fetchall())
                    rango = {**dict(rr), "top_clientes":top_r, "facturas":rows_r}
                c.close()
                return self._j({"meses":meses,"top_clientes":top,"rango":rango})


            elif p == "/api/reporte_avanzado":
                # Reporte avanzado con filtros múltiples
                f_ini = qs.get("fecha_ini",[""])[0]
                f_fin = qs.get("fecha_fin",[""])[0]
                filtro_cli = qs.get("cliente",[""])[0].strip()
                filtro_usr = qs.get("vendedor",[""])[0].strip()
                filtro_est = qs.get("estado",[""])[0].strip()
                dias_venc = int(qs.get("dias_vencidos",["0"])[0] or 0)
                c = db()
                sql = """SELECT f.*,cl.nombre as cli_nombre,cl.ruc_cedula as cli_ruc,
                    cl.email as cli_email,cl.telefono as cli_tel, cl.celular as cli_cel,
                    u.username as vendedor
                    FROM facturas f
                    LEFT JOIN clientes cl ON f.cliente_id=cl.id
                    LEFT JOIN usuarios u ON f.usuario_id=u.id
                    WHERE f.empresa_id=?"""
                params = [eid]
                if f_ini: sql += " AND f.fecha>=?"; params.append(f_ini)
                if f_fin: sql += " AND f.fecha<=?"; params.append(f_fin)
                if filtro_cli: sql += " AND cl.nombre LIKE ?"; params.append(f"%{filtro_cli}%")
                if filtro_usr: sql += " AND u.username LIKE ?"; params.append(f"%{filtro_usr}%")
                if filtro_est: sql += " AND f.estado=?"; params.append(filtro_est)
                sql += " ORDER BY f.fecha DESC"
                rows = rl(c.execute(sql, params).fetchall())
                # Calcular días vencidos para cada factura
                from datetime import datetime as dt2
                hoy = dt2.now(TZ_EC).date()
                for r in rows:
                    try:
                        fd = dt2.strptime(r["fecha"],"%Y-%m-%d").date()
                        r["dias"] = (hoy - fd).days
                    except: r["dias"] = 0
                if dias_venc > 0:
                    rows = [r for r in rows if r.get("estado")=="PENDIENTE" and r.get("dias",0)>=dias_venc]
                # Stats
                total = sum(float(r.get("total",0)) for r in rows)
                total_pend = sum(float(r.get("total",0)) for r in rows if r.get("estado")=="PENDIENTE")
                total_pag = sum(float(r.get("total",0)) for r in rows if r.get("estado") in ("PAGADA","AUTORIZADA"))
                n = len(rows)
                # Top clientes
                from collections import Counter, defaultdict
                cli_totals = defaultdict(float)
                cli_counts = Counter()
                vend_totals = defaultdict(float)
                for r in rows:
                    cn = r.get("cli_nombre","Sin nombre")
                    cli_totals[cn] += float(r.get("total",0))
                    cli_counts[cn] += 1
                    vn = r.get("vendedor","")
                    if vn: vend_totals[vn] += float(r.get("total",0))
                top_cli = sorted(cli_totals.items(), key=lambda x:-x[1])[:10]
                top_vend = sorted(vend_totals.items(), key=lambda x:-x[1])[:10]
                # Alertas cobranza
                alertas = [r for r in rows if r.get("estado")=="PENDIENTE" and r.get("dias",0)>30]
                c.close()
                return self._j({
                    "facturas":rows, "total":total, "total_pendiente":total_pend,
                    "total_pagado":total_pag, "n":n,
                    "top_clientes":[{"nombre":k,"total":v,"n":cli_counts[k]} for k,v in top_cli],
                    "top_vendedores":[{"nombre":k,"total":v} for k,v in top_vend],
                    "alertas_cobranza":len(alertas),
                    "monto_vencido":sum(float(a.get("total",0)) for a in alertas)
                })

            elif p == "/api/reporte_excel_avanzado":
                # Generar Excel profesional con múltiples hojas
                f_ini = qs.get("fecha_ini",[""])[0]
                f_fin = qs.get("fecha_fin",[""])[0]
                filtro_cli = qs.get("cliente",[""])[0].strip()
                filtro_usr = qs.get("vendedor",[""])[0].strip()
                filtro_est = qs.get("estado",[""])[0].strip()
                c = db()
                sql = """SELECT f.*,cl.nombre as cli_nombre,cl.ruc_cedula as cli_ruc,
                    cl.email as cli_email, u.username as vendedor
                    FROM facturas f LEFT JOIN clientes cl ON f.cliente_id=cl.id
                    LEFT JOIN usuarios u ON f.usuario_id=u.id
                    WHERE f.empresa_id=?"""
                params = [eid]
                if f_ini: sql += " AND f.fecha>=?"; params.append(f_ini)
                if f_fin: sql += " AND f.fecha<=?"; params.append(f_fin)
                if filtro_cli: sql += " AND cl.nombre LIKE ?"; params.append(f"%{filtro_cli}%")
                if filtro_usr: sql += " AND u.username LIKE ?"; params.append(f"%{filtro_usr}%")
                if filtro_est: sql += " AND f.estado=?"; params.append(filtro_est)
                sql += " ORDER BY f.fecha DESC"
                rows = rl(c.execute(sql, params).fetchall())
                emp_info = rd(c.execute("SELECT * FROM empresas WHERE id=?",(eid,)).fetchone())
                c.close()
                from datetime import datetime as dt3
                hoy = dt3.now(TZ_EC).date()
                import openpyxl, io
                from openpyxl.styles import Font, PatternFill, Alignment, Border, Side, numbers
                from openpyxl.chart import BarChart, PieChart, Reference
                from openpyxl.utils import get_column_letter
                wb = openpyxl.Workbook()
                bdr = Border(left=Side("thin"),right=Side("thin"),top=Side("thin"),bottom=Side("thin"))
                hfont = Font(name="Arial",bold=True,color="FFFFFF",size=10)
                hfill = PatternFill("solid",fgColor="1a56db")
                afill = PatternFill("solid",fgColor="FFF3CD")
                rfill = PatternFill("solid",fgColor="F8D7DA")
                gfill = PatternFill("solid",fgColor="D4EDDA")
                # ═══ HOJA 1: RESUMEN EJECUTIVO ═══
                ws1 = wb.active; ws1.title = "Resumen Ejecutivo"
                ws1.column_dimensions["A"].width = 30
                ws1.column_dimensions["B"].width = 25
                ws1["A1"] = emp_info.get("razon_social","EMPRESA")
                ws1["A1"].font = Font(name="Arial",bold=True,size=16,color="1a56db")
                ws1["A2"] = f"Reporte: {f_ini or 'inicio'} a {f_fin or 'hoy'}"
                ws1["A2"].font = Font(name="Arial",size=11,color="666666")
                ws1["A3"] = f"RUC: {emp_info.get('ruc','')}"
                r = 5
                total = sum(float(x.get("total",0)) for x in rows)
                pend = sum(float(x.get("total",0)) for x in rows if x.get("estado")=="PENDIENTE")
                pag = total - pend
                indicators = [
                    ("Total facturado", total, gfill),
                    ("Total cobrado", pag, gfill),
                    ("Total pendiente", pend, afill if pend > 0 else gfill),
                    ("Número de facturas", len(rows), None),
                    ("Promedio por factura", total/max(len(rows),1), None),
                ]
                vencidas = [x for x in rows if x.get("estado")=="PENDIENTE" and (hoy - dt3.strptime(x["fecha"],"%Y-%m-%d").date()).days > 30]
                if vencidas:
                    monto_v = sum(float(x.get("total",0)) for x in vencidas)
                    indicators.append(("⚠ Facturas vencidas (>30 días)", len(vencidas), rfill))
                    indicators.append(("⚠ Monto vencido", monto_v, rfill))
                for label, val, fill in indicators:
                    ws1.cell(r,1,label).font = Font(name="Arial",bold=True,size=11)
                    c2 = ws1.cell(r,2,val)
                    c2.font = Font(name="Arial",size=12,bold=True)
                    if isinstance(val, float): c2.number_format = "$#,##0.00"
                    if fill: ws1.cell(r,1).fill = fill; c2.fill = fill
                    r += 1
                # ═══ HOJA 2: DETALLE FACTURAS ═══
                ws2 = wb.create_sheet("Detalle Facturas")
                hdrs = ["Numero","Cliente","RUC","Fecha","Subtotal","IVA","Total","Estado","Estado SRI","Vendedor","Días","Autorización"]
                widths = [22,30,15,12,12,10,12,12,12,14,8,50]
                for ci,h in enumerate(hdrs,1):
                    cell = ws2.cell(1,ci,h); cell.font=hfont; cell.fill=hfill; cell.border=bdr; cell.alignment=Alignment(horizontal="center")
                for ci,w in enumerate(widths,1): ws2.column_dimensions[get_column_letter(ci)].width = w
                for ri,f in enumerate(rows,2):
                    try: dias = (hoy - dt3.strptime(f["fecha"],"%Y-%m-%d").date()).days
                    except: dias = 0
                    vals = [f.get("numero",""),f.get("cli_nombre",""),f.get("cli_ruc",""),f.get("fecha",""),
                        float(f.get("subtotal",0)),float(f.get("iva",0)),float(f.get("total",0)),
                        f.get("estado",""),f.get("estado_sri",""),f.get("vendedor",""),dias,
                        str(f.get("autorizacion","") or "")]
                    for ci,v in enumerate(vals,1):
                        cell = ws2.cell(ri,ci,v); cell.border = bdr
                        if ci in (5,6,7): cell.number_format = "$#,##0.00"
                        if f.get("estado")=="PENDIENTE" and dias > 30: cell.fill = rfill
                        elif f.get("estado")=="PENDIENTE": cell.fill = afill
                # ═══ HOJA 3: POR CLIENTE ═══
                ws3 = wb.create_sheet("Por Cliente")
                from collections import defaultdict
                cli_data = defaultdict(lambda:{"total":0,"n":0,"pendiente":0})
                for f in rows:
                    cn = f.get("cli_nombre","Sin nombre")
                    cli_data[cn]["total"] += float(f.get("total",0))
                    cli_data[cn]["n"] += 1
                    if f.get("estado")=="PENDIENTE": cli_data[cn]["pendiente"] += float(f.get("total",0))
                for ci,h in enumerate(["Cliente","Facturas","Total","Pendiente","% del Total"],1):
                    cell = ws3.cell(1,ci,h); cell.font=hfont; cell.fill=hfill; cell.border=bdr
                ws3.column_dimensions["A"].width=35; ws3.column_dimensions["C"].width=14; ws3.column_dimensions["D"].width=14; ws3.column_dimensions["E"].width=12
                sorted_cli = sorted(cli_data.items(), key=lambda x:-x[1]["total"])
                for ri,(cn,cd) in enumerate(sorted_cli,2):
                    ws3.cell(ri,1,cn).border=bdr
                    ws3.cell(ri,2,cd["n"]).border=bdr
                    ws3.cell(ri,3,cd["total"]).border=bdr; ws3.cell(ri,3).number_format="$#,##0.00"
                    ws3.cell(ri,4,cd["pendiente"]).border=bdr; ws3.cell(ri,4).number_format="$#,##0.00"
                    pct = cd["total"]/total*100 if total else 0
                    ws3.cell(ri,5,round(pct,1)).border=bdr; ws3.cell(ri,5).number_format="0.0%"
                # Gráfico de barras por cliente
                if len(sorted_cli) > 0:
                    chart = BarChart(); chart.title = "Ventas por Cliente"; chart.style = 10
                    chart.y_axis.title = "Monto ($)"; chart.x_axis.title = "Cliente"
                    n_cli = min(len(sorted_cli),10)
                    data = Reference(ws3,min_col=3,min_row=1,max_row=n_cli+1)
                    cats = Reference(ws3,min_col=1,min_row=2,max_row=n_cli+1)
                    chart.add_data(data,titles_from_data=True); chart.set_categories(cats)
                    chart.width = 22; chart.height = 12
                    ws3.add_chart(chart, f"A{len(sorted_cli)+4}")
                # ═══ HOJA 4: ALERTAS COBRANZA ═══
                ws4 = wb.create_sheet("Alertas Cobranza")
                ws4["A1"] = "⚠ ALERTAS DE COBRANZA — Facturas pendientes > 30 días"
                ws4["A1"].font = Font(name="Arial",bold=True,size=13,color="CC0000")
                for ci,h in enumerate(["Número","Cliente","Teléfono","Email","Fecha","Total","Días Vencidos"],1):
                    cell = ws4.cell(2,ci,h); cell.font=hfont; cell.fill=PatternFill("solid",fgColor="CC0000"); cell.border=bdr
                ws4.column_dimensions["A"].width=22; ws4.column_dimensions["B"].width=30; ws4.column_dimensions["C"].width=15
                ws4.column_dimensions["D"].width=25; ws4.column_dimensions["F"].width=12; ws4.column_dimensions["G"].width=14
                ri = 3
                for f in sorted(vencidas, key=lambda x:-(hoy-dt3.strptime(x["fecha"],"%Y-%m-%d").date()).days):
                    dias = (hoy - dt3.strptime(f["fecha"],"%Y-%m-%d").date()).days
                    vals = [f.get("numero",""),f.get("cli_nombre",""),f.get("cli_tel",""),f.get("cli_email",""),
                        f.get("fecha",""),float(f.get("total",0)),dias]
                    for ci,v in enumerate(vals,1):
                        cell = ws4.cell(ri,ci,v); cell.border=bdr
                        if ci==6: cell.number_format="$#,##0.00"
                        if dias > 60: cell.fill = rfill
                        elif dias > 30: cell.fill = afill
                    ri += 1
                if not vencidas:
                    ws4.cell(3,1,"✓ No hay facturas vencidas").font = Font(name="Arial",size=12,color="228B22")
                # Guardar y enviar
                buf = io.BytesIO(); wb.save(buf); buf.seek(0)
                self.send_response(200)
                self.send_header("Content-Type","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                fname = f"Reporte_{emp_info.get('razon_social','empresa')}_{f_ini}_{f_fin}.xlsx".replace(" ","_")
                self.send_header("Content-Disposition",f"attachment; filename={fname}")
                self._cors(); self.end_headers(); self.wfile.write(buf.read())
                return

            elif p == "/api/reporte_ventas_sri":
                anio = qs.get("anio",[""])[0]; mes = qs.get("mes",[""])[0]
                pref = f"{anio}-{str(mes).zfill(2)}" if mes else str(anio)
                like = pref + "%" if not mes else pref
                c = db()
                cond = "substr(f.fecha,1,7)=?" if mes else "substr(f.fecha,1,4)=?"
                rows = rl(c.execute(f"""SELECT f.id, f.numero, f.fecha, f.subtotal, f.iva, f.total, f.estado, f.clave_acceso,
                        cl.nombre AS cliente, cl.ruc_cedula AS ruc, cl.tipo_identificacion AS tid
                        FROM facturas f LEFT JOIN clientes cl ON f.cliente_id=cl.id
                        WHERE f.empresa_id=? AND {cond}
                        ORDER BY f.fecha, f.id""", (eid, pref if mes else anio)).fetchall())
                for r in rows:
                    sub = float(r.get("subtotal") or 0); iva = float(r.get("iva") or 0)
                    r["base15"] = round(iva/0.15, 2) if iva > 0 else 0.0
                    r["base0"] = round(sub - r["base15"], 2); r["base0"] = r["base0"] if r["base0"] > 0 else 0.0
                    r["anulada"] = 1 if str(r.get("estado","")).upper() == "ANULADA" else 0
                act = [r for r in rows if not r["anulada"]]
                tot = {"num": len(act), "base0": round(sum(r["base0"] for r in act),2),
                       "base15": round(sum(r["base15"] for r in act),2),
                       "iva": round(sum(float(r.get("iva") or 0) for r in act),2),
                       "total": round(sum(float(r.get("total") or 0) for r in act),2),
                       "anuladas": sum(1 for r in rows if r["anulada"])}
                c.close()
                return self._j({"rows": rows, "totales": tot})

            elif p == "/api/reporte_compras_sri":
                anio = qs.get("anio",[""])[0]; mes = qs.get("mes",[""])[0]
                pref = f"{anio}-{str(mes).zfill(2)}" if mes else str(anio)
                c = db()
                cond = "substr(co.fecha,1,7)=?" if mes else "substr(co.fecha,1,4)=?"
                rows = rl(c.execute(f"""SELECT co.id, co.numero, co.fecha, co.subtotal, co.iva, co.total, co.estado, co.tipo,
                        pr.nombre AS proveedor, pr.ruc_cedula AS ruc
                        FROM compras co LEFT JOIN proveedores pr ON co.proveedor_id=pr.id
                        WHERE co.empresa_id=? AND {cond}
                        ORDER BY co.fecha, co.id""", (eid, pref if mes else anio)).fetchall())
                # Retenciones del período por compra
                retmap = {}
                for rr in c.execute(f"""SELECT r.compra_id, SUM(CASE WHEN d.tipo_impuesto='IVA' THEN d.valor_retenido ELSE 0 END) as ret_iva,
                        SUM(CASE WHEN d.tipo_impuesto='RENTA' THEN d.valor_retenido ELSE 0 END) as ret_renta
                        FROM retenciones r JOIN retencion_detalle d ON d.retencion_id=r.id
                        WHERE r.empresa_id=? AND IFNULL(r.estado,'')!='ANULADA' GROUP BY r.compra_id""", (eid,)).fetchall():
                    retmap[rr["compra_id"]] = {"ret_iva": float(rr["ret_iva"] or 0), "ret_renta": float(rr["ret_renta"] or 0)}
                for r in rows:
                    rm = retmap.get(r["id"], {})
                    r["ret_iva"] = round(rm.get("ret_iva",0),2); r["ret_renta"] = round(rm.get("ret_renta",0),2)
                    r["anulada"] = 1 if str(r.get("estado","")).upper() == "ANULADA" else 0
                    iva = float(r.get("iva") or 0); sub = float(r.get("subtotal") or 0)
                    r["base_iva"] = round(iva/0.15,2) if iva>0 else 0.0
                    r["base_iva0"] = round(sub - (r["base_iva"] or 0),2)
                    if r["base_iva0"] < 0: r["base_iva0"] = 0.0
                act = [r for r in rows if not r["anulada"]]
                tot = {"num": len(act),
                       "base0": round(sum(float(r.get("base_iva0") or 0) for r in act),2),
                       "base15": round(sum(float(r.get("base_iva") or 0) for r in act),2),
                       "iva": round(sum(float(r.get("iva") or 0) for r in act),2),
                       "total": round(sum(float(r.get("total") or 0) for r in act),2),
                       "ret_iva": round(sum(r["ret_iva"] for r in act),2),
                       "ret_renta": round(sum(r["ret_renta"] for r in act),2)}
                c.close()
                return self._j({"rows": rows, "totales": tot})

            elif p == "/api/reporte_sri_excel":
                tipo = qs.get("tipo",["ventas"])[0]; anio = qs.get("anio",[""])[0]; mes = qs.get("mes",[""])[0]
                data, fname = _reporte_sri_xlsx(eid, tipo, anio, mes)
                self.send_response(200)
                self.send_header("Content-Type","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                self.send_header("Content-Disposition", f'attachment; filename="{fname}"')
                self.send_header("Content-Length", str(len(data)))
                self.end_headers(); self.wfile.write(data); return

            elif p == "/api/ats_xml":
                anio = qs.get("anio",[""])[0] or now_ec()[:4]
                mes  = qs.get("mes",[""])[0] or now_ec()[5:7]
                try:
                    data, fname = _ats_xml_bytes(eid, anio, mes)
                except Exception as ex:
                    return self._j({"ok":False,"error":str(ex)})
                self.send_response(200)
                self.send_header("Content-Type","application/xml; charset=ISO-8859-1")
                self.send_header("Content-Disposition", f"attachment; filename={fname}")
                self.send_header("Content-Length", str(len(data)))
                self._cors(); self.end_headers(); self.wfile.write(data)
                return

            elif p == "/api/ats_zip":
                anio = qs.get("anio",[""])[0] or now_ec()[:4]
                mes  = qs.get("mes",[""])[0] or now_ec()[5:7]
                try:
                    data, fname = _ats_zip(eid, anio, mes)
                except Exception as ex:
                    return self._j({"ok":False,"error":str(ex)})
                self.send_response(200)
                self.send_header("Content-Type","application/zip")
                self.send_header("Content-Disposition", f"attachment; filename={fname}")
                self.send_header("Content-Length", str(len(data)))
                self._cors(); self.end_headers(); self.wfile.write(data)
                return

            elif p == "/api/ats_validar":
                anio = qs.get("anio",[""])[0] or now_ec()[:4]
                mes  = qs.get("mes",[""])[0] or now_ec()[5:7]
                try:
                    return self._j(_ats_validar(eid, anio, mes))
                except Exception as ex:
                    return self._j({"ok":False,"problemas":[str(ex)],"avisos":[]})

            elif p == "/api/ats_excel":
                anio = qs.get("anio",[""])[0] or now_ec()[:4]
                mes  = qs.get("mes",[""])[0] or now_ec()[5:7]
                try:
                    buf, fname = _ats_xlsx(eid, anio, mes)
                except Exception as ex:
                    return self._j({"ok":False,"error":str(ex)})
                self.send_response(200)
                self.send_header("Content-Type","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                self.send_header("Content-Disposition", f"attachment; filename={fname}")
                self._cors(); self.end_headers(); self.wfile.write(buf.read())
                return

            elif p == "/api/exportar_xlsx":
                f_ini = qs.get("fecha_ini",[""])[0]
                f_fin = qs.get("fecha_fin",[""])[0]
                filtro = qs.get("filtro",[""])[0].strip()
                c = db()
                emp_r = rd(c.execute("SELECT * FROM empresas WHERE id=?",(eid,)).fetchone())
                sql = """SELECT f.*,cl.nombre as cli_nombre,cl.ruc_cedula as cli_ruc,u.username as usuario_nombre
                    FROM facturas f LEFT JOIN clientes cl ON f.cliente_id=cl.id
                    LEFT JOIN usuarios u ON f.usuario_id=u.id
                    WHERE f.empresa_id=? AND f.fecha>=? AND f.fecha<=?"""
                params = [eid, f_ini, f_fin]
                if filtro:
                    sql += " AND cl.nombre LIKE ?"
                    params.append(f"%{filtro}%")
                sql += " ORDER BY f.fecha"
                rows = rl(c.execute(sql, params).fetchall()); c.close()
                import openpyxl, io
                from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
                from openpyxl.utils import get_column_letter
                wb = openpyxl.Workbook()
                ws = wb.active; ws.title = "ListadoVentas"
                bdr = Border(left=Side("thin"),right=Side("thin"),top=Side("thin"),bottom=Side("thin"))
                # Título
                ws.merge_cells("A2:N2")
                ws["A2"] = "LISTADO DE VENTAS"
                ws["A2"].font = Font(name="Arial",bold=True,size=14,color="1a56db")
                ws["A2"].alignment = Alignment(horizontal="center")
                ws.merge_cells("A4:D4")
                ws["A4"] = emp_r.get("nombre","EMPRESA")
                ws["A4"].font = Font(name="Arial",bold=True,size=11)
                ws.merge_cells("F4:I4")
                ws["F4"] = f"Período: {f_ini} al {f_fin}"
                ws["F4"].font = Font(name="Arial",size=10,color="666666")
                # Encabezados en fila 7
                hdrs = ["Estatus","Cliente","RUC","Factura","Fecha","Subtotal 15%","Subtotal 0%","Descuento","IVA","Total","Forma Pago","Autorización","Vendedor","N. Crédito"]
                widths = [8,30,15,22,12,14,12,10,12,14,20,50,14,14]
                hfont = Font(name="Arial",bold=True,color="FFFFFF",size=9)
                hfill = PatternFill("solid",fgColor="1a56db")
                for ci,h in enumerate(hdrs,1):
                    cell = ws.cell(7,ci,h)
                    cell.font=hfont;cell.fill=hfill;cell.border=bdr
                    cell.alignment=Alignment(horizontal="center",wrap_text=True)
                    ws.column_dimensions[get_column_letter(ci)].width = widths[ci-1]
                # Datos
                fp_map = {"01":"Efectivo","15":"Comp. Deudas","16":"T. Débito","17":"D. Electrónico","18":"T. Prepago","19":"T. Crédito","20":"Transferencia","21":"Endoso"}
                tot_sub=tot_iva=tot_total=0
                alt = PatternFill("solid",fgColor="F0F4FF")
                for ri,f in enumerate(rows,8):
                    est = "A" if f.get("estado") in ("ANULADA","RECHAZADA") else "I"
                    fp = fp_map.get(str(f.get("forma_pago","01")),"Efectivo")
                    sub=float(f.get("subtotal",0));iva=float(f.get("iva",0));total=float(f.get("total",0))
                    tot_sub+=sub;tot_iva+=iva;tot_total+=total
                    vals = [est,f.get("cli_nombre",""),f.get("cli_ruc",""),f.get("numero",""),
                        f.get("fecha",""),sub,0,0,iva,total,fp,
                        str(f.get("autorizacion","") or ""),f.get("usuario_nombre",""),""]
                    for ci,v in enumerate(vals,1):
                        cell = ws.cell(ri,ci,v); cell.border=bdr
                        cell.font = Font(name="Arial",size=9)
                        if ci in (6,7,8,9,10): cell.number_format="$#,##0.00"
                        if ri%2==0: cell.fill=alt
                        if est=="A": cell.font=Font(name="Arial",size=9,color="CC0000")
                # Totales
                tr = len(rows)+8
                ws.cell(tr,5,"TOTALES:").font=Font(name="Arial",bold=True,size=10)
                for ci,val in [(6,tot_sub),(9,tot_iva),(10,tot_total)]:
                    cell=ws.cell(tr,ci,val);cell.font=Font(name="Arial",bold=True,size=10)
                    cell.number_format="$#,##0.00";cell.border=bdr
                    cell.fill=PatternFill("solid",fgColor="D4EDDA")
                buf = io.BytesIO(); wb.save(buf); buf.seek(0)
                self.send_response(200)
                self.send_header("Content-Type","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                fname = f"Ventas_{emp_r.get('nombre','').replace(' ','_')}_{f_ini}_{f_fin}.xlsx"
                self.send_header("Content-Disposition",f"attachment; filename={fname}")
                self._cors(); self.end_headers()
                self.wfile.write(buf.read())
                return

            elif p == "/api/notas_credito":
                q = qs.get("q",[""])[0]; c = db()
                sql = """SELECT nc.*, cl.nombre as cli_nombre FROM notas_credito nc
                         LEFT JOIN clientes cl ON nc.cliente_id=cl.id
                         WHERE nc.empresa_id=?"""
                params = [eid]
                if q: sql += " AND (nc.numero LIKE ? OR cl.nombre LIKE ?)"; params += [f"%{q}%",f"%{q}%"]
                sql += " ORDER BY nc.id DESC"
                rows = rl(c.execute(sql, params).fetchall()); c.close()
                return self._j(rows)

            elif p == "/api/nota_credito":
                nid = int(qs.get("id",[0])[0]); c = db()
                n = rd(c.execute("""SELECT nc.*,cl.nombre as cli_nombre,cl.ruc_cedula,cl.email as cli_email
                    FROM notas_credito nc LEFT JOIN clientes cl ON nc.cliente_id=cl.id
                    WHERE nc.id=? AND nc.empresa_id=?""",(nid,eid)).fetchone())
                items = rl(c.execute("SELECT * FROM nota_credito_items WHERE nota_id=?",(nid,)).fetchall())
                c.close()
                return self._j({**(n or {}),"items":items})

            elif p == "/api/guias":
                q = qs.get("q",[""])[0]; c = db()
                sql = """SELECT g.*,cl.nombre as cli_nombre FROM guias_remision g
                         LEFT JOIN clientes cl ON g.cliente_id=cl.id WHERE g.empresa_id=?"""
                params = [eid]
                if q: sql += " AND (g.numero LIKE ? OR cl.nombre LIKE ?)"; params += [f"%{q}%",f"%{q}%"]
                sql += " ORDER BY g.id DESC"
                rows = rl(c.execute(sql, params).fetchall()); c.close()
                return self._j(rows)

            elif p == "/api/guia":
                gid = int(qs.get("id",[0])[0]); c = db()
                g = rd(c.execute("""SELECT g.*,cl.nombre as cli_nombre FROM guias_remision g
                    LEFT JOIN clientes cl ON g.cliente_id=cl.id
                    WHERE g.id=? AND g.empresa_id=?""",(gid,eid)).fetchone())
                items = rl(c.execute("SELECT * FROM guia_items WHERE guia_id=?",(gid,)).fetchall())
                c.close()
                return self._j({**(g or {}),"items":items})

            elif p == "/api/importaciones":
                q = (qs.get("q",[""])[0] or "").strip(); c = db()
                sql = "SELECT * FROM importaciones WHERE empresa_id=?"; args=[eid]
                if q: sql += " AND proyecto LIKE ?"; args.append("%"+q+"%")
                d1 = qs.get("desde",[""])[0]; d2 = qs.get("hasta",[""])[0]
                if d1: sql += " AND fecha>=?"; args.append(d1)
                if d2: sql += " AND fecha<=?"; args.append(d2)
                sql += " ORDER BY id DESC LIMIT 200"
                rows = rl(c.execute(sql, args).fetchall()); c.close()
                return self._j(rows)

            elif p == "/api/importacion":
                iid = int(qs.get("id",[0])[0]); c = db()
                imp = rd(c.execute("SELECT * FROM importaciones WHERE id=? AND empresa_id=?", (iid, eid)).fetchone())
                if not imp: c.close(); return self._j({"error":"No encontrada"},404)
                imp["items"] = rl(c.execute("SELECT * FROM importacion_items WHERE importacion_id=?", (iid,)).fetchall())
                c.close(); return self._j(imp)

            elif p == "/api/extracto_banco":
                cta = qs.get("cuenta_bancaria_id",["0"])[0]; c = db()
                rows = rl(c.execute("""SELECT * FROM extracto_banco WHERE empresa_id=? AND cuenta_bancaria_id=?
                        ORDER BY fecha, id""", (eid, cta)).fetchall())
                pend_ext = [r for r in rows if not r["conciliado"]]
                libro = rl(c.execute("""SELECT id,fecha,concepto,documento,ingreso,egreso,estado_concil FROM movimientos_banco
                        WHERE empresa_id=? AND cuenta_bancaria_id=? AND IFNULL(estado,'ACTIVO')='ACTIVO'
                        AND IFNULL(estado_concil,'PENDIENTE')!='CONCILIADO' ORDER BY fecha""", (eid, cta)).fetchall())
                resumen = {
                    "total_extracto": len(rows),
                    "conciliados": sum(1 for r in rows if r["conciliado"]),
                    "pend_extracto": len(pend_ext),
                    "pend_libro": len(libro),
                    "ing_extracto": round(sum(float(r.get("ingreso") or 0) for r in rows),2),
                    "egr_extracto": round(sum(float(r.get("egreso") or 0) for r in rows),2)}
                c.close()
                return self._j({"extracto": rows, "libro_pendiente": libro, "resumen": resumen})

            elif p == "/api/bodegas":
                c = db()
                if not c.execute("SELECT 1 FROM bodegas WHERE empresa_id=?", (eid,)).fetchone():
                    c.execute("INSERT INTO bodegas (empresa_id,nombre,codigo,principal,estado,created_at) VALUES (?,?,?,?,?,?)",
                              (eid, "Principal", "PRIN", 1, "ACTIVO", now_ec())); c.commit()
                rows = rl(c.execute("SELECT id,nombre,codigo,principal,estado FROM bodegas WHERE empresa_id=? ORDER BY principal DESC, id", (eid,)).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/inventario":
                q = (qs.get("q",[""])[0] or "").strip(); c = db()
                sql = "SELECT id,codigo,nombre,unidad,tipo,precio,costo,stock,cuenta_inventario FROM productos WHERE empresa_id=? AND IFNULL(activo,1)=1 AND IFNULL(tipo,'PRODUCTO')!='SERVICIO'"
                args = [eid]
                if q: sql += " AND (nombre LIKE ? OR codigo LIKE ?)"; args += ["%"+q+"%","%"+q+"%"]
                sql += " ORDER BY nombre LIMIT 1000"
                prods = rl(c.execute(sql, args).fetchall())
                for p2 in prods:
                    p2["valor"] = round(float(p2.get("stock") or 0) * float(p2.get("costo") or 0), 2)
                tot_val = round(sum(p2["valor"] for p2 in prods), 2)
                tot_items = sum(1 for p2 in prods)
                bajo = sum(1 for p2 in prods if float(p2.get("stock") or 0) <= 0)
                c.close()
                return self._j({"productos": prods, "valor_total": tot_val, "items": tot_items, "sin_stock": bajo})

            elif p == "/api/inventario_movimientos":
                pid = int(qs.get("producto",[0])[0]); c = db()
                sql = """SELECT sm.id,sm.fecha,sm.tipo,sm.cantidad,sm.stock_antes,sm.stock_despues,sm.notas,
                         p.nombre as prod_nombre, p.codigo as prod_codigo,
                         b1.nombre as bodega, b2.nombre as bodega_destino
                         FROM stock_movimientos sm
                         LEFT JOIN productos p ON sm.producto_id=p.id
                         LEFT JOIN bodegas b1 ON sm.bodega_id=b1.id
                         LEFT JOIN bodegas b2 ON sm.bodega_destino_id=b2.id
                         WHERE sm.empresa_id=?"""
                args = [eid]
                if pid: sql += " AND sm.producto_id=?"; args.append(pid)
                sql += " ORDER BY sm.id DESC LIMIT 300"
                rows = rl(c.execute(sql, args).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/cuentas_cobrar":
                cid_cl = qs.get("cliente_id",[""])[0]
                f_ini  = qs.get("fecha_ini",[""])[0]
                f_fin  = qs.get("fecha_fin",[""])[0]
                c = db()
                sql = """SELECT cc.*,cl.nombre as cli_nombre,f.numero as fac_numero
                         FROM cuentas_cobrar cc
                         LEFT JOIN clientes cl ON cc.cliente_id=cl.id
                         LEFT JOIN facturas f ON cc.factura_id=f.id
                         WHERE cc.empresa_id=?"""
                params = [eid]
                if cid_cl: sql += " AND cc.cliente_id=?"; params.append(cid_cl)
                if f_ini:  sql += " AND cc.fecha>=?";      params.append(f_ini)
                if f_fin:  sql += " AND cc.fecha<=?";      params.append(f_fin)
                sql += " ORDER BY cc.id DESC"
                rows = rl(c.execute(sql, params).fetchall())
                saldos = rl(c.execute("""SELECT cl.id,cl.nombre,cl.ruc_cedula,
                    COALESCE((SELECT saldo FROM cuentas_cobrar cc WHERE cc.empresa_id=? AND cc.cliente_id=cl.id ORDER BY cc.id DESC LIMIT 1),0) as saldo_actual
                    FROM clientes cl WHERE cl.empresa_id=? ORDER BY cl.nombre""",(eid,eid)).fetchall())
                c.close()
                return self._j({"movimientos":rows,"saldos":saldos})

            elif p == "/api/saldo_cliente":
                cid_cl = int(qs.get("id",[0])[0]); c = db()
                last = rd(c.execute("SELECT saldo FROM cuentas_cobrar WHERE empresa_id=? AND cliente_id=? ORDER BY id DESC LIMIT 1",(eid,cid_cl)).fetchone())
                movs = rl(c.execute("""SELECT cc.*,f.numero as fac_numero,nc.numero as nc_numero
                    FROM cuentas_cobrar cc
                    LEFT JOIN facturas f ON cc.factura_id=f.id
                    LEFT JOIN notas_credito nc ON cc.nota_credito_id=nc.id
                    WHERE cc.empresa_id=? AND cc.cliente_id=? ORDER BY cc.id DESC LIMIT 50""",(eid,cid_cl)).fetchall())
                cli = rd(c.execute("SELECT * FROM clientes WHERE id=? AND empresa_id=?",(cid_cl,eid)).fetchone())
                c.close()
                return self._j({"saldo":last["saldo"] if last else 0,"movimientos":movs,"cliente":cli})

            elif p == "/api/stock_movimientos":
                pid = qs.get("producto_id",[""])[0]
                c = db()
                sql = """SELECT sm.*,p.nombre as prod_nombre FROM stock_movimientos sm
                         LEFT JOIN productos p ON sm.producto_id=p.id
                         WHERE sm.empresa_id=?"""
                params = [eid]
                if pid: sql += " AND sm.producto_id=?"; params.append(pid)
                # Cada sucursal ve el kardex de SU bodega. La matriz ve todo,
                # y puede pedir una bodega concreta con ?bodega=
                _bod = qs.get("bodega", [""])[0]
                if not _bod and not _suc_ve_todo(c, eid, sess):
                    _bod = _suc_bodega(c, eid, sess)
                if _bod:
                    sql += " AND sm.bodega_id=?"; params.append(int(_bod))
                sql += " ORDER BY sm.id DESC LIMIT 200"
                rows = rl(c.execute(sql, params).fetchall()); c.close()
                return self._j(rows)

            elif p == "/api/caja":
                # GET /api/caja?fecha=YYYY-MM-DD → sesión del día con movimientos
                fecha = qs.get("fecha",[today_ec()])[0]
                c = db()
                ses = rd(c.execute("SELECT * FROM caja_sesiones WHERE empresa_id=? AND fecha=?",(eid,fecha)).fetchone())
                movs = []
                if ses:
                    movs = rl(c.execute("""SELECT cm.*,f.numero as fac_numero FROM caja_movimientos cm
                        LEFT JOIN facturas f ON cm.factura_id=f.id
                        WHERE cm.sesion_id=? ORDER BY cm.id""",(ses["id"],)).fetchall())
                # Facturas del día no registradas aún en caja
                facts_dia = rl(c.execute("""SELECT id,numero,total,estado FROM facturas
                    WHERE empresa_id=? AND fecha=? AND estado NOT IN ('ANULADA')
                    ORDER BY id""",(eid,fecha)).fetchall())
                c.close()
                return self._j({"sesion":ses,"movimientos":movs,"facturas_dia":facts_dia,"fecha":fecha})

            elif p == "/api/caja_mes":
                # GET /api/caja_mes?anio=YYYY&mes=MM → consolidado mensual
                anio = qs.get("anio",[today_ec()[:4]])[0]
                mes  = qs.get("mes",[today_ec()[5:7]])[0]
                c = db()
                sesiones = rl(c.execute("""SELECT cs.*,u.nombre as usuario_nombre FROM caja_sesiones cs
                    LEFT JOIN usuarios u ON cs.usuario_id=u.id
                    WHERE cs.empresa_id=? AND strftime('%Y',cs.fecha)=? AND strftime('%m',cs.fecha)=?
                    ORDER BY cs.fecha""",(eid,anio,mes.zfill(2))).fetchall())
                # Totales del mes
                tot = rd(c.execute("""SELECT
                    COALESCE(SUM(total_ingresos),0) as total_ingresos,
                    COALESCE(SUM(total_egresos),0) as total_egresos,
                    COALESCE(SUM(total_facturas),0) as total_facturas,
                    COUNT(*) as dias_trabajados
                    FROM caja_sesiones WHERE empresa_id=?
                    AND strftime('%Y',fecha)=? AND strftime('%m',fecha)=?""",(eid,anio,mes.zfill(2))).fetchone())
                # Top categorías de egreso
                cats = rl(c.execute("""SELECT cm.categoria, SUM(cm.monto) as total, COUNT(*) as n
                    FROM caja_movimientos cm JOIN caja_sesiones cs ON cm.sesion_id=cs.id
                    WHERE cs.empresa_id=? AND cm.tipo='EGRESO'
                    AND strftime('%Y',cs.fecha)=? AND strftime('%m',cs.fecha)=?
                    GROUP BY cm.categoria ORDER BY total DESC""",(eid,anio,mes.zfill(2))).fetchall())
                c.close()
                return self._j({"sesiones":sesiones,"totales":tot,"categorias_egreso":cats,
                                "anio":anio,"mes":mes})

            elif p == "/api/usuarios":
                if sess["rol"] not in ["admin","supervisor"] and sess.get("rol_empresa") not in ["admin","supervisor"]:
                    return self._j({"error":"Sin permiso"},403)
                c = db()
                rows = rl(c.execute("""SELECT u.*, ue.rol as rol_empresa,
                    (SELECT COUNT(*) FROM usuario_empresa x WHERE x.usuario_id=u.id) as num_empresas
                    FROM usuarios u
                    JOIN usuario_empresa ue ON u.id=ue.usuario_id
                    WHERE ue.empresa_id=? AND u.activo=1 ORDER BY u.nombre""", (eid,)).fetchall())
                c.close(); return self._j(rows)

            elif p == "/api/usuario_empresas":
                # Empresas del sistema + cuáles tiene asignadas un usuario (solo admin)
                if sess["rol"] != "admin" and sess.get("rol_empresa") != "admin":
                    return self._j({"error":"Sin permiso"},403)
                uid_q = int(qs.get("usuario_id",[0])[0] or 0)
                c = db()
                todas = rl(c.execute("SELECT id, nombre, ruc FROM empresas WHERE activa=1 ORDER BY nombre").fetchall())
                asignadas = [r["empresa_id"] for r in rl(c.execute(
                    "SELECT empresa_id FROM usuario_empresa WHERE usuario_id=?", (uid_q,)).fetchall())] if uid_q else []
                c.close()
                return self._j({"empresas": todas, "asignadas": asignadas})

            elif p == "/api/ride_pdf":
                tipo = (qs.get("tipo",["fac"])[0] or "fac").lower()
                did  = int(qs.get("id",[0])[0])
                try:
                    data, fname, err = _ride_pdf_asegurar(eid, tipo, did)
                except Exception as ex:
                    log.error("ride_pdf: %s", ex, exc_info=True)
                    return self._j({"ok":False,"error":"No se pudo generar el PDF: " + str(ex)}, 500)
                if err or not data:
                    return self._j({"ok":False,"error": err or "PDF no disponible"}, 404)
                self.send_response(200)
                self.send_header("Content-Type","application/pdf")
                self.send_header("Content-Disposition", 'attachment; filename="%s"' % fname)
                self.send_header("Content-Length", str(len(data)))
                self._cors(); self.end_headers(); self.wfile.write(data)
                return

            elif p == "/api/ride":
                fid = int(qs.get("id",[0])[0]); c = db()
                f = rd(c.execute("SELECT * FROM facturas WHERE id=? AND empresa_id=?", (fid,eid)).fetchone())
                emp2 = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()); c.close()
                if not f: return self._j({"error":"Factura no encontrada"},404)
                rp = f.get("ride_path","")
                # Si no existe el archivo, regenerar automáticamente
                if (not rp or not Path(rp).exists()) and f.get("autorizacion"):
                    rp = _generar_ride(fid, eid, f["clave_acceso"], f["autorizacion"], f.get("fecha_autorizacion",""), emp2)
                if rp and Path(rp).exists():
                    cont = Path(rp).read_bytes()
                    self.send_response(200)
                    self.send_header("Content-Type","text/html; charset=utf-8")
                    self._cors(); self.end_headers(); self.wfile.write(cont)
                else: self._j({"error":"RIDE no disponible — la factura debe estar autorizada"},404)

            elif p == "/api/ride_nc":
                nid = int(qs.get("id",[0])[0]); c = db()
                n = rd(c.execute("SELECT * FROM notas_credito WHERE id=? AND empresa_id=?",(nid,eid)).fetchone())
                emp2 = rd(c.execute("SELECT * FROM empresas WHERE id=?",(eid,)).fetchone()); c.close()
                if n and n.get("autorizacion"):
                    # Generar o regenerar el RIDE
                    ride_html = _generar_ride_nc(nid, eid, n["clave_acceso"],
                                                  n["autorizacion"], n["fecha_autorizacion"], emp2)
                    if ride_html and Path(ride_html).exists():
                        cont = Path(ride_html).read_bytes()
                        self.send_response(200)
                        self.send_header("Content-Type","text/html; charset=utf-8")
                        self._cors(); self.end_headers(); self.wfile.write(cont)
                        return
                self._j({"error":"RIDE NC no disponible — la NC debe estar autorizada"},404)

            elif p == "/api/ride_guia":
                gid = int(qs.get("id",[0])[0]); c = db()
                g = rd(c.execute("SELECT * FROM guias_remision WHERE id=? AND empresa_id=?",(gid,eid)).fetchone())
                emp2 = rd(c.execute("SELECT * FROM empresas WHERE id=?",(eid,)).fetchone()); c.close()
                if g and g.get("autorizacion"):
                    ride_html = _generar_ride_guia(gid, eid, g["clave_acceso"],
                                                   g["autorizacion"], g["fecha_autorizacion"], emp2)
                    if ride_html and Path(ride_html).exists():
                        cont = Path(ride_html).read_bytes()
                        self.send_response(200)
                        self.send_header("Content-Type","text/html; charset=utf-8")
                        self._cors(); self.end_headers(); self.wfile.write(cont)
                        return
                self._j({"error":"RIDE Guía no disponible — la guía debe estar autorizada"},404)

            elif p == "/api/todas_empresas":
                if sess["rol"] != "admin": return self._j({"error":"Solo admin"},403)
                c = db(); rows = rl(c.execute("SELECT * FROM empresas ORDER BY nombre").fetchall()); c.close()
                return self._j(rows)

            elif p == "/api/conexiones":
                # Ver conexiones activas de la empresa (solo admin)
                if not is_admin: return self._j({"error":"Sin permiso"},403)
                activas = get_conexiones_empresa(eid)
                puede, n_activas, limite = verificar_limite_conexiones(eid)
                return self._j({
                    "conexiones": activas,
                    "total_activas": n_activas,
                    "limite": MAX_CONEXIONES_POR_EMPRESA,
                    "disponibles": max(0, limite - n_activas)
                })

            elif p == "/api/sri_log":
                # Últimos logs del SRI — diagnóstico admin
                if not is_admin: return self._j({"error":"Sin permiso"},403)
                lim = int(qs.get("limit",["100"])[0])
                c = db()
                rows = rl(c.execute(
                    "SELECT * FROM sri_log WHERE empresa_id=? ORDER BY id DESC LIMIT ?",
                    (eid, lim)
                ).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/liquidaciones":
                # GET: listar liquidaciones de compra
                q = qs.get("q",[""])[0]
                c = db()
                rows = rl(c.execute("""
                    SELECT lc.*, u.nombre as usuario_nombre
                    FROM liquidaciones_compra lc
                    LEFT JOIN usuarios u ON lc.usuario_id=u.id
                    WHERE lc.empresa_id=?
                    AND (lc.proveedor_razon_social LIKE ? OR lc.numero LIKE ?
                         OR lc.proveedor_identificacion LIKE ?)
                    ORDER BY lc.id DESC LIMIT 200
                """, (eid, f"%{q}%", f"%{q}%", f"%{q}%")).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/liquidacion":
                # GET: detalle de una liquidación con sus ítems
                lid = int(qs.get("id",[0])[0])
                c = db()
                liq = rd(c.execute(
                    "SELECT * FROM liquidaciones_compra WHERE id=? AND empresa_id=?",
                    (lid, eid)
                ).fetchone())
                if not liq:
                    c.close(); return self._j({"error":"No encontrada"},404)
                items = rl(c.execute(
                    "SELECT * FROM liquidacion_items WHERE liquidacion_id=? ORDER BY id",
                    (lid,)
                ).fetchall())
                c.close()
                return self._j({**liq, "items": items})

            elif p == "/api/ride_liquidacion":
                # GET: RIDE de la liquidación de compra
                lid = int(qs.get("id",[0])[0])
                c = db()
                liq  = rd(c.execute("SELECT * FROM liquidaciones_compra WHERE id=? AND empresa_id=?", (lid,eid)).fetchone())
                emp2 = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
                c.close()
                if liq and liq.get("autorizacion"):
                    c2 = db()
                    items = rl(c2.execute("SELECT * FROM liquidacion_items WHERE liquidacion_id=? ORDER BY id",(lid,)).fetchall())
                    c2.close()
                    ride_html = _generar_ride_liquidacion(lid, eid, liq, items, emp2)
                    if ride_html:
                        cont = ride_html.encode("utf-8")
                        self.send_response(200)
                        self.send_header("Content-Type","text/html; charset=utf-8")
                        self._cors(); self.end_headers(); self.wfile.write(cont)
                        return
                return self._j({"error":"RIDE no disponible — la liquidación debe estar autorizada"},404)

            # ═══ COMPRAS/GASTOS GET ═══
            elif p == "/api/proveedores":
                c = db()
                rows = rl(c.execute("SELECT * FROM proveedores WHERE empresa_id=? ORDER BY nombre", (eid,)).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/proveedor":
                pid = int(qs.get("id",[0])[0]); c = db()
                r = rd(c.execute("SELECT * FROM proveedores WHERE id=? AND empresa_id=?", (pid,eid)).fetchone())
                c.close()
                return self._j(r or {})

            elif p == "/api/categorias_gasto":
                c = db()
                rows = rl(c.execute("SELECT * FROM categorias_gasto WHERE empresa_id=? AND activa=1 ORDER BY nombre", (eid,)).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/compras":
                f_ini = qs.get("fecha_ini",["2020-01-01"])[0]
                f_fin = qs.get("fecha_fin",["2099-12-31"])[0]
                tipo = qs.get("tipo",[""])[0]
                c = db()
                sql = """SELECT co.*, p.nombre as prov_nombre, p.ruc_cedula as prov_ruc,
                    cg.nombre as categoria_nombre, u.username as usuario_nombre
                    FROM compras co
                    LEFT JOIN proveedores p ON co.proveedor_id=p.id
                    LEFT JOIN categorias_gasto cg ON co.categoria_id=cg.id
                    LEFT JOIN usuarios u ON co.usuario_id=u.id
                    WHERE co.empresa_id=? AND co.fecha>=? AND co.fecha<=?"""
                params = [eid, f_ini, f_fin]
                if tipo:
                    sql += " AND co.tipo=?"
                    params.append(tipo)
                sql += " ORDER BY co.fecha DESC, co.id DESC"
                rows = rl(c.execute(sql, params).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/compra":
                cid = int(qs.get("id",[0])[0]); c = db()
                r = rd(c.execute("""SELECT co.*, p.nombre as prov_nombre, p.ruc_cedula as prov_ruc,
                    cg.nombre as categoria_nombre
                    FROM compras co LEFT JOIN proveedores p ON co.proveedor_id=p.id
                    LEFT JOIN categorias_gasto cg ON co.categoria_id=cg.id
                    WHERE co.id=? AND co.empresa_id=?""", (cid,eid)).fetchone())
                if r:
                    r["items"] = rl(c.execute("SELECT * FROM compra_items WHERE compra_id=?", (cid,)).fetchall())
                c.close()
                return self._j(r or {})

            elif p == "/api/resumen_compras":
                f_ini = qs.get("fecha_ini",["2020-01-01"])[0]
                f_fin = qs.get("fecha_fin",["2099-12-31"])[0]
                c = db()
                tot = rd(c.execute("""SELECT COUNT(*) as total_docs,
                    COALESCE(SUM(subtotal),0) as sum_subtotal,
                    COALESCE(SUM(iva),0) as sum_iva,
                    COALESCE(SUM(total),0) as sum_total,
                    COALESCE(SUM(CASE WHEN estado_pago='PENDIENTE' THEN total ELSE 0 END),0) as pendiente,
                    COALESCE(SUM(CASE WHEN estado_pago='PAGADA' THEN total ELSE 0 END),0) as pagado
                    FROM compras WHERE empresa_id=? AND fecha>=? AND fecha<=?
                    AND estado!='ANULADA'""", (eid,f_ini,f_fin)).fetchone())
                por_cat = rl(c.execute("""SELECT cg.nombre as categoria,
                    COALESCE(SUM(co.total),0) as total, COUNT(*) as docs
                    FROM compras co LEFT JOIN categorias_gasto cg ON co.categoria_id=cg.id
                    WHERE co.empresa_id=? AND co.fecha>=? AND co.fecha<=?
                    AND co.estado!='ANULADA'
                    GROUP BY co.categoria_id ORDER BY total DESC""", (eid,f_ini,f_fin)).fetchall())
                por_prov = rl(c.execute("""SELECT p.nombre as proveedor,
                    COALESCE(SUM(co.total),0) as total, COUNT(*) as docs
                    FROM compras co LEFT JOIN proveedores p ON co.proveedor_id=p.id
                    WHERE co.empresa_id=? AND co.fecha>=? AND co.fecha<=?
                    AND co.estado!='ANULADA'
                    GROUP BY co.proveedor_id ORDER BY total DESC LIMIT 10""", (eid,f_ini,f_fin)).fetchall())
                c.close()
                return self._j({"totales":tot,"por_categoria":por_cat,"por_proveedor":por_prov})


            # ═══ CONTABILIDAD GET ═══
            elif p == "/api/plan_cuentas":
                c = db()
                rows = rl(c.execute("SELECT * FROM plan_cuentas WHERE empresa_id=? ORDER BY codigo", (eid,)).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/exportar_plan_json":
                c = db()
                rows = rl(c.execute("SELECT codigo,nombre,nivel,tipo,naturaleza,grupo,padre_codigo FROM plan_cuentas WHERE empresa_id=? ORDER BY codigo", (eid,)).fetchall())
                c.close()
                import json as _json
                plan = [{"codigo":r["codigo"],"nombre":r["nombre"],"nivel":r.get("nivel",1),"tipo":r.get("tipo","DETALLE"),
                         "naturaleza":r.get("naturaleza","DEUDORA"),"grupo":r.get("grupo",""),"padre":r.get("padre_codigo","")} for r in rows]
                data = _json.dumps(plan, ensure_ascii=False, indent=2).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type","application/json; charset=utf-8")
                self.send_header("Content-Disposition", "attachment; filename=plan_cuentas_niif.json")
                self.send_header("Content-Length", str(len(data)))
                self._cors(); self.end_headers(); self.wfile.write(data)
                return

            elif p == "/api/cuenta":
                cid = int(qs.get("id",[0])[0]); c = db()
                r = rd(c.execute("SELECT * FROM plan_cuentas WHERE id=? AND empresa_id=?", (cid,eid)).fetchone())
                c.close()
                return self._j(r or {})

            # ═══ CONTABILIDAD GET ═══
            elif p == "/api/asientos":
                f_ini = qs.get("fecha_ini",["2020-01-01"])[0]
                f_fin = qs.get("fecha_fin",["2099-12-31"])[0]
                c = db()
                rows = rl(c.execute("""SELECT a.*, u.username as usuario_nombre,
                    (SELECT COALESCE(SUM(debe),0) FROM asiento_detalle WHERE asiento_id=a.id) as total_debe,
                    (SELECT COALESCE(SUM(haber),0) FROM asiento_detalle WHERE asiento_id=a.id) as total_haber
                    FROM asientos_contables a LEFT JOIN usuarios u ON a.usuario_id=u.id
                    WHERE a.empresa_id=? AND a.fecha>=? AND a.fecha<=? AND a.estado='ACTIVO'
                    ORDER BY a.fecha DESC, a.numero DESC""", (eid,f_ini,f_fin)).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/asiento":
                aid = int(qs.get("id",[0])[0]); c = db()
                r = rd(c.execute("SELECT * FROM asientos_contables WHERE id=? AND empresa_id=?", (aid,eid)).fetchone())
                if r:
                    r["detalle"] = rl(c.execute("SELECT * FROM asiento_detalle WHERE asiento_id=? ORDER BY id", (aid,)).fetchall())
                c.close()
                return self._j(r or {})

            elif p == "/api/config_contable":
                c = db()
                cfg = _cfg_contable(c, eid)
                plan = rl(c.execute("SELECT codigo,nombre FROM plan_cuentas WHERE empresa_id=? AND activa=1 ORDER BY codigo", (eid,)).fetchall())
                c.commit(); c.close()
                return self._j({"config":cfg,"plan":plan})

            elif p == "/api/codigos_retencion":
                return self._j(CODIGOS_RETENCION)

            elif p == "/api/comprobantes_cv":
                f_ini = qs.get("fecha_ini",["2020-01-01"])[0]
                f_fin = qs.get("fecha_fin",["2099-12-31"])[0]
                c = db()
                rows = rl(c.execute("""SELECT id,numero,fecha_emision,documento,cliente_nombre,estado,total,total_abono,saldo,anulado
                    FROM comprobantes_cv WHERE empresa_id=? AND fecha_emision>=? AND fecha_emision<=?
                    ORDER BY fecha_emision DESC, id DESC""", (eid,f_ini,f_fin)).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/comprobante_cv":
                cvid = int(qs.get("id",[0])[0]); c = db()
                r = rd(c.execute("SELECT * FROM comprobantes_cv WHERE id=? AND empresa_id=?", (cvid,eid)).fetchone())
                if r:
                    r["detalle"] = rl(c.execute("SELECT * FROM comprobante_cv_det WHERE comprobante_id=? ORDER BY id", (cvid,)).fetchall())
                    r["empresa"] = rd(c.execute("SELECT nombre,nombre_comercial,ruc,direccion,telefono,ciudad,logo_base64 FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
                c.close()
                return self._j(r or {})

            elif p == "/api/comprobante_cv_pdf":
                try:
                    cv = _cv_cargar(eid, int(qs.get("id",[0])[0]))
                    data = _cv_pdf_bytes(cv)
                except ImportError:
                    return self._j({"ok":False,"error":"Falta la librería reportlab. Ejecuta: pip install reportlab"},500)
                except Exception as ex:
                    return self._j({"ok":False,"error":str(ex)},500)
                fname = _cv_nombre_archivo(cv, "pdf")
                self.send_response(200)
                self.send_header("Content-Type","application/pdf")
                self.send_header("Content-Disposition", f'attachment; filename="{fname}"')
                self.send_header("Content-Length", str(len(data)))
                self._cors(); self.end_headers(); self.wfile.write(data)
                return

            elif p == "/api/comprobante_cv_excel":
                try:
                    cv = _cv_cargar(eid, int(qs.get("id",[0])[0]))
                    data = _cv_xlsx_bytes(cv)
                except Exception as ex:
                    return self._j({"ok":False,"error":str(ex)},500)
                fname = _cv_nombre_archivo(cv, "xlsx")
                self.send_response(200)
                self.send_header("Content-Type","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                self.send_header("Content-Disposition", f'attachment; filename="{fname}"')
                self.send_header("Content-Length", str(len(data)))
                self._cors(); self.end_headers(); self.wfile.write(data)
                return

            elif p == "/api/comprobantes_cv_excel":
                f_ini = qs.get("fecha_ini",["2020-01-01"])[0]
                f_fin = qs.get("fecha_fin",["2099-12-31"])[0]
                try:
                    data, fname = _cv_lista_xlsx_bytes(eid, f_ini, f_fin)
                except Exception as ex:
                    return self._j({"ok":False,"error":str(ex)},500)
                self.send_response(200)
                self.send_header("Content-Type","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                self.send_header("Content-Disposition", f'attachment; filename="{fname}"')
                self.send_header("Content-Length", str(len(data)))
                self._cors(); self.end_headers(); self.wfile.write(data)
                return

            elif p == "/api/cert_diag":
                c = db(); emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()); c.close()
                emp = emp or {}
                guardada = str(emp.get("cert_path") or "")
                out = {"ok": True, "empresa": emp.get("nombre",""),
                       "carpeta_empresa": _dir_emp(eid),
                       "ruta_guardada": guardada,
                       "existe": bool(guardada and Path(guardada).exists()),
                       "base_dir": str(BASE_DIR),
                       "tiene_password": bool(str(emp.get("cert_password") or "").strip()),
                       "p12_encontrados": [str(q) for q in _cert_inventario()[:20]]}
                try:
                    ruta = _resolver_cert(emp, eid)
                    out["ruta_resuelta"] = str(ruta)
                    out["reparada"] = (str(ruta) != guardada)
                except Exception as ex:
                    out["ok"] = False; out["error"] = str(ex)
                if out.get("ok"):
                    try:
                        datos = _firma_datos_cert({**emp, "cert_path": out["ruta_resuelta"], "id": eid})
                        out["firmante"] = datos
                    except Exception as ex:
                        out["aviso"] = str(ex)
                return self._j(out)

            elif p == "/api/sello_estado":
                c = db(); emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
                c.close()
                cfg = _sello_config(emp)
                ruta = _sello_ruta(eid)
                cfg["tiene_sello"] = ruta.exists() and ruta.stat().st_size > 100
                cfg["archivo"] = str(ruta) if cfg["tiene_sello"] else ""
                if cfg["tiene_sello"]:
                    try:
                        cfg["png_base64"] = base64.b64encode(ruta.read_bytes()).decode()
                    except Exception:
                        cfg["png_base64"] = ""
                return self._j({"ok": True, **cfg})

            elif p == "/api/producto_foto":
                pid = int(qs.get("id", ["0"])[0] or 0)
                ruta = _foto_ruta(eid, pid)
                if not pid or not ruta.exists():
                    self.send_response(404); self._cors(); self.end_headers(); return
                data = ruta.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "image/jpeg")
                self.send_header("Content-Length", str(len(data)))
                # Cada maquina la descarga una vez y la reutiliza
                self.send_header("Cache-Control", "public, max-age=604800")
                self.send_header("ETag", '"' + str(int(ruta.stat().st_mtime)) + '"')
                self._cors(); self.end_headers(); self.wfile.write(data)
                return

            elif p == "/api/egreso_pdf":
                did = int(qs.get("id", ["0"])[0] or 0)
                c = db()
                eg = rd(c.execute("SELECT * FROM comprobantes_egreso WHERE id=? AND empresa_id=?",
                                  (did, eid)).fetchone())
                if not eg:
                    c.close(); return self._j({"ok": False, "error": "Comprobante no encontrado"}, 404)
                emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
                cta = rd(c.execute("SELECT * FROM cuentas_bancarias WHERE id=?",
                                   (eg.get("cuenta_bancaria_id") or 0,)).fetchone()) or {}
                if eg.get("compra_id"):
                    cp = rd(c.execute("SELECT numero FROM compras WHERE id=?", (eg["compra_id"],)).fetchone()) or {}
                    eg["compra_numero"] = cp.get("numero", "")
                c.close()
                try:
                    data = _egreso_pdf_bytes(eg, emp, cta, sess.get("nombre", ""))
                except Exception as ex:
                    log.error("egreso_pdf: %s", ex, exc_info=True)
                    return self._j({"ok": False, "error": "No se pudo generar el PDF: " + str(ex)}, 500)
                nom = "EGRESO_" + str(eg.get("numero") or did) + ".pdf"
                self.send_response(200)
                self.send_header("Content-Type", "application/pdf")
                self.send_header("Content-Disposition", 'attachment; filename="%s"' % nom)
                self.send_header("Content-Length", str(len(data)))
                self._cors(); self.end_headers(); self.wfile.write(data)
                return

            elif p == "/api/saldos_empleados":
                """Lo que cada empleado debe por préstamos y anticipos."""
                c = db()
                emps = rl(c.execute("""SELECT id, nombres, cedula, cargo FROM empleados
                                       WHERE empresa_id=? AND IFNULL(estado,'ACTIVO')='ACTIVO'
                                       ORDER BY nombres""", (eid,)).fetchall())
                salida = []
                for e in emps:
                    ent = c.execute("""SELECT IFNULL(SUM(monto),0) FROM comprobantes_egreso
                                       WHERE empresa_id=? AND beneficiario_tipo='EMPLEADO'
                                       AND empleado_id=? AND IFNULL(estado,'')<>'ANULADO'""",
                                    (eid, e["id"])).fetchone()[0]
                    desc = c.execute("""SELECT IFNULL(SUM(d.anticipo_sueldo),0)+IFNULL(SUM(d.prestamo),0)
                                        FROM nomina_detalle d JOIN roles_nomina r ON r.id=d.rol_id
                                        WHERE r.empresa_id=? AND d.empleado_id=?""",
                                     (eid, e["id"])).fetchone()[0]
                    saldo = round(float(ent or 0) - float(desc or 0), 2)
                    if abs(saldo) > 0.004 or float(ent or 0) > 0:
                        salida.append({"id": e["id"], "nombre": e["nombres"], "cedula": e.get("cedula", ""),
                                       "cargo": e.get("cargo", ""), "entregado": round(float(ent or 0), 2),
                                       "descontado": round(float(desc or 0), 2), "saldo": saldo})
                c.close()
                return self._j({"ok": True, "empleados": salida})

            elif p == "/api/etiquetas_formatos":
                return self._j({"ok": True, "formatos": [
                    {"id": k, "nombre": v["nombre"], "por_hoja": v["cols"] * v["filas"]}
                    for k, v in ETIQUETA_FORMATOS.items()]})

            elif p == "/api/buscar_codigo":
                """Busca un producto por su código exacto. Lo usa la pistola."""
                cod = (qs.get("codigo", [""])[0] or "").strip()
                if not cod:
                    return self._j({"ok": False, "error": "Sin código"})
                c = db()
                p = rd(c.execute("""SELECT * FROM productos WHERE empresa_id=? AND codigo=?
                                    AND IFNULL(activo,1)=1 LIMIT 1""", (eid, cod)).fetchone())
                if not p:
                    p = rd(c.execute("""SELECT * FROM productos WHERE empresa_id=? AND UPPER(codigo)=UPPER(?)
                                        AND IFNULL(activo,1)=1 LIMIT 1""", (eid, cod)).fetchone())
                c.close()
                if not p:
                    return self._j({"ok": False, "error": "No se encontró el código " + cod})
                return self._j({"ok": True, "producto": p})

            elif p == "/api/qr":
                """Código QR en PNG. Se arma aquí porque la red puede no
                tener salida a internet."""
                texto = qs.get("texto", [""])[0]
                if not texto:
                    self.send_response(400); self._cors(); self.end_headers(); return
                try:
                    import qrcode, io as _io
                    img = qrcode.make(texto)
                    b = _io.BytesIO(); img.save(b, format="PNG")
                    data = b.getvalue()
                except Exception as ex:
                    log.warning("qr: %s", ex)
                    self.send_response(500); self._cors(); self.end_headers(); return
                self.send_response(200)
                self.send_header("Content-Type", "image/png")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "public, max-age=3600")
                self._cors(); self.end_headers(); self.wfile.write(data)
                return

            elif p == "/api/empresa_actual":
                """Nombre de la empresa en la que se está trabajando."""
                c = db()
                e = rd(c.execute("SELECT id, nombre, ruc FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
                c.close()
                return self._j({"ok": True, "id": e.get("id"), "nombre": e.get("nombre", ""),
                                "ruc": e.get("ruc", "")})

            elif p == "/api/toma_actual":
                c = db()
                bid = int(qs.get("bodega", ["0"])[0] or 0)
                t = _toma_abierta(c, eid, bid)
                n = 0
                if t:
                    n = c.execute("SELECT COUNT(*) FROM toma_items WHERE toma_id=?", (t["id"],)).fetchone()[0]
                bodegas = rl(c.execute("SELECT id, nombre FROM bodegas WHERE empresa_id=? ORDER BY id",
                                       (eid,)).fetchall())
                c.close()
                return self._j({"ok": True, "toma": t, "contados": n, "bodegas": bodegas})

            elif p == "/api/toma_items":
                tid = int(qs.get("toma_id", ["0"])[0] or 0)
                c = db()
                filas = rl(c.execute("""SELECT * FROM toma_items WHERE toma_id=?
                                        ORDER BY id DESC LIMIT 400""", (tid,)).fetchall())
                c.close()
                return self._j({"ok": True, "items": filas})

            elif p == "/api/toma_diferencias":
                tid = int(qs.get("toma_id", ["0"])[0] or 0)
                c = db()
                toma, difs = _toma_diferencias(c, eid, tid)
                c.close()
                if not toma:
                    return self._j({"ok": False, "error": "Toma no encontrada"}, 404)
                faltan = sum(1 for d in difs if d["diferencia"] < -0.0001)
                sobran = sum(1 for d in difs if d["diferencia"] > 0.0001)
                valor = sum(d["diferencia"] * (d["costo"] or 0) for d in difs)
                return self._j({"ok": True, "toma": toma, "diferencias": difs,
                                "faltantes": faltan, "sobrantes": sobran,
                                "valor_diferencia": round(valor, 2)})

            elif p == "/api/cierres_mes":
                c = db()
                emp = rd(c.execute("SELECT bloquear_cerrados FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
                filas = rl(c.execute("""SELECT cm.*, u.nombre AS cerro, u2.nombre AS reabrio
                                        FROM cierres_mes cm
                                        LEFT JOIN usuarios u  ON u.id = cm.cerrado_por
                                        LEFT JOIN usuarios u2 ON u2.id = cm.reabierto_por
                                        WHERE cm.empresa_id=? ORDER BY cm.periodo DESC""", (eid,)).fetchall())
                c.close()
                return self._j({"ok": True, "bloquear": int(emp.get("bloquear_cerrados", 1) or 0),
                                "es_admin": str(sess.get("rol", "")).lower() in ("admin", "administrador"),
                                "cierres": filas})

            elif p == "/api/suc_diag":
                """Explica de donde sale el numero con el que se va a facturar."""
                c = db()
                emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
                u = rd(c.execute("SELECT id, username, nombre, rol, secuencial, sucursal_id "
                                 "FROM usuarios WHERE id=?", (sess.get("usuario_id"),)).fetchone()) or {}
                mia = _suc_del_usuario(c, eid, sess)
                estab, pto = _pto_emision_usuario(c, emp, sess)
                _caja = str(u.get("secuencial") or "").strip()
                if mia:
                    motivo = ("Establecimiento " + str(mia.get("codigo") or "") +
                              " por la sucursal " + str(mia.get("nombre") or "") + ". ")
                    if _caja:
                        motivo += ("Punto " + _caja.zfill(3) +
                                   " por la caja asignada a este usuario en su ficha.")
                    else:
                        motivo += ("Punto " + str(mia.get("pto_emi") or "001") +
                                   " por defecto del local (este usuario no tiene caja propia).")
                elif not _suc_activas(emp):
                    motivo = ("El trabajo por sucursales esta DESACTIVADO, asi que se usa el "
                              "establecimiento de la empresa y el punto del usuario.")
                elif not int(u.get("sucursal_id") or 0):
                    _co = str(u.get("secuencial") or "").strip().zfill(3)[:3]
                    _sr = rd(c.execute("SELECT nombre FROM sucursales WHERE empresa_id=? AND codigo=?",
                                       (eid, _co)).fetchone()) if _co else None
                    motivo = ("El usuario NO tiene sucursal asignada: el establecimiento sale de la "
                              "empresa (" + str(emp.get("estab") or "001") + ") y el punto, de su caja. "
                              "Asignele su sucursal en Configuracion -> Usuarios para que el "
                              "establecimiento sea el del local.")
                else:
                    motivo = "La sucursal asignada no existe o esta inactiva."
                sucs = rl(c.execute("SELECT codigo, nombre, pto_emi, estado FROM sucursales "
                                    "WHERE empresa_id=? ORDER BY codigo", (eid,)).fetchall())
                c.close()
                return self._j({"ok": True,
                                "usuario": u.get("username"), "rol": u.get("rol"),
                                "punto_usuario": u.get("secuencial") or "",
                                "sucursal_id": u.get("sucursal_id") or 0,
                                "sucursal": (mia or {}).get("nombre", ""),
                                "usa_sucursales": _suc_activas(emp),
                                "empresa_estab": emp.get("estab"), "empresa_pto": emp.get("pto_emi"),
                                "estab": estab, "pto": pto,
                                "ejemplo": estab + "-" + pto + "-000000001",
                                "motivo": motivo, "sucursales": sucs})

            elif p == "/api/suc_lista":
                c = db()
                emp = _suc_emp(c, eid)
                rows = rl(c.execute("""SELECT s.*, b.nombre as bodega_nombre,
                           (SELECT COUNT(*) FROM usuarios u WHERE u.sucursal_id=s.id) as usuarios
                           FROM sucursales s LEFT JOIN bodegas b ON b.id=s.bodega_id
                           WHERE s.empresa_id=? ORDER BY s.codigo, s.id""", (eid,)).fetchall())
                mia = _suc_del_usuario(c, eid, sess)
                c.close()
                return self._j({"ok": True, "activo": _suc_activas(emp),
                                "bloquea_stock": int(emp.get("suc_bloquea_stock", 1) or 0),
                                "mi_sucursal": (mia or {}).get("id", 0),
                                "mi_sucursal_nombre": (mia or {}).get("nombre", ""),
                                "ve_todo": mia is None,
                                "sucursales": rows})

            elif p == "/api/resumen_sucursales":
                d1 = qs.get("desde", [""])[0]; d2 = qs.get("hasta", [""])[0]
                c = db()
                if not _suc_ve_todo(c, eid, sess):
                    c.close()
                    return self._j({"ok": False, "error": "Solo la matriz puede ver el resumen de todas las sucursales"}, 403)
                sucs = rl(c.execute("SELECT * FROM sucursales WHERE empresa_id=? ORDER BY codigo", (eid,)).fetchall())
                out = []
                for s in sucs:
                    a = [eid, s["id"]]
                    fv = " AND fecha>=?" if d1 else ""; fv2 = " AND fecha<=?" if d2 else ""
                    av = list(a) + ([d1] if d1 else []) + ([d2] if d2 else [])
                    ven = c.execute("""SELECT IFNULL(SUM(subtotal),0), IFNULL(SUM(iva),0),
                                       IFNULL(SUM(total),0), COUNT(*) FROM facturas
                                       WHERE empresa_id=? AND IFNULL(sucursal_id,0)=?
                                       AND IFNULL(estado,'')<>'ANULADA'""" + fv + fv2, av).fetchone()
                    try:
                        com = c.execute("""SELECT IFNULL(SUM(total),0), COUNT(*) FROM compras
                                           WHERE empresa_id=? AND IFNULL(sucursal_id,0)=?""" + fv + fv2, av).fetchone()
                    except Exception:
                        com = (0, 0)
                    out.append({"id": s["id"], "codigo": s["codigo"], "nombre": s["nombre"],
                                "ventas_subtotal": round(float(ven[0] or 0), 2),
                                "ventas_iva": round(float(ven[1] or 0), 2),
                                "ventas_total": round(float(ven[2] or 0), 2),
                                "facturas": int(ven[3] or 0),
                                "compras_total": round(float(com[0] or 0), 2),
                                "compras": int(com[1] or 0),
                                "margen": round(float(ven[0] or 0) - float(com[0] or 0), 2)})
                # Lo que quedó sin sucursal asignada (anterior a este módulo)
                sin = c.execute("""SELECT IFNULL(SUM(total),0), COUNT(*) FROM facturas
                                   WHERE empresa_id=? AND IFNULL(sucursal_id,0)=0
                                   AND IFNULL(estado,'')<>'ANULADA'""" + fv + fv2,
                                [eid] + ([d1] if d1 else []) + ([d2] if d2 else [])).fetchone()
                c.close()
                return self._j({"ok": True, "sucursales": out,
                                "sin_asignar": {"total": round(float(sin[0] or 0), 2), "n": int(sin[1] or 0)}})

            elif p == "/api/stock_consolidado":
                """Existencias de cada producto repartidas por sucursal."""
                c = db()
                if not _suc_ve_todo(c, eid, sess):
                    c.close()
                    return self._j({"ok": False, "error": "Solo la matriz ve el consolidado de todas las sucursales"}, 403)
                sucs = rl(c.execute("""SELECT s.id, s.codigo, s.nombre, s.bodega_id
                                       FROM sucursales s WHERE s.empresa_id=? ORDER BY s.codigo""", (eid,)).fetchall())
                q = qs.get("q", [""])[0]
                prods = rl(c.execute("SELECT id, codigo, nombre, stock, costo, precio FROM productos "
                                     "WHERE empresa_id=? AND activo=1" +
                                     (" AND (nombre LIKE ? OR codigo LIKE ?)" if q else "") +
                                     " ORDER BY nombre LIMIT 600",
                                     (eid,) + ((f"%{q}%", f"%{q}%") if q else ())).fetchall())
                saldos = {}
                for r in c.execute("SELECT producto_id, bodega_id, cantidad FROM stock_bodega").fetchall():
                    saldos[(r[0], r[1])] = float(r[2] or 0)
                c.close()
                salida = []
                for p in prods:
                    fila = {"id": p["id"], "codigo": p["codigo"], "nombre": p["nombre"],
                            "costo": p["costo"], "precio": p["precio"],
                            "stock_sistema": float(p["stock"] or 0), "por_sucursal": [], "total": 0.0}
                    for s in sucs:
                        cant = saldos.get((p["id"], s["bodega_id"]), 0.0)
                        fila["por_sucursal"].append({"codigo": s["codigo"], "nombre": s["nombre"],
                                                     "cantidad": cant})
                        fila["total"] += cant
                    fila["total"] = round(fila["total"], 2)
                    salida.append(fila)
                return self._j({"ok": True, "sucursales": [{"codigo": s["codigo"], "nombre": s["nombre"]} for s in sucs],
                                "productos": salida})

            elif p == "/api/stock_sucursal":
                c = db()
                bid = int(qs.get("bodega", ["0"])[0] or 0)
                if not bid:
                    bid = _suc_bodega(c, eid, sess)
                rows = rl(c.execute("""SELECT p.id, p.codigo, p.nombre, IFNULL(sb.cantidad,0) as cantidad,
                           p.stock as stock_total, p.costo, p.precio
                           FROM productos p LEFT JOIN stock_bodega sb
                             ON sb.producto_id=p.id AND sb.bodega_id=?
                           WHERE p.empresa_id=? AND IFNULL(p.activo,1)=1
                           ORDER BY p.nombre LIMIT 1000""", (bid, eid)).fetchall())
                c.close()
                return self._j({"ok": True, "bodega_id": bid, "productos": rows})

            elif p == "/api/firma_estado":
                c = db()
                emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
                c.close()
                res = {"pyhanko": bool(_firma_pyhanko()),
                       "tiene_cert": bool(str(emp.get("cert_path","") or "").strip()),
                       "tsa_default": FIRMA_TSA_DEFAULT}
                if res["tiene_cert"]:
                    try:
                        res["cert"] = _firma_datos_cert(emp)
                    except Exception as ex:
                        res["error_cert"] = str(ex)
                return self._j(res)

            elif p == "/api/comprobante_cv_wa":
                try:
                    cv = _cv_cargar(eid, int(qs.get("id",[0])[0]))
                except Exception as ex:
                    return self._j({"ok":False,"error":str(ex)})
                return self._j({"ok":True,
                                "telefono": _cv_tel_wa(cv.get("telefonos","")),
                                "texto": _cv_texto_wa(cv),
                                "numero": cv.get("numero","")})

            elif p == "/api/retenciones":
                f_ini = qs.get("fecha_ini",["2020-01-01"])[0]
                f_fin = qs.get("fecha_fin",["2099-12-31"])[0]
                c = db()
                rows = rl(c.execute("""SELECT r.*, u.username as usuario_nombre
                    FROM retenciones r LEFT JOIN usuarios u ON r.usuario_id=u.id
                    WHERE r.empresa_id=? AND r.fecha>=? AND r.fecha<=?
                    ORDER BY r.fecha DESC, r.id DESC""", (eid,f_ini,f_fin)).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/nomina":
                c = db()
                rows = rl(c.execute("SELECT * FROM roles_nomina WHERE empresa_id=? ORDER BY id DESC", (eid,)).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/rol_pdf":
                ids = [x for x in (qs.get("id", [""])[0] or "").split(",") if x.strip()]
                if not ids and qs.get("rol_id"):
                    c = db()
                    ids = [str(r["id"]) for r in rl(c.execute(
                        "SELECT id FROM nomina_detalle WHERE rol_id=? ORDER BY id",
                        (int(qs.get("rol_id", ["0"])[0]),)).fetchall())]
                    c.close()
                if not ids:
                    return self._j({"ok": False, "error": "No se indicó qué rol imprimir"}, 400)
                try:
                    _rol_autonumerar(eid, ids)
                    data = _rol_individual_pdf(eid, ids)
                except Exception as ex:
                    log.error("rol_pdf: %s", ex, exc_info=True)
                    return self._j({"ok": False, "error": "No se pudo generar el PDF: " + str(ex)}, 500)
                nom = "rol_" + (ids[0] if len(ids) == 1 else "todos") + ".pdf"
                self.send_response(200)
                self.send_header("Content-Type", "application/pdf")
                self.send_header("Content-Disposition", 'attachment; filename="%s"' % nom)
                self.send_header("Content-Length", str(len(data)))
                self._cors(); self.end_headers(); self.wfile.write(data)
                return

            elif p == "/api/nomina_rol":
                rid = int(qs.get("id",[0])[0]); c = db()
                r = rd(c.execute("SELECT * FROM roles_nomina WHERE id=? AND empresa_id=?", (rid,eid)).fetchone())
                if r:
                    r["detalle"] = rl(c.execute("SELECT * FROM nomina_detalle WHERE rol_id=? ORDER BY id", (rid,)).fetchall())
                    asi = rd(c.execute("SELECT id,numero FROM asientos_contables WHERE empresa_id=? AND tipo='NOMINA' AND origen_id=? AND estado='ACTIVO'", (eid, rid)).fetchone())
                    r["asiento"] = asi
                c.close()
                return self._j(r or {})

            elif p == "/api/empleados":
                c = db()
                rows = rl(c.execute("SELECT * FROM empleados WHERE empresa_id=? ORDER BY nombres", (eid,)).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/empleado":
                iid = int(qs.get("id",[0])[0]); c = db()
                r = rd(c.execute("SELECT * FROM empleados WHERE id=? AND empresa_id=?", (iid, eid)).fetchone())
                c.close()
                return self._j(r or {})

            elif p == "/api/sucursales":
                c = db()
                rows = rl(c.execute("SELECT * FROM sucursales WHERE empresa_id=? ORDER BY nombre", (eid,)).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/novedades":
                periodo = qs.get("periodo",[""])[0] or now_ec()[:7]
                c = db()
                rows = rl(c.execute("""SELECT n.*, e.nombres AS empleado FROM nomina_novedades n
                    LEFT JOIN empleados e ON n.empleado_id=e.id
                    WHERE n.empresa_id=? AND n.periodo=? AND n.estado='ACTIVO' ORDER BY n.id DESC""", (eid, periodo)).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/cuentas_bancarias":
                c = db()
                rows = rl(c.execute("SELECT * FROM cuentas_bancarias WHERE empresa_id=? ORDER BY banco", (eid,)).fetchall())
                for r in rows:
                    r["saldo_actual"] = _saldo_banco(c, eid, r["id"])
                c.close()
                return self._j(rows)

            elif p == "/api/cuenta_bancaria":
                iid = int(qs.get("id",[0])[0]); c = db()
                r = rd(c.execute("SELECT * FROM cuentas_bancarias WHERE id=? AND empresa_id=?", (iid, eid)).fetchone())
                if r: r["saldo_actual"] = _saldo_banco(c, eid, iid)
                c.close()
                return self._j(r or {})

            elif p == "/api/movimientos_banco":
                cta = int(qs.get("cuenta",[0])[0]); ini = qs.get("ini",["2000-01-01"])[0]; fin = qs.get("fin",["2099-12-31"])[0]
                c = db()
                rows = rl(c.execute("""SELECT * FROM movimientos_banco WHERE empresa_id=? AND cuenta_bancaria_id=?
                    AND estado='ACTIVO' AND fecha>=? AND fecha<=? ORDER BY fecha, id""", (eid, cta, ini, fin)).fetchall())
                saldo = _saldo_banco(c, eid, cta) if cta else 0
                c.close()
                return self._j({"movimientos":rows, "saldo_actual":saldo})

            elif p == "/api/comprobantes_egreso":
                ini = qs.get("ini",["2000-01-01"])[0]; fin = qs.get("fin",["2099-12-31"])[0]; c = db()
                rows = rl(c.execute("""SELECT e.*, cb.banco, cb.numero_cuenta FROM comprobantes_egreso e
                    LEFT JOIN cuentas_bancarias cb ON e.cuenta_bancaria_id=cb.id
                    WHERE e.empresa_id=? AND e.fecha>=? AND e.fecha<=? ORDER BY e.fecha DESC, e.id DESC""", (eid, ini, fin)).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/comprobante_egreso":
                iid = int(qs.get("id",[0])[0]); c = db()
                r = rd(c.execute("""SELECT e.*, cb.banco, cb.numero_cuenta FROM comprobantes_egreso e
                    LEFT JOIN cuentas_bancarias cb ON e.cuenta_bancaria_id=cb.id
                    WHERE e.id=? AND e.empresa_id=?""", (iid, eid)).fetchone())
                c.close()
                return self._j(r or {})

            elif p == "/api/comprobantes_ingreso":
                ini = qs.get("ini",["2000-01-01"])[0]; fin = qs.get("fin",["2099-12-31"])[0]; c = db()
                rows = rl(c.execute("""SELECT i.*, cb.banco, cb.numero_cuenta FROM comprobantes_ingreso i
                    LEFT JOIN cuentas_bancarias cb ON i.cuenta_bancaria_id=cb.id
                    WHERE i.empresa_id=? AND i.fecha>=? AND i.fecha<=? ORDER BY i.fecha DESC, i.id DESC""", (eid, ini, fin)).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/comprobante_ingreso":
                iid = int(qs.get("id",[0])[0]); c = db()
                r = rd(c.execute("""SELECT i.*, cb.banco, cb.numero_cuenta FROM comprobantes_ingreso i
                    LEFT JOIN cuentas_bancarias cb ON i.cuenta_bancaria_id=cb.id
                    WHERE i.id=? AND i.empresa_id=?""", (iid, eid)).fetchone())
                c.close()
                return self._j(r or {})

            elif p == "/api/conciliacion":
                cta = int(qs.get("cuenta",[0])[0]); ini = qs.get("ini",["2000-01-01"])[0]; fin = qs.get("fin",["2099-12-31"])[0]
                c = db()
                rows = rl(c.execute("""SELECT * FROM movimientos_banco WHERE empresa_id=? AND cuenta_bancaria_id=?
                    AND estado='ACTIVO' AND fecha>=? AND fecha<=? ORDER BY fecha, id""", (eid, cta, ini, fin)).fetchall())
                conc = round(sum((float(m["ingreso"] or 0)-float(m["egreso"] or 0)) for m in rows if m["estado_concil"]=="CONCILIADO"), 2)
                pend = round(sum((float(m["ingreso"] or 0)-float(m["egreso"] or 0)) for m in rows if m["estado_concil"]!="CONCILIADO"), 2)
                saldo = _saldo_banco(c, eid, cta) if cta else 0
                c.close()
                return self._j({"movimientos":rows, "saldo_libros":saldo, "neto_conciliado":conc, "neto_pendiente":pend})

            elif p == "/api/compras_por_pagar":
                pid = int(qs.get("proveedor",[0])[0]); c = db()
                q = """SELECT cp.id, cp.numero, cp.fecha, cp.total, cp.estado_pago, pr.nombre as proveedor_nombre
                    FROM compras cp LEFT JOIN proveedores pr ON cp.proveedor_id=pr.id
                    WHERE cp.empresa_id=? AND IFNULL(cp.estado,'')!='ANULADA' AND IFNULL(cp.estado_pago,'')!='PAGADA'"""
                args = [eid]
                if pid: q += " AND cp.proveedor_id=?"; args.append(pid)
                q += " ORDER BY cp.fecha DESC"
                rows = rl(c.execute(q, args).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/anticipos_disponibles":
                tipo = (qs.get("tipo",["CLIENTE"])[0]).upper(); ter = int(qs.get("tercero",[0])[0]); c = db()
                aplicado = float(c.execute("SELECT COALESCE(SUM(monto),0) FROM aplicaciones_anticipo WHERE empresa_id=? AND tipo=? AND tercero_id=? AND estado='ACTIVO'", (eid, tipo, ter)).fetchone()[0] or 0)
                if tipo == "CLIENTE":
                    recibido = float(c.execute("SELECT COALESCE(SUM(monto),0) FROM comprobantes_ingreso WHERE empresa_id=? AND aplicar_a='ANTICIPO' AND cliente_id=? AND estado!='ANULADO'", (eid, ter)).fetchone()[0] or 0)
                    docs = rl(c.execute("""SELECT id, numero, fecha, total FROM facturas
                        WHERE empresa_id=? AND cliente_id=? AND IFNULL(estado,'') NOT IN ('PAGADA','ANULADA')
                        ORDER BY fecha""", (eid, ter)).fetchall())
                else:
                    recibido = float(c.execute("SELECT COALESCE(SUM(monto),0) FROM comprobantes_egreso WHERE empresa_id=? AND aplicar_a='ANTICIPO' AND proveedor_id=? AND estado!='ANULADO'", (eid, ter)).fetchone()[0] or 0)
                    docs = rl(c.execute("""SELECT id, numero, fecha, total FROM compras
                        WHERE empresa_id=? AND proveedor_id=? AND IFNULL(estado,'')!='ANULADA' AND IFNULL(estado_pago,'')!='PAGADA'
                        ORDER BY fecha""", (eid, ter)).fetchall())
                c.close()
                return self._j({"disponible": round(recibido - aplicado, 2), "recibido": round(recibido,2), "aplicado": round(aplicado,2), "documentos": docs})

            elif p == "/api/establecimientos":
                c = db()
                if not c.execute("SELECT 1 FROM establecimientos WHERE empresa_id=?", (eid,)).fetchone():
                    for cod, nom in [("001","Quito"),("002","Guayaquil"),("004","Milagro"),("005","Manta")]:
                        c.execute("INSERT INTO establecimientos (empresa_id,codigo,nombre,estado,created_at) VALUES (?,?,?,?,?)",
                                  (eid, cod, nom, "ACTIVO", now_ec()))
                    c.commit()
                rows = rl(c.execute("SELECT id,codigo,nombre,estado FROM establecimientos WHERE empresa_id=? ORDER BY codigo", (eid,)).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/ventas_dia_sucursal":
                fecha = qs.get("fecha",[today_ec()])[0]; c = db()
                if not c.execute("SELECT 1 FROM establecimientos WHERE empresa_id=?", (eid,)).fetchone():
                    for cod, nom in [("001","Quito"),("002","Guayaquil"),("004","Milagro"),("005","Manta")]:
                        c.execute("INSERT INTO establecimientos (empresa_id,codigo,nombre,estado,created_at) VALUES (?,?,?,?,?)",
                                  (eid, cod, nom, "ACTIVO", now_ec()))
                    c.commit()
                estabs = {r["codigo"]: r["nombre"] for r in c.execute("SELECT codigo,nombre FROM establecimientos WHERE empresa_id=?", (eid,)).fetchall()}
                rows = c.execute("""SELECT numero, total FROM facturas
                    WHERE empresa_id=? AND fecha=? AND IFNULL(estado,'')!='ANULADA'""", (eid, fecha)).fetchall()
                agg = {}
                for r in rows:
                    est = _estab_de_numero(r["numero"])
                    if est not in agg: agg[est] = {"codigo":est, "nombre":estabs.get(est, "Estab. "+est), "cantidad":0, "total":0.0}
                    agg[est]["cantidad"] += 1; agg[est]["total"] += float(r["total"] or 0)
                out = sorted(agg.values(), key=lambda x: x["codigo"])
                for o in out: o["total"] = round(o["total"], 2)
                c.close()
                return self._j({"fecha": fecha, "sucursales": out, "total": round(sum(o["total"] for o in out),2)})

            elif p == "/api/reporte_ventas_sucursal":
                anio = qs.get("anio",[str(datetime.datetime.now(TZ_EC).year)])[0]; c = db()
                if not c.execute("SELECT 1 FROM establecimientos WHERE empresa_id=?", (eid,)).fetchone():
                    for cod, nom in [("001","Quito"),("002","Guayaquil"),("004","Milagro"),("005","Manta")]:
                        c.execute("INSERT INTO establecimientos (empresa_id,codigo,nombre,estado,created_at) VALUES (?,?,?,?,?)", (eid, cod, nom, "ACTIVO", now_ec()))
                    c.commit()
                estabs = {r["codigo"]: r["nombre"] for r in c.execute("SELECT codigo,nombre FROM establecimientos WHERE empresa_id=?", (eid,)).fetchall()}
                rows = c.execute("SELECT numero,fecha,subtotal,iva,total FROM facturas WHERE empresa_id=? AND substr(fecha,1,4)=? AND IFNULL(estado,'')!='ANULADA'", (eid, anio)).fetchall()
                data = {}; meses_tot = {m:0.0 for m in range(1,13)}
                for r in rows:
                    est = _estab_de_numero(r["numero"])
                    try: mes = int(str(r["fecha"])[5:7])
                    except: continue
                    if mes < 1 or mes > 12: continue
                    d = data.setdefault(est, {"codigo":est,"nombre":estabs.get(est,"Estab. "+est),"meses":{m:0.0 for m in range(1,13)},"cant":0,"total":0.0,"subtotal":0.0,"iva":0.0})
                    d["meses"][mes] += float(r["total"] or 0)
                    d["total"] += float(r["total"] or 0); d["subtotal"] += float(r["subtotal"] or 0); d["iva"] += float(r["iva"] or 0); d["cant"] += 1
                    meses_tot[mes] += float(r["total"] or 0)
                out = sorted(data.values(), key=lambda x: x["codigo"])
                for d in out:
                    d["total"]=round(d["total"],2); d["subtotal"]=round(d["subtotal"],2); d["iva"]=round(d["iva"],2)
                    d["meses"]={m:round(v,2) for m,v in d["meses"].items()}
                c.close()
                return self._j({"anio":anio,"sucursales":out,"meses_total":{m:round(v,2) for m,v in meses_tot.items()},"total":round(sum(d["total"] for d in out),2),"cant":sum(d["cant"] for d in out)})

            elif p == "/api/ventas_sucursal_xlsx":
                anio = qs.get("anio",[str(datetime.datetime.now(TZ_EC).year)])[0]; c = db()
                estabs = {r["codigo"]: r["nombre"] for r in c.execute("SELECT codigo,nombre FROM establecimientos WHERE empresa_id=?", (eid,)).fetchall()}
                emp_info = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
                rows = c.execute("SELECT numero,fecha,subtotal,iva,total FROM facturas WHERE empresa_id=? AND substr(fecha,1,4)=? AND IFNULL(estado,'')!='ANULADA'", (eid, anio)).fetchall()
                c.close()
                data = {}; 
                for r in rows:
                    est = _estab_de_numero(r["numero"])
                    try: mes = int(str(r["fecha"])[5:7])
                    except: continue
                    if mes < 1 or mes > 12: continue
                    d = data.setdefault(est, {"codigo":est,"nombre":estabs.get(est,"Estab. "+est),"meses":[0.0]*12,"cant":0,"total":0.0})
                    d["meses"][mes-1] += float(r["total"] or 0); d["total"] += float(r["total"] or 0); d["cant"] += 1
                cods = sorted(data.keys())
                import openpyxl, io
                from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
                from openpyxl.chart import BarChart, Reference
                from openpyxl.utils import get_column_letter
                wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Ventas por Sucursal"
                hfont = Font(name="Arial",bold=True,color="FFFFFF",size=10); hfill = PatternFill("solid",fgColor="1a56db")
                bdr = Border(*[Side("thin")]*4)
                ws["A1"] = (emp_info.get("razon_social") or "EMPRESA"); ws["A1"].font = Font(name="Arial",bold=True,size=15,color="1a56db")
                ws["A2"] = "Ventas por Sucursal — Año " + str(anio); ws["A2"].font = Font(name="Arial",size=11,color="666666")
                meses_nom = ["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"]
                hr = 4
                ws.cell(hr,1,"Mes").font=hfont; ws.cell(hr,1).fill=hfill
                for j,cod in enumerate(cods):
                    cel=ws.cell(hr,2+j,cod+" "+data[cod]["nombre"]); cel.font=hfont; cel.fill=hfill
                tcol = 2+len(cods); ce=ws.cell(hr,tcol,"Total mes"); ce.font=hfont; ce.fill=hfill
                for m in range(12):
                    row = hr+1+m; ws.cell(row,1,meses_nom[m]).font=Font(bold=True)
                    tm = 0.0
                    for j,cod in enumerate(cods):
                        v = round(data[cod]["meses"][m],2); cc=ws.cell(row,2+j,v); cc.number_format="$#,##0.00"; cc.border=bdr; tm+=v
                    ct=ws.cell(row,tcol,round(tm,2)); ct.number_format="$#,##0.00"; ct.font=Font(bold=True)
                # Fila total anual
                trow = hr+13; ws.cell(trow,1,"TOTAL AÑO").font=Font(bold=True,color="FFFFFF"); ws.cell(trow,1).fill=PatternFill("solid",fgColor="16a34a")
                for j,cod in enumerate(cods):
                    cc=ws.cell(trow,2+j,round(data[cod]["total"],2)); cc.number_format="$#,##0.00"; cc.font=Font(bold=True,color="FFFFFF"); cc.fill=PatternFill("solid",fgColor="16a34a")
                gt = round(sum(data[c0]["total"] for c0 in cods),2)
                cg=ws.cell(trow,tcol,gt); cg.number_format="$#,##0.00"; cg.font=Font(bold=True,color="FFFFFF"); cg.fill=PatternFill("solid",fgColor="16a34a")
                ws.column_dimensions["A"].width=12
                for j in range(len(cods)+1): ws.column_dimensions[get_column_letter(2+j)].width=16
                # Gráfico de barras: total por sucursal
                if cods:
                    ch = BarChart(); ch.title="Ventas por sucursal "+str(anio); ch.type="col"; ch.height=9; ch.width=18
                    rrow = trow+3
                    ws.cell(rrow-1,1,"Sucursal").font=Font(bold=True); ws.cell(rrow-1,2,"Total").font=Font(bold=True)
                    for j,cod in enumerate(cods):
                        ws.cell(rrow+j,1,cod+" "+data[cod]["nombre"]); cc=ws.cell(rrow+j,2,round(data[cod]["total"],2)); cc.number_format="$#,##0.00"
                    dref = Reference(ws, min_col=2, min_row=rrow, max_row=rrow+len(cods)-1)
                    cref = Reference(ws, min_col=1, min_row=rrow, max_row=rrow+len(cods)-1)
                    ch.add_data(dref, titles_from_data=False); ch.set_categories(cref); ch.legend=None
                    ws.add_chart(ch, "B"+str(hr))
                buf = io.BytesIO(); wb.save(buf); buf.seek(0)
                self.send_response(200)
                self.send_header("Content-Type","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                fname = ("Ventas_Sucursal_"+str(anio)+".xlsx")
                self.send_header("Content-Disposition","attachment; filename="+fname)
                self._cors(); self.end_headers(); self.wfile.write(buf.read())
                return

            elif p == "/api/facturas_pendientes":
                suc = qs.get("sucursal",[""])[0]; cid = int(qs.get("cliente",[0])[0])
                f1 = qs.get("desde",[""])[0]; f2 = qs.get("hasta",[""])[0]; c = db()
                q = """SELECT f.id, f.numero, f.fecha, f.total, f.cliente_id, cl.nombre as cliente_nombre, cl.ruc_cedula as ruc
                    FROM facturas f LEFT JOIN clientes cl ON f.cliente_id=cl.id
                    WHERE f.empresa_id=? AND IFNULL(f.estado,'') NOT IN ('PAGADA','ANULADA')"""
                args = [eid]
                if cid: q += " AND f.cliente_id=?"; args.append(cid)
                if f1: q += " AND f.fecha>=?"; args.append(f1)
                if f2: q += " AND f.fecha<=?"; args.append(f2)
                q += " ORDER BY f.fecha DESC, f.numero DESC LIMIT 2000"
                rows = rl(c.execute(q, args).fetchall())
                if suc:
                    rows = [r for r in rows if _estab_de_numero(r["numero"]) == suc.zfill(3)]
                c.close()
                return self._j(rows)

            elif p == "/api/retencion":
                rid = int(qs.get("id",[0])[0]); c = db()
                r = rd(c.execute("SELECT * FROM retenciones WHERE id=? AND empresa_id=?", (rid,eid)).fetchone())
                if r:
                    r["detalle"] = rl(c.execute("SELECT * FROM retencion_detalle WHERE retencion_id=? ORDER BY id", (rid,)).fetchall())
                c.close()
                return self._j(r or {})

            elif p == "/api/retencion_xml":
                rid = int(qs.get("id",[0])[0]); c = db()
                r = rd(c.execute("SELECT * FROM retenciones WHERE id=? AND empresa_id=?", (rid,eid)).fetchone())
                c.close()
                if not r: return self._j({"ok":False,"error":"Retención no encontrada"})
                xml_str = None; clave = (r.get("clave_acceso") or "").strip()
                if clave:
                    ap = BASE_DIR / "comprobantes" / _dir_emp(eid) / "autorizados" / f"{clave}.xml"
                    if ap.exists():
                        try: xml_str = ap.read_text(encoding="utf-8")
                        except Exception: xml_str = None
                if xml_str is None:
                    try: xml_str, clave = _generar_xml_retencion(rid, eid)
                    except Exception as ex: return self._j({"ok":False,"error":str(ex)})
                data = xml_str.encode("utf-8")
                fname = "RET_" + (r.get("numero") or str(rid)).replace("-","_") + ".xml"
                self.send_response(200)
                self.send_header("Content-Type","application/xml; charset=utf-8")
                self.send_header("Content-Disposition", f"attachment; filename={fname}")
                self.send_header("Content-Length", str(len(data)))
                self._cors(); self.end_headers(); self.wfile.write(data)
                return

            elif p == "/api/compras_sin_retencion":
                # Compras que aún no tienen comprobante de retención (para el selector)
                c = db()
                rows = rl(c.execute("""SELECT cp.id, cp.numero, cp.fecha, cp.subtotal, cp.iva, cp.total,
                    pr.nombre as proveedor_nombre, pr.ruc_cedula as proveedor_ruc, pr.id as proveedor_id
                    FROM compras cp LEFT JOIN proveedores pr ON cp.proveedor_id=pr.id
                    WHERE cp.empresa_id=? AND cp.estado!='ANULADA'
                    AND cp.id NOT IN (SELECT COALESCE(compra_id,0) FROM retenciones WHERE empresa_id=? AND estado!='ANULADA')
                    ORDER BY cp.fecha DESC LIMIT 200""", (eid,eid)).fetchall())
                c.close()
                return self._j(rows)

            elif p == "/api/libro_mayor":
                cuenta = qs.get("cuenta",[""])[0]
                f_ini = qs.get("fecha_ini",["2020-01-01"])[0]
                f_fin = qs.get("fecha_fin",["2099-12-31"])[0]
                c = db()
                movs = rl(c.execute("""SELECT d.*, a.fecha, a.concepto, a.numero as asiento_num
                    FROM asiento_detalle d JOIN asientos_contables a ON d.asiento_id=a.id
                    WHERE a.empresa_id=? AND d.cuenta_codigo=? AND a.fecha>=? AND a.fecha<=? AND a.estado='ACTIVO'
                    ORDER BY a.fecha, a.numero""", (eid,cuenta,f_ini,f_fin)).fetchall())
                c.close()
                return self._j(movs)

            elif p == "/api/balance_general":
                fecha = qs.get("fecha",["2099-12-31"])[0]
                c = db()
                saldos = rl(c.execute("""SELECT d.cuenta_codigo, d.cuenta_nombre,
                    COALESCE(SUM(d.debe),0) as total_debe, COALESCE(SUM(d.haber),0) as total_haber
                    FROM asiento_detalle d JOIN asientos_contables a ON d.asiento_id=a.id
                    WHERE a.empresa_id=? AND a.fecha<=? AND a.estado='ACTIVO'
                    GROUP BY d.cuenta_codigo ORDER BY d.cuenta_codigo""", (eid,fecha)).fetchall())
                # Obtener plan de cuentas para clasificar
                plan = rl(c.execute("SELECT codigo,nombre,naturaleza,grupo,tipo,padre_codigo FROM plan_cuentas WHERE empresa_id=? ORDER BY codigo", (eid,)).fetchall())
                c.close()
                return self._j({"saldos":saldos,"plan":plan,"fecha":fecha})

            elif p == "/api/estado_resultados":
                f_ini = qs.get("fecha_ini",[""])[0] or (qs.get("anio",[str(now_ec()[:4])])[0]+"-01-01")
                f_fin = qs.get("fecha_fin",[""])[0] or (qs.get("anio",[str(now_ec()[:4])])[0]+"-12-31")
                c = db()
                saldos = rl(c.execute("""SELECT d.cuenta_codigo, d.cuenta_nombre,
                    COALESCE(SUM(d.debe),0) as total_debe, COALESCE(SUM(d.haber),0) as total_haber
                    FROM asiento_detalle d JOIN asientos_contables a ON d.asiento_id=a.id
                    WHERE a.empresa_id=? AND a.fecha>=? AND a.fecha<=? AND a.estado='ACTIVO'
                    AND (d.cuenta_codigo LIKE '4%' OR d.cuenta_codigo LIKE '5%' OR d.cuenta_codigo LIKE '6%')
                    GROUP BY d.cuenta_codigo ORDER BY d.cuenta_codigo""", (eid,f_ini,f_fin)).fetchall())
                plan = rl(c.execute("SELECT codigo,nombre,naturaleza,grupo FROM plan_cuentas WHERE empresa_id=? AND (codigo LIKE '4%' OR codigo LIKE '5%' OR codigo LIKE '6%') ORDER BY codigo", (eid,)).fetchall())
                c.close()
                return self._j({"saldos":saldos,"plan":plan,"desde":f_ini,"hasta":f_fin})

            elif p == "/api/estado_resultados_mensual":
                anio = qs.get("anio",[str(now_ec()[:4])])[0]
                c = db()
                rows = rl(c.execute("""SELECT d.cuenta_codigo cod, CAST(strftime('%m',a.fecha) AS INTEGER) mes,
                    COALESCE(SUM(d.debe),0) debe, COALESCE(SUM(d.haber),0) haber
                    FROM asiento_detalle d JOIN asientos_contables a ON d.asiento_id=a.id
                    WHERE a.empresa_id=? AND a.estado='ACTIVO' AND substr(a.fecha,1,4)=?
                      AND (d.cuenta_codigo LIKE '4%' OR d.cuenta_codigo LIKE '5%' OR d.cuenta_codigo LIKE '6%')
                    GROUP BY d.cuenta_codigo, mes""", (eid, anio)).fetchall())
                planrows = rl(c.execute("SELECT codigo,nombre,grupo FROM plan_cuentas WHERE empresa_id=?", (eid,)).fetchall())
                c.close()
                plan = {p2["codigo"]: p2 for p2 in planrows}
                cuentas = {}
                for r2 in rows:
                    cod = r2["cod"]; m = int(r2["mes"] or 0)
                    info = plan.get(cod, {}); grupo = (info.get("grupo") or "").upper()
                    nombre = info.get("nombre") or cod
                    if grupo == "INGRESO" or cod.startswith("4"):
                        val = r2["haber"] - r2["debe"]; cat = "INGRESO"
                    elif grupo == "COSTO" or cod.startswith("5.1"):
                        val = r2["debe"] - r2["haber"]; cat = "COSTO"
                    else:
                        val = r2["debe"] - r2["haber"]; cat = "GASTO"
                    cu = cuentas.setdefault(cod, {"codigo": cod, "nombre": nombre, "categoria": cat, "valores": [0.0]*12})
                    if 1 <= m <= 12:
                        cu["valores"][m-1] = round(cu["valores"][m-1] + val, 2)
                lista = sorted(cuentas.values(), key=lambda x: x["codigo"])
                for cu in lista:
                    cu["total"] = round(sum(cu["valores"]), 2)
                return self._j({"ok": True, "anio": anio, "cuentas": lista})

            elif p == "/api/obtener_tema":
                c = db()
                e = rd(c.execute("SELECT tema FROM empresas WHERE id=?", (eid,)).fetchone())
                c.close()
                return self._j({"tema": (e.get("tema") if e else "oscuro") or "oscuro"})

            else: return self._j({"error":"Ruta no encontrada"},404)

        # ── POST ─────────────────────────────────────────────────
        except Exception as ex:
            import traceback; log.error("do_GET error: %s", traceback.format_exc())
            try: self._j({"ok":False,"error":str(ex)},500)
            except: pass

    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length",0))
            body   = json.loads(self.rfile.read(length)) if length else {}
            p      = urlparse(self.path).path
            self._do_POST_inner(p, body)
        except Exception as ex:
            log.error("Error en do_POST: %s", ex, exc_info=True)
            try:
                self._j({"ok":False,"error":f"Error interno del servidor: {str(ex)}"},500)
            except: pass

    def _do_POST_inner(self, p, body):

        # Apagar el sistema (sin sesión: botón "Cerrar sistema")
        if p == "/api/apagar":
            # El boton "Cerrar sistema" cierra la SESION de esta maquina.
            # No apaga el servidor: las demas computadoras siguen trabajando.
            tok = (self.headers.get("Authorization", "") or "").replace("Bearer ", "").strip()
            if tok:
                sesion_eliminar(tok)
            return self._j({"ok": True, "mensaje": "Sesión cerrada", "solo_sesion": True})

        if p == "/api/apagar_servidor":
            # Apagado real del servidor. Queda aparte y a proposito.
            self._j({"ok": True, "mensaje": "Sistema cerrado"})
            log.info("Apagado del servidor solicitado.")
            # Señal para el vigilante: este cierre es a proposito, no una caida.
            # Sin esto, el lanzador automatico volveria a levantar el servidor
            # a los pocos segundos y el boton "Cerrar sistema" no serviria.
            try:
                _d = BASE_DIR / "logs"
                _d.mkdir(parents=True, exist_ok=True)
                (_d / "detener.flag").write_text("apagado desde el sistema " + now_ec(), encoding="utf-8")
            except Exception as _ex:
                log.warning("No se pudo dejar la senal de apagado: %s", _ex)
            threading.Thread(target=lambda: (time.sleep(0.4), os._exit(0)), daemon=True).start()
            return

        # Login — sin autenticación previa
        # ── Activar licencia (sin sesión) ────────────────────────
        if p == "/api/activar_licencia":
            codigo = body.get("codigo","").strip()
            c = db()
            emp = rd(c.execute("SELECT ruc FROM empresas LIMIT 1").fetchone())
            c.close()
            ruc = emp["ruc"] if emp else ""
            res = verificar_licencia(codigo, ruc)
            if res["valida"]:
                guardar_licencia(codigo)
                return self._j({"ok": True, "mensaje": res["mensaje"], "expira": res.get("expira","")})
            return self._j({"ok": False, "error": res["mensaje"]})

        # ── Generar licencia (herramienta del propietario del sistema) ──
        if p == "/api/gen_licencia":
            # Protegida con clave maestra del sistema
            clave_maestra = body.get("clave_maestra","")
            if not hmac.compare_digest(
                hashlib.sha256(clave_maestra.encode()).hexdigest(),
                hashlib.sha256(_LIC_SECRET.encode()).hexdigest()
            ):
                return self._j({"ok": False, "error": "Clave maestra incorrecta"}, 403)
            mid  = body.get("machine_id","").replace("-","").upper()
            ruc  = body.get("ruc","")
            dias = int(body.get("dias", 365))
            if not mid or not ruc:
                return self._j({"ok": False, "error": "machine_id y ruc son requeridos"})
            licencia = generar_licencia_admin(mid, ruc, dias)
            return self._j({"ok": True, "licencia": licencia, "machine_id": mid, "ruc": ruc, "dias": dias})

        if p == "/api/login":
            u  = body.get("username","").strip()
            pwd_plain = body.get("password","")
            ph = hashlib.sha256(pwd_plain.encode()).hexdigest()  # compat
            # Obtener IP del cliente
            ip_cliente = (self.headers.get("X-Forwarded-For","") or
                          self.client_address[0] if self.client_address else "127.0.0.1")
            nombre_maquina = body.get("nombre_maquina","") or ip_cliente

            c = db()
            usr = rd(c.execute("SELECT * FROM usuarios WHERE LOWER(username)=LOWER(?) AND activo=1", (u,)).fetchone())
            if usr and not verify_password(pwd_plain, usr.get("password_hash","")):
                usr = None
            elif usr and not usr.get("password_hash","").startswith("pbkdf2$"):
                # Migrar hash antiguo a pbkdf2 automáticamente
                try:
                    nuevo = hash_password(pwd_plain)
                    c.execute("UPDATE usuarios SET password_hash=? WHERE id=?", (nuevo, usr["id"]))
                    c.commit()
                except: pass
            if not usr: c.close(); return self._j({"ok":False,"error":"Usuario o contraseña incorrectos"},401)
            emps = rl(c.execute("""SELECT e.*, ue.rol as mi_rol FROM empresas e
                JOIN usuario_empresa ue ON e.id=ue.empresa_id
                WHERE ue.usuario_id=? AND e.activa=1 ORDER BY e.nombre""", (usr["id"],)).fetchall())
            eid_req = body.get("empresa_id")
            emp_sel = next((e for e in emps if e["id"] == int(eid_req)), None) if eid_req else None
            if not emp_sel: emp_sel = emps[0] if emps else None
            if not emp_sel: c.close(); return self._j({"ok":False,"error":"Sin empresa asignada"},403)

            # ── CONTROL DE CONEXIONES SIMULTÁNEAS ──────────────
            puede, activas, limite = verificar_limite_conexiones(emp_sel["id"])
            if not puede:
                c.close()
                conexiones = get_conexiones_empresa(emp_sel["id"])
                return self._j({
                    "ok": False,
                    "error": f"Límite de conexiones alcanzado ({activas}/{limite} máquinas). Cierra sesión en otra computadora o contacta al administrador.",
                    "conexiones_activas": conexiones,
                    "limite": limite,
                    "tipo_error": "LIMITE_CONEXIONES"
                }, 429)

            c.execute("UPDATE usuarios SET ultimo_acceso=? WHERE id=?", (now_ec(), usr["id"]))
            c.commit(); c.close()
            token = sesion_crear(usr["id"], emp_sel["id"], usr["rol"], usr["nombre"],
                                 emp_sel.get("mi_rol","cajero"),
                                 ip=ip_cliente, maquina=nombre_maquina)
            log.info("Login: %s desde %s (%s) — empresa %s", u, ip_cliente, nombre_maquina, emp_sel["nombre"])
            return self._j({"ok":True,"token":token,
                            "usuario":{"id":usr["id"],"nombre":usr["nombre"],"username":usr["username"],"rol":usr["rol"],
                                       "modulos":(usr.get("modulos") or "")},
                            "empresa":emp_sel,"empresas":emps,
                            "conexion":{"ip":ip_cliente,"maquina":nombre_maquina,
                                        "activas":activas+1,"limite":limite}})

        # Cambiar empresa
        if p == "/api/cambiar_empresa":
            sess = self._auth()
            if not sess: return self._j({"error":"No autenticado"},401)
            eid_n = body.get("empresa_id")
            c = db()
            ue  = rd(c.execute("SELECT * FROM usuario_empresa WHERE usuario_id=? AND empresa_id=?", (sess["usuario_id"],eid_n)).fetchone())
            emp = rd(c.execute("SELECT * FROM empresas WHERE id=? AND activa=1", (eid_n,)).fetchone()); c.close()
            if not ue or not emp: return self._j({"ok":False,"error":"Sin acceso"},403)
            token = self.headers.get("Authorization","").replace("Bearer ","").strip()
            SESSIONS[token]["empresa_id"]  = eid_n
            SESSIONS[token]["rol_empresa"] = ue["rol"]
            SESSIONS[token]["expires"]     = time.time() + 8*3600
            return self._j({"ok":True,"empresa":emp})

        sess = self._auth()
        if not sess: return self._j({"error":"No autenticado"},401)
        eid = sess["empresa_id"]
        # Admin: rol global admin/supervisor O rol en empresa admin/supervisor
        is_admin = (sess.get("rol") in ["admin","supervisor"] or
                    sess.get("rol_empresa") in ["admin","supervisor"])

        # Candado del cierre de mes: se revisa ANTES de abrir ninguna conexion,
        # para no dejar la base tomada si hay que rechazar la operacion.
        _aviso_cierre = _guardia_cierre(p, body, eid)
        if _aviso_cierre:
            return self._j({"ok": False, "error": _aviso_cierre, "mes_cerrado": True})

        if p == "/api/empresa":
            if not is_admin: return self._j({"ok":False,"error":"Sin permiso"},403)
            c = db()
            emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
            if not emp: c.close(); return self._j({"ok":False,"error":"Empresa no encontrada"},404)

            # Actualizar solo los campos que vienen en el body
            for k in ["nombre","nombre_comercial","ruc","direccion","telefono","email","ciudad",
                      "iva_porcentaje","precios_incluyen_iva","facturacion_electronica","ambiente","estab","pto_emi",
                      "obligado_contabilidad","contribuyente_especial","cert_password",
                      "smtp_host","smtp_port","smtp_user","smtp_pass","smtp_from","envio_auto_correo","logo_base64","sec_inicio_fac","sec_inicio_nc","sec_inicio_gr","sec_inicio_lc","sec_inicio_ret","prov_sistema_ruc","prov_sistema_campo"]:
                if k in body:
                    emp[k] = body[k]

            # Convertir tipos — None o "" → valor por defecto
            def safe_int(v, default=0):
                try: return int(v) if v not in (None,"") else default
                except: return default
            def safe_float(v, default=0.0):
                try: return float(v) if v not in (None,"") else default
                except: return default
            def safe_str(v, default=""):
                return v if v is not None else default
            # Valor que llega; si viene vacío o no viene, se queda el anterior
            def _cfg_cons(nuevo, anterior, campo):
                v = nuevo.get(campo)
                if v is None or str(v).strip() == "":
                    return (anterior or {}).get(campo) or ""
                return v
            prev = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()) or {}

            c.execute("""UPDATE empresas SET
                nombre=?, nombre_comercial=?, ruc=?, direccion=?, telefono=?,
                email=?, ciudad=?, iva_porcentaje=?, precios_incluyen_iva=?, facturacion_electronica=?,
                ambiente=?, estab=?, pto_emi=?,
                obligado_contabilidad=?, contribuyente_especial=?, cert_password=?,
                smtp_host=?, smtp_port=?, smtp_user=?, smtp_pass=?, smtp_from=?, envio_auto_correo=?,
                logo_base64=?,
                sec_inicio_fac=?, sec_inicio_nc=?, sec_inicio_gr=?, sec_inicio_lc=?, sec_inicio_ret=?,
                prov_sistema_ruc=?, prov_sistema_campo=?
                WHERE id=?""",
                [
                    # Los campos delicados NO se borran si el formulario no los
                    # manda: se conserva lo que ya estaba guardado. Antes, un
                    # guardado parcial dejaba la dirección o el RUC en blanco y
                    # el SRI devolvía el comprobante con el error 35.
                    _cfg_cons(emp, prev, "nombre"),
                    safe_str(emp.get("nombre_comercial")),
                    _cfg_cons(emp, prev, "ruc"),
                    _cfg_cons(emp, prev, "direccion"),
                    _cfg_cons(emp, prev, "telefono"),
                    _cfg_cons(emp, prev, "email"),
                    _cfg_cons(emp, prev, "ciudad"),
                    safe_float(emp.get("iva_porcentaje"), 15),
                    safe_int(emp.get("precios_incluyen_iva"), 0),
                    safe_int(emp.get("facturacion_electronica"), prev.get("facturacion_electronica", 0))
                        if "facturacion_electronica" in emp else prev.get("facturacion_electronica", 0),
                    safe_str(emp.get("ambiente"), "1"),
                    safe_str(emp.get("estab"), "001"),
                    safe_str(emp.get("pto_emi"), "001"),
                    safe_str(emp.get("obligado_contabilidad"), "NO"),
                    safe_str(emp.get("contribuyente_especial")),
                    _cfg_cons(emp, prev, "cert_password"),
                    safe_str(emp.get("smtp_host")),
                    safe_int(emp.get("smtp_port"), 587),
                    safe_str(emp.get("smtp_user")),
                    safe_str(emp.get("smtp_pass")),
                    safe_str(emp.get("smtp_from")),
                    safe_int(emp.get("envio_auto_correo"), 0),
                    safe_str(emp.get("logo_base64")),
                    safe_int(emp.get("sec_inicio_fac"), 0),
                    safe_int(emp.get("sec_inicio_nc"), 0),
                    safe_int(emp.get("sec_inicio_gr"), 0),
                    safe_int(emp.get("sec_inicio_lc"), 0),
                    safe_int(emp.get("sec_inicio_ret"), 0),
                    safe_str(emp.get("prov_sistema_ruc"), PROV_SISTEMA_RUC_DEFAULT) or PROV_SISTEMA_RUC_DEFAULT,
                    safe_str(emp.get("prov_sistema_campo"), PROV_SISTEMA_CAMPO_DEFAULT) or PROV_SISTEMA_CAMPO_DEFAULT,
                    eid
                ])
            # ── Si cambió el nombre: renombrar la carpeta de comprobantes al nuevo nombre ──
            try:
                if "nombre" in body:
                    vieja = (emp.get("carpeta") or "").strip() or f"empresa_{eid}"
                    base_n = _sanitizar_carpeta(body.get("nombre")) or f"EMPRESA_{eid}"
                    if base_n != vieja:
                        otras = {r[0] for r in c.execute("SELECT IFNULL(carpeta,'') FROM empresas WHERE id!=?", (eid,)).fetchall()}
                        nueva = base_n if base_n not in otras else f"{base_n}_{eid}"
                        _renombrar_dirs_empresa(vieja, nueva)
                        _actualizar_rutas_empresa(c, eid, vieja, nueva)
                        c.execute("UPDATE empresas SET carpeta=? WHERE id=?", (nueva, eid))
                        _CARP_CACHE.pop(int(eid), None)
            except Exception as ex:
                log.warning("No se pudo renombrar la carpeta de la empresa %s: %s", eid, ex)
            c.commit(); c.close()
            _CARP_CACHE.pop(int(eid), None)
            return self._j({"ok":True})

        elif p == "/api/clientes":
            c = db()
            if body.get("id"):
                c.execute("UPDATE clientes SET nombre=?,ruc_cedula=?,tipo_identificacion=?,email=?,telefono=?,celular=?,direccion=? WHERE id=? AND empresa_id=?",
                    [body.get(k,"") for k in ["nombre","ruc_cedula","tipo_identificacion","email","telefono","celular","direccion"]] + [body["id"],eid])
                c.commit(); c.close(); return self._j({"ok":True,"id":body["id"]})
            ruc = (body.get("ruc_cedula","") or "").strip()
            # Evitar duplicados: si ya existe un cliente con ese RUC/cédula (no genérico), devolverlo
            if ruc and ruc != "9999999999999":
                ex = rd(c.execute("SELECT id FROM clientes WHERE empresa_id=? AND ruc_cedula=?", (eid, ruc)).fetchone())
                if ex:
                    c.close(); return self._j({"ok":True,"id":ex["id"],"existente":True})
            c.execute("INSERT INTO clientes (empresa_id,nombre,ruc_cedula,tipo_identificacion,email,telefono,celular,direccion,created_at) VALUES (?,?,?,?,?,?,?,?,?)",
                [eid]+[body.get(k,"") for k in ["nombre","ruc_cedula","tipo_identificacion","email","telefono","celular","direccion"]]+[now_ec()])
            nid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            c.commit(); c.close(); return self._j({"ok":True,"id":nid})

        elif p == "/api/eliminar_producto":
            c = db(); pid = body.get("id")
            usado = c.execute("SELECT COUNT(*) FROM stock_movimientos WHERE producto_id=? AND empresa_id=?", (pid, eid)).fetchone()[0]
            if usado:
                # Tiene historial: desactivar para no romper kardex/reportes
                c.execute("UPDATE productos SET activo=0 WHERE id=? AND empresa_id=?", (pid, eid))
                c.commit(); c.close()
                return self._j({"ok":True,"desactivado":True,"mensaje":"El producto tiene movimientos; se desactivó (no se borra el historial)."})
            c.execute("DELETE FROM stock_bodega WHERE producto_id=? AND empresa_id=?", (pid, eid))
            c.execute("DELETE FROM productos WHERE id=? AND empresa_id=?", (pid, eid))
            c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/eliminar_cliente":
            c = db(); n = c.execute("SELECT COUNT(*) as n FROM facturas WHERE cliente_id=? AND empresa_id=?", (body.get("id"),eid)).fetchone()["n"]
            if n > 0: c.close(); return self._j({"ok":False,"error":"Cliente con facturas asociadas"})
            c.execute("DELETE FROM clientes WHERE id=? AND empresa_id=?", (body.get("id"),eid))
            c.commit(); c.close(); return self._j({"ok":True})

        elif p == "/api/reparar_iva_productos":
            c = db()
            r1 = c.execute("UPDATE productos SET iva_porcentaje=0 WHERE empresa_id=? AND graba_iva=0 AND IFNULL(iva_porcentaje,0)<>0", (eid,)).rowcount
            r2 = c.execute("UPDATE productos SET iva_porcentaje=15 WHERE empresa_id=? AND IFNULL(graba_iva,1)=1 AND IFNULL(iva_porcentaje,0)<=0", (eid,)).rowcount
            c.commit(); c.close()
            return self._j({"ok":True,"corregidos_a_0":r1,"corregidos_a_15":r2,
                            "mensaje":f"{r1} producto(s) puestos en 0% (no gravan) y {r2} en 15% (gravan). Total corregidos: {r1+r2}."})

        elif p == "/api/productos":
            c = db(); cfgp = _cfg_contable(c, eid)
            tipo_p = (body.get("tipo","PRODUCTO") or "PRODUCTO").upper()
            es_serv = (tipo_p == "SERVICIO")
            costo = float(body.get("costo",0) or 0)
            # ── IVA consistente: "graba_iva" manda sobre el porcentaje ──
            giva_p = 1 if int(body.get("graba_iva",1) or 0) else 0
            try: ivap_p = float(body.get("iva_porcentaje",15))
            except Exception: ivap_p = 15.0
            if giva_p == 0: ivap_p = 0.0          # no graba → 0% siempre
            elif ivap_p <= 0: ivap_p = 15.0        # graba sin % → 15% por defecto
            if body.get("id"):
                c.execute("""UPDATE productos SET codigo=?,nombre=?,descripcion=?,precio=?,costo=?,stock=?,
                    unidad=?,activo=?,tipo=?,graba_iva=?,iva_porcentaje=?,
                    precio_mayorista=?,precio_otros=?,cant_mayorista=? WHERE id=? AND empresa_id=?""",
                    [body.get("codigo",""),body.get("nombre",""),body.get("descripcion",""),
                     float(body.get("precio",0)),costo,(0 if es_serv else int(body.get("stock",0))),body.get("unidad","unidad"),
                     int(body.get("activo",1)),tipo_p,giva_p,
                     ivap_p,
                     float(body.get("precio_mayorista",0) or 0),
                     float(body.get("precio_otros",0) or 0),
                     max(1, int(body.get("cant_mayorista",6) or 6)),
                     body["id"],eid])
            else:
                cta_inv = "" if es_serv else cfgp["cta_inventario"]
                c.execute("""INSERT INTO productos (empresa_id,codigo,nombre,descripcion,precio,costo,stock,unidad,activo,tipo,graba_iva,iva_porcentaje,
                    cuenta_inventario,cuenta_ingreso,cuenta_costo,precio_mayorista,precio_otros,cant_mayorista)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    [eid,body.get("codigo",""),body.get("nombre",""),body.get("descripcion",""),
                     float(body.get("precio",0)),costo,(0 if es_serv else int(body.get("stock",0))),body.get("unidad","unidad"),
                     int(body.get("activo",1)),tipo_p,giva_p,
                     ivap_p, cta_inv, cfgp["cta_ventas"], ("" if es_serv else cfgp["cta_gastos"]),
                     float(body.get("precio_mayorista",0) or 0),
                     float(body.get("precio_otros",0) or 0),
                     max(1, int(body.get("cant_mayorista",6) or 6))])
                pid_new = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                stk0 = 0 if es_serv else int(body.get("stock",0))
                if stk0 > 0:
                    bod = _bodega_principal(c, eid); _stock_bodega_mov(c, eid, pid_new, bod, stk0)
            c.commit(); c.close(); return self._j({"ok":True})


        elif p == "/api/parsear_excel":
            # Parsear Excel enviado como base64
            try:
                import openpyxl, io
                b64_data = body.get("data_base64","")
                raw = base64.b64decode(b64_data)
                wb = openpyxl.load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
                ws = wb.active
                headers = [str(ws.cell(1,c).value or "").strip() for c in range(1, ws.max_column+1)]
                rows = []
                for r in range(2, ws.max_row+1):
                    row = {}
                    for c in range(1, ws.max_column+1):
                        v = ws.cell(r,c).value
                        row[headers[c-1]] = v if v is not None else ""
                    if any(str(v).strip() for v in row.values()):
                        rows.append(row)
                wb.close()
                return self._j({"ok":True,"headers":headers,"rows":rows})
            except ImportError:
                return self._j({"ok":False,"error":"Falta openpyxl. Ejecuta: pip install openpyxl"})
            except Exception as ex:
                return self._j({"ok":False,"error":f"Error leyendo Excel: {ex}"})

        elif p == "/api/importar_clientes_excel":
            lista = body.get("clientes") or []
            if not lista: return self._j({"ok":False,"error":"Sin clientes para importar"})
            c = db(); nuevos = 0; actualizados = 0
            for cl in lista:
                nombre = str(cl.get("nombre","") or "").strip()
                if not nombre: continue
                ruc = str(cl.get("ruc_cedula","") or "").strip().replace(".0","") if cl.get("ruc_cedula") is not None else ""
                # Tipo de identificación automático
                tid = "05"
                if len(ruc) == 13: tid = "04"
                elif len(ruc) == 10: tid = "05"
                elif ruc: tid = "06"
                ex = rd(c.execute("SELECT id FROM clientes WHERE empresa_id=? AND ruc_cedula=? AND ?!=''", (eid, ruc, ruc)).fetchone()) if ruc else None
                if ex:
                    c.execute("UPDATE clientes SET nombre=?,email=?,telefono=?,celular=?,direccion=? WHERE id=?",
                        [nombre, str(cl.get("email","") or ""), str(cl.get("telefono","") or ""),
                         str(cl.get("celular","") or ""), str(cl.get("direccion","") or ""), ex["id"]])
                    actualizados += 1
                else:
                    c.execute("""INSERT INTO clientes (empresa_id,nombre,ruc_cedula,tipo_identificacion,email,telefono,celular,direccion,created_at)
                                 VALUES (?,?,?,?,?,?,?,?,?)""",
                        [eid, nombre, ruc, tid, str(cl.get("email","") or ""), str(cl.get("telefono","") or ""),
                         str(cl.get("celular","") or ""), str(cl.get("direccion","") or ""), now_ec()])
                    nuevos += 1
            c.commit(); c.close()
            return self._j({"ok":True,"mensaje":f"{nuevos} clientes nuevos, {actualizados} actualizados"})

        elif p == "/api/importar_productos_excel":
            # Importar productos desde datos parseados
            productos = body.get("productos",[])
            if not productos: return self._j({"ok":False,"error":"Sin productos"})
            c = db()
            importados = actualizados = 0
            for pr in productos:
                codigo = str(pr.get("codigo","")).strip()
                nombre = str(pr.get("nombre","")).strip()
                if not nombre: continue
                # Si ya existe por código, actualizar
                cfgp = _cfg_contable(c, eid)
                tipo_p = str(pr.get("tipo","PRODUCTO")).upper()
                es_serv = "SERV" in tipo_p
                tipo_norm = "SERVICIO" if es_serv else "PRODUCTO"
                cta_inv = "" if es_serv else cfgp["cta_inventario"]
                cta_ing = cfgp["cta_ventas"]; cta_cos = "" if es_serv else cfgp["cta_gastos"]
                if codigo:
                    ex = rd(c.execute("SELECT id FROM productos WHERE empresa_id=? AND codigo=?",(eid,codigo)).fetchone())
                    if ex:
                        c.execute("UPDATE productos SET nombre=?,precio=?,costo=?,stock=?,unidad=?,tipo=?,activo=1 WHERE id=?",
                            [nombre,float(pr.get("precio",0)),float(pr.get("costo",0)),0 if es_serv else float(pr.get("stock",0)),pr.get("unidad","unidad"),tipo_norm,ex["id"]])
                        actualizados += 1; continue
                stk = 0 if es_serv else float(pr.get("stock",0))
                c.execute("""INSERT INTO productos (empresa_id,codigo,nombre,descripcion,precio,costo,stock,unidad,activo,tipo,
                    graba_iva,iva_porcentaje,cuenta_inventario,cuenta_ingreso,cuenta_costo)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    [eid,codigo,nombre,str(pr.get("descripcion","")),float(pr.get("precio",0)),float(pr.get("costo",0)),stk,
                     "servicio" if es_serv else pr.get("unidad","unidad"),1,tipo_norm,
                     1,float(pr.get("iva_porcentaje",15)),cta_inv,cta_ing,cta_cos])
                pid_new = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                if not es_serv and stk > 0:
                    bod = _bodega_principal(c, eid); _stock_bodega_mov(c, eid, pid_new, bod, stk)
                importados += 1
            c.commit(); c.close()
            return self._j({"ok":True,"importados":importados,"actualizados":actualizados,"mensaje":f"{importados} importados, {actualizados} actualizados"})

        elif p == "/api/eliminar_factura":
            fid = body.get("id"); c = db()
            fac = rd(c.execute("SELECT * FROM facturas WHERE id=? AND empresa_id=?",(fid,eid)).fetchone())
            if not fac: c.close(); return self._j({"ok":False,"error":"No encontrada"})
            if fac.get("estado_sri") in ("AUTORIZADA","RECIBIDA"):
                c.close(); return self._j({"ok":False,"error":"No se puede eliminar una factura autorizada por el SRI"})
            cli_id = fac.get("cliente_id")
            fac_total = float(fac.get("total",0))
            # Eliminar registros relacionados
            c.execute("DELETE FROM factura_items WHERE factura_id=?", (fid,))
            c.execute("DELETE FROM cuentas_cobrar WHERE factura_id=?", (fid,))
            c.execute("DELETE FROM facturas WHERE id=? AND empresa_id=?", (fid,eid))
            # Recalcular saldo del cliente
            if cli_id:
                ultimo = rd(c.execute("SELECT saldo FROM cuentas_cobrar WHERE empresa_id=? AND cliente_id=? ORDER BY id DESC LIMIT 1",(eid,cli_id)).fetchone())
                saldo_actual = float(ultimo["saldo"]) if ultimo else 0
                # Si el saldo quedó negativo por la eliminación, insertar ajuste
                if saldo_actual > 0:
                    nuevo_saldo = saldo_actual - fac_total
                    if nuevo_saldo < 0: nuevo_saldo = 0
                    c.execute("INSERT INTO cuentas_cobrar (empresa_id,cliente_id,factura_id,tipo,concepto,monto,saldo,fecha,created_at) VALUES (?,?,NULL,'AJUSTE','Ajuste por eliminación de factura',?,?,?,?)",
                        (eid,cli_id,-fac_total,nuevo_saldo,now_ec()[:10],now_ec()))
            c.commit(); c.close()
            return self._j({"ok":True,"mensaje":"Factura eliminada y saldos actualizados"})

        elif p == "/api/calcular_iva":
            c = db(); emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
            _inc = body.get("precios_incluyen_iva")
            _inc = None if _inc in (None, "") else bool(int(_inc))
            its, tot = _desglosar_items(c, eid, body.get("items", []), emp, _inc)
            c.close()
            return self._j({"ok": True, "items": its, "totales": tot})

        elif p == "/api/facturas":
            items = body.get("items",[])
            if not items: return self._j({"ok":False,"error":"Sin ítems"},400)
            c = db(); emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
            # Sucursales: no se puede vender lo que no está en esta sucursal
            _falta_stock = _suc_validar_stock(c, eid, sess, items)
            if _falta_stock:
                c.close()
                return self._j({"ok": False, "error": _falta_stock})
            _suc_id = _suc_id_actual(c, eid, sess)
            # Desglose por ítem: cada producto con su tarifa, y si la empresa
            # digita precios con IVA incluido, aquí se separa la base del IVA.
            _inc = body.get("precios_incluyen_iva")
            _inc = None if _inc in (None, "") else bool(int(_inc))
            items, _tot = _desglosar_items(c, eid, items, emp, _inc)
            sub   = _tot["subtotal"]
            iva   = _tot["iva"]
            total = _tot["total"]
            # Establecimiento y punto: manda la sucursal del usuario; si no
            # trabaja por sucursales, su punto propio; si no, el de la empresa.
            estab_u, pto_u = _pto_emision_usuario(c, emp, sess)
            sec_custom = int(emp.get("sec_inicio_fac") or 0)
            # Secuencia independiente por (estab, punto): así el 002 no choca con el 001
            sec = _siguiente_secuencial_factura(c, eid, estab_u, pto_u, sec_custom)
            num  = f"{estab_u}-{pto_u}-{str(sec).zfill(9)}"
            fecha_f = body.get("fecha") or today_ec()
            estado_f = body.get("estado","PENDIENTE")
            c.execute("INSERT INTO facturas (empresa_id,numero,cliente_id,usuario_id,fecha,subtotal,iva,total,estado,notas,forma_pago,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                [eid,num,body.get("cliente_id"),sess["usuario_id"],fecha_f,sub,iva,total,estado_f,body.get("notas",""),body.get("forma_pago","01"),now_ec()])
            fid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            try:
                if not _suc_id:
                    _suc_id = _suc_por_codigo(c, eid, estab_u, pto_u)
                c.execute("UPDATE facturas SET sucursal_id=? WHERE id=?", (_suc_id, fid))
            except Exception:
                pass
            for it in items:
                c.execute("""INSERT INTO factura_items
                        (factura_id,producto_id,codigo,descripcion,cantidad,precio_unitario,descuento,subtotal,iva_tarifa,iva_valor)
                        VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    [fid,(int(it.get("producto_id")) if it.get("producto_id") else None),
                     it.get("codigo",""),it.get("descripcion",""),float(it.get("cantidad",1)),
                     float(it.get("precio_unitario",0)),float(it.get("descuento",0)),float(it.get("subtotal",0)),
                     float(it.get("iva_tarifa",-1)),float(it.get("iva_valor",0))])
                # ── Descontar stock automáticamente si el producto existe y es PRODUCTO ──
                pid_it = it.get("producto_id")
                if pid_it:
                    prod = rd(c.execute("SELECT stock,tipo FROM productos WHERE id=? AND empresa_id=?",(pid_it,eid)).fetchone())
                    if prod and str(prod.get("tipo","PRODUCTO")).upper() != "SERVICIO":
                        cant_it = float(it.get("cantidad",1))
                        stock_ant = float(prod["stock"])
                        stock_nuevo = stock_ant - cant_it
                        c.execute("UPDATE productos SET stock=? WHERE id=?", (stock_nuevo, pid_it))
                        _bp = _suc_bodega(c, eid, sess); _stock_bodega_mov(c, eid, pid_it, _bp, -cant_it)
                        c.execute("""INSERT INTO stock_movimientos
                            (empresa_id,producto_id,tipo,cantidad,stock_antes,stock_despues,
                             referencia_id,referencia_tipo,notas,fecha,usuario_id,bodega_id)
                            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                            [eid,pid_it,"VENTA",-cant_it,stock_ant,stock_nuevo,
                             fid,"FACTURA",f"Factura {num}",fecha_f,sess["usuario_id"],_bp])

            # ── Registrar en Cuentas por Cobrar ──────────────────────────
            cid_cl = body.get("cliente_id")
            if cid_cl:
                last_cc = rd(c.execute("SELECT saldo FROM cuentas_cobrar WHERE empresa_id=? AND cliente_id=? ORDER BY id DESC LIMIT 1",(eid,cid_cl)).fetchone())
                saldo_ant = float(last_cc["saldo"]) if last_cc else 0
                saldo_nuevo = saldo_ant + total
                cc_estado = "PAGADO" if estado_f == "PAGADA" else "PENDIENTE"
                c.execute("""INSERT INTO cuentas_cobrar
                    (empresa_id,cliente_id,factura_id,tipo,concepto,monto,saldo,fecha,usuario_id,estado,referencia,created_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                    [eid,cid_cl,fid,"FACTURA",f"Factura {num}",
                     total if cc_estado=="PENDIENTE" else 0,
                     saldo_nuevo if cc_estado=="PENDIENTE" else saldo_ant,
                     fecha_f,sess["usuario_id"],cc_estado,num,now_ec()])
                _pago_inline_id = 0
                if estado_f == "PAGADA":
                    # Si se crea directamente como pagada, registrar pago también
                    c.execute("""INSERT INTO cuentas_cobrar
                        (empresa_id,cliente_id,factura_id,tipo,concepto,monto,saldo,fecha,usuario_id,estado,referencia,created_at)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                        [eid,cid_cl,fid,"PAGO",f"Pago factura {num}",
                         -total, saldo_ant, fecha_f, sess["usuario_id"], "PAGADO", num, now_ec()])
                    _pago_inline_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]

            # ── Asiento contable automático (venta → Cuentas por Cobrar) ──
            cfgc = _cfg_contable(c, eid)
            _b15 = round(iva / 0.15, 2) if iva and iva > 0 else 0.0
            _b0 = round(float(sub) - _b15, 2)
            if _b0 < 0: _b0 = 0.0
            _cta_v0 = cfgc.get("cta_ventas_0") or cfgc["cta_ventas"]
            _lineas_v = [(cfgc["cta_cxc"], total, 0)]
            if _b15 > 0: _lineas_v.append((cfgc["cta_ventas"], 0, _b15))
            if _b0 > 0:  _lineas_v.append((_cta_v0, 0, _b0))
            if _b15 == 0 and _b0 == 0: _lineas_v.append((cfgc["cta_ventas"], 0, float(sub)))
            if iva and iva > 0: _lineas_v.append((cfgc["cta_iva_ventas"], 0, iva))
            generar_asiento_auto(c, eid, sess["usuario_id"], fecha_f,
                "Venta factura " + num, "VENTA", fid, _lineas_v)
            # Si se creó pagada, asiento de cobro (Caja/Bancos ← Cuentas por Cobrar)
            if estado_f == "PAGADA" and cid_cl:
                _fp = body.get("forma_pago","01")
                _cta_cobro = cfgc["cta_caja"] if _fp == "01" else cfgc["cta_bancos"]
                generar_asiento_auto(c, eid, sess["usuario_id"], fecha_f,
                    "Cobro factura " + num, "COBRO", _pago_inline_id,
                    [(_cta_cobro, total, 0),
                     (cfgc["cta_cxc"], 0, total)])

            c.commit(); c.close()
            return self._j({"ok":True,"id":fid,"numero":num})

        elif p == "/api/procesar_electronica":
            fid = body.get("factura_id")
            if not fid: return self._j({"ok":False,"error":"factura_id requerido"},400)
            return self._j(procesar_fe(int(fid), eid))

        elif p == "/api/consultar_autorizacion":
            fid = body.get("factura_id")
            c = db()
            fac = rd(c.execute("SELECT clave_acceso FROM facturas WHERE id=? AND empresa_id=?", (int(fid),eid)).fetchone())
            emp2 = rd(c.execute("SELECT ambiente FROM empresas WHERE id=?", (eid,)).fetchone()); c.close()
            if not fac or not fac.get("clave_acceso"):
                return self._j({"ok":False,"error":"Sin clave de acceso"})
            res = autorizar_sri(fac["clave_acceso"], emp2.get("ambiente","1"))
            _slog(eid, int(fid), "CONSULTAR_AUTH", res.get("estado","?"), "", json.dumps(res))
            if res.get("estado") == "AUTORIZADO":
                na = res.get("numero_autorizacion") or fac["clave_acceso"]
                fa = res.get("fecha_autorizacion") or now_ec()
                _upd(int(fid), estado="AUTORIZADA", estado_sri="AUTORIZADA", autorizacion=na, fecha_autorizacion=fa)
                return self._j({"ok":True,"estado":"AUTORIZADO","numero_autorizacion":na,"fecha_autorizacion":fa,"clave_acceso":fac["clave_acceso"]})
            return self._j({"ok":False,"estado":res.get("estado"),"mensajes":res.get("mensajes",[]),"detalle":res,"clave_acceso":fac["clave_acceso"]})

        elif p == "/api/anular":
            fid = body.get("id"); c = db()
            f = rd(c.execute("SELECT estado,clave_acceso FROM facturas WHERE id=? AND empresa_id=?", (fid,eid)).fetchone())
            if f:
                c.execute("UPDATE facturas SET estado='ANULADA',estado_sri='ANULADA' WHERE id=?", (fid,)); c.commit()
                revertir_asiento_auto(c, eid, "VENTA", fid); c.commit()
                if f.get("clave_acceso"):
                    cd = BASE_DIR / "comprobantes" / _dir_emp(eid)
                    (cd / "anulados").mkdir(parents=True, exist_ok=True)
                    for sub in ["autorizados","firmados","generados"]:
                        src = cd / sub / f"{f['clave_acceso']}.xml"
                        try:
                            if src.exists(): src.rename((cd / "anulados") / f"{f['clave_acceso']}.xml"); break
                        except: pass
            # Recalcular saldo del cliente al anular
            cli_a = f.get("cliente_id") if f else None
            if cli_a:
                tot_f = c.execute("SELECT COALESCE(SUM(total),0) FROM facturas WHERE cliente_id=? AND empresa_id=? AND estado NOT IN ('ANULADA')", (cli_a,eid)).fetchone()[0]
                tot_p = c.execute("SELECT COALESCE(SUM(CASE WHEN tipo='PAGO' THEN monto ELSE 0 END),0) FROM cuentas_cobrar WHERE cliente_id=? AND empresa_id=?", (cli_a,eid)).fetchone()[0]
                ns = float(tot_f) - float(tot_p)
                ul = rd(c.execute("SELECT id FROM cuentas_cobrar WHERE cliente_id=? AND empresa_id=? ORDER BY id DESC LIMIT 1", (cli_a,eid)).fetchone())
                if ul: c.execute("UPDATE cuentas_cobrar SET saldo=? WHERE id=?", (ns, ul["id"]))
            c.commit(); c.close(); return self._j({"ok":True})

        elif p == "/api/marcar_pagada":
            fid_p = body.get("id"); c = db()
            fac_p = rd(c.execute("SELECT * FROM facturas WHERE id=? AND empresa_id=?",(fid_p,eid)).fetchone())
            if fac_p:
                c.execute("UPDATE facturas SET estado='PAGADA' WHERE id=? AND empresa_id=?", (fid_p,eid))
                cid_cl = fac_p.get("cliente_id")
                if cid_cl:
                    last_p = rd(c.execute("SELECT saldo FROM cuentas_cobrar WHERE empresa_id=? AND cliente_id=? ORDER BY id DESC LIMIT 1",(eid,cid_cl)).fetchone())
                    saldo_a = float(last_p["saldo"]) if last_p else 0
                    nuevo_p = saldo_a - float(fac_p["total"])
                    c.execute("""INSERT INTO cuentas_cobrar
                        (empresa_id,cliente_id,factura_id,tipo,concepto,monto,saldo,fecha,usuario_id,estado,referencia,created_at)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                        [eid,cid_cl,fid_p,"PAGO",f"Pago factura {fac_p['numero']}",
                         -float(fac_p["total"]),nuevo_p,today_ec(),sess["usuario_id"],"PAGADO",fac_p["numero"],now_ec()])
            c.commit(); c.close(); return self._j({"ok":True})

        elif p == "/api/eliminar_factura":
            fid = body.get("id"); c = db()
            f = rd(c.execute("SELECT estado,estado_sri,clave_acceso FROM facturas WHERE id=? AND empresa_id=?", (fid,eid)).fetchone())
            if not f: c.close(); return self._j({"ok":False,"error":"No encontrada"})
            if f["estado"] == "AUTORIZADA" or f["estado_sri"] == "AUTORIZADA":
                c.close(); return self._j({"ok":False,"error":"No se puede eliminar una factura AUTORIZADA por el SRI"})
            c.execute("DELETE FROM factura_items WHERE factura_id=?", (fid,))
            c.execute("DELETE FROM sri_log WHERE factura_id=?", (fid,))
            c.execute("DELETE FROM facturas WHERE id=? AND empresa_id=?", (fid,eid))
            c.commit(); c.close()
            if f.get("clave_acceso"):
                cd = BASE_DIR / "comprobantes" / _dir_emp(eid)
                for sub in ["generados","firmados","rechazados","anulados"]:
                    xf = cd / sub / f"{f['clave_acceso']}.xml"
                    try:
                        if xf.exists(): xf.unlink()
                    except: pass
            return self._j({"ok":True})

        elif p == "/api/enviar_correo":
            # Enviar correo universal: factura, NC, guía o liquidación
            tipo      = body.get("tipo","factura")     # factura|nc|guia|liquidacion
            doc_id    = body.get("factura_id") or body.get("id")
            correo    = (body.get("correo","") or "").strip()
            c = db()
            emp2 = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())

            if tipo == "nc":
                doc = rd(c.execute("""SELECT nc.*, cl.email as cli_email, cl.nombre as cli_nombre
                    FROM notas_credito nc LEFT JOIN clientes cl ON nc.cliente_id=cl.id
                    WHERE nc.id=? AND nc.empresa_id=?""",(doc_id,eid)).fetchone())
                c.close()
                if not doc: return self._j({"ok":False,"error":"NC no encontrada"})
                dest = correo or doc.get("cli_email","") or ""
                if not dest: return self._j({"ok":False,"error":"No hay correo del destinatario"})
                return self._j(enviar_correo_nc(doc, emp2, dest))

            elif tipo == "guia":
                doc = rd(c.execute("""SELECT gr.*, cl.email as cli_email, cl.nombre as cli_nombre
                    FROM guias_remision gr LEFT JOIN clientes cl ON gr.cliente_id=cl.id
                    WHERE gr.id=? AND gr.empresa_id=?""",(doc_id,eid)).fetchone())
                c.close()
                if not doc: return self._j({"ok":False,"error":"Guía no encontrada"})
                dest = correo or doc.get("cli_email","") or ""
                if not dest: return self._j({"ok":False,"error":"No hay correo del destinatario"})
                return self._j(enviar_correo_guia(doc, emp2, dest))

            elif tipo == "liquidacion":
                doc = rd(c.execute("SELECT * FROM liquidaciones_compra WHERE id=? AND empresa_id=?",
                                   (doc_id,eid)).fetchone())
                c.close()
                if not doc: return self._j({"ok":False,"error":"Liquidación no encontrada"})
                dest = correo or doc.get("proveedor_email","") or ""
                if not dest: return self._j({"ok":False,"error":"No hay correo del proveedor"})
                return self._j(enviar_correo_liquidacion(doc, emp2, dest))

            else:  # factura (por defecto)
                f = rd(c.execute("""SELECT f.*, cl.email as cli_email, cl.nombre as cli_nombre
                    FROM facturas f LEFT JOIN clientes cl ON f.cliente_id=cl.id
                    WHERE f.id=? AND f.empresa_id=?""",(doc_id,eid)).fetchone())
                c.close()
                if not f: return self._j({"ok":False,"error":"Factura no encontrada"})
                dest = correo or f.get("cli_email","") or ""
                if not dest: return self._j({"ok":False,"error":"No hay correo del cliente. Agrégalo en el perfil del cliente."})
                return self._j(enviar_correo(f, emp2, dest))

        elif p == "/api/usuario_empresas":
            if not is_admin: return self._j({"ok":False,"error":"Solo el administrador puede asignar compañías"},403)
            uid_a = body.get("usuario_id"); lista = body.get("empresas") or []
            if not uid_a: return self._j({"ok":False,"error":"usuario_id requerido"})
            try: lista = [int(x) for x in lista]
            except Exception: return self._j({"ok":False,"error":"Lista de empresas inválida"})
            if not lista:
                return self._j({"ok":False,"error":"El usuario debe quedar asignado al menos a una compañía"})
            c = db()
            u = rd(c.execute("SELECT id, rol, username FROM usuarios WHERE id=?", (uid_a,)).fetchone())
            if not u: c.close(); return self._j({"ok":False,"error":"Usuario no encontrado"})
            # Protección: el admin no puede quitarse a sí mismo la empresa actual
            if int(uid_a) == int(sess["usuario_id"]) and int(eid) not in lista:
                c.close(); return self._j({"ok":False,"error":"No puedes quitarte a ti mismo la compañía en la que estás trabajando"})
            rol_u = u.get("rol") or "cajero"
            actuales = {r["empresa_id"]: r["rol"] for r in rl(c.execute(
                "SELECT empresa_id, rol FROM usuario_empresa WHERE usuario_id=?", (uid_a,)).fetchall())}
            # Quitar las que ya no están
            for emp_id in list(actuales.keys()):
                if emp_id not in lista:
                    c.execute("DELETE FROM usuario_empresa WHERE usuario_id=? AND empresa_id=?", (uid_a, emp_id))
            # Agregar las nuevas (conservando el rol si ya existía)
            for emp_id in lista:
                c.execute("INSERT OR REPLACE INTO usuario_empresa (usuario_id,empresa_id,rol) VALUES (?,?,?)",
                          (uid_a, emp_id, actuales.get(emp_id, rol_u)))
            c.commit()
            n = c.execute("SELECT COUNT(*) FROM usuario_empresa WHERE usuario_id=?", (uid_a,)).fetchone()[0]
            c.close()
            return self._j({"ok":True,"asignadas":n,"mensaje":f"El usuario quedó asignado a {n} compañía(s)"})

        elif p == "/api/upload_cert":
            if not is_admin: return self._j({"ok":False,"error":"Sin permiso"},403)
            b64 = body.get("cert_b64",""); fname = body.get("filename","cert.p12")
            if not b64: return self._j({"ok":False,"error":"Sin datos"})
            cd = BASE_DIR / "certificados" / _dir_emp(eid); cd.mkdir(parents=True, exist_ok=True)
            cp = cd / fname; cp.write_bytes(base64.b64decode(b64))
            c = db(); c.execute("UPDATE empresas SET cert_path=? WHERE id=?", (str(cp),eid)); c.commit(); c.close()
            return self._j({"ok":True,"path":str(cp)})

        elif p == "/api/usuarios":
            if not is_admin: return self._j({"ok":False,"error":"Sin permiso"},403)
            c = db()
            mods = (body.get("modulos") or "").strip()
            if body.get("id"):
                _pto = re.sub(r"\D", "", str(body.get("secuencial") or ""))[:3]
                try:
                    c.execute("UPDATE usuarios SET sucursal_id=? WHERE id=?",
                              (int(body.get("sucursal_id") or 0), body["id"]))
                except Exception:
                    pass
                c.execute("UPDATE usuarios SET nombre=?,email=?,rol=?,modulos=?,secuencial=? WHERE id=?",
                    [body.get("nombre",""),body.get("email",""),body.get("rol","cajero"),mods,
                     (_pto.zfill(3) if _pto else ""),body["id"]])
                c.execute("INSERT OR REPLACE INTO usuario_empresa (usuario_id,empresa_id,rol) VALUES (?,?,?)",
                    (body["id"],eid,body.get("rol","cajero")))
            else:
                usern = (body.get("username","") or "").strip().lower()
                if not usern: c.close(); return self._j({"ok":False,"error":"El nombre de usuario (login) es requerido"})
                if not body.get("password"): c.close(); return self._j({"ok":False,"error":"Contraseña requerida"})
                # ── Usuario ya existe: mensaje claro y opción de vincularlo a esta empresa ──
                ex = rd(c.execute("SELECT id, nombre FROM usuarios WHERE LOWER(username)=?", (usern,)).fetchone())
                if ex:
                    ya = c.execute("SELECT 1 FROM usuario_empresa WHERE usuario_id=? AND empresa_id=?", (ex["id"], eid)).fetchone()
                    if ya:
                        c.close(); return self._j({"ok":False,"error":"El usuario '"+usern+"' ya existe en esta empresa. Usa otro nombre de usuario o edítalo desde la lista."})
                    if body.get("vincular"):
                        c.execute("INSERT OR REPLACE INTO usuario_empresa (usuario_id,empresa_id,rol) VALUES (?,?,?)", (ex["id"], eid, body.get("rol","cajero")))
                        if mods: c.execute("UPDATE usuarios SET modulos=? WHERE id=?", (mods, ex["id"]))
                        c.commit(); c.close()
                        return self._j({"ok":True,"vinculado":True,"mensaje":"El usuario ya existía ("+str(ex.get("nombre") or usern)+") y se agregó a esta empresa."})
                    c.close()
                    return self._j({"ok":False,"existe":True,
                                    "error":"El usuario '"+usern+"' ya existe en el sistema (pertenece a otra empresa). ¿Deseas agregarlo también a esta empresa?"})
                ph = hashlib.sha256(body["password"].encode()).hexdigest()
                try:
                    _pto = re.sub(r"\D", "", str(body.get("secuencial") or ""))[:3]
                    _suc_nuevo = int(body.get("sucursal_id") or 0)
                    c.execute("INSERT INTO usuarios (username,password_hash,nombre,email,rol,modulos,secuencial,created_at,sucursal_id) VALUES (?,?,?,?,?,?,?,?,?)",
                        [usern,ph,body.get("nombre",""),body.get("email",""),body.get("rol","cajero"),mods,
                         (_pto.zfill(3) if _pto else ""),now_ec(),_suc_nuevo])
                    uid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                    c.execute("INSERT INTO usuario_empresa (usuario_id,empresa_id,rol) VALUES (?,?,?)", (uid,eid,body.get("rol","cajero")))
                except Exception as ex2:
                    c.close()
                    msg = str(ex2)
                    if "UNIQUE" in msg and "username" in msg:
                        msg = "El nombre de usuario ya existe. Elige otro."
                    return self._j({"ok":False,"error":msg})
            uid_out = body.get("id") or locals().get("uid")
            c.commit(); c.close(); return self._j({"ok":True,"id":uid_out})

        elif p == "/api/eliminar_usuario":
            if sess["rol"] != "admin": return self._j({"ok":False,"error":"Solo admin"},403)
            uid = body.get("id"); c = db()
            c.execute("DELETE FROM usuario_empresa WHERE usuario_id=? AND empresa_id=?", (uid,eid))
            c.execute("UPDATE usuarios SET activo=0 WHERE id=?", (uid,))
            c.commit(); c.close(); return self._j({"ok":True})

        elif p == "/api/cambiar_password":
            uid = sess["usuario_id"]; old_pwd = body.get("old_password","")
            c = db(); u = rd(c.execute("SELECT id,password_hash FROM usuarios WHERE id=?", (uid,)).fetchone())
            if not u or not verify_password(old_pwd, u.get("password_hash","")):
                c.close(); return self._j({"ok":False,"error":"Contraseña actual incorrecta"})
            c.execute("UPDATE usuarios SET password_hash=? WHERE id=?",
                (hash_password(body.get("new_password","")), uid))
            c.commit(); c.close(); return self._j({"ok":True})

        elif p == "/api/empresas_admin":
            if sess["rol"] != "admin": return self._j({"ok":False,"error":"Solo admin"},403)
            c = db()
            if body.get("id"):
                # Se actualiza SOLO lo que vino en la petición. El botón
                # "Desactivar" manda únicamente el estado: antes esto dejaba
                # el nombre y el RUC de la empresa en blanco.
                _campos, _vals = [], []
                for _k in ("nombre", "ruc", "ciudad"):
                    if _k in body and str(body.get(_k) or "").strip() != "":
                        _campos.append(_k + "=?"); _vals.append(body.get(_k))
                if "activa" in body:
                    _campos.append("activa=?"); _vals.append(int(body.get("activa", 1)))
                if _campos:
                    c.execute("UPDATE empresas SET " + ",".join(_campos) + " WHERE id=?",
                              _vals + [body["id"]])
                # Se cierra la escritura antes de tocar carpetas: si no, el
                # renombrado abre otra conexión y salta "database is locked".
                c.commit()
                _solo_estado = not any(k in body and str(body.get(k) or "").strip() != ""
                                       for k in ("nombre", "ruc", "ciudad"))
                # Si cambió el nombre: renombrar la carpeta al nuevo nombre
                try:
                    if _solo_estado:
                        raise StopIteration
                    eid_u = int(body["id"])
                    row_c = c.execute("SELECT IFNULL(carpeta,'') FROM empresas WHERE id=?", (eid_u,)).fetchone()
                    vieja = (row_c[0] or "").strip() or f"empresa_{eid_u}"
                    base_n = _sanitizar_carpeta(body.get("nombre")) or f"EMPRESA_{eid_u}"
                    if base_n != vieja:
                        otras = {r[0] for r in c.execute("SELECT IFNULL(carpeta,'') FROM empresas WHERE id!=?", (eid_u,)).fetchall()}
                        nueva = base_n if base_n not in otras else f"{base_n}_{eid_u}"
                        _renombrar_dirs_empresa(vieja, nueva)
                        _actualizar_rutas_empresa(c, eid_u, vieja, nueva)
                        c.execute("UPDATE empresas SET carpeta=? WHERE id=?", (nueva, eid_u))
                        _CARP_CACHE.pop(eid_u, None)
                except StopIteration:
                    pass
                except Exception as ex:
                    log.warning("Renombrar carpeta empresa %s: %s", body.get("id"), ex)
            else:
                c.execute("INSERT INTO empresas (nombre,ruc,ciudad,activa,created_at) VALUES (?,?,?,1,?)",
                    [body.get("nombre"),body.get("ruc"),body.get("ciudad",""),now_ec()])
                new_eid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                # Carpeta con el nombre real de la empresa
                try:
                    base_n = _sanitizar_carpeta(body.get("nombre")) or f"EMPRESA_{new_eid}"
                    otras = {r[0] for r in c.execute("SELECT IFNULL(carpeta,'') FROM empresas WHERE id!=?", (new_eid,)).fetchall()}
                    carp = base_n if base_n not in otras else f"{base_n}_{new_eid}"
                    c.execute("UPDATE empresas SET carpeta=? WHERE id=?", (carp, new_eid))
                    c.commit()
                    _CARP_CACHE.pop(int(new_eid), None)
                except Exception:
                    pass
                _mkdirs(new_eid)
                c.execute("INSERT OR IGNORE INTO usuario_empresa (usuario_id,empresa_id,rol) VALUES (?,?,'admin')",
                    (sess["usuario_id"],new_eid))
            c.commit(); c.close(); return self._j({"ok":True})

        elif p == "/api/logout":
            token = self.headers.get("Authorization","").replace("Bearer ","").strip()
            sesion_eliminar(token)
            return self._j({"ok":True})

        elif p == "/api/cerrar_sesion_remota":
            # Admin puede cerrar la sesión de otra máquina
            if not is_admin: return self._j({"ok":False,"error":"Solo admin"},403)
            token_preview = body.get("token_preview","")
            cerradas = 0
            for token, s in list(SESSIONS.items()):
                if (s.get("empresa_id") == eid and
                        token.startswith(token_preview.replace("...",""))):
                    sesion_eliminar(token)
                    cerradas += 1
                    break
            return self._j({"ok":True,"cerradas":cerradas})

        elif p == "/api/cambiar_limite_conexiones":
            # Solo admin puede cambiar el límite (se almacena en config de empresa)
            if sess["rol"] != "admin": return self._j({"ok":False,"error":"Solo admin"},403)
            global MAX_CONEXIONES_POR_EMPRESA
            nuevo_limite = int(body.get("limite", MAX_CONEXIONES_POR_EMPRESA))
            if 1 <= nuevo_limite <= 20:
                MAX_CONEXIONES_POR_EMPRESA = nuevo_limite
                return self._j({"ok":True,"limite":MAX_CONEXIONES_POR_EMPRESA})
            return self._j({"ok":False,"error":"Límite debe ser entre 1 y 20"})

        # ════════════════════════════════════════════════════
        # NOTAS DE CRÉDITO
        # ════════════════════════════════════════════════════
        elif p == "/api/notas_credito":
            items = body.get("items",[])
            c = db(); emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
            # Una anulación debe llevar los valores reales de la factura.
            # Antes se guardaba un renglón "Anulación completa" en CERO y la
            # nota no anulaba nada ante el SRI ni en el libro de ventas.
            if str(body.get("tipo","")).upper() == "ANULACION" and body.get("factura_ref_id"):
                _suma = sum(float(i.get("subtotal",0) or 0) for i in items)
                if not items or _suma <= 0:
                    _reales = _nc_items_de_factura(c, eid, body.get("factura_ref_id"))
                    if _reales:
                        items = _reales
            sub  = sum(float(i.get("subtotal",0)) for i in items)
            ivap = float(emp["iva_porcentaje"] or 15)
            iva  = sub * ivap / 100; total = sub + iva
            sec  = emp["secuencial_actual"] or 1
            sec_nc = int(emp.get("sec_inicio_nc") or 0)
            if sec_nc > 0 and sec_nc >= sec: sec = sec_nc
            _est_u, _pto_u = _pto_emision_usuario(c, emp, sess)
            num  = f"{_est_u}-{_pto_u}-NC{str(sec).zfill(9)}"
            c.execute("UPDATE empresas SET secuencial_actual=? WHERE id=?", (sec+1,eid))
            c.execute("""INSERT INTO notas_credito
                (empresa_id,numero,factura_ref_id,factura_ref_numero,cliente_id,usuario_id,
                 fecha,tipo,motivo,subtotal,iva,total,estado,notas,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                [eid, num, body.get("factura_ref_id"), body.get("factura_ref_numero",""),
                 body.get("cliente_id"), sess["usuario_id"],
                 body.get("fecha") or today_ec(), body.get("tipo","DESCUENTO"),
                 body.get("motivo",""), sub, iva, total, "PENDIENTE",
                 body.get("notas",""), now_ec()])
            nid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            _nc_tipo = str(body.get("tipo","DESCUENTO")).upper()
            _bp_nc = _bodega_principal(c, eid)
            for it in items:
                c.execute("INSERT INTO nota_credito_items (nota_id,codigo,descripcion,cantidad,precio_unitario,descuento,subtotal) VALUES (?,?,?,?,?,?,?)",
                    [nid,it.get("codigo",""),it.get("descripcion",""),float(it.get("cantidad",1)),
                     float(it.get("precio_unitario",0)),float(it.get("descuento",0)),float(it.get("subtotal",0))])
                # ── Devolución: sumar stock al producto (no aplica a servicios) ──
                pid_it = it.get("producto_id")
                if pid_it and _nc_tipo in ("DEVOLUCION","DEVOLUCIÓN"):
                    prod = rd(c.execute("SELECT stock,tipo FROM productos WHERE id=? AND empresa_id=?",(pid_it,eid)).fetchone())
                    if prod and str(prod.get("tipo","PRODUCTO")).upper() != "SERVICIO":
                        cant_it = float(it.get("cantidad",1))
                        st_ant = float(prod["stock"]); st_new = st_ant + cant_it
                        c.execute("UPDATE productos SET stock=? WHERE id=?", (st_new, pid_it))
                        _stock_bodega_mov(c, eid, pid_it, _bp_nc, cant_it)
                        c.execute("""INSERT INTO stock_movimientos
                            (empresa_id,producto_id,tipo,cantidad,stock_antes,stock_despues,referencia_id,referencia_tipo,notas,fecha,usuario_id,bodega_id)
                            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                            [eid,pid_it,"DEVOLUCION",cant_it,st_ant,st_new,nid,"NOTA_CREDITO","NC "+num,(body.get("fecha") or today_ec()),sess["usuario_id"],_bp_nc])
            # ── Asiento contable automático (nota de crédito / devolución en ventas) ──
            cfgc = _cfg_contable(c, eid)
            generar_asiento_auto(c, eid, sess["usuario_id"], (body.get("fecha") or today_ec()),
                "Nota de crédito " + num, "NOTA_CREDITO", nid,
                [(cfgc["cta_dev_ventas"], sub, 0),
                 (cfgc["cta_iva_ventas"], iva, 0),
                 (cfgc["cta_cxc"], 0, total)])

            c.commit(); c.close()
            return self._j({"ok":True,"id":nid,"numero":num})

        elif p == "/api/procesar_nota_credito":
            nid = body.get("nota_id")
            if not nid: return self._j({"ok":False,"error":"nota_id requerido"},400)
            return self._j(_procesar_nc(int(nid), eid))

        elif p == "/api/anular_nota_credito":
            nid = body.get("id")
            c = db(); c.execute("UPDATE notas_credito SET estado='ANULADA',estado_sri='ANULADA' WHERE id=? AND empresa_id=?",(nid,eid))
            revertir_asiento_auto(c, eid, "NOTA_CREDITO", nid)
            c.commit(); c.close(); return self._j({"ok":True})

        elif p == "/api/eliminar_nota_credito":
            # Eliminar definitivamente una NC y REVERTIR su efecto en CxC
            nid = body.get("id")
            if not nid: return self._j({"ok":False,"error":"id requerido"},400)
            c = db()
            nc = rd(c.execute("SELECT * FROM notas_credito WHERE id=? AND empresa_id=?",(nid,eid)).fetchone())
            if not nc:
                c.close(); return self._j({"ok":False,"error":"Nota de crédito no encontrada"},404)
            # Bloquear eliminación si está autorizada en el SRI
            if nc.get("estado_sri") == "AUTORIZADA" and nc.get("autorizacion"):
                c.close()
                return self._j({
                    "ok": False,
                    "error": ("No se puede eliminar una nota de crédito ya autorizada por el SRI. "
                              "Si necesitas anularla, usa el proceso de anulación.")
                },400)
            # ── Revertir registros en Cuentas por Cobrar ──────
            # Buscar todos los movimientos CxC que referencian esta NC
            cxc_movs = rl(c.execute(
                "SELECT * FROM cuentas_cobrar WHERE nota_credito_id=? AND empresa_id=?",
                (nid, eid)
            ).fetchall())
            # Eliminar esos movimientos de CxC
            c.execute("DELETE FROM cuentas_cobrar WHERE nota_credito_id=? AND empresa_id=?",
                      (nid, eid))
            # Recalcular saldos del cliente si había movimientos
            if cxc_movs and nc.get("cliente_id"):
                cid_cl = nc["cliente_id"]
                # Reconstruir el saldo acumulado desde el primer movimiento del cliente
                todos = rl(c.execute(
                    """SELECT * FROM cuentas_cobrar WHERE empresa_id=? AND cliente_id=?
                       ORDER BY id""", (eid, cid_cl)
                ).fetchall())
                saldo_acum = 0.0
                for mov in todos:
                    saldo_acum = round(saldo_acum + float(mov["monto"]), 2)
                    c.execute("UPDATE cuentas_cobrar SET saldo=? WHERE id=?",
                              (saldo_acum, mov["id"]))
            # Eliminar ítems y la NC
            c.execute("DELETE FROM nota_credito_items WHERE nota_id=?", (nid,))
            c.execute("DELETE FROM notas_credito WHERE id=? AND empresa_id=?", (nid, eid))
            c.commit(); c.close()
            log.info("NC %d eliminada y CxC revertida — %d movimientos eliminados",
                     nid, len(cxc_movs))
            return self._j({
                "ok": True,
                "mensaje": "Nota de crédito eliminada y saldo de CxC actualizado correctamente",
                "movimientos_revertidos": len(cxc_movs)
            })

        elif p == "/api/limpiar_cxc_huerfanos":
            # Eliminar registros CxC de NCs que ya no existen en la base de datos
            # Útil para corregir el saldo después de eliminaciones previas
            if not is_admin:
                return self._j({"ok":False,"error":"Solo admin puede ejecutar esta operación"},403)
            c = db()
            # Encontrar movimientos CxC con nota_credito_id que ya no existe
            huerfanos = rl(c.execute("""
                SELECT cc.* FROM cuentas_cobrar cc
                WHERE cc.empresa_id = ?
                  AND cc.nota_credito_id IS NOT NULL
                  AND cc.nota_credito_id > 0
                  AND NOT EXISTS (
                      SELECT 1 FROM notas_credito nc
                      WHERE nc.id = cc.nota_credito_id
                  )
            """, (eid,)).fetchall())

            if not huerfanos:
                c.close()
                return self._j({"ok":True,"mensaje":"No hay registros huérfanos en CxC","eliminados":0})

            # Agrupar por cliente para recalcular saldos
            clientes_afectados = list(set(h["cliente_id"] for h in huerfanos))

            # Eliminar los huérfanos
            for h in huerfanos:
                c.execute("DELETE FROM cuentas_cobrar WHERE id=?", (h["id"],))

            # Recalcular saldo acumulado para cada cliente afectado
            for cid_cl in clientes_afectados:
                todos = rl(c.execute(
                    """SELECT * FROM cuentas_cobrar WHERE empresa_id=? AND cliente_id=?
                       ORDER BY id""", (eid, cid_cl)
                ).fetchall())
                saldo_acum = 0.0
                for mov in todos:
                    saldo_acum = round(saldo_acum + float(mov["monto"]), 2)
                    c.execute("UPDATE cuentas_cobrar SET saldo=? WHERE id=?",
                              (saldo_acum, mov["id"]))

            c.commit(); c.close()
            log.info("CxC huérfanos eliminados: %d registros, %d clientes afectados",
                     len(huerfanos), len(clientes_afectados))
            return self._j({
                "ok": True,
                "mensaje": f"Se eliminaron {len(huerfanos)} registros huérfanos y se recalcularon los saldos de {len(clientes_afectados)} cliente(s).",
                "eliminados": len(huerfanos),
                "clientes_recalculados": len(clientes_afectados)
            })

        # ════════════════════════════════════════════════════
        # GUÍAS DE REMISIÓN
        # ════════════════════════════════════════════════════
        elif p == "/api/guias":
            items = body.get("items",[])
            c = db(); emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
            sec = emp["secuencial_actual"] or 1
            sec_gr = int(emp.get("sec_inicio_gr") or 0)
            if sec_gr > 0 and sec_gr >= sec: sec = sec_gr
            _est_u, _pto_u = _pto_emision_usuario(c, emp, sess)
            num = f"{_est_u}-{_pto_u}-GR{str(sec).zfill(9)}"
            c.execute("UPDATE empresas SET secuencial_actual=? WHERE id=?", (sec+1,eid))
            c.execute("""INSERT INTO guias_remision
                (empresa_id,numero,cliente_id,usuario_id,fecha_inicio,fecha_fin,
                 motivo_traslado,ruta,dir_partida,dir_destino,
                 transportista_ruc,transportista_nombre,placa,factura_ref_numero,
                 estado,notas,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                [eid,num,body.get("cliente_id"),sess["usuario_id"],
                 body.get("fecha_inicio") or today_ec(), body.get("fecha_fin",""),
                 body.get("motivo_traslado","VENTA"), body.get("ruta",""),
                 body.get("dir_partida",""), body.get("dir_destino",""),
                 body.get("transportista_ruc",""), body.get("transportista_nombre",""),
                 body.get("placa",""), body.get("factura_ref_numero",""),
                 "PENDIENTE", body.get("notas",""), now_ec()])
            gid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            for it in items:
                c.execute("INSERT INTO guia_items (guia_id,codigo,descripcion,cantidad) VALUES (?,?,?,?)",
                    [gid,it.get("codigo",""),it.get("descripcion",""),float(it.get("cantidad",1))])
            c.commit(); c.close()
            return self._j({"ok":True,"id":gid,"numero":num})

        elif p == "/api/procesar_guia":
            gid = body.get("guia_id")
            if not gid: return self._j({"ok":False,"error":"guia_id requerido"},400)
            return self._j(_procesar_guia(int(gid), eid))

        elif p == "/api/anular_guia":
            gid=body.get("id"); c=db()
            c.execute("UPDATE guias_remision SET estado='ANULADA' WHERE id=? AND empresa_id=?",(gid,eid))
            c.commit(); c.close(); return self._j({"ok":True})

        elif p == "/api/eliminar_guia":
            # Eliminar definitivamente una guía (solo si NO está autorizada)
            gid = body.get("id")
            if not gid: return self._j({"ok":False,"error":"id requerido"},400)
            c = db()
            g = rd(c.execute("SELECT * FROM guias_remision WHERE id=? AND empresa_id=?",(gid,eid)).fetchone())
            if not g:
                c.close(); return self._j({"ok":False,"error":"Guía no encontrada"},404)
            # Bloquear eliminación si está autorizada en el SRI
            if g.get("estado_sri") == "AUTORIZADA" and g.get("autorizacion"):
                c.close()
                return self._j({
                    "ok": False,
                    "error": ("No se puede eliminar una guía ya autorizada por el SRI. "
                              "Si necesitas anularla, usa el proceso de anulación.")
                },400)
            # Eliminar ítems y la guía
            c.execute("DELETE FROM guia_items WHERE guia_id=?", (gid,))
            c.execute("DELETE FROM guias_remision WHERE id=? AND empresa_id=?", (gid,eid))
            c.commit(); c.close()
            log.info("Guía %d eliminada por usuario %s", gid, sess.get("nombre","?"))
            return self._j({"ok":True,"mensaje":"Guía de remisión eliminada correctamente"})

        # ════════════════════════════════════════════════════
        # CUENTAS POR COBRAR
        # ════════════════════════════════════════════════════
        elif p == "/api/registrar_pago":
            cid_cl  = body.get("cliente_id")
            monto   = float(body.get("monto",0))
            ref     = body.get("referencia","")
            fid_ref = body.get("factura_id")
            nc_id   = body.get("nota_credito_id")
            tipo    = body.get("tipo","PAGO")  # PAGO | ABONO | PAGO_NC
            if not cid_cl or monto <= 0: return self._j({"ok":False,"error":"cliente_id y monto requeridos"})
            c = db()
            # Saldo actual del cliente
            last = rd(c.execute("SELECT saldo FROM cuentas_cobrar WHERE empresa_id=? AND cliente_id=? ORDER BY id DESC LIMIT 1",(eid,cid_cl)).fetchone())
            saldo_ant = last["saldo"] if last else 0
            nuevo_saldo = saldo_ant - monto   # el pago reduce la deuda
            c.execute("""INSERT INTO cuentas_cobrar
                (empresa_id,cliente_id,factura_id,nota_credito_id,tipo,concepto,monto,saldo,fecha,usuario_id,estado,referencia,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                [eid,cid_cl,fid_ref,nc_id,tipo,
                 body.get("concepto",f"Pago — {ref}"),
                 -monto, nuevo_saldo,
                 body.get("fecha") or today_ec(), sess["usuario_id"],
                 "PAGADO", ref, now_ec()])
            # Si viene una factura asociada, actualizarla
            if fid_ref:
                fac = rd(c.execute("SELECT total FROM facturas WHERE id=? AND empresa_id=?",(fid_ref,eid)).fetchone())
                if fac:
                    c.execute("UPDATE facturas SET estado='PAGADA' WHERE id=? AND empresa_id=?",(fid_ref,eid))
            # ── Asiento contable automático (cobro a cliente) ──
            _pago_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            cfgc = _cfg_contable(c, eid)
            _fecha_p = body.get("fecha") or today_ec()
            generar_asiento_auto(c, eid, sess["usuario_id"], _fecha_p,
                "Cobro cliente — " + (ref or "abono"), "COBRO", _pago_id,
                [(cfgc["cta_caja"], monto, 0),
                 (cfgc["cta_cxc"], 0, monto)])
            c.commit(); c.close()
            return self._j({"ok":True,"nuevo_saldo":nuevo_saldo})

        # ════════════════════════════════════════════════════
        # STOCK — descuento automático al crear factura (interno)
        # ════════════════════════════════════════════════════
        elif p == "/api/ajuste_stock":
            if not is_admin: return self._j({"ok":False,"error":"Sin permiso"},403)
            pid = body.get("producto_id"); cant = float(body.get("cantidad",0))
            tipo = body.get("tipo","AJUSTE"); notas = body.get("notas","")
            c = db()
            prod = rd(c.execute("SELECT stock FROM productos WHERE id=? AND empresa_id=?",(pid,eid)).fetchone())
            if not prod: c.close(); return self._j({"ok":False,"error":"Producto no encontrado"})
            ant = prod["stock"]; nuevo = ant + cant
            c.execute("UPDATE productos SET stock=? WHERE id=?",(max(0,nuevo),pid))
            c.execute("INSERT INTO stock_movimientos (empresa_id,producto_id,tipo,cantidad,stock_antes,stock_despues,notas,fecha,usuario_id) VALUES (?,?,?,?,?,?,?,?,?)",
                [eid,pid,tipo,cant,ant,max(0,nuevo),notas,today_ec(),sess["usuario_id"]])
            c.commit(); c.close()
            return self._j({"ok":True,"stock_nuevo":max(0,nuevo)})

        # ════════════════════════════════════════════════════
        # CAJA
        # ════════════════════════════════════════════════════
        elif p == "/api/caja_abrir":
            # Abrir o recuperar sesión de caja del día
            fecha  = body.get("fecha") or today_ec()
            saldo_i = float(body.get("saldo_inicial",0))
            c = db()
            ses = rd(c.execute("SELECT * FROM caja_sesiones WHERE empresa_id=? AND fecha=?",(eid,fecha)).fetchone())
            if ses:
                # Ya existe, devolver la existente
                c.close(); return self._j({"ok":True,"sesion":ses,"nueva":False})
            # Crear nueva sesión
            c.execute("""INSERT INTO caja_sesiones
                (empresa_id,usuario_id,fecha,estado,saldo_inicial,created_at)
                VALUES (?,?,?,?,?,?)""",
                [eid,sess["usuario_id"],fecha,"ABIERTA",saldo_i,now_ec()])
            sid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            # Importar facturas del día automáticamente como ingresos
            facts = rl(c.execute("""SELECT * FROM facturas WHERE empresa_id=? AND fecha=?
                AND estado NOT IN ('ANULADA') ORDER BY id""",(eid,fecha)).fetchall())
            total_facts = 0
            for f in facts:
                total_facts += float(f["total"])
                c.execute("""INSERT INTO caja_movimientos
                    (empresa_id,sesion_id,factura_id,tipo,categoria,concepto,monto,
                     metodo_pago,comprobante,fecha,hora,usuario_id,created_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    [eid,sid,f["id"],"INGRESO_FACTURA","Ventas",
                     f"Factura {f['numero']}",float(f["total"]),
                     "EFECTIVO",f["numero"],fecha,now_ec().split()[1],
                     sess["usuario_id"],now_ec()])
            c.execute("UPDATE caja_sesiones SET total_facturas=?,total_ingresos=? WHERE id=?",
                      (total_facts,total_facts,sid))
            c.commit()
            ses = rd(c.execute("SELECT * FROM caja_sesiones WHERE id=?",(sid,)).fetchone())
            c.close()
            return self._j({"ok":True,"sesion":ses,"nueva":True,"facturas_importadas":len(facts)})

        elif p == "/api/caja_movimiento":
            # Agregar ingreso o egreso a la sesión de caja
            fecha  = body.get("fecha") or today_ec()
            c = db()
            ses = rd(c.execute("SELECT * FROM caja_sesiones WHERE empresa_id=? AND fecha=?",(eid,fecha)).fetchone())
            if not ses: c.close(); return self._j({"ok":False,"error":"No hay sesión de caja abierta para esta fecha. Ábrela primero."})
            if ses["estado"] == "CERRADA": c.close(); return self._j({"ok":False,"error":"La caja de este día ya está cerrada."})
            tipo  = body.get("tipo","EGRESO")  # INGRESO_OTRO | EGRESO
            monto = float(body.get("monto",0))
            if monto <= 0: c.close(); return self._j({"ok":False,"error":"El monto debe ser mayor a 0"})
            c.execute("""INSERT INTO caja_movimientos
                (empresa_id,sesion_id,tipo,categoria,concepto,monto,metodo_pago,
                 comprobante,fecha,hora,usuario_id,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                [eid,ses["id"],tipo,body.get("categoria","Otro"),
                 body.get("concepto",""),monto,
                 body.get("metodo_pago","EFECTIVO"),body.get("comprobante",""),
                 fecha,now_ec().split()[1],sess["usuario_id"],now_ec()])
            # Actualizar totales en sesión
            if tipo == "EGRESO":
                c.execute("UPDATE caja_sesiones SET total_egresos=total_egresos+? WHERE id=?", (monto,ses["id"]))
            else:
                c.execute("UPDATE caja_sesiones SET total_ingresos=total_ingresos+? WHERE id=?", (monto,ses["id"]))
            c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/caja_eliminar_movimiento":
            mid = body.get("id"); c = db()
            mov = rd(c.execute("SELECT * FROM caja_movimientos WHERE id=? AND empresa_id=?",(mid,eid)).fetchone())
            if not mov: c.close(); return self._j({"ok":False,"error":"Movimiento no encontrado"})
            ses = rd(c.execute("SELECT estado FROM caja_sesiones WHERE id=?",(mov["sesion_id"],)).fetchone())
            if ses and ses["estado"]=="CERRADA": c.close(); return self._j({"ok":False,"error":"Caja cerrada, no se puede eliminar"})
            # Revertir el total
            monto = float(mov["monto"])
            if mov["tipo"]=="EGRESO":
                c.execute("UPDATE caja_sesiones SET total_egresos=total_egresos-? WHERE id=?",(monto,mov["sesion_id"]))
            elif mov["tipo"]=="INGRESO_OTRO":
                c.execute("UPDATE caja_sesiones SET total_ingresos=total_ingresos-? WHERE id=?",(monto,mov["sesion_id"]))
            c.execute("DELETE FROM caja_movimientos WHERE id=?",(mid,))
            c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/caja_cerrar":
            fecha = body.get("fecha") or today_ec()
            obs   = body.get("observaciones","")
            c = db()
            ses = rd(c.execute("SELECT * FROM caja_sesiones WHERE empresa_id=? AND fecha=?",(eid,fecha)).fetchone())
            if not ses: c.close(); return self._j({"ok":False,"error":"No hay sesión de caja para esta fecha"})
            if ses["estado"]=="CERRADA": c.close(); return self._j({"ok":False,"error":"La caja ya está cerrada"})
            # Recalcular totales reales
            tots = rd(c.execute("""SELECT
                COALESCE(SUM(CASE WHEN tipo='EGRESO' THEN monto ELSE 0 END),0) as egresos,
                COALESCE(SUM(CASE WHEN tipo!='EGRESO' THEN monto ELSE 0 END),0) as ingresos,
                COALESCE(SUM(CASE WHEN tipo='INGRESO_FACTURA' THEN monto ELSE 0 END),0) as facturas
                FROM caja_movimientos WHERE sesion_id=?""",(ses["id"],)).fetchone())
            saldo_f = float(ses["saldo_inicial"]) + float(tots["ingresos"]) - float(tots["egresos"])
            c.execute("""UPDATE caja_sesiones SET estado='CERRADA',saldo_final=?,
                total_ingresos=?,total_egresos=?,total_facturas=?,
                observaciones=?,cerrada_at=? WHERE id=?""",
                [saldo_f,tots["ingresos"],tots["egresos"],tots["facturas"],
                 obs,now_ec(),ses["id"]])
            c.commit()
            ses_upd = rd(c.execute("SELECT * FROM caja_sesiones WHERE id=?",(ses["id"],)).fetchone())
            c.close()
            return self._j({"ok":True,"sesion":ses_upd})

        elif p == "/api/caja_reabrir":
            if not is_admin: return self._j({"ok":False,"error":"Solo admin puede reabrir caja"},403)
            fecha = body.get("fecha") or today_ec()
            c = db()
            c.execute("UPDATE caja_sesiones SET estado='ABIERTA',cerrada_at='' WHERE empresa_id=? AND fecha=?",(eid,fecha))
            c.commit(); c.close()
            return self._j({"ok":True})

        # ════════════════════════════════════════════════════
        # LIQUIDACIONES DE COMPRA
        # ════════════════════════════════════════════════════
        elif p == "/api/liquidaciones":
            if self.command == "GET":
                q = qs.get("q",[""])[0]
                c = db()
                rows = rl(c.execute("""
                    SELECT lc.*, u.nombre as usuario_nombre
                    FROM liquidaciones_compra lc
                    LEFT JOIN usuarios u ON lc.usuario_id=u.id
                    WHERE lc.empresa_id=?
                    AND (lc.proveedor_razon_social LIKE ? OR lc.numero LIKE ?)
                    ORDER BY lc.id DESC LIMIT 100
                """, (eid, f"%{q}%", f"%{q}%")).fetchall())
                c.close(); return self._j(rows)
            else:
                # Crear nueva liquidación
                items = body.get("items", [])
                if not items: return self._j({"ok":False,"error":"Agrega al menos un ítem"},400)
                c = db()
                emp2 = rd(c.execute("SELECT * FROM empresas WHERE id=?",(eid,)).fetchone())

                # Secuencial propio para liquidaciones (independiente de facturas/guías)
                last_liq = rd(c.execute(
                    "SELECT numero FROM liquidaciones_compra WHERE empresa_id=? ORDER BY id DESC LIMIT 1",
                    (eid,)
                ).fetchone())
                if last_liq and last_liq.get("numero"):
                    # Extraer el último número de la serie LC
                    try:
                        last_sec = int(last_liq["numero"].split("-LC")[-1])
                        sec = last_sec + 1
                    except:
                        sec = 1
                else:
                    sec = 1

                sec_lc = int(emp2.get("sec_inicio_lc") or 0)
                if sec_lc > 0 and sec_lc >= sec: sec = sec_lc
                _est_u, _pto_u = _pto_emision_usuario(c, emp2, sess)
                num  = f"{_est_u}-{_pto_u}-LC{str(sec).zfill(9)}"

                subtotal_total = round(sum(float(it.get("subtotal",0)) for it in items), 2)
                iva_pct2 = float(emp2.get("iva_porcentaje") or 15)
                iva_total = round(subtotal_total * iva_pct2 / 100, 2)
                total_total = round(subtotal_total + iva_total, 2)

                c.execute("""INSERT INTO liquidaciones_compra
                    (empresa_id,numero,proveedor_tipo_id,proveedor_identificacion,
                     proveedor_razon_social,proveedor_direccion,proveedor_email,
                     fecha,subtotal,iva,total,motivo,forma_pago,
                     estado,usuario_id,created_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    [eid, num,
                     body.get("proveedor_tipo_id","05"),
                     body.get("proveedor_identificacion",""),
                     body.get("proveedor_razon_social",""),
                     body.get("proveedor_direccion",""),
                     body.get("proveedor_email",""),
                     body.get("fecha") or today_ec(),
                     subtotal_total, iva_total, total_total,
                     body.get("motivo",""),
                     body.get("forma_pago","EFECTIVO"),
                     "PENDIENTE", sess["usuario_id"], now_ec()])
                lid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                for it in items:
                    c.execute("""INSERT INTO liquidacion_items
                        (liquidacion_id,codigo,descripcion,cantidad,precio_unitario,descuento,subtotal)
                        VALUES (?,?,?,?,?,?,?)""",
                        [lid, it.get("codigo",""), it.get("descripcion",""),
                         float(it.get("cantidad",1)), float(it.get("precio_unitario",0)),
                         float(it.get("descuento",0)), float(it.get("subtotal",0))])
                c.commit(); c.close()
                return self._j({"ok":True,"id":lid,"numero":num})

        elif p == "/api/liquidacion":
            lid = int(qs.get("id",[0])[0])
            c = db()
            liq = rd(c.execute("SELECT * FROM liquidaciones_compra WHERE id=? AND empresa_id=?",
                               (lid,eid)).fetchone())
            if not liq: c.close(); return self._j({"error":"No encontrada"},404)
            items = rl(c.execute("SELECT * FROM liquidacion_items WHERE liquidacion_id=? ORDER BY id",
                                 (lid,)).fetchall())
            c.close()
            return self._j({**liq, "items":items})

        elif p == "/api/procesar_liquidacion":
            lid = body.get("liquidacion_id")
            if not lid: return self._j({"ok":False,"error":"liquidacion_id requerido"},400)
            return self._j(_procesar_liquidacion(int(lid), eid))

        elif p == "/api/probar_correo":
            # Enviar correo de prueba para verificar la configuración SMTP
            if not is_admin: return self._j({"ok":False,"error":"Sin permiso"},403)
            c = db()
            emp2 = rd(c.execute("SELECT * FROM empresas WHERE id=?",(eid,)).fetchone())
            c.close()
            smtp_h = str(emp2.get("smtp_host") or "").strip()
            smtp_p = int(emp2.get("smtp_port") or 587)
            smtp_u = str(emp2.get("smtp_user") or "").strip()
            smtp_s = str(emp2.get("smtp_pass") or "").strip()
            smtp_f = str(emp2.get("smtp_from") or smtp_u).strip()
            destino = body.get("destino") or smtp_u
            if not smtp_h or not smtp_u or not smtp_s:
                return self._j({"ok":False,"error":"Configura el servidor SMTP, usuario y contraseña antes de probar"})
            try:
                import smtplib, ssl
                from email.mime.text import MIMEText
                msg = MIMEText(f"""
Hola,

Este es un correo de prueba del sistema DAVI&LOZA SOFT.

Si recibes este mensaje, la configuración SMTP está funcionando correctamente.

Configuración usada:
- Servidor: {smtp_h}:{smtp_p}
- Usuario:  {smtp_u}

Sistema: DAVI&LOZA SOFT v3
Facturación Electrónica SRI Ecuador
                """.strip(), "plain", "utf-8")
                msg["Subject"] = "✓ Prueba de correo — DAVI&LOZA SOFT"
                msg["From"]    = f"{emp2.get('nombre','DAVI&LOZA SOFT')} <{smtp_f}>"
                msg["To"]      = destino

                ctx = ssl.create_default_context()
                if smtp_p == 465:
                    with smtplib.SMTP_SSL(smtp_h, smtp_p, context=ctx, timeout=15) as sv:
                        sv.login(smtp_u, smtp_s)
                        sv.sendmail(smtp_f, [destino], msg.as_string())
                else:
                    with smtplib.SMTP(smtp_h, smtp_p, timeout=15) as sv:
                        sv.ehlo()
                        sv.starttls(context=ctx)
                        sv.login(smtp_u, smtp_s)
                        sv.sendmail(smtp_f, [destino], msg.as_string())

                log.info("Correo de prueba enviado a %s", destino)
                return self._j({"ok":True,"mensaje":f"Correo de prueba enviado correctamente a {destino}"})
            except smtplib.SMTPAuthenticationError:
                return self._j({"ok":False,"error":"Error de autenticación. Verifica usuario y contraseña. Para Gmail usa 'Contraseña de aplicación'."})
            except smtplib.SMTPConnectError:
                return self._j({"ok":False,"error":f"No se pudo conectar a {smtp_h}:{smtp_p}. Verifica el servidor y puerto."})
            except Exception as ex:
                return self._j({"ok":False,"error":f"Error al enviar: {str(ex)}"})

        elif p == "/api/regenerar_ride":
            # Regenerar el RIDE de cualquier documento autorizado
            tipo   = body.get("tipo","factura")   # factura|nc|guia|liquidacion
            doc_id = body.get("id")
            if not doc_id:
                return self._j({"ok":False,"error":"id requerido"},400)
            c = db()
            emp2 = rd(c.execute("SELECT * FROM empresas WHERE id=?",(eid,)).fetchone())

            try:
                if tipo == "nc":
                    doc = rd(c.execute("SELECT * FROM notas_credito WHERE id=? AND empresa_id=?",(doc_id,eid)).fetchone())
                    c.close()
                    if not doc: return self._j({"ok":False,"error":"NC no encontrada"})
                    if not doc.get("autorizacion"): return self._j({"ok":False,"error":"La NC no está autorizada por el SRI"})
                    ruta = _generar_ride_nc(doc_id, eid, doc["clave_acceso"],
                                            doc["autorizacion"], doc.get("fecha_autorizacion",""), emp2)
                    return self._j({"ok":True,"ride_path":ruta,"mensaje":"RIDE NC regenerado correctamente"})

                elif tipo == "guia":
                    doc = rd(c.execute("SELECT * FROM guias_remision WHERE id=? AND empresa_id=?",(doc_id,eid)).fetchone())
                    c.close()
                    if not doc: return self._j({"ok":False,"error":"Guía no encontrada"})
                    if not doc.get("autorizacion"): return self._j({"ok":False,"error":"La guía no está autorizada por el SRI"})
                    ruta = _generar_ride_guia(doc_id, eid, doc["clave_acceso"],
                                              doc["autorizacion"], doc.get("fecha_autorizacion",""), emp2)
                    return self._j({"ok":True,"ride_path":ruta,"mensaje":"RIDE Guía regenerado correctamente"})

                elif tipo == "liquidacion":
                    doc = rd(c.execute("SELECT * FROM liquidaciones_compra WHERE id=? AND empresa_id=?",(doc_id,eid)).fetchone())
                    items = rl(c.execute("SELECT * FROM liquidacion_items WHERE liquidacion_id=? ORDER BY id",(doc_id,)).fetchall())
                    c.close()
                    if not doc: return self._j({"ok":False,"error":"Liquidación no encontrada"})
                    if not doc.get("autorizacion"): return self._j({"ok":False,"error":"La liquidación no está autorizada por el SRI"})
                    html = _generar_ride_liquidacion(doc_id, eid, doc, items, emp2)
                    return self._j({"ok":True,"mensaje":"RIDE Liquidación regenerado correctamente"})

                else:  # factura
                    doc = rd(c.execute("SELECT * FROM facturas WHERE id=? AND empresa_id=?",(doc_id,eid)).fetchone())
                    c.close()
                    if not doc: return self._j({"ok":False,"error":"Factura no encontrada"})
                    if not doc.get("autorizacion"): return self._j({"ok":False,"error":"La factura no está autorizada por el SRI"})
                    ruta = _generar_ride(doc_id, eid, doc["clave_acceso"],
                                        doc["autorizacion"], doc.get("fecha_autorizacion",""), emp2)
                    return self._j({"ok":True,"ride_path":ruta,"mensaje":"RIDE Factura regenerado correctamente"})

            except Exception as ex:
                try: c.close()
                except: pass
                return self._j({"ok":False,"error":f"Error regenerando RIDE: {ex}"})

        elif p == "/api/reintentar_sri":
            # Reintentar envío al SRI con la MISMA clave de acceso (no genera nueva)
            tipo   = body.get("tipo","factura")
            doc_id = body.get("id")
            if not doc_id: return self._j({"ok":False,"error":"id requerido"},400)
            if tipo == "nc":
                return self._j(_procesar_nc(int(doc_id), eid))
            elif tipo == "guia":
                return self._j(_procesar_guia(int(doc_id), eid))
            elif tipo == "liquidacion":
                return self._j(_procesar_liquidacion(int(doc_id), eid))
            else:
                return self._j(_procesar_factura(int(doc_id), eid))

        elif p == "/api/reenviar_sri":
            # Reenviar al SRI con nueva clave — útil si la firma expiró o fue rechazada
            tipo   = body.get("tipo","factura")
            doc_id = body.get("id")
            if not doc_id: return self._j({"ok":False,"error":"id requerido"},400)
            c = db()
            emp2 = rd(c.execute("SELECT * FROM empresas WHERE id=?",(eid,)).fetchone())

            if tipo == "nc":
                doc = rd(c.execute("SELECT * FROM notas_credito WHERE id=? AND empresa_id=?",(doc_id,eid)).fetchone())
                if not doc: c.close(); return self._j({"ok":False,"error":"NC no encontrada"})
                c.execute("UPDATE notas_credito SET estado='PENDIENTE',estado_sri='',autorizacion='',fecha_autorizacion='',clave_acceso='' WHERE id=? AND empresa_id=?",(doc_id,eid))
                c.commit(); c.close()
                return self._j(_procesar_nc(int(doc_id), eid))

            elif tipo == "guia":
                doc = rd(c.execute("SELECT * FROM guias_remision WHERE id=? AND empresa_id=?",(doc_id,eid)).fetchone())
                if not doc: c.close(); return self._j({"ok":False,"error":"Guía no encontrada"})
                c.execute("UPDATE guias_remision SET estado='PENDIENTE',estado_sri='',autorizacion='',fecha_autorizacion='',clave_acceso='' WHERE id=? AND empresa_id=?",(doc_id,eid))
                c.commit(); c.close()
                return self._j(_procesar_guia(int(doc_id), eid))

            elif tipo == "liquidacion":
                doc = rd(c.execute("SELECT * FROM liquidaciones_compra WHERE id=? AND empresa_id=?",(doc_id,eid)).fetchone())
                if not doc: c.close(); return self._j({"ok":False,"error":"Liquidación no encontrada"})
                c.execute("UPDATE liquidaciones_compra SET estado='PENDIENTE',estado_sri='',autorizacion='',fecha_autorizacion='',clave_acceso='' WHERE id=? AND empresa_id=?",(doc_id,eid))
                c.commit(); c.close()
                return self._j(_procesar_liquidacion(int(doc_id), eid))

            else:  # factura
                doc = rd(c.execute("SELECT * FROM facturas WHERE id=? AND empresa_id=?",(doc_id,eid)).fetchone())
                if not doc: c.close(); return self._j({"ok":False,"error":"Factura no encontrada"})
                c.execute("UPDATE facturas SET estado='PENDIENTE',estado_sri='',autorizacion='',fecha_autorizacion='',clave_acceso='' WHERE id=? AND empresa_id=?",(doc_id,eid))
                c.commit(); c.close()
                return self._j(_procesar_factura(int(doc_id), eid))

        elif p == "/api/pagar_liquidacion_caja":
            lid    = body.get("liquidacion_id")
            fecha  = body.get("fecha") or today_ec()
            metodo = body.get("metodo_pago","EFECTIVO")
            if not lid: return self._j({"ok":False,"error":"liquidacion_id requerido"},400)
            c = db()
            liq = rd(c.execute("SELECT * FROM liquidaciones_compra WHERE id=? AND empresa_id=?",(lid,eid)).fetchone())
            if not liq: c.close(); return self._j({"ok":False,"error":"Liquidación no encontrada"},404)
            ses = rd(c.execute("SELECT * FROM caja_sesiones WHERE empresa_id=? AND fecha=? AND estado='ABIERTA'",(eid,fecha)).fetchone())
            if not ses:
                c.close()
                return self._j({"ok":False,"error":f"No hay caja abierta para el {fecha}. Abre la caja del día primero."})
            # Insertar egreso
            c.execute("""INSERT INTO caja_movimientos
                (empresa_id,sesion_id,tipo,categoria,concepto,monto,metodo_pago,
                 comprobante,fecha,hora,usuario_id,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                [eid, ses["id"], "EGRESO", "Compras/Liquidaciones",
                 f"Liquidación {liq['numero']} — {liq.get('proveedor_razon_social','')[:50]}",
                 float(liq["total"]), metodo, liq["numero"],
                 fecha, now_ec().split()[1], sess["usuario_id"], now_ec()])
            # Actualizar total egresos en sesión
            c.execute("UPDATE caja_sesiones SET total_egresos=total_egresos+? WHERE id=?",
                      (float(liq["total"]), ses["id"]))
            # Marcar liquidación como pagada
            c.execute("UPDATE liquidaciones_compra SET forma_pago=?,estado='PAGADA' WHERE id=?",
                      (metodo, lid))
            c.commit(); c.close()
            return self._j({"ok":True,"mensaje":f"Liquidación {liq['numero']} registrada como egreso en caja del {fecha}"})

        elif p == "/api/eliminar_liquidacion":
            lid = body.get("id")
            if not lid: return self._j({"ok":False,"error":"id requerido"},400)
            c = db()
            liq = rd(c.execute("SELECT * FROM liquidaciones_compra WHERE id=? AND empresa_id=?",
                                (lid,eid)).fetchone())
            if not liq: c.close(); return self._j({"ok":False,"error":"Liquidación no encontrada"},404)
            if liq.get("estado_sri") == "AUTORIZADA" and liq.get("autorizacion"):
                c.close(); return self._j({"ok":False,"error":"No se puede eliminar una liquidación ya autorizada por el SRI"},400)
            c.execute("DELETE FROM liquidacion_items WHERE liquidacion_id=?", (lid,))
            c.execute("DELETE FROM liquidaciones_compra WHERE id=? AND empresa_id=?", (lid,eid))
            c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/ride_liquidacion":
            lid = int(qs.get("id",[0])[0])
            c = db()
            liq = rd(c.execute("SELECT * FROM liquidaciones_compra WHERE id=? AND empresa_id=?",(lid,eid)).fetchone())
            emp2 = rd(c.execute("SELECT * FROM empresas WHERE id=?",(eid,)).fetchone())
            c.close()
            if liq and liq.get("autorizacion"):
                items = rl(db().execute("SELECT * FROM liquidacion_items WHERE liquidacion_id=? ORDER BY id",(lid,)).fetchall())
                ride_html = _generar_ride_liquidacion(lid, eid, liq, items, emp2)
                if ride_html:
                    cont = ride_html.encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type","text/html; charset=utf-8")
                    self._cors(); self.end_headers(); self.wfile.write(cont)
                    return
            return self._j({"error":"RIDE no disponible — liquidación debe estar autorizada"},404)


        
        elif p == "/api/enviar_correo_masivo":
            # Enviar correos a múltiples documentos de una vez
            docs = body.get("documentos",[])  # [{id:1,tipo:'factura'}, {id:2,tipo:'nc'}]
            if not docs: return self._j({"ok":False,"error":"No hay documentos seleccionados"})
            resultados = []
            for d in docs:
                try:
                    doc_id = d.get("id")
                    tipo   = d.get("tipo","factura")
                    c2 = db()
                    emp2 = rd(c2.execute("SELECT * FROM empresas WHERE id=?",(eid,)).fetchone())
                    if tipo == "nc":
                        doc2 = rd(c2.execute("SELECT nc.*, cl.email as cli_email, cl.nombre as cli_nombre FROM notas_credito nc LEFT JOIN clientes cl ON nc.cliente_id=cl.id WHERE nc.id=? AND nc.empresa_id=?",(doc_id,eid)).fetchone())
                        c2.close()
                        dest = d.get("correo") or (doc2 or {}).get("cli_email","")
                        if dest and doc2: r = enviar_correo_nc(doc2, emp2, dest); resultados.append({"id":doc_id,"tipo":tipo,**r})
                        else: resultados.append({"id":doc_id,"tipo":tipo,"ok":False,"error":"Sin email"})
                    elif tipo == "guia":
                        doc2 = rd(c2.execute("SELECT gr.*, cl.email as cli_email, cl.nombre as cli_nombre FROM guias_remision gr LEFT JOIN clientes cl ON gr.cliente_id=cl.id WHERE gr.id=? AND gr.empresa_id=?",(doc_id,eid)).fetchone())
                        c2.close()
                        dest = d.get("correo") or (doc2 or {}).get("cli_email","")
                        if dest and doc2: r = enviar_correo_guia(doc2, emp2, dest); resultados.append({"id":doc_id,"tipo":tipo,**r})
                        else: resultados.append({"id":doc_id,"tipo":tipo,"ok":False,"error":"Sin email"})
                    elif tipo == "liquidacion":
                        doc2 = rd(c2.execute("SELECT * FROM liquidaciones_compra WHERE id=? AND empresa_id=?",(doc_id,eid)).fetchone())
                        c2.close()
                        dest = d.get("correo") or (doc2 or {}).get("proveedor_email","")
                        if dest and doc2: r = enviar_correo_liquidacion(doc2, emp2, dest); resultados.append({"id":doc_id,"tipo":tipo,**r})
                        else: resultados.append({"id":doc_id,"tipo":tipo,"ok":False,"error":"Sin email"})
                    else:
                        doc2 = rd(c2.execute("SELECT f.*, cl.email as cli_email, cl.nombre as cli_nombre FROM facturas f LEFT JOIN clientes cl ON f.cliente_id=cl.id WHERE f.id=? AND f.empresa_id=?",(doc_id,eid)).fetchone())
                        c2.close()
                        dest = d.get("correo") or (doc2 or {}).get("cli_email","")
                        if dest and doc2: r = enviar_correo(doc2, emp2, dest); resultados.append({"id":doc_id,"tipo":tipo,**r})
                        else: resultados.append({"id":doc_id,"tipo":tipo,"ok":False,"error":"Sin email"})
                except Exception as ex:
                    resultados.append({"id":d.get("id"),"tipo":d.get("tipo"),"ok":False,"error":str(ex)})
            enviados = sum(1 for r in resultados if r.get("ok"))
            return self._j({"ok":True,"enviados":enviados,"total":len(docs),"resultados":resultados,
                            "mensaje":f"Enviados {enviados} de {len(docs)} correos"})


        # ═══ COMPRAS/GASTOS/CONTABILIDAD POST ═══
        elif p == "/api/proveedores":
            c = db()
            if body.get("id"):
                c.execute("UPDATE proveedores SET nombre=?,ruc_cedula=?,tipo_identificacion=?,email=?,telefono=?,celular=?,direccion=?,tipo=? WHERE id=? AND empresa_id=?",
                    [body.get(k,"") for k in ["nombre","ruc_cedula","tipo_identificacion","email","telefono","celular","direccion","tipo"]]+[body["id"],eid])
            else:
                c.execute("INSERT INTO proveedores (empresa_id,nombre,ruc_cedula,tipo_identificacion,email,telefono,celular,direccion,tipo,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                    [eid]+[body.get(k,"") for k in ["nombre","ruc_cedula","tipo_identificacion","email","telefono","celular","direccion","tipo"]]+[now_ec()])
            c.commit(); pid = body.get("id") or c.execute("SELECT last_insert_rowid()").fetchone()[0]; c.close()
            return self._j({"ok":True,"id":pid})

        elif p == "/api/categorias_gasto":
            c = db()
            if body.get("id"):
                c.execute("UPDATE categorias_gasto SET nombre=?,tipo=?,cuenta_contable=? WHERE id=? AND empresa_id=?",(body.get("nombre",""),body.get("tipo","GASTO"),body.get("cuenta_contable",""),body["id"],eid))
            else:
                c.execute("INSERT INTO categorias_gasto (empresa_id,nombre,tipo,cuenta_contable,activa) VALUES (?,?,?,?,1)",(eid,body.get("nombre",""),body.get("tipo","GASTO"),body.get("cuenta_contable","")))
            c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/compras":
            c = db(); items = body.get("items",[])
            sub = sum(float(it.get("subtotal",0)) for it in items)
            iva_t = sum(float(it.get("iva_valor",0)) for it in items)
            c.execute("INSERT INTO compras (empresa_id,numero,numero_autorizacion,proveedor_id,categoria_id,usuario_id,fecha,fecha_registro,subtotal,iva,total,tipo,forma_pago,estado,estado_pago,notas,sustento,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (eid,body.get("numero",""),body.get("numero_autorizacion",""),body.get("proveedor_id"),body.get("categoria_id"),sess["usuario_id"],body.get("fecha",now_ec()[:10]),now_ec()[:10],sub,iva_t,sub+iva_t,body.get("tipo","GASTO"),body.get("forma_pago","01"),"REGISTRADA","PENDIENTE",body.get("notas",""),body.get("sustento","01"),now_ec()))
            cid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            for it in items:
                st = float(it.get("cantidad",1))*float(it.get("precio_unitario",0))
                iv = st*float(it.get("iva_tarifa",15))/100
                c.execute("INSERT INTO compra_items (compra_id,codigo,descripcion,cantidad,precio_unitario,descuento,subtotal,iva_tarifa,iva_valor) VALUES (?,?,?,?,?,?,?,?,?)",(cid,it.get("codigo",""),it.get("descripcion",""),float(it.get("cantidad",1)),float(it.get("precio_unitario",0)),0,st,float(it.get("iva_tarifa",15)),iv))
            # ── Asiento contable automático (compra / gasto) ──
            cfgc = _cfg_contable(c, eid)
            _tipo_compra = body.get("tipo","GASTO")
            _cta_debe_c = cfgc["cta_inventario"] if _tipo_compra == "COMPRA" else cfgc["cta_gastos"]
            _fp_c = body.get("forma_pago","01")
            _cta_haber_c = cfgc["cta_caja"] if _fp_c == "01" else cfgc["cta_cxp"]
            _total_c = sub + iva_t
            generar_asiento_auto(c, eid, sess["usuario_id"], (body.get("fecha", now_ec()[:10])),
                "Compra/Gasto " + (body.get("numero","") or ("#" + str(cid))), "COMPRA", cid,
                [(_cta_debe_c, sub, 0),
                 (cfgc["cta_iva_compras"], iva_t, 0),
                 (_cta_haber_c, 0, _total_c)])
            c.commit(); c.close()
            return self._j({"ok":True,"id":cid})

        elif p == "/api/pagar_compra":
            cid = body.get("id"); medio = (body.get("medio") or "caja").lower()
            c = db()
            comp = rd(c.execute("SELECT * FROM compras WHERE id=? AND empresa_id=?", (cid, eid)).fetchone())
            if not comp:
                c.close(); return self._j({"ok":False,"error":"Compra no encontrada"})
            c.execute("UPDATE compras SET estado_pago='PAGADA' WHERE id=? AND empresa_id=?", (cid, eid))
            cfg = _cfg_contable(c, eid)
            cxp = cfg["cta_cxp"]
            # Solo generar pago si la compra acreditó CxP (fue a crédito); las de contado ya movieron caja
            tiene_cxp = c.execute("""SELECT 1 FROM asiento_detalle d
                JOIN asientos_contables a ON d.asiento_id=a.id
                WHERE a.empresa_id=? AND a.tipo='COMPRA' AND a.origen_id=? AND a.estado='ACTIVO'
                  AND d.cuenta_codigo=? AND d.haber>0""", (eid, cid, cxp)).fetchone()
            if tiene_cxp:
                cta_pago = cfg["cta_bancos"] if medio == "banco" else cfg["cta_caja"]
                total = float(comp.get("total") or 0)
                # Si la compra ya tiene retención(es), al proveedor se le paga el NETO
                # (la retención ya debitó parte de la CxP). Evita sobrepagar Caja/Bancos.
                _retfila = c.execute(
                    "SELECT COALESCE(SUM(total_retenido),0) FROM retenciones WHERE empresa_id=? AND compra_id=? AND estado!='ANULADA'",
                    (eid, cid)).fetchone()
                ret_aplicada = float((_retfila[0] if _retfila else 0) or 0)
                pago = round(total - ret_aplicada, 2)
                if pago > 0:
                    generar_asiento_auto(c, eid, sess["usuario_id"], now_ec()[:10],
                        "Pago a proveedor — compra " + str(comp.get("numero") or ""),
                        "PAGO_COMPRA", cid, [(cxp, pago, 0), (cta_pago, 0, pago)])
            c.commit(); c.close()
            return self._j({"ok":True,"asiento": bool(tiene_cxp)})

        elif p == "/api/anular_compra":
            _cid_an = body.get("id")
            c = db(); c.execute("UPDATE compras SET estado='ANULADA' WHERE id=? AND empresa_id=?",(_cid_an,eid))
            revertir_asiento_auto(c, eid, "COMPRA", _cid_an); c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/guardar_plan_predeterminado":
            c = db()
            rows = rl(c.execute("SELECT codigo,nombre,nivel,tipo,naturaleza,grupo,padre_codigo FROM plan_cuentas WHERE empresa_id=? ORDER BY codigo", (eid,)).fetchall())
            c.close()
            if not rows: return self._j({"ok":False,"error":"El plan está vacío"})
            import json as _json
            plan = [{"codigo":r["codigo"],"nombre":r["nombre"],"nivel":r.get("nivel",1),"tipo":r.get("tipo","DETALLE"),
                     "naturaleza":r.get("naturaleza","DEUDORA"),"grupo":r.get("grupo",""),"padre":r.get("padre_codigo","")} for r in rows]
            try:
                dest = BASE_DIR / "plan_cuentas_niif.json"
                dest.write_text(_json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
                return self._j({"ok":True,"cuentas":len(plan),"ruta":str(dest)})
            except Exception as ex:
                return self._j({"ok":False,"error":str(ex)})

        elif p == "/api/plan_cuentas":
            c = db(); cod=body.get("codigo","").strip(); nom=body.get("nombre","").strip()
            if not cod or not nom: c.close(); return self._j({"ok":False,"error":"Codigo y nombre requeridos"})
            if body.get("id"):
                c.execute("UPDATE plan_cuentas SET codigo=?,codigo_rapido=?,nombre=?,nivel=?,tipo=?,naturaleza=?,grupo=?,padre_codigo=?,activa=? WHERE id=? AND empresa_id=?",(cod,cod.replace(".",""),nom,int(body.get("nivel",1)),body.get("tipo","DETALLE"),body.get("naturaleza","DEUDORA"),body.get("grupo",""),body.get("padre_codigo",""),int(body.get("activa",1)),body["id"],eid))
            else:
                if c.execute("SELECT 1 FROM plan_cuentas WHERE empresa_id=? AND codigo=?",(eid,cod)).fetchone():
                    c.close(); return self._j({"ok":False,"error":"Ya existe cuenta "+cod})
                c.execute("INSERT INTO plan_cuentas (empresa_id,codigo,codigo_rapido,nombre,nivel,tipo,naturaleza,grupo,padre_codigo,activa,editable) VALUES (?,?,?,?,?,?,?,?,?,1,1)",(eid,cod,cod.replace(".",""),nom,int(body.get("nivel",1)),body.get("tipo","DETALLE"),body.get("naturaleza","DEUDORA"),body.get("grupo",""),body.get("padre_codigo","")))
            c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/eliminar_cuenta":
            c = db(); cuenta=rd(c.execute("SELECT codigo FROM plan_cuentas WHERE id=? AND empresa_id=?",(body.get("id"),eid)).fetchone())
            if cuenta and c.execute("SELECT COUNT(*) FROM plan_cuentas WHERE empresa_id=? AND padre_codigo=?",(eid,cuenta["codigo"])).fetchone()[0]>0:
                c.close(); return self._j({"ok":False,"error":"Tiene subcuentas"})
            c.execute("DELETE FROM plan_cuentas WHERE id=? AND empresa_id=?",(body.get("id"),eid)); c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/recargar_plan_cuentas":
            c = db(); json_path=None
            for _jp in [BASE_DIR/"plan_cuentas_niif.json",BASE_DIR.parent/"plan_cuentas_niif.json",Path("C:/daviloza_soft/plan_cuentas_niif.json")]:
                if _jp.exists(): json_path=_jp; break
            if not json_path: c.close(); return self._j({"ok":False,"error":"Copia plan_cuentas_niif.json a C:\\daviloza_soft\\"})
            import json as _json; _pc=_json.loads(json_path.read_text(encoding="utf-8")); added=0
            for pc in _pc:
                if not c.execute("SELECT 1 FROM plan_cuentas WHERE empresa_id=? AND codigo=?",(eid,pc["codigo"])).fetchone():
                    c.execute("INSERT INTO plan_cuentas (empresa_id,codigo,codigo_rapido,nombre,nivel,tipo,naturaleza,grupo,padre_codigo) VALUES (?,?,?,?,?,?,?,?,?)",(eid,pc["codigo"],pc["codigo"].replace(".",""),pc["nombre"],pc["nivel"],pc["tipo"],pc["naturaleza"],pc["grupo"],pc["padre"]))
                    added+=1
            c.commit(); c.close()
            return self._j({"ok":True,"mensaje":str(added)+" cuentas cargadas"})


        # ═══ CONTABILIDAD POST ═══
        elif p == "/api/asientos":
            c = db()
            num = (c.execute("SELECT COALESCE(MAX(numero),0)+1 FROM asientos_contables WHERE empresa_id=?", (eid,)).fetchone()[0])
            detalle = body.get("detalle",[])
            total_d = sum(float(d.get("debe",0)) for d in detalle)
            total_h = sum(float(d.get("haber",0)) for d in detalle)
            if abs(total_d - total_h) > 0.01:
                c.close(); return self._j({"ok":False,"error":"Asiento descuadrado: Debe=$%.2f Haber=$%.2f" % (total_d,total_h)})
            c.execute("INSERT INTO asientos_contables (empresa_id,numero,fecha,concepto,referencia,tipo,usuario_id,estado,created_at) VALUES (?,?,?,?,?,?,?,?,?)",
                (eid,num,body.get("fecha",now_ec()[:10]),body.get("concepto",""),body.get("referencia",""),body.get("tipo","MANUAL"),sess["usuario_id"],"ACTIVO",now_ec()))
            aid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            for d in detalle:
                if float(d.get("debe",0)) > 0 or float(d.get("haber",0)) > 0:
                    c.execute("INSERT INTO asiento_detalle (asiento_id,cuenta_codigo,cuenta_nombre,debe,haber,referencia) VALUES (?,?,?,?,?,?)",
                        (aid,d.get("cuenta_codigo",""),d.get("cuenta_nombre",""),float(d.get("debe",0)),float(d.get("haber",0)),d.get("referencia","")))
            c.commit(); c.close()
            return self._j({"ok":True,"id":aid,"numero":num})

        elif p == "/api/anular_asiento":
            c = db()
            c.execute("UPDATE asientos_contables SET estado='ANULADO' WHERE id=? AND empresa_id=?", (body.get("id"),eid))
            c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/editar_asiento":
            c = db()
            aid = body.get("id")
            a = c.execute("SELECT id FROM asientos_contables WHERE id=? AND empresa_id=?", (aid, eid)).fetchone()
            if not a:
                c.close(); return self._j({"ok":False,"error":"Asiento no encontrado"})
            detalle = body.get("detalle", [])
            total_d = round(sum(float(d.get("debe", 0) or 0) for d in detalle), 2)
            total_h = round(sum(float(d.get("haber", 0) or 0) for d in detalle), 2)
            if abs(total_d - total_h) > 0.01:
                c.close(); return self._j({"ok":False,"error":"Asiento descuadrado: Debe=$%.2f Haber=$%.2f" % (total_d, total_h)})
            c.execute("UPDATE asientos_contables SET fecha=?, concepto=?, referencia=? WHERE id=?",
                      (body.get("fecha") or now_ec()[:10], body.get("concepto","") or "", body.get("referencia","") or "", aid))
            c.execute("DELETE FROM asiento_detalle WHERE asiento_id=?", (aid,))
            for d in detalle:
                de = float(d.get("debe", 0) or 0); ha = float(d.get("haber", 0) or 0)
                if de > 0 or ha > 0:
                    nom = d.get("cuenta_nombre") or _nombre_cuenta(c, eid, d.get("cuenta_codigo",""))
                    c.execute("INSERT INTO asiento_detalle (asiento_id,cuenta_codigo,cuenta_nombre,debe,haber,referencia) VALUES (?,?,?,?,?,?)",
                              (aid, d.get("cuenta_codigo",""), nom, de, ha, d.get("referencia","")))
            c.commit(); c.close()
            return self._j({"ok":True,"id":aid})

        elif p == "/api/config_contable":
            c = db()
            _cfg = _cfg_contable(c, eid)  # asegura que exista la fila
            campos = ["auto_asientos","cta_caja","cta_bancos","cta_cxc","cta_ventas","cta_ventas_0",
                      "cta_iva_ventas","cta_dev_ventas","cta_cxp","cta_inventario",
                      "cta_gastos","cta_iva_compras","cta_ret_iva","cta_ret_renta",
                      "cta_gasto_sueldos","cta_aporte_patronal","cta_beneficios",
                      "cta_iess_pagar","cta_sueldos_pagar","cta_anticipos_emp","cta_beneficios_pagar",
                      "cta_prestamos_emp","cta_multas","cta_honorarios"]
            sets = []; vals = []
            for k in campos:
                if k in body:
                    sets.append(k + "=?")
                    vals.append(int(body[k]) if k == "auto_asientos" else str(body[k]).strip())
            if sets:
                sets.append("updated_at=?"); vals.append(now_ec())
                vals.append(eid)
                c.execute("UPDATE config_contable SET " + ", ".join(sets) + " WHERE empresa_id=?", vals)
                c.commit()
            c.close()
            return self._j({"ok":True})

        elif p == "/api/retenciones":
            c = db()
            emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
            detalle = body.get("detalle", [])
            if not detalle:
                c.close(); return self._j({"ok":False,"error":"Agrega al menos una línea de retención"})
            # Calcular valores por línea y totales
            lineas = []; tot_iva = 0.0; tot_renta = 0.0
            for d in detalle:
                base = round(float(d.get("base_imponible", 0)), 2)
                pct  = float(d.get("porcentaje", 0))
                val  = round(base * pct / 100.0, 2)
                tipo_imp = (d.get("tipo_impuesto","RENTA") or "RENTA").upper()
                lineas.append({"tipo_impuesto":tipo_imp, "codigo":str(d.get("codigo","")),
                               "concepto":d.get("concepto",""), "base_imponible":base,
                               "porcentaje":pct, "valor_retenido":val})
                if tipo_imp == "IVA": tot_iva += val
                else: tot_renta += val
            tot_iva = round(tot_iva, 2); tot_renta = round(tot_renta, 2)
            total_ret = round(tot_iva + tot_renta, 2)
            # Secuencial de retención
            n = c.execute("SELECT COUNT(*)+1 FROM retenciones WHERE empresa_id=?", (eid,)).fetchone()[0]
            sec_ret = int(emp.get("sec_inicio_ret") or 0)
            if sec_ret > 0 and sec_ret >= n: n = sec_ret
            numero = (emp['estab'] or '001') + "-" + (emp['pto_emi'] or '001') + "-" + str(n).zfill(9)
            fecha_r = body.get("fecha") or today_ec()
            c.execute("""INSERT INTO retenciones
                (empresa_id,numero,compra_id,proveedor_id,proveedor_nombre,proveedor_ruc,fecha,
                 doc_sustento_tipo,doc_sustento_numero,base_total,total_ret_iva,total_ret_renta,
                 total_retenido,estado,usuario_id,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                [eid, numero, int(body.get("compra_id",0) or 0), int(body.get("proveedor_id",0) or 0),
                 body.get("proveedor_nombre",""), body.get("proveedor_ruc",""), fecha_r,
                 body.get("doc_sustento_tipo","01"), body.get("doc_sustento_numero",""),
                 round(float(body.get("base_total",0)),2), tot_iva, tot_renta, total_ret,
                 "EMITIDA", sess["usuario_id"], now_ec()])
            rid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            for ln in lineas:
                c.execute("""INSERT INTO retencion_detalle
                    (retencion_id,tipo_impuesto,codigo,concepto,base_imponible,porcentaje,valor_retenido)
                    VALUES (?,?,?,?,?,?,?)""",
                    [rid, ln["tipo_impuesto"], ln["codigo"], ln["concepto"],
                     ln["base_imponible"], ln["porcentaje"], ln["valor_retenido"]])
            # ── Asiento contable automático (retención en compras) ──
            cfgc = _cfg_contable(c, eid)
            generar_asiento_auto(c, eid, sess["usuario_id"], fecha_r,
                "Retención " + numero + " — " + body.get("proveedor_nombre",""), "RETENCION", rid,
                [(cfgc["cta_cxp"], total_ret, 0),
                 (cfgc["cta_ret_iva"], 0, tot_iva),
                 (cfgc["cta_ret_renta"], 0, tot_renta)])
            c.commit(); c.close()
            return self._j({"ok":True,"id":rid,"numero":numero,"total_retenido":total_ret})

        elif p == "/api/anular_retencion":
            _rid = body.get("id"); c = db()
            c.execute("UPDATE retenciones SET estado='ANULADA' WHERE id=? AND empresa_id=?", (_rid,eid))
            revertir_asiento_auto(c, eid, "RETENCION", _rid); c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/procesar_retencion_electronica":
            rid = body.get("id")
            res = _procesar_retencion(int(rid), eid)
            return self._j(res)

        elif p == "/api/rol_numerar":
            """Pone número a los roles individuales que todavía no lo tienen."""
            c = db()
            faltan = rl(c.execute("""SELECT d.id FROM nomina_detalle d
                                     JOIN roles_nomina r ON r.id=d.rol_id
                                     WHERE r.empresa_id=? AND IFNULL(d.numero,'')=''
                                     ORDER BY d.rol_id, d.id""", (eid,)).fetchall())
            if not faltan:
                c.close(); return self._j({"ok": True, "numerados": 0})
            nums = _rol_siguiente_numero(c, eid, len(faltan))
            for fila, num in zip(faltan, nums):
                c.execute("UPDATE nomina_detalle SET numero=? WHERE id=?", (num, fila["id"]))
            c.commit(); c.close()
            return self._j({"ok": True, "numerados": len(faltan)})

        elif p == "/api/rol_config":
            c = db()
            if body.get("leer"):
                emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
                c.close(); return self._j({"ok": True, **_rol_cfg(emp)})
            try:
                dig = int(body.get("digitos") or 6)
            except Exception:
                dig = 6
            c.execute("UPDATE empresas SET rol_prefijo=?, rol_secuencial=?, rol_digitos=? WHERE id=?",
                      (str(body.get("prefijo") or "ROL").strip()[:12] or "ROL",
                       max(1, int(_rol_f(body.get("secuencial"), 1) or 1)),
                       max(1, min(dig, 12)), eid))
            c.commit(); c.close()
            return self._j({"ok": True})

        elif p == "/api/nomina":
            d = body
            emps = d.get("empleados") or []
            if not emps:
                return self._j({"ok":False,"error":"Agrega al menos un empleado"})
            APORTE_PAT = 0.1115  # aporte patronal general IESS 11.15%
            ti = tip = t_ant = t_pre = t_mul = t_ot = tliq = 0.0
            def _ef(e):
                su=float(e.get("sueldo") or 0); ot=float(e.get("otros_ingresos") or 0)
                ip=float(e.get("iess_personal") or 0)
                an=float(e.get("anticipo_sueldo") or 0); pr=float(e.get("prestamo") or 0)
                mu=float(e.get("multa") or 0); od=float(e.get("otras_deducciones") or 0)
                liq=(su+ot)-ip-an-pr-mu-od
                return su,ot,ip,an,pr,mu,od,liq
            for e in emps:
                su,ot,ip,an,pr,mu,od,liq=_ef(e)
                ti+=su+ot; tip+=ip; t_ant+=an; t_pre+=pr; t_mul+=mu; t_ot+=od; tliq+=liq
            tded = round(t_ant+t_pre+t_mul+t_ot, 2)
            aporte_pat = round(ti*APORTE_PAT, 2)
            incprov = 1 if d.get("incluir_provisiones") else 0
            sbu = float(d.get("sbu") or 470)
            total_prov = _calc_provisiones(ti, len(emps), sbu) if incprov else 0.0
            c = db()
            c.execute("""INSERT INTO roles_nomina
                (empresa_id,periodo,fecha,concepto,num_empleados,total_ingresos,total_iess_personal,
                 total_deducciones,total_anticipos,total_prestamos,total_multas,total_liquido,
                 total_aporte_patronal,incluir_provisiones,total_provisiones,estado,usuario_id,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (eid, d.get("periodo") or "", d.get("fecha") or now_ec()[:10], d.get("concepto") or "Rol de pagos",
                 len(emps), round(ti,2), round(tip,2), tded, round(t_ant,2), round(t_pre,2), round(t_mul,2),
                 round(tliq,2), aporte_pat, incprov, total_prov, "REGISTRADO", sess["usuario_id"], now_ec()))
            rid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            for e in emps:
                su,ot,ip,an,pr,mu,od,liq=_ef(e)
                _num_rol = _rol_siguiente_numero(c, eid, 1)[0]
                c.execute("""INSERT INTO nomina_detalle
                    (rol_id,empleado,cargo,sueldo,otros_ingresos,iess_personal,anticipo_sueldo,prestamo,multa,otras_deducciones,anticipos,liquido,numero)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (rid, e.get("empleado") or "", e.get("cargo") or "", su, ot, ip, an, pr, mu, od, an, round(liq,2), _num_rol))
            c.commit()
            rol = rd(c.execute("SELECT * FROM roles_nomina WHERE id=?", (rid,)).fetchone())
            aid = _asiento_nomina(c, eid, sess["usuario_id"], rol)
            c.commit(); c.close()
            return self._j({"ok":True,"id":rid,"asiento_id":aid})

        elif p == "/api/generar_asiento_nomina":
            rid = body.get("id"); c = db()
            rol = rd(c.execute("SELECT * FROM roles_nomina WHERE id=? AND empresa_id=?", (rid, eid)).fetchone())
            if not rol:
                c.close(); return self._j({"ok":False,"error":"Rol no encontrado"})
            aid = _asiento_nomina(c, eid, sess["usuario_id"], rol)
            c.commit(); c.close()
            return self._j({"ok":bool(aid),"asiento_id":aid})

        elif p == "/api/recalcular_nomina_prov":
            rid = body.get("id"); sbu = float(body.get("sbu") or 470); c = db()
            rol = rd(c.execute("SELECT * FROM roles_nomina WHERE id=? AND empresa_id=?", (rid, eid)).fetchone())
            if not rol:
                c.close(); return self._j({"ok":False,"error":"Rol no encontrado"})
            total_prov = _calc_provisiones(rol["total_ingresos"], rol["num_empleados"], sbu)
            c.execute("UPDATE roles_nomina SET incluir_provisiones=1, total_provisiones=? WHERE id=?", (total_prov, rid))
            # Revertir el asiento anterior y volver a generarlo con la provisión incluida
            revertir_asiento_auto(c, eid, "NOMINA", rid)
            rol = rd(c.execute("SELECT * FROM roles_nomina WHERE id=?", (rid,)).fetchone())
            aid = _asiento_nomina(c, eid, sess["usuario_id"], rol)
            c.commit(); c.close()
            return self._j({"ok":bool(aid),"asiento_id":aid,"provision":total_prov})

        elif p == "/api/empleado":
            d = body; iid = d.get("id")
            campos = (d.get("nombres","") or "", d.get("cedula","") or "", d.get("cargo","") or "", d.get("sucursal","") or "",
                float(d.get("sueldo") or 0), (d.get("regimen") or "LABORAL").upper(), d.get("fecha_ingreso","") or "",
                d.get("fecha_egreso","") or "", (d.get("region") or "COSTA"), (d.get("fondos_reserva") or "PROVISIONA"),
                1 if d.get("mensualiza_decimos") else 0, (d.get("forma_pago") or "EFECTIVO"), d.get("email","") or "",
                (d.get("estado") or "ACTIVO").upper())
            c = db()
            if iid:
                c.execute("""UPDATE empleados SET nombres=?,cedula=?,cargo=?,sucursal=?,sueldo=?,regimen=?,fecha_ingreso=?,
                    fecha_egreso=?,region=?,fondos_reserva=?,mensualiza_decimos=?,forma_pago=?,email=?,estado=? WHERE id=? AND empresa_id=?""",
                    campos + (iid, eid))
            else:
                c.execute("""INSERT INTO empleados (nombres,cedula,cargo,sucursal,sueldo,regimen,fecha_ingreso,fecha_egreso,
                    region,fondos_reserva,mensualiza_decimos,forma_pago,email,estado,empresa_id,created_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", campos + (eid, now_ec()))
                iid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            c.commit(); c.close()
            return self._j({"ok":True,"id":iid})

        elif p == "/api/eliminar_empleado":
            c = db(); c.execute("DELETE FROM empleados WHERE id=? AND empresa_id=?", (body.get("id"), eid))
            c.commit(); c.close(); return self._j({"ok":True})

        elif p == "/api/sucursal":
            d = body; iid = d.get("id"); c = db()
            if iid:
                c.execute("UPDATE sucursales SET nombre=?, cta_gasto_sueldos=? WHERE id=? AND empresa_id=?",
                          (d.get("nombre","") or "", d.get("cta_gasto_sueldos","") or "", iid, eid))
            else:
                c.execute("INSERT INTO sucursales (empresa_id,nombre,cta_gasto_sueldos,created_at) VALUES (?,?,?,?)",
                          (eid, d.get("nombre","") or "", d.get("cta_gasto_sueldos","") or "", now_ec()))
            c.commit(); c.close(); return self._j({"ok":True})

        elif p == "/api/eliminar_sucursal":
            c = db(); c.execute("DELETE FROM sucursales WHERE id=? AND empresa_id=?", (body.get("id"), eid))
            c.commit(); c.close(); return self._j({"ok":True})

        elif p == "/api/novedad":
            d = body; tipo = (d.get("tipo") or "").upper()
            periodo = (d.get("periodo") or now_ec()[:7]).strip()
            valor = float(d.get("valor") or 0); cuotas = int(d.get("cuotas") or 1)
            alcance = (d.get("alcance") or "UNO").upper()
            c = db()
            if alcance == "TODOS":
                destinatarios = [r["id"] for r in c.execute("SELECT id FROM empleados WHERE empresa_id=? AND estado='ACTIVO'", (eid,)).fetchall()]
            else:
                destinatarios = [d.get("empleado_id")]
            def ins_nov(empid, per, conc, val):
                c.execute("""INSERT INTO nomina_novedades (empresa_id,empleado_id,periodo,tipo,concepto,valor,cuotas,observacion,estado,created_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?)""", (eid, empid, per, tipo, conc, val, cuotas, d.get("observacion","") or "", "ACTIVO", now_ec()))
            for empid in destinatarios:
                if not empid: continue
                if tipo == "PRESTAMO" and cuotas > 1:
                    cuota_val = round(valor / cuotas, 2)
                    y, m = int(periodo[:4]), int(periodo[5:7])
                    for k in range(cuotas):
                        mm = m + k; yy = y + (mm - 1) // 12; mm = ((mm - 1) % 12) + 1
                        ins_nov(empid, "%04d-%02d" % (yy, mm), (d.get("concepto") or "Préstamo") + " (cuota %d/%d)" % (k + 1, cuotas), cuota_val)
                else:
                    ins_nov(empid, periodo, d.get("concepto","") or tipo.title(), valor)
            c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/eliminar_novedad":
            c = db(); c.execute("UPDATE nomina_novedades SET estado='ANULADO' WHERE id=? AND empresa_id=?", (body.get("id"), eid))
            c.commit(); c.close(); return self._j({"ok":True})

        elif p == "/api/procesar_nomina":
            periodo = (body.get("periodo") or now_ec()[:7]).strip()
            fecha = body.get("fecha") or (periodo + "-28")
            incluir_prov = 1 if body.get("incluir_provisiones") else 0
            sbu = float(body.get("sbu") or 470)
            c = db()
            emps_db = rl(c.execute("SELECT * FROM empleados WHERE empresa_id=? AND estado='ACTIVO'", (eid,)).fetchall())
            if not emps_db:
                c.close(); return self._j({"ok":False,"error":"No hay empleados activos. Regístralos primero."})
            nov = rl(c.execute("SELECT * FROM nomina_novedades WHERE empresa_id=? AND periodo=? AND estado='ACTIVO'", (eid, periodo)).fetchall())
            novmap = {}
            for n in nov:
                novmap.setdefault(n["empleado_id"], []).append(n)
            # Reproceso: borrar rol y asiento previos del mismo periodo
            _nums_prev = {}
            for pr in c.execute("SELECT id FROM roles_nomina WHERE empresa_id=? AND periodo=?", (eid, periodo)).fetchall():
                revertir_asiento_auto(c, eid, "NOMINA", pr["id"])
                # Al reprocesar, cada colaborador conserva el numero de su rol:
                # si no, cada recalculo consumiria numeros nuevos y la
                # secuencia quedaria llena de huecos.
                for _o in c.execute("SELECT empleado_id, numero FROM nomina_detalle WHERE rol_id=?",
                                    (pr["id"],)).fetchall():
                    if _o["numero"]:
                        _nums_prev[_o["empleado_id"]] = _o["numero"]
                c.execute("DELETE FROM nomina_detalle WHERE rol_id=?", (pr["id"],))
                c.execute("DELETE FROM roles_nomina WHERE id=?", (pr["id"],))
            emps_calc = []
            ti=tip=tded=tant=tpre=tmul=todesc=tliq=tpat=toing=thon=0.0
            for e in emps_db:
                regimen = (e["regimen"] or "LABORAL").upper(); sueldo = float(e["sueldo"] or 0)
                ns = novmap.get(e["id"], [])
                def suma(tp): return round(sum(float(x["valor"] or 0) for x in ns if (x["tipo"] or "").upper()==tp), 2)
                otros_ing = suma("OTRO_INGRESO"); anticipo = suma("ANTICIPO"); prestamo = suma("PRESTAMO")
                multa = suma("MULTA"); otros_desc = suma("OTRO_DESCUENTO")
                iess_p = round(sueldo*0.0945,2) if regimen=="LABORAL" else 0.0
                aporte = round(sueldo*0.1115,2) if regimen=="LABORAL" else 0.0
                ingresos = round(sueldo+otros_ing,2)
                neto = round(ingresos - iess_p - anticipo - prestamo - multa - otros_desc, 2)
                emps_calc.append({"empleado_id":e["id"],"nombres":e["nombres"],"cargo":e["cargo"],"sucursal":e["sucursal"],
                    "regimen":regimen,"sueldo":sueldo,"otros_ing":otros_ing,"iess_personal":iess_p,"aporte_pat":aporte,
                    "anticipo":anticipo,"prestamo":prestamo,"multa":multa,"otros_desc":otros_desc,"neto":neto})
                ti+=ingresos; tip+=iess_p; tded+=(anticipo+prestamo+multa+otros_desc)
                tant+=anticipo; tpre+=prestamo; tmul+=multa; todesc+=otros_desc; tliq+=neto; tpat+=aporte; toing+=otros_ing
                if regimen=="CIVIL": thon+=ingresos
            total_prov = _calc_provisiones(ti, len(emps_calc), sbu) if incluir_prov else 0.0
            c.execute("""INSERT INTO roles_nomina (empresa_id,periodo,fecha,concepto,num_empleados,total_ingresos,total_iess_personal,
                total_deducciones,total_anticipos,total_prestamos,total_multas,total_liquido,total_aporte_patronal,
                incluir_provisiones,total_provisiones,total_otros_ingresos,total_honorarios,estado,usuario_id,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (eid, periodo, fecha, "Rol de pagos "+periodo, len(emps_calc), round(ti,2), round(tip,2), round(tded,2),
                 round(tant,2), round(tpre,2), round(tmul,2), round(tliq,2), round(tpat,2), incluir_prov, total_prov,
                 round(toing,2), round(thon,2), "PROCESADO", sess["usuario_id"], now_ec()))
            rid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            for e in emps_calc:
                _num_rol = _nums_prev.get(e["empleado_id"]) or _rol_siguiente_numero(c, eid, 1)[0]
                c.execute("""INSERT INTO nomina_detalle (rol_id,empleado_id,empleado,cargo,regimen,sucursal,sueldo,otros_ingresos,
                    iess_personal,anticipo_sueldo,prestamo,multa,otras_deducciones,otros_descuentos,anticipos,liquido,numero)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (rid, e["empleado_id"], e["nombres"], e["cargo"], e["regimen"], e["sucursal"], e["sueldo"], e["otros_ing"],
                     e["iess_personal"], e["anticipo"], e["prestamo"], e["multa"], e["otros_desc"], e["otros_desc"], e["anticipo"], e["neto"], _num_rol))
            aid = _asiento_nomina_proc(c, eid, sess["usuario_id"], rid, fecha, periodo, emps_calc, total_prov)
            c.commit(); c.close()
            return self._j({"ok":True,"id":rid,"asiento_id":aid,"empleados":len(emps_calc),"liquido":round(tliq,2)})

        elif p == "/api/pago_masivo":
            d = body; ids = d.get("factura_ids") or []
            destino = (d.get("destino") or "caja").strip()  # caja | bancos
            cuenta_banco_id = int(d.get("cuenta_bancaria_id") or 0)
            fecha = d.get("fecha") or today_ec()
            c = db(); cfg = _cfg_contable(c, eid)
            if destino == "bancos" and cuenta_banco_id:
                cta_destino = _cta_banco(c, eid, cuenta_banco_id)
            elif destino == "bancos":
                cta_destino = cfg["cta_bancos"]
            else:
                cta_destino = cfg["cta_caja"]
            ok = 0; total_cobrado = 0.0
            for fid in ids:
                fid = int(fid)
                f = rd(c.execute("SELECT id,numero,total,cliente_id,estado FROM facturas WHERE id=? AND empresa_id=?", (fid, eid)).fetchone())
                if not f or f.get("estado") in ("PAGADA","ANULADA"): continue
                monto = round(float(f.get("total") or 0), 2)
                if monto <= 0: continue
                cli_id = f.get("cliente_id") or 0
                # Asiento: Debe caja/bancos · Haber CxC
                aid = generar_asiento_auto(c, eid, sess["usuario_id"], fecha,
                    "Cobro factura " + str(f.get("numero")), "COBRO", fid,
                    [(cta_destino, monto, 0), (cfg["cta_cxc"], 0, monto)], forzar=True)
                # Cartera: registrar PAGO (saldo baja)
                last = c.execute("SELECT saldo FROM cuentas_cobrar WHERE empresa_id=? AND cliente_id=? ORDER BY id DESC LIMIT 1", (eid, cli_id)).fetchone()
                saldo_ant = float(last[0]) if last else 0.0
                nuevo = round(saldo_ant - monto, 2)
                c.execute("""INSERT INTO cuentas_cobrar (empresa_id,cliente_id,factura_id,tipo,concepto,monto,saldo,fecha,usuario_id,estado,referencia,created_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (eid, cli_id, fid, "PAGO", "Cobro factura " + str(f.get("numero")), -monto, nuevo, fecha, sess["usuario_id"], "PAGADO", str(f.get("numero")), now_ec()))
                c.execute("UPDATE facturas SET estado='PAGADA' WHERE id=?", (fid,))
                ok += 1; total_cobrado += monto
            # Si fue a bancos con cuenta, registrar movimiento bancario (ingreso) para conciliación
            if destino == "bancos" and cuenta_banco_id and ok:
                _mov_banco(c, eid, cuenta_banco_id, fecha, "INGRESO", "Cobro masivo de facturas", "", round(total_cobrado,2), 0, "Cobro masivo", "COBRO_MASIVO", 0, 0, sess["usuario_id"])
            c.commit(); c.close()
            return self._j({"ok":True,"pagadas":ok,"total":round(total_cobrado,2)})

        elif p == "/api/reconstruir_cartera":
            c = db()
            # Inserta el movimiento de cartera para facturas a crédito que aún no lo tienen
            fs = c.execute("""SELECT f.id,f.numero,f.total,f.cliente_id,f.fecha FROM facturas f
                WHERE f.empresa_id=? AND IFNULL(f.estado,'') NOT IN ('PAGADA','ANULADA')
                AND NOT EXISTS (SELECT 1 FROM cuentas_cobrar cc WHERE cc.factura_id=f.id AND cc.tipo='FACTURA')
                ORDER BY f.cliente_id, f.fecha, f.id""", (eid,)).fetchall()
            n = 0
            for f in fs:
                cli = f["cliente_id"] or 0
                if not cli: continue
                _cxc_add_factura(c, eid, cli, f["id"], f["numero"], f["total"], f["fecha"] or today_ec(), sess["usuario_id"])
                n += 1
            c.commit(); c.close()
            return self._j({"ok":True,"agregadas":n})

        elif p == "/api/reclasificar_ventas":
            c = db(); cfg = _cfg_contable(c, eid)
            cv15 = cfg["cta_ventas"]; cv0 = cfg.get("cta_ventas_0") or cfg["cta_ventas"]; civ = cfg["cta_iva_ventas"]
            asientos = c.execute("""SELECT a.id as aid, f.subtotal as subtotal, f.iva as iva
                FROM asientos_contables a JOIN facturas f ON a.origen_id=f.id AND f.empresa_id=a.empresa_id
                WHERE a.empresa_id=? AND a.tipo='VENTA' AND IFNULL(a.estado,'ACTIVO')='ACTIVO'""", (eid,)).fetchall()
            n = 0
            for a in asientos:
                aid = a["aid"]; sub = float(a["subtotal"] or 0); iva = float(a["iva"] or 0)
                b15 = round(iva / 0.15, 2) if iva > 0 else 0.0
                b0 = round(sub - b15, 2)
                if b0 < 0: b0 = 0.0
                vlines = c.execute("SELECT id, cuenta_codigo FROM asiento_detalle WHERE asiento_id=? AND haber>0 AND cuenta_codigo!=?", (aid, civ)).fetchall()
                if not vlines: continue
                actuales = sorted(set((v["cuenta_codigo"] or "") for v in vlines))
                objetivo = sorted(set([cv15] + ([cv0] if b0 > 0 else [])))
                if actuales == objetivo: continue
                for v in vlines: c.execute("DELETE FROM asiento_detalle WHERE id=?", (v["id"],))
                if b15 > 0:
                    c.execute("INSERT INTO asiento_detalle (asiento_id,cuenta_codigo,cuenta_nombre,debe,haber,referencia) VALUES (?,?,?,?,?,?)",
                              (aid, cv15, _nombre_cuenta(c, eid, cv15), 0, b15, "Reclasif. ventas 15%"))
                if b0 > 0:
                    c.execute("INSERT INTO asiento_detalle (asiento_id,cuenta_codigo,cuenta_nombre,debe,haber,referencia) VALUES (?,?,?,?,?,?)",
                              (aid, cv0, _nombre_cuenta(c, eid, cv0), 0, b0, "Reclasif. ventas 0%"))
                n += 1
            c.commit(); c.close()
            return self._j({"ok":True,"reclasificadas":n,"cta_15":cv15,"cta_0":cv0})

        elif p == "/api/optimizar_db":
            try:
                import os as _os
                tam_antes = _os.path.getsize(str(DB_PATH)) if _os.path.exists(str(DB_PATH)) else 0
            except Exception:
                tam_antes = 0
            c = db()
            try:
                c.isolation_level = None
                c.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                c.execute("VACUUM")
                c.execute("ANALYZE")
            except Exception as ex:
                c.close(); return self._j({"ok":False,"error":str(ex)})
            c.close()
            try:
                import os as _os2
                tam_despues = _os2.path.getsize(str(DB_PATH)) if _os2.path.exists(str(DB_PATH)) else 0
            except Exception:
                tam_despues = 0
            return self._j({"ok":True,"antes_mb":round(tam_antes/1048576,2),"despues_mb":round(tam_despues/1048576,2),
                            "liberado_mb":round((tam_antes-tam_despues)/1048576,2)})

        elif p == "/api/importacion":
            d = body; c = db()
            sup = d.get("supuestos") or {}
            def _f(k, dv=0.0):
                try: return float(sup.get(k, dv) or 0)
                except Exception: return dv
            flete=_f("flete",0.12); isd=_f("isd",0.05); arancel=_f("arancel",0)
            fodinfa=_f("fodinfa",0.005); aduana=_f("aduana",0.035); glocal=_f("glocal",0.15)
            margen=_f("margen",0.46); markup=_f("markup",0.35)
            items = d.get("items") or []
            if not items: c.close(); return self._j({"ok":False,"error":"Agrega al menos un ítem"})
            fob_total = 0.0; inversion = 0.0; venta = 0.0; items_out = []
            for it in items:
                cant = float(it.get("cantidad",0) or 0); fob = float(it.get("fob_unit",0) or 0)
                if cant <= 0 or fob <= 0: continue
                fl  = fob*flete; cif = fob+fl
                cu  = fob + fl + fob*isd + cif*arancel + cif*fodinfa + cif*aduana + cif*glocal
                pm  = cu/(1-margen) if margen < 1 else cu
                pvp = pm*(1+markup)
                fob_total += fob*cant; inversion += cu*cant; venta += pm*cant
                items_out.append({"codigo":str(it.get("codigo","") or ""),"descripcion":str(it.get("descripcion","") or ""),
                                  "cantidad":cant,"fob_unit":round(fob,4),"costo_unit":round(cu,4),
                                  "p_mayorista":round(pm,4),"pvp":round(pvp,4)})
            if not items_out: c.close(); return self._j({"ok":False,"error":"Los ítems necesitan cantidad y FOB mayores a 0"})
            import json as _json
            sup_json = _json.dumps({"flete":flete,"isd":isd,"arancel":arancel,"fodinfa":fodinfa,
                                    "aduana":aduana,"glocal":glocal,"margen":margen,"markup":markup})
            iid = d.get("id")
            if iid:
                imp = rd(c.execute("SELECT estado FROM importaciones WHERE id=? AND empresa_id=?", (iid, eid)).fetchone())
                if not imp: c.close(); return self._j({"ok":False,"error":"No encontrada"})
                if imp["estado"] == "INGRESADA": c.close(); return self._j({"ok":False,"error":"Esta importación ya fue ingresada al inventario; no se puede modificar."})
                c.execute("UPDATE importaciones SET proyecto=?,fecha=?,supuestos=?,fob_total=?,inversion=?,venta_proy=? WHERE id=?",
                          (d.get("proyecto",""), d.get("fecha") or today_ec(), sup_json,
                           round(fob_total,2), round(inversion,2), round(venta,2), iid))
                c.execute("DELETE FROM importacion_items WHERE importacion_id=?", (iid,))
            else:
                c.execute("""INSERT INTO importaciones (empresa_id,proyecto,fecha,supuestos,fob_total,inversion,venta_proy,estado,usuario_id,created_at)
                             VALUES (?,?,?,?,?,?,?,?,?,?)""",
                          (eid, d.get("proyecto",""), d.get("fecha") or today_ec(), sup_json,
                           round(fob_total,2), round(inversion,2), round(venta,2), "BORRADOR",
                           sess["usuario_id"], now_ec()))
                iid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            for io_ in items_out:
                c.execute("""INSERT INTO importacion_items (importacion_id,codigo,descripcion,cantidad,fob_unit,costo_unit,p_mayorista,pvp)
                             VALUES (?,?,?,?,?,?,?,?)""",
                          (iid, io_["codigo"], io_["descripcion"], io_["cantidad"], io_["fob_unit"],
                           io_["costo_unit"], io_["p_mayorista"], io_["pvp"]))
            c.commit(); c.close()
            return self._j({"ok":True,"id":iid,"fob_total":round(fob_total,2),
                            "inversion":round(inversion,2),"venta_proy":round(venta,2)})

        elif p == "/api/eliminar_importacion":
            c = db()
            imp = rd(c.execute("SELECT estado FROM importaciones WHERE id=? AND empresa_id=?", (body.get("id"), eid)).fetchone())
            if imp and imp["estado"] == "INGRESADA":
                c.close(); return self._j({"ok":False,"error":"Ya fue ingresada al inventario; no se puede eliminar."})
            c.execute("DELETE FROM importacion_items WHERE importacion_id=?", (body.get("id"),))
            c.execute("DELETE FROM importaciones WHERE id=? AND empresa_id=?", (body.get("id"), eid))
            c.commit(); c.close(); return self._j({"ok":True})

        elif p == "/api/importacion_ingresar":
            iid = body.get("id"); c = db(); cfg = _cfg_contable(c, eid)
            imp = rd(c.execute("SELECT * FROM importaciones WHERE id=? AND empresa_id=?", (iid, eid)).fetchone())
            if not imp: c.close(); return self._j({"ok":False,"error":"Importación no encontrada"})
            if imp["estado"] == "INGRESADA":
                c.close(); return self._j({"ok":False,"error":"Esta importación ya fue ingresada al inventario (no se duplica)."})
            items = rl(c.execute("SELECT * FROM importacion_items WHERE importacion_id=?", (iid,)).fetchall())
            if not items: c.close(); return self._j({"ok":False,"error":"La importación no tiene ítems"})
            bod = _bodega_principal(c, eid)
            act_precio = bool(body.get("actualizar_precios"))
            fecha = imp.get("fecha") or today_ec()
            creados = 0; actualizados = 0; total_inv = 0.0
            for it in items:
                cod = (it.get("codigo") or "").strip(); nom = (it.get("descripcion") or "").strip()
                cant = float(it.get("cantidad",0) or 0); cu = float(it.get("costo_unit",0) or 0)
                pvp = float(it.get("pvp",0) or 0)
                if cant <= 0: continue
                prod = None
                if cod:
                    prod = rd(c.execute("SELECT * FROM productos WHERE empresa_id=? AND codigo=?", (eid, cod)).fetchone())
                if not prod and nom:
                    prod = rd(c.execute("SELECT * FROM productos WHERE empresa_id=? AND nombre=?", (eid, nom)).fetchone())
                if prod:
                    st_ant = float(prod.get("stock") or 0); st_new = st_ant + cant
                    sets = "stock=?, costo=?"; vals=[st_new, cu]
                    if act_precio and pvp > 0: sets += ", precio=?"; vals.append(pvp)
                    vals += [prod["id"]]
                    c.execute(f"UPDATE productos SET {sets} WHERE id=?", vals)
                    pid = prod["id"]; actualizados += 1
                else:
                    c.execute("""INSERT INTO productos (empresa_id,codigo,nombre,descripcion,precio,costo,stock,unidad,activo,tipo,graba_iva,iva_porcentaje,cuenta_inventario,cuenta_ingreso,cuenta_costo)
                                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                              (eid, cod, nom or cod, "", (pvp if pvp>0 else 0), cu, cant, "unidad", 1, "PRODUCTO",
                               1, 15, cfg["cta_inventario"], cfg["cta_ventas"], cfg["cta_gastos"]))
                    pid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                    st_ant = 0; st_new = cant; creados += 1
                _stock_bodega_mov(c, eid, pid, bod, cant)
                c.execute("""INSERT INTO stock_movimientos (empresa_id,producto_id,tipo,cantidad,stock_antes,stock_despues,referencia_id,referencia_tipo,notas,fecha,usuario_id,bodega_id)
                             VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                          (eid, pid, "INGRESO", cant, st_ant, st_new, iid, "IMPORTACION",
                           "Importación: " + (imp.get("proyecto") or ("#"+str(iid))), fecha, sess["usuario_id"], bod))
                total_inv += cu*cant
            # Asiento contable opcional del ingreso de mercadería
            aid = 0
            contra = (body.get("cuenta_contrapartida") or "").strip()
            if body.get("generar_asiento") and contra and total_inv > 0:
                aid = generar_asiento_auto(c, eid, sess["usuario_id"], fecha,
                    "Ingreso importación " + (imp.get("proyecto") or ("#"+str(iid))),
                    "INVENTARIO", 900000+int(iid),
                    [(cfg["cta_inventario"], round(total_inv,2), 0), (contra, 0, round(total_inv,2))], forzar=True)
            c.execute("UPDATE importaciones SET estado='INGRESADA' WHERE id=?", (iid,))
            c.commit(); c.close()
            return self._j({"ok":True,"creados":creados,"actualizados":actualizados,
                            "total":round(total_inv,2),"asiento_id":aid})

        elif p == "/api/extracto_parsear":
            b64 = body.get("pdf_base64","")
            if not b64: return self._j({"ok":False,"error":"No se recibió el PDF"})
            try:
                pdf_bytes = base64.b64decode(b64.split(",")[-1])
            except Exception:
                return self._j({"ok":False,"error":"El archivo no es válido"})
            movs, err = _parse_extracto_pdf(pdf_bytes)
            if err: return self._j({"ok":False,"error":err})
            ing = round(sum(m["ingreso"] for m in movs),2)
            egr = round(sum(m["egreso"] for m in movs),2)
            return self._j({"ok":True,"movimientos":movs,"total":len(movs),
                            "total_ingresos":ing,"total_egresos":egr})

        elif p == "/api/extracto_guardar":
            cta = body.get("cuenta_bancaria_id")
            movs = body.get("movimientos") or []
            if not cta: return self._j({"ok":False,"error":"Selecciona la cuenta bancaria"})
            if not movs: return self._j({"ok":False,"error":"No hay movimientos para guardar"})
            c = db(); lote = now_ec(); nuevos = 0; dup = 0
            for m in movs:
                # Evitar duplicados por (cuenta, fecha, documento, monto)
                doc = str(m.get("documento","") or "")
                val = float(m.get("ingreso") or 0) + float(m.get("egreso") or 0)
                ya = c.execute("""SELECT 1 FROM extracto_banco WHERE empresa_id=? AND cuenta_bancaria_id=?
                        AND fecha=? AND documento=? AND (ingreso+egreso)=?""",
                        (eid, cta, m.get("fecha",""), doc, val)).fetchone()
                if ya: dup += 1; continue
                c.execute("""INSERT INTO extracto_banco (empresa_id,cuenta_bancaria_id,fecha,concepto,oficina,documento,tipo,ingreso,egreso,saldo,codigo,conciliado,lote,created_at)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,0,?,?)""",
                        (eid, cta, m.get("fecha",""), str(m.get("concepto",""))[:200], str(m.get("oficina","")),
                         doc, str(m.get("tipo","")), float(m.get("ingreso") or 0), float(m.get("egreso") or 0),
                         float(m.get("saldo") or 0), str(m.get("codigo","")), lote, now_ec()))
                nuevos += 1
            c.commit(); c.close()
            return self._j({"ok":True,"nuevos":nuevos,"duplicados":dup})

        elif p == "/api/conciliar_auto":
            cta = body.get("cuenta_bancaria_id")
            tol_dias = int(body.get("tolerancia_dias", 3) or 3)
            c = db()
            # Extracto pendiente
            ext = rl(c.execute("""SELECT * FROM extracto_banco WHERE empresa_id=? AND cuenta_bancaria_id=? AND conciliado=0
                    ORDER BY fecha""", (eid, cta)).fetchall())
            # Movimientos del sistema pendientes
            libro = rl(c.execute("""SELECT * FROM movimientos_banco WHERE empresa_id=? AND cuenta_bancaria_id=?
                    AND IFNULL(estado,'ACTIVO')='ACTIVO' AND IFNULL(estado_concil,'PENDIENTE')!='CONCILIADO'
                    ORDER BY fecha""", (eid, cta)).fetchall())
            import datetime as _dt
            def dd(s):
                try: return _dt.datetime.strptime(str(s)[:10], "%Y-%m-%d")
                except Exception: return None
            usados = set(); emparejados = 0
            for e in ext:
                e_val = float(e.get("ingreso") or 0) - float(e.get("egreso") or 0)
                e_fecha = dd(e.get("fecha")); e_doc = str(e.get("documento","") or "")
                mejor = None; mejor_score = 999
                for l in libro:
                    if l["id"] in usados: continue
                    l_val = float(l.get("ingreso") or 0) - float(l.get("egreso") or 0)
                    if abs(l_val - e_val) > 0.01: continue        # el monto debe coincidir (mismo signo)
                    l_fecha = dd(l.get("fecha"))
                    dias = abs((l_fecha - e_fecha).days) if (l_fecha and e_fecha) else 0
                    if dias > tol_dias: continue
                    # Bonus si el documento coincide
                    score = dias - (5 if e_doc and e_doc in str(l.get("documento","")) else 0)
                    if score < mejor_score: mejor_score = score; mejor = l
                if mejor:
                    usados.add(mejor["id"])
                    c.execute("UPDATE extracto_banco SET conciliado=1, mov_banco_id=? WHERE id=?", (mejor["id"], e["id"]))
                    c.execute("UPDATE movimientos_banco SET estado_concil='CONCILIADO', fecha_concil=? WHERE id=?", (today_ec(), mejor["id"]))
                    emparejados += 1
            c.commit()
            pend_ext = c.execute("SELECT COUNT(*) FROM extracto_banco WHERE empresa_id=? AND cuenta_bancaria_id=? AND conciliado=0", (eid, cta)).fetchone()[0]
            pend_lib = c.execute("""SELECT COUNT(*) FROM movimientos_banco WHERE empresa_id=? AND cuenta_bancaria_id=?
                    AND IFNULL(estado,'ACTIVO')='ACTIVO' AND IFNULL(estado_concil,'PENDIENTE')!='CONCILIADO'""", (eid, cta)).fetchone()[0]
            c.close()
            return self._j({"ok":True,"emparejados":emparejados,"pendientes_extracto":pend_ext,"pendientes_libro":pend_lib})

        elif p == "/api/extracto_crear_movimiento":
            # Crear en el libro un movimiento a partir de una línea del extracto (para partidas que solo están en el banco)
            ext_id = body.get("extracto_id"); c = db()
            e = rd(c.execute("SELECT * FROM extracto_banco WHERE id=? AND empresa_id=?", (ext_id, eid)).fetchone())
            if not e: c.close(); return self._j({"ok":False,"error":"Línea no encontrada"})
            if e["conciliado"]: c.close(); return self._j({"ok":False,"error":"Ya está conciliada"})
            tipo = "INGRESO" if float(e.get("ingreso") or 0) > 0 else "EGRESO"
            c.execute("""INSERT INTO movimientos_banco (empresa_id,cuenta_bancaria_id,fecha,tipo,concepto,documento,ingreso,egreso,estado_concil,fecha_concil,origen_tipo,usuario_id,created_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (eid, e["cuenta_bancaria_id"], e["fecha"], tipo, e.get("concepto",""), e.get("documento",""),
                     float(e.get("ingreso") or 0), float(e.get("egreso") or 0), "CONCILIADO", today_ec(), "EXTRACTO", sess["usuario_id"], now_ec()))
            mid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            c.execute("UPDATE extracto_banco SET conciliado=1, mov_banco_id=? WHERE id=?", (mid, ext_id))
            c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/extracto_limpiar":
            cta = body.get("cuenta_bancaria_id"); c = db()
            if body.get("solo_pendientes"):
                c.execute("DELETE FROM extracto_banco WHERE empresa_id=? AND cuenta_bancaria_id=? AND conciliado=0", (eid, cta))
            else:
                c.execute("DELETE FROM extracto_banco WHERE empresa_id=? AND cuenta_bancaria_id=?", (eid, cta))
            c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/bodega":
            d = body; c = db(); iid = d.get("id")
            nombre = (d.get("nombre") or "").strip()
            if not nombre: c.close(); return self._j({"ok":False,"error":"Nombre requerido"})
            if iid:
                c.execute("UPDATE bodegas SET nombre=?,codigo=?,estado=? WHERE id=? AND empresa_id=?",
                          (nombre, d.get("codigo",""), d.get("estado","ACTIVO"), iid, eid))
            else:
                principal = 1 if not c.execute("SELECT 1 FROM bodegas WHERE empresa_id=?", (eid,)).fetchone() else int(d.get("principal") or 0)
                c.execute("INSERT INTO bodegas (empresa_id,nombre,codigo,principal,estado,created_at) VALUES (?,?,?,?,?,?)",
                          (eid, nombre, d.get("codigo",""), principal, "ACTIVO", now_ec()))
            c.commit(); c.close(); return self._j({"ok":True})

        elif p == "/api/eliminar_bodega":
            c = db(); c.execute("UPDATE bodegas SET estado='INACTIVO' WHERE id=? AND empresa_id=?", (body.get("id"), eid))
            c.commit(); c.close(); return self._j({"ok":True})

        elif p == "/api/inventario_movimiento":
            d = body; tipo = (d.get("tipo") or "AJUSTE").upper()
            pid = int(d.get("producto_id") or 0)
            cant = round(float(d.get("cantidad") or 0), 4)
            fecha = d.get("fecha") or today_ec()
            c = db(); cfg = _cfg_contable(c, eid)
            prod = rd(c.execute("SELECT id,nombre,stock,costo,tipo,cuenta_inventario FROM productos WHERE id=? AND empresa_id=?", (pid, eid)).fetchone())
            if not prod: c.close(); return self._j({"ok":False,"error":"Producto no encontrado"})
            if str(prod.get("tipo","PRODUCTO")).upper() == "SERVICIO":
                c.close(); return self._j({"ok":False,"error":"Los servicios no manejan stock"})
            bod = int(d.get("bodega_id") or 0) or _bodega_principal(c, eid)
            bod_dest = int(d.get("bodega_destino_id") or 0)
            st_ant = float(prod.get("stock") or 0)
            costo_u = float(d.get("costo_unit") if d.get("costo_unit") not in (None,"") else (prod.get("costo") or 0))
            cta_inv = (prod.get("cuenta_inventario") or "").strip() or cfg["cta_inventario"]
            gen = bool(d.get("generar_asiento"))
            contra = (d.get("cuenta_contrapartida") or "").strip()
            motivo = d.get("motivo","") or tipo.title()
            aid = 0
            if tipo == "TRASLADO":
                if not bod_dest or bod_dest == bod: c.close(); return self._j({"ok":False,"error":"Selecciona bodega destino distinta"})
                _stock_bodega_mov(c, eid, pid, bod, -cant)
                _stock_bodega_mov(c, eid, pid, bod_dest, cant)
                st_new = st_ant  # total no cambia
                c.execute("""INSERT INTO stock_movimientos (empresa_id,producto_id,tipo,cantidad,stock_antes,stock_despues,referencia_tipo,notas,fecha,usuario_id,bodega_id,bodega_destino_id)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""", (eid,pid,"TRASLADO",cant,st_ant,st_new,"INVENTARIO",motivo,fecha,sess["usuario_id"],bod,bod_dest))
            else:
                if tipo == "INGRESO":   delta = cant
                elif tipo == "EGRESO":  delta = -cant
                else:  # AJUSTE: 'cantidad' es la EXISTENCIA FINAL deseada
                    delta = round(cant - st_ant, 4)
                st_new = round(st_ant + delta, 4)
                c.execute("UPDATE productos SET stock=? WHERE id=?", (st_new, pid))
                _stock_bodega_mov(c, eid, pid, bod, delta)
                valor = round(abs(delta) * costo_u, 2)
                if gen and valor > 0 and contra:
                    if delta > 0:  # entra inventario
                        aid = generar_asiento_auto(c, eid, sess["usuario_id"], fecha, "Inventario "+tipo+" — "+str(prod.get("nombre")), "INVENTARIO", pid, [(cta_inv, valor, 0),(contra, 0, valor)], forzar=True)
                    else:          # sale inventario
                        aid = generar_asiento_auto(c, eid, sess["usuario_id"], fecha, "Inventario "+tipo+" — "+str(prod.get("nombre")), "INVENTARIO", pid, [(contra, valor, 0),(cta_inv, 0, valor)], forzar=True)
                c.execute("""INSERT INTO stock_movimientos (empresa_id,producto_id,tipo,cantidad,stock_antes,stock_despues,referencia_tipo,notas,fecha,usuario_id,bodega_id,asiento_id)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""", (eid,pid,tipo,delta,st_ant,st_new,"INVENTARIO",motivo,fecha,sess["usuario_id"],bod,aid))
            c.commit(); c.close()
            return self._j({"ok":True,"stock":st_new,"asiento_id":aid})

        elif p == "/api/aplicar_anticipo":
            d = body; tipo = (d.get("tipo") or "CLIENTE").upper()
            ter = int(d.get("tercero_id") or 0); doc_id = int(d.get("doc_id") or 0)
            monto = round(float(d.get("monto") or 0), 2)
            if not ter or not doc_id or monto <= 0:
                return self._j({"ok":False,"error":"Tercero, documento y monto son requeridos"})
            c = db(); cfg = _cfg_contable(c, eid); fecha = d.get("fecha") or today_ec()
            aplicado = float(c.execute("SELECT COALESCE(SUM(monto),0) FROM aplicaciones_anticipo WHERE empresa_id=? AND tipo=? AND tercero_id=? AND estado='ACTIVO'", (eid, tipo, ter)).fetchone()[0] or 0)
            if tipo == "CLIENTE":
                recibido = float(c.execute("SELECT COALESCE(SUM(monto),0) FROM comprobantes_ingreso WHERE empresa_id=? AND aplicar_a='ANTICIPO' AND cliente_id=? AND estado!='ANULADO'", (eid, ter)).fetchone()[0] or 0)
            else:
                recibido = float(c.execute("SELECT COALESCE(SUM(monto),0) FROM comprobantes_egreso WHERE empresa_id=? AND aplicar_a='ANTICIPO' AND proveedor_id=? AND estado!='ANULADO'", (eid, ter)).fetchone()[0] or 0)
            disponible = round(recibido - aplicado, 2)
            if monto > disponible + 0.01:
                c.close(); return self._j({"ok":False,"error":"El anticipo disponible es $%.2f" % disponible})
            if tipo == "CLIENTE":
                doc = rd(c.execute("SELECT numero,total FROM facturas WHERE id=? AND empresa_id=?", (doc_id, eid)).fetchone())
                num = (doc.get("numero") if doc else str(doc_id))
                aid = generar_asiento_auto(c, eid, sess["usuario_id"], fecha,
                    "Aplicación de anticipo a factura " + str(num), "APLIC_ANTICIPO", doc_id,
                    [(cfg["cta_anticipo_clientes"], monto, 0), (cfg["cta_cxc"], 0, monto)], forzar=True)
                if doc and monto >= round(float(doc.get("total") or 0),2) - 0.01:
                    c.execute("UPDATE facturas SET estado='PAGADA' WHERE id=? AND empresa_id=?", (doc_id, eid))
            else:
                doc = rd(c.execute("SELECT numero,total FROM compras WHERE id=? AND empresa_id=?", (doc_id, eid)).fetchone())
                num = (doc.get("numero") if doc else str(doc_id))
                aid = generar_asiento_auto(c, eid, sess["usuario_id"], fecha,
                    "Aplicación de anticipo a compra " + str(num), "APLIC_ANTICIPO", doc_id,
                    [(cfg["cta_cxp"], monto, 0), (cfg["cta_anticipo_proveedores"], 0, monto)], forzar=True)
                if doc and monto >= round(float(doc.get("total") or 0),2) - 0.01:
                    c.execute("UPDATE compras SET estado_pago='PAGADA' WHERE id=? AND empresa_id=?", (doc_id, eid))
            c.execute("""INSERT INTO aplicaciones_anticipo (empresa_id,tipo,tercero_id,doc_id,doc_numero,monto,fecha,asiento_id,estado,usuario_id,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)""", (eid, tipo, ter, doc_id, str(num), monto, fecha, aid, "ACTIVO", sess["usuario_id"], now_ec()))
            c.commit(); c.close()
            return self._j({"ok":True,"asiento_id":aid})

        elif p == "/api/cuenta_bancaria":
            d = body; iid = d.get("id")
            campos = (d.get("banco","") or "", d.get("numero_cuenta","") or "", (d.get("tipo") or "CORRIENTE"),
                d.get("titular","") or "", d.get("cuenta_contable","") or "", int(d.get("secuencia_cheque") or 1),
                float(d.get("saldo_inicial") or 0), (d.get("estado") or "ACTIVO"))
            c = db()
            if iid:
                c.execute("""UPDATE cuentas_bancarias SET banco=?,numero_cuenta=?,tipo=?,titular=?,cuenta_contable=?,
                    secuencia_cheque=?,saldo_inicial=?,estado=? WHERE id=? AND empresa_id=?""", campos + (iid, eid))
            else:
                c.execute("""INSERT INTO cuentas_bancarias (banco,numero_cuenta,tipo,titular,cuenta_contable,
                    secuencia_cheque,saldo_inicial,estado,empresa_id,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    campos + (eid, now_ec()))
                iid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            c.commit(); c.close()
            return self._j({"ok":True,"id":iid})

        elif p == "/api/eliminar_cuenta_bancaria":
            c = db()
            n = c.execute("SELECT COUNT(*) FROM movimientos_banco WHERE empresa_id=? AND cuenta_bancaria_id=? AND estado='ACTIVO'", (eid, body.get("id"))).fetchone()[0]
            if n > 0:
                c.close(); return self._j({"ok":False,"error":"La cuenta tiene movimientos; no se puede eliminar. Puedes inactivarla."})
            c.execute("DELETE FROM cuentas_bancarias WHERE id=? AND empresa_id=?", (body.get("id"), eid))
            c.commit(); c.close(); return self._j({"ok":True})

        elif p == "/api/comprobante_egreso":
            d = body; c = db()
            origen_fondos = (d.get("origen_fondos") or "BANCO").upper()
            es_banco = (origen_fondos == "BANCO")
            cta_id = int(d.get("cuenta_bancaria_id") or 0)
            if es_banco and not cta_id: c.close(); return self._j({"ok":False,"error":"Selecciona la cuenta bancaria"})
            monto = round(float(d.get("monto") or 0), 2)
            if monto <= 0: c.close(); return self._j({"ok":False,"error":"Monto inválido"})
            fecha = d.get("fecha") or today_ec()
            forma = (d.get("forma_pago") or "CHEQUE").upper()
            aplicar = (d.get("aplicar_a") or "CXP").upper()
            cfg = _cfg_contable(c, eid)
            # Cuenta de origen (Haber): banco / caja / caja chica
            if es_banco:
                cta_origen = _cta_banco(c, eid, cta_id)
            elif origen_fondos == "CAJA_CHICA":
                cta_origen = cfg["cta_caja_chica"]; forma = "CAJA CHICA"
            else:
                cta_origen = cfg["cta_caja"]; forma = "EFECTIVO"
            cheque_num = ""
            if es_banco and forma == "CHEQUE":
                cheque_num = d.get("cheque_numero") or _next_cheque(c, eid, cta_id)
            benef = d.get("beneficiario","") or ""
            concepto = d.get("concepto","") or "Egreso"
            compra_id = int(d.get("compra_id") or 0)
            if aplicar == "CXP":      cta_debe = cfg["cta_cxp"]
            elif aplicar == "ANTICIPO": cta_debe = cfg["cta_anticipo_proveedores"]
            else:                      cta_debe = d.get("cuenta_contrapartida") or cfg["cta_gastos"]
            numero = _num_comprobante(c, eid, "comprobantes_egreso", "EGR")
            c.execute("""INSERT INTO comprobantes_egreso (empresa_id,numero,fecha,cuenta_bancaria_id,origen_fondos,forma_pago,cheque_numero,
                beneficiario_tipo,proveedor_id,beneficiario,aplicar_a,compra_id,cuenta_contrapartida,concepto,monto,estado,usuario_id,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (eid, numero, fecha, cta_id, origen_fondos, forma, cheque_num, (d.get("beneficiario_tipo") or "PROVEEDOR"),
                 int(d.get("proveedor_id") or 0), benef, aplicar, compra_id, (d.get("cuenta_contrapartida") or ""),
                 concepto, monto, "EMITIDO", sess["usuario_id"], now_ec()))
            comp_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            aid = generar_asiento_auto(c, eid, sess["usuario_id"], fecha,
                "Egreso " + numero + " — " + concepto, "EGRESO", comp_id,
                [(cta_debe, monto, 0), (cta_origen, 0, monto)], forzar=True)
            # Solo los egresos por BANCO generan movimiento bancario (para conciliación)
            if es_banco:
                doc = ("Cheque " + cheque_num) if forma == "CHEQUE" else (forma.title())
                _mov_banco(c, eid, cta_id, fecha, "EGRESO", concepto, benef, 0, monto, doc, "EGRESO", comp_id, aid, sess["usuario_id"])
            if aplicar == "CXP" and compra_id:
                c.execute("UPDATE compras SET estado_pago='PAGADA' WHERE id=? AND empresa_id=?", (compra_id, eid))
            c.execute("UPDATE comprobantes_egreso SET asiento_id=? WHERE id=?", (aid, comp_id))
            c.commit(); c.close()
            return self._j({"ok":True,"id":comp_id,"numero":numero,"cheque":cheque_num})

        elif p == "/api/comprobante_ingreso":
            d = body; c = db()
            cta_id = int(d.get("cuenta_bancaria_id") or 0)
            if not cta_id: c.close(); return self._j({"ok":False,"error":"Selecciona la cuenta bancaria"})
            monto = round(float(d.get("monto") or 0), 2)
            if monto <= 0: c.close(); return self._j({"ok":False,"error":"Monto inválido"})
            fecha = d.get("fecha") or today_ec()
            forma = (d.get("forma") or "DEPOSITO").upper()
            aplicar = (d.get("aplicar_a") or "CXC").upper()
            cfg = _cfg_contable(c, eid); cta_bco = _cta_banco(c, eid, cta_id)
            origen = d.get("origen","") or ""
            concepto = d.get("concepto","") or "Ingreso"
            cli_id = int(d.get("cliente_id") or 0)
            fac_id = int(d.get("factura_id") or 0)
            if aplicar == "CXC":      cta_haber = cfg["cta_cxc"]
            elif aplicar == "ANTICIPO": cta_haber = cfg["cta_anticipo_clientes"]
            else:                      cta_haber = d.get("cuenta_contrapartida") or cfg["cta_ingreso_financiero"]
            numero = _num_comprobante(c, eid, "comprobantes_ingreso", "ING")
            c.execute("""INSERT INTO comprobantes_ingreso (empresa_id,numero,fecha,cuenta_bancaria_id,forma,referencia,
                origen_tipo,cliente_id,origen,aplicar_a,factura_id,cuenta_contrapartida,concepto,monto,estado,usuario_id,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (eid, numero, fecha, cta_id, forma, (d.get("referencia") or ""), (d.get("origen_tipo") or "CLIENTE"),
                 cli_id, origen, aplicar, fac_id, (d.get("cuenta_contrapartida") or ""), concepto, monto, "EMITIDO",
                 sess["usuario_id"], now_ec()))
            comp_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            aid = generar_asiento_auto(c, eid, sess["usuario_id"], fecha,
                "Ingreso " + numero + " — " + concepto, "INGRESO", comp_id,
                [(cta_bco, monto, 0), (cta_haber, 0, monto)], forzar=True)
            _mov_banco(c, eid, cta_id, fecha, "INGRESO", concepto, origen, monto, 0, (d.get("referencia") or forma.title()), "INGRESO", comp_id, aid, sess["usuario_id"])
            # Afectar cartera del cliente (cobro o anticipo a favor)
            if aplicar in ("CXC","ANTICIPO") and cli_id:
                last = rd(c.execute("SELECT saldo FROM cuentas_cobrar WHERE empresa_id=? AND cliente_id=? ORDER BY id DESC LIMIT 1",(eid,cli_id)).fetchone())
                saldo_ant = last["saldo"] if last else 0
                nuevo = round(saldo_ant - monto, 2)
                tip = "ANTICIPO" if aplicar == "ANTICIPO" else "PAGO"
                c.execute("""INSERT INTO cuentas_cobrar (empresa_id,cliente_id,factura_id,tipo,concepto,monto,saldo,fecha,usuario_id,estado,referencia,created_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (eid, cli_id, (fac_id or None), tip, concepto, -monto, nuevo, fecha, sess["usuario_id"], "PAGADO", numero, now_ec()))
                if fac_id:
                    c.execute("UPDATE facturas SET estado='PAGADA' WHERE id=? AND empresa_id=?", (fac_id, eid))
            c.execute("UPDATE comprobantes_ingreso SET asiento_id=? WHERE id=?", (aid, comp_id))
            c.commit(); c.close()
            return self._j({"ok":True,"id":comp_id,"numero":numero})

        elif p == "/api/mov_banco_ncnd":
            d = body; c = db()
            cta_id = int(d.get("cuenta_bancaria_id") or 0); monto = round(float(d.get("monto") or 0), 2)
            tipo = (d.get("tipo") or "NC").upper()  # NC=acredita banco | ND=debita banco
            if not cta_id or monto <= 0: c.close(); return self._j({"ok":False,"error":"Cuenta y monto requeridos"})
            fecha = d.get("fecha") or today_ec(); concepto = d.get("concepto","") or ("Nota " + tipo)
            cfg = _cfg_contable(c, eid); cta_bco = _cta_banco(c, eid, cta_id)
            if tipo == "NC":
                lineas = [(cta_bco, monto, 0), (cfg["cta_ingreso_financiero"], 0, monto)]
                ing, egr, mtipo = monto, 0, "NC_BANCO"
            else:
                lineas = [(cfg["cta_gasto_bancario"], monto, 0), (cta_bco, 0, monto)]
                ing, egr, mtipo = 0, monto, "ND_BANCO"
            aid = generar_asiento_auto(c, eid, sess["usuario_id"], fecha, "Nota "+tipo+" banco — "+concepto, "BANCO", 0, lineas, forzar=True)
            _mov_banco(c, eid, cta_id, fecha, mtipo, concepto, d.get("referencia","") or "", ing, egr, d.get("referencia","") or ("Nota "+tipo), mtipo, 0, aid, sess["usuario_id"])
            c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/deposito_banco":
            d = body; c = db()
            cta_id = int(d.get("cuenta_bancaria_id") or 0); monto = round(float(d.get("monto") or 0), 2)
            if not cta_id or monto <= 0: c.close(); return self._j({"ok":False,"error":"Cuenta y monto requeridos"})
            fecha = d.get("fecha") or today_ec(); concepto = d.get("concepto","") or "Depósito a banco"
            cfg = _cfg_contable(c, eid); cta_bco = _cta_banco(c, eid, cta_id)
            aid = generar_asiento_auto(c, eid, sess["usuario_id"], fecha, "Depósito bancario — "+concepto, "BANCO", 0,
                [(cta_bco, monto, 0), (cfg["cta_caja"], 0, monto)], forzar=True)
            _mov_banco(c, eid, cta_id, fecha, "DEPOSITO", concepto, d.get("referencia","") or "", monto, 0, d.get("referencia","") or "Depósito", "DEPOSITO", 0, aid, sess["usuario_id"])
            c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/conciliar_movimiento":
            c = db()
            mv = rd(c.execute("SELECT estado_concil FROM movimientos_banco WHERE id=? AND empresa_id=?", (body.get("id"), eid)).fetchone())
            if not mv: c.close(); return self._j({"ok":False,"error":"Movimiento no encontrado"})
            nuevo = "PENDIENTE" if mv["estado_concil"] == "CONCILIADO" else "CONCILIADO"
            c.execute("UPDATE movimientos_banco SET estado_concil=?, fecha_concil=? WHERE id=? AND empresa_id=?",
                      (nuevo, (today_ec() if nuevo == "CONCILIADO" else ""), body.get("id"), eid))
            c.commit(); c.close()
            return self._j({"ok":True,"estado":nuevo})

        elif p == "/api/anular_comprobante_banco":
            d = body; tipo = (d.get("tipo") or "EGRESO").upper(); cid = d.get("id"); c = db()
            tabla = "comprobantes_egreso" if tipo == "EGRESO" else "comprobantes_ingreso"
            c.execute("UPDATE " + tabla + " SET estado='ANULADO' WHERE id=? AND empresa_id=?", (cid, eid))
            c.execute("UPDATE movimientos_banco SET estado='ANULADO' WHERE empresa_id=? AND origen_tipo=? AND origen_id=?", (eid, tipo, cid))
            revertir_asiento_auto(c, eid, tipo, cid)
            c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/anular_nomina":
            rid = body.get("id"); c = db()
            c.execute("UPDATE roles_nomina SET estado='ANULADO' WHERE id=? AND empresa_id=?", (rid, eid))
            revertir_asiento_auto(c, eid, "NOMINA", rid); c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/comprobante_cv":
            c = db()
            det = body.get("detalle", [])
            if not det:
                c.close(); return self._j({"ok":False,"error":"Agrega al menos un ítem"})
            s15=s5=s0=0.0; tot_abono=0.0; lineas=[]
            for d in det:
                cant = float(d.get("cantidad",1) or 0)
                precio = float(d.get("precio",0) or 0)
                desc = float(d.get("desc_pct",0) or 0)
                abono = float(d.get("abono",0) or 0)
                tarifa = float(d.get("iva_tarifa",0) or 0)
                base = round(cant*precio*(1-desc/100.0) - abono, 2)
                tot_abono += abono
                if abs(tarifa-15)<0.01: s15 += base
                elif abs(tarifa-5)<0.01: s5 += base
                else: s0 += base
                lineas.append((cant, d.get("unidad","Unid."), d.get("codigo",""), d.get("bien_servicio",""),
                               d.get("detalle",""), precio, d.get("ret_ir",""), desc, abono, tarifa, base))
            s15=round(s15,2); s5=round(s5,2); s0=round(s0,2)
            iva15=round(s15*0.15,2); iva5=round(s5*0.05,2)
            total=round(s15+s5+s0+iva15+iva5,2); saldo=total
            fecha_cv = body.get("fecha_emision") or today_ec()
            pref = fecha_cv.replace("-","")[:6]
            n = c.execute("SELECT COUNT(*)+1 FROM comprobantes_cv WHERE empresa_id=?", (eid,)).fetchone()[0]
            numero = pref + str(n).zfill(6)
            uname = rd(c.execute("SELECT username FROM usuarios WHERE id=?", (sess["usuario_id"],)).fetchone())
            c.execute("""INSERT INTO comprobantes_cv
                (empresa_id,numero,fecha_emision,vencimiento_dias,documento,cliente_nombre,cliente_ci,
                 cliente_email,telefonos,vendedor,estado,bodega,direccion,descripcion,subtotal_15,subtotal_5,subtotal_0,
                 iva_15,iva_5,total,total_abono,saldo,usuario_id,usuario_nombre,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                [eid, numero, fecha_cv, int(body.get("vencimiento_dias",0) or 0), body.get("documento",""),
                 body.get("cliente_nombre",""), body.get("cliente_ci",""),
                 body.get("cliente_email",""), body.get("telefonos",""),
                 body.get("vendedor",""), body.get("estado","pendiente"), body.get("bodega",""),
                 body.get("direccion",""), body.get("descripcion",""), s15, s5, s0, iva15, iva5, total,
                 round(tot_abono,2), saldo, sess["usuario_id"], (uname["username"] if uname else ""), now_ec()])
            cvid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            for ln in lineas:
                c.execute("""INSERT INTO comprobante_cv_det
                    (comprobante_id,cantidad,unidad,codigo,bien_servicio,detalle,precio,ret_ir,desc_pct,abono,iva_tarifa,subtotal)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                    [cvid] + list(ln))
            c.commit(); c.close()
            return self._j({"ok":True,"id":cvid,"numero":numero})

        elif p == "/api/anular_comprobante_cv":
            c = db()
            c.execute("UPDATE comprobantes_cv SET anulado=1 WHERE id=? AND empresa_id=?", (body.get("id"),eid))
            c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/producto_foto":
            pid = int(body.get("producto_id") or 0)
            if not pid:
                return self._j({"ok": False, "error": "Falta el producto"})
            c = db()
            existe = c.execute("SELECT id FROM productos WHERE id=? AND empresa_id=?", (pid, eid)).fetchone()
            if not existe:
                c.close(); return self._j({"ok": False, "error": "Producto no encontrado"})
            if body.get("quitar"):
                try:
                    r = _foto_ruta(eid, pid)
                    if r.exists(): r.unlink()
                except Exception:
                    pass
                c.execute("UPDATE productos SET foto='' WHERE id=?", (pid,))
                c.commit(); c.close()
                return self._j({"ok": True, "quitada": True})
            b64 = str(body.get("imagen_base64") or "")
            if "," in b64[:120]:
                b64 = b64.split(",", 1)[1]
            try:
                crudo = base64.b64decode(b64)
            except Exception:
                c.close(); return self._j({"ok": False, "error": "La imagen no se pudo leer"})
            if not crudo:
                c.close(); return self._j({"ok": False, "error": "No se recibió ninguna imagen"})
            try:
                tam = _foto_guardar(eid, pid, crudo)
            except ValueError as ex:
                c.close(); return self._j({"ok": False, "error": str(ex)})
            c.execute("UPDATE productos SET foto=? WHERE id=?", (str(pid) + ".jpg", pid))
            c.commit(); c.close()
            return self._j({"ok": True, "bytes": tam, "kb": round(tam / 1024.0, 1)})

        elif p == "/api/actualizar_sistema":
            if str(sess.get("rol", "")).lower() not in ("admin", "administrador"):
                return self._j({"ok": False, "error": "Solo el administrador puede actualizar"}, 403)
            try:
                import actualizador as _act
                info = _act.consultar_version(APP_VERSION)
                if not info.get("ok") or not info.get("hay_actualizacion"):
                    return self._j({"ok": False, "error": "No hay una versión nueva"})
                # El paquete y su firma vienen del mismo archivo de versión
                crudo = _act.leer_version_completa(URL_VERSION_SERVIDOR)
                pkg = _act.paquete_de_version(crudo) if crudo else None
                if not pkg or not pkg.get("url"):
                    return self._j({"ok": False, "error": "El archivo de versión no trae el paquete"})
                # Siempre la carpeta RAÍZ (donde está index.html), aunque el
                # servidor corra desde la copia servidor/sri_server.py
                carpeta_app = Path(BASE_DIR)
                tmp = carpeta_app / "logs" / "actualizacion"
                dl = _act.descargar_y_validar(pkg, tmp, _CLAVE_PUBLICA_PEM)
                if not dl.get("ok"):
                    return self._j({"ok": False, "error": dl.get("error")})
                ap = _act.aplicar(Path(dl["ruta"]), carpeta_app, carpeta_app / "respaldos" / "programa")
                # La copia servidor/sri_server.py también recibe la versión nueva
                try:
                    import shutil
                    _copia = carpeta_app / "servidor" / "sri_server.py"
                    if _copia.exists() and (carpeta_app / "sri_server.py").exists():
                        shutil.copy2(carpeta_app / "sri_server.py", _copia)
                except Exception as _e:
                    log.warning("No se pudo copiar a servidor/: %s", _e)
                log.info("Actualizado a %s (respaldo: %s)", pkg.get("version"), ap.get("respaldo"))
                _reiniciar_servidor_luego()
                return self._j({"ok": True, "version": pkg.get("version"),
                                "reinicio": True, "archivos": ap.get("archivos")})
            except Exception as ex:
                log.error("Error al actualizar: %s", ex, exc_info=True)
                return self._j({"ok": False, "error": "No se pudo actualizar: " + str(ex)}, 500)

        elif p == "/api/prestamo_empleado":
            """Préstamo o anticipo a un empleado.

            Deja el comprobante de egreso (con su número y, si es cheque,
            su movimiento bancario para la conciliación), el asiento contra
            la cuenta de anticipos a empleados, y la novedad de nómina para
            que se descuente del rol.
            """
            d = body
            emp_id = int(d.get("empleado_id") or 0)
            monto = round(float(d.get("monto") or 0), 2)
            fecha = str(d.get("fecha") or today_ec())[:10]
            forma = str(d.get("forma_pago") or "EFECTIVO").upper()
            tipo_mov = str(d.get("tipo") or "ANTICIPO").upper()   # ANTICIPO o PRESTAMO
            cuotas = max(1, int(d.get("cuotas") or 1))
            if not emp_id or monto <= 0:
                return self._j({"ok": False, "error": "Elija el empleado y escriba el monto"})
            c = db()
            emple = rd(c.execute("SELECT * FROM empleados WHERE id=? AND empresa_id=?",
                                 (emp_id, eid)).fetchone())
            if not emple:
                c.close(); return self._j({"ok": False, "error": "Empleado no encontrado"})
            cfg = _cfg_contable(c, eid)
            cta_emp = str(d.get("cuenta_contable") or "").strip() or \
                      cfg.get("cta_anticipos_empleados") or "1.1.03.02"
            es_banco = forma in ("CHEQUE", "TRANSFERENCIA")
            cta_id = int(d.get("cuenta_bancaria_id") or 0)
            if es_banco and not cta_id:
                c.close(); return self._j({"ok": False, "error": "Elija la cuenta bancaria"})
            cta_origen = cfg.get("cta_caja", "1.1.01.01")
            ctab = {}
            if es_banco:
                ctab = rd(c.execute("SELECT * FROM cuentas_bancarias WHERE id=? AND empresa_id=?",
                                    (cta_id, eid)).fetchone()) or {}
                if not ctab:
                    c.close(); return self._j({"ok": False, "error": "Cuenta bancaria no encontrada"})
                cta_origen = ctab.get("cuenta_contable") or cfg.get("cta_bancos", "1.1.01.02")
            cheque_num = ""
            if forma == "CHEQUE":
                cheque_num = str(d.get("cheque_numero") or "").strip() or _next_cheque(c, eid, cta_id)
            concepto = str(d.get("concepto") or "").strip() or \
                       (("Anticipo de sueldo a " if tipo_mov == "ANTICIPO" else "Préstamo a ") +
                        str(emple.get("nombres") or ""))
            numero = _num_comprobante(c, eid, "comprobantes_egreso", "EGR")
            c.execute("""INSERT INTO comprobantes_egreso (empresa_id,numero,fecha,cuenta_bancaria_id,origen_fondos,
                forma_pago,cheque_numero,beneficiario_tipo,proveedor_id,empleado_id,beneficiario,aplicar_a,
                compra_id,cuenta_contrapartida,concepto,monto,estado,usuario_id,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (eid, numero, fecha, (cta_id if es_banco else 0), ("BANCO" if es_banco else "CAJA"),
                 forma, cheque_num, "EMPLEADO", 0, emp_id, str(emple.get("nombres") or ""),
                 "CUENTA", 0, cta_emp, concepto, monto, "EMITIDO", sess["usuario_id"], now_ec()))
            comp_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            aid = 0
            try:
                aid = generar_asiento_auto(c, eid, sess["usuario_id"], fecha,
                                           "Egreso " + numero + " — " + concepto,
                                           "EGRESO", comp_id,
                                           [(cta_emp, monto, 0), (cta_origen, 0, monto)], forzar=True)
                c.execute("UPDATE comprobantes_egreso SET asiento_id=? WHERE id=?", (aid or 0, comp_id))
            except Exception as ex:
                log.warning("asiento prestamo empleado: %s", ex)
            if es_banco:
                doc = ("Cheque " + cheque_num) if forma == "CHEQUE" else forma.title()
                _mov_banco(c, eid, cta_id, fecha, "EGRESO", concepto, str(emple.get("nombres") or ""),
                           0, monto, doc, "EGRESO", comp_id, aid, sess["usuario_id"])
            # Novedad de nómina: así se descuenta en el rol del período
            per = str(d.get("periodo") or fecha[:7])
            try:
                c.execute("""INSERT INTO nomina_novedades
                    (empresa_id,empleado_id,periodo,tipo,concepto,valor,cuotas,observacion,estado,created_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    (eid, emp_id, per, tipo_mov, concepto, monto, cuotas,
                     "Egreso " + numero, "ACTIVO", now_ec()))
            except Exception as ex:
                log.warning("novedad de nomina: %s", ex)
            c.commit(); c.close()
            return self._j({"ok": True, "id": comp_id, "numero": numero,
                            "cheque": cheque_num, "periodo": per})

        elif p == "/api/etiquetas_pdf":
            # La cola llega como [{id, copias}]; también se acepta la lista simple
            cola = body.get("items") or []
            copias_por_id = {}
            ids = body.get("ids") or []
            if cola:
                ids = []
                for x in cola:
                    try:
                        pid = int(x.get("id"))
                    except Exception:
                        continue
                    ids.append(pid)
                    copias_por_id[pid] = max(1, int(x.get("copias") or 1))
            c = db()
            if ids:
                marcas = ",".join("?" * len(ids))
                filas = rl(c.execute("SELECT * FROM productos WHERE empresa_id=? AND id IN (%s) ORDER BY nombre"
                                     % marcas, [eid] + [int(x) for x in ids]).fetchall())
            else:
                filas = rl(c.execute("""SELECT * FROM productos WHERE empresa_id=? AND IFNULL(activo,1)=1
                                        ORDER BY nombre LIMIT 500""", (eid,)).fetchall())
            # A los que no tienen código se les genera uno, si se pide
            if body.get("generar_codigos"):
                base = int(c.execute("SELECT IFNULL(MAX(id),0) FROM productos WHERE empresa_id=?",
                                     (eid,)).fetchone()[0])
                for f in filas:
                    if not str(f.get("codigo") or "").strip():
                        nuevo = "P" + str(f["id"]).zfill(5)
                        c.execute("UPDATE productos SET codigo=? WHERE id=?", (nuevo, f["id"]))
                        f["codigo"] = nuevo
                c.commit()
            c.close()
            if not filas:
                return self._j({"ok": False, "error": "No hay productos para imprimir"})
            if copias_por_id:
                orden = {pid: i for i, pid in enumerate(ids)}
                filas.sort(key=lambda f: orden.get(f["id"], 9999))
                for f in filas:
                    f["copias"] = copias_por_id.get(f["id"], 1)
            try:
                data = _etiquetas_pdf(eid, filas, str(body.get("formato") or "a4_33"),
                                      int(body.get("copias") or 1),
                                      bool(body.get("precio", True)),
                                      bool(body.get("imagen", False)))
            except Exception as ex:
                log.error("etiquetas: %s", ex, exc_info=True)
                return self._j({"ok": False, "error": "No se pudo generar: " + str(ex)}, 500)
            total = (sum(int(f.get("copias") or 1) for f in filas) if copias_por_id
                     else len(filas) * max(1, int(body.get("copias") or 1)))
            return self._j({"ok": True, "pdf_base64": base64.b64encode(data).decode(),
                            "etiquetas": total})

        elif p == "/api/toma_abrir":
            c = db()
            bid = int(body.get("bodega_id") or 0) or _bodega_principal(c, eid)
            ya = _toma_abierta(c, eid, bid)
            if ya:
                c.close()
                return self._j({"ok": False, "error": "Ya hay una toma abierta en esa bodega",
                                "toma_id": ya["id"]})
            c.execute("""INSERT INTO tomas_fisicas (empresa_id,nombre,bodega_id,sucursal_id,estado,inicio,usuario_id,notas)
                         VALUES (?,?,?,?,?,?,?,?)""",
                      (eid, str(body.get("nombre") or ("Toma " + today_ec())), bid,
                       int(body.get("sucursal_id") or 0), "ABIERTA", now_ec(),
                       sess["usuario_id"], str(body.get("notas") or "")))
            tid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            c.commit(); c.close()
            return self._j({"ok": True, "toma_id": tid})

        elif p == "/api/toma_item":
            """Registra lo contado. Si el producto no existe, lo crea."""
            tid = int(body.get("toma_id") or 0)
            c = db()
            toma = rd(c.execute("SELECT * FROM tomas_fisicas WHERE id=? AND empresa_id=? AND estado='ABIERTA'",
                                (tid, eid)).fetchone())
            if not toma:
                c.close(); return self._j({"ok": False, "error": "No hay una toma abierta"})
            cod = str(body.get("codigo") or "").strip()
            nom = str(body.get("nombre") or "").strip()
            cant = float(body.get("cantidad") or 0)
            precio = float(body.get("precio") or 0)
            costo = float(body.get("costo") or 0)
            pid = int(body.get("producto_id") or 0)
            nuevo = 0
            if not pid and cod:
                r = c.execute("SELECT id FROM productos WHERE empresa_id=? AND codigo=?", (eid, cod)).fetchone()
                if r:
                    pid = r[0]
            if not pid:
                if not nom:
                    c.close(); return self._j({"ok": False, "error": "Escriba el nombre del producto"})
                cfgp = _cfg_contable(c, eid)
                c.execute("""INSERT INTO productos (empresa_id,codigo,nombre,precio,costo,stock,unidad,activo,
                             tipo,graba_iva,iva_porcentaje,cuenta_inventario,cuenta_ingreso,cuenta_costo)
                             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                          (eid, cod, nom, precio, costo, 0, "unidad", 1, "PRODUCTO", 1, 15,
                           cfgp.get("cta_inventario", "1.1.03.01"), cfgp["cta_ventas"], cfgp["cta_gastos"]))
                pid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                nuevo = 1
            else:
                if nom or precio or costo:
                    sets, vals = [], []
                    if nom: sets.append("nombre=?"); vals.append(nom)
                    if precio: sets.append("precio=?"); vals.append(precio)
                    if costo: sets.append("costo=?"); vals.append(costo)
                    if sets:
                        c.execute("UPDATE productos SET " + ",".join(sets) + " WHERE id=?", vals + [pid])
            prev = rd(c.execute("SELECT * FROM toma_items WHERE toma_id=? AND producto_id=?",
                                (tid, pid)).fetchone())
            if prev and body.get("sumar"):
                cant = float(prev.get("cantidad") or 0) + cant
            if prev:
                c.execute("""UPDATE toma_items SET cantidad=?, precio=?, costo=?, contado_en=?,
                             usuario_id=?, nombre=? WHERE id=?""",
                          (cant, precio, costo, now_ec(), sess["usuario_id"],
                           nom or prev.get("nombre"), prev["id"]))
                iid = prev["id"]
            else:
                c.execute("""INSERT INTO toma_items (toma_id,producto_id,codigo,nombre,cantidad,precio,costo,
                             contado_en,usuario_id,nuevo) VALUES (?,?,?,?,?,?,?,?,?,?)""",
                          (tid, pid, cod, nom, cant, precio, costo, now_ec(), sess["usuario_id"], nuevo))
                iid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            c.commit(); c.close()
            return self._j({"ok": True, "item_id": iid, "producto_id": pid, "nuevo": nuevo,
                            "cantidad": cant})

        elif p == "/api/toma_foto":
            pid = int(body.get("producto_id") or 0)
            iid = int(body.get("item_id") or 0)
            b64 = str(body.get("imagen_base64") or "")
            if "," in b64[:120]:
                b64 = b64.split(",", 1)[1]
            if not pid or not b64:
                return self._j({"ok": False, "error": "Falta el producto o la imagen"})
            try:
                crudo = base64.b64decode(b64)
                tam = _foto_guardar(eid, pid, crudo)
            except ValueError as ex:
                return self._j({"ok": False, "error": str(ex)})
            except Exception:
                return self._j({"ok": False, "error": "La imagen no se pudo leer"})
            c = db()
            c.execute("UPDATE productos SET foto=? WHERE id=?", (str(pid) + ".jpg", pid))
            if iid:
                c.execute("UPDATE toma_items SET foto=1 WHERE id=?", (iid,))
            c.commit(); c.close()
            return self._j({"ok": True, "kb": round(tam / 1024.0, 1)})

        elif p == "/api/toma_cerrar":
            """Cierra la toma. Solo ajusta el stock si se pide aplicar."""
            tid = int(body.get("toma_id") or 0)
            aplicar = bool(body.get("aplicar"))
            c = db()
            toma, difs = _toma_diferencias(c, eid, tid)
            if not toma:
                c.close(); return self._j({"ok": False, "error": "Toma no encontrada"})
            if str(toma.get("estado")) != "ABIERTA":
                c.close(); return self._j({"ok": False, "error": "Esa toma ya fue cerrada"})
            bid = int(toma.get("bodega_id") or 0) or _bodega_principal(c, eid)
            ajustados, valor = 0, 0.0
            if aplicar:
                cfg = _cfg_contable(c, eid)
                fecha = today_ec()
                for d in difs:
                    if abs(d["diferencia"]) < 0.0001 or not d["producto_id"]:
                        continue
                    pid = d["producto_id"]
                    delta = d["diferencia"]
                    _stock_bodega_mov(c, eid, pid, bid, delta)
                    saldo = 0.0
                    r = c.execute("SELECT cantidad FROM stock_bodega WHERE producto_id=? AND bodega_id=?",
                                  (pid, bid)).fetchone()
                    saldo = float(r[0]) if r else 0.0
                    c.execute("""INSERT INTO stock_movimientos
                        (empresa_id,producto_id,tipo,cantidad,stock_antes,stock_despues,
                         referencia_id,referencia_tipo,notas,fecha,usuario_id,bodega_id)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (eid, pid, "AJUSTE_TOMA", delta, saldo - delta, saldo, tid, "TOMA",
                         "Toma física " + str(toma.get("nombre") or ""), fecha, sess["usuario_id"], bid))
                    try:
                        c.execute("UPDATE productos SET stock = IFNULL(stock,0) + ? WHERE id=?", (delta, pid))
                    except Exception:
                        pass
                    ajustados += 1
                    valor += delta * (d["costo"] or 0)
                valor = round(valor, 2)
                if abs(valor) >= 0.01:
                    try:
                        cta_inv = cfg.get("cta_inventario", "1.1.03.01")
                        cta_aju = cfg.get("cta_gastos", "5.1.01.01")
                        lineas = ([(cta_inv, valor, 0), (cta_aju, 0, valor)] if valor > 0
                                  else [(cta_aju, -valor, 0), (cta_inv, 0, -valor)])
                        aid = generar_asiento_auto(c, eid, sess["usuario_id"], fecha,
                                                   "Ajuste por toma física " + str(toma.get("nombre") or ""),
                                                   "TOMA", tid, lineas, forzar=True)
                        c.execute("UPDATE tomas_fisicas SET asiento_id=? WHERE id=?", (aid or 0, tid))
                    except Exception as ex:
                        log.warning("asiento de la toma: %s", ex)
            c.execute("UPDATE tomas_fisicas SET estado=?, cierre=? WHERE id=?",
                      ("CERRADA" if aplicar else "CERRADA_SIN_APLICAR", now_ec(), tid))
            c.commit(); c.close()
            return self._j({"ok": True, "aplicada": aplicar, "ajustados": ajustados,
                            "valor": round(valor, 2)})

        elif p == "/api/cerrar_mes":
            per = str(body.get("periodo") or "").strip()[:7]
            if len(per) != 7 or per[4] != "-":
                return self._j({"ok": False, "error": "Indique el mes como 2026-09"})
            if per >= today_ec()[:7]:
                return self._j({"ok": False, "error":
                                "No se puede cerrar el mes en curso ni uno futuro. "
                                "Cierre meses ya terminados."})
            c = db()
            ya = rd(c.execute("SELECT estado FROM cierres_mes WHERE empresa_id=? AND periodo=?",
                              (eid, per)).fetchone())
            if ya and str(ya.get("estado")) == "CERRADO":
                c.close(); return self._j({"ok": False, "error": "El mes " + per + " ya estaba cerrado"})
            # Aviso si queda algo sin autorizar en ese mes
            pend = c.execute("""SELECT COUNT(*) FROM facturas WHERE empresa_id=? AND fecha LIKE ?
                                AND IFNULL(estado,'')<>'AUTORIZADA' AND IFNULL(estado,'')<>'ANULADA'""",
                             (eid, per + "%")).fetchone()[0]
            if ya:
                c.execute("""UPDATE cierres_mes SET estado='CERRADO', cerrado_por=?, cerrado_en=?,
                             notas=? WHERE empresa_id=? AND periodo=?""",
                          (sess["usuario_id"], now_ec(), str(body.get("notas") or ""), eid, per))
            else:
                c.execute("""INSERT INTO cierres_mes (empresa_id,periodo,estado,cerrado_por,cerrado_en,notas)
                             VALUES (?,?,?,?,?,?)""",
                          (eid, per, "CERRADO", sess["usuario_id"], now_ec(), str(body.get("notas") or "")))
            c.commit(); c.close()
            return self._j({"ok": True, "periodo": per, "pendientes": int(pend or 0)})

        elif p == "/api/reabrir_mes":
            if str(sess.get("rol", "")).lower() not in ("admin", "administrador"):
                return self._j({"ok": False, "error":
                                "Solo el administrador puede reabrir un mes cerrado"}, 403)
            per = str(body.get("periodo") or "").strip()[:7]
            motivo = str(body.get("motivo") or "").strip()
            if not motivo:
                return self._j({"ok": False, "error": "Escriba el motivo de la reapertura"})
            c = db()
            c.execute("""UPDATE cierres_mes SET estado='ABIERTO', reabierto_por=?, reabierto_en=?,
                         motivo_reapertura=? WHERE empresa_id=? AND periodo=?""",
                      (sess["usuario_id"], now_ec(), motivo, eid, per))
            c.commit(); c.close()
            return self._j({"ok": True})

        elif p == "/api/cierres_config":
            c = db()
            c.execute("UPDATE empresas SET bloquear_cerrados=? WHERE id=?",
                      (1 if body.get("bloquear") else 0, eid))
            c.commit(); c.close()
            return self._j({"ok": True})

        elif p == "/api/suc_guardar":
            c = db()
            cod = re.sub(r"\D", "", str(body.get("codigo") or ""))[:3].zfill(3)
            pto = re.sub(r"\D", "", str(body.get("pto_emi") or ""))[:3].zfill(3)
            nom = str(body.get("nombre") or "").strip()
            if not nom:
                c.close(); return self._j({"ok": False, "error": "Escriba el nombre de la sucursal"})
            if cod == "000":
                c.close(); return self._j({"ok": False, "error": "El establecimiento debe ser 001, 002, etc."})
            sid = body.get("id")
            dup = c.execute("""SELECT id FROM sucursales WHERE empresa_id=? AND codigo=? AND pto_emi=?
                               AND id<>IFNULL(?,0)""", (eid, cod, pto, sid)).fetchone()
            if dup:
                c.close()
                return self._j({"ok": False, "error": "Ya existe otra sucursal con el establecimiento "
                                + cod + " y punto " + pto})
            if sid:
                c.execute("""UPDATE sucursales SET nombre=?,codigo=?,direccion=?,telefono=?,
                             pto_emi=?,estado=? WHERE id=? AND empresa_id=?""",
                          (nom, cod, str(body.get("direccion") or ""), str(body.get("telefono") or ""),
                           pto, str(body.get("estado") or "ACTIVA"), sid, eid))
            else:
                c.execute("""INSERT INTO sucursales (empresa_id,nombre,codigo,direccion,telefono,
                             pto_emi,estado,created_at) VALUES (?,?,?,?,?,?,?,?)""",
                          (eid, nom, cod, str(body.get("direccion") or ""),
                           str(body.get("telefono") or ""), pto,
                           str(body.get("estado") or "ACTIVA"), now_ec()))
                sid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            _suc_asegurar_bodega(c, eid, int(sid), nom)
            c.commit(); c.close()
            return self._j({"ok": True, "id": sid})

        elif p == "/api/suc_eliminar":
            sid = int(body.get("id") or 0); c = db()
            n = c.execute("SELECT COUNT(*) FROM facturas WHERE empresa_id=? AND sucursal_id=?",
                          (eid, sid)).fetchone()[0]
            if n:
                c.execute("UPDATE sucursales SET estado='INACTIVA' WHERE id=? AND empresa_id=?", (sid, eid))
                c.commit(); c.close()
                return self._j({"ok": True, "inactivada": True,
                                "mensaje": "Tiene %d comprobante(s) emitidos, así que se desactivó en vez de borrarla." % n})
            c.execute("UPDATE usuarios SET sucursal_id=0 WHERE sucursal_id=?", (sid,))
            c.execute("DELETE FROM sucursales WHERE id=? AND empresa_id=?", (sid, eid))
            c.commit(); c.close()
            return self._j({"ok": True})

        elif p == "/api/suc_config":
            c = db()
            c.execute("UPDATE empresas SET usa_sucursales=?, suc_bloquea_stock=? WHERE id=?",
                      (1 if body.get("activo") else 0,
                       1 if body.get("bloquea_stock", 1) else 0, eid))
            c.commit(); c.close()
            return self._j({"ok": True})

        elif p == "/api/traspaso":
            c = db()
            try:
                n = _suc_traspaso(c, eid, sess, body.get("origen"), body.get("destino"),
                                  body.get("items") or [], str(body.get("notas") or ""))
                c.commit()
            except ValueError as ex:
                c.close(); return self._j({"ok": False, "error": str(ex)})
            except Exception as ex:
                c.close(); log.error("traspaso: %s", ex, exc_info=True)
                return self._j({"ok": False, "error": "No se pudo hacer el traspaso: " + str(ex)}, 500)
            c.close()
            return self._j({"ok": True, "movidos": n})

        elif p == "/api/sello_procesar":
            b64 = str(body.get("imagen_base64","") or "")
            if "," in b64[:120]: b64 = b64.split(",",1)[1]
            try:
                crudo = base64.b64decode(b64)
            except Exception:
                return self._j({"ok":False,"error":"La imagen no se pudo leer"})
            if not crudo:
                return self._j({"ok":False,"error":"No se recibió ninguna imagen"})
            try:
                png, tam = _sello_recortar(crudo, body)
            except Exception as ex:
                return self._j({"ok":False,"error":str(ex)})
            return self._j({"ok":True, "png_base64": base64.b64encode(png).decode(),
                            "ancho": tam[0], "alto": tam[1]})

        elif p == "/api/sello_guardar":
            b64 = str(body.get("png_base64","") or "")
            if "," in b64[:120]: b64 = b64.split(",",1)[1]
            c = db()
            if b64:
                try:
                    png = base64.b64decode(b64)
                    if not png[:4] == b"\x89PNG":
                        c.close(); return self._j({"ok":False,"error":"El sello debe ser un PNG procesado"})
                    _sello_ruta(eid).write_bytes(png)
                except Exception as ex:
                    c.close(); return self._j({"ok":False,"error":"No se pudo guardar el sello: "+str(ex)})
            pos = str(body.get("posicion","inf-der") or "inf-der")
            if pos not in SELLO_POSICIONES: pos = "inf-der"
            c.execute("""UPDATE empresas SET sello_activo=?, sello_pos=?, sello_escala=?,
                         sello_opacidad=?, sello_pagina=? WHERE id=?""",
                      (1 if body.get("activo") else 0, pos,
                       _fiva(body.get("escala"), 1.0) or 1.0,
                       _fiva(body.get("opacidad"), 0.9) or 0.9,
                       str(body.get("pagina","ultima") or "ultima"), eid))
            c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/sello_eliminar":
            try:
                r = _sello_ruta(eid)
                if r.exists(): r.unlink()
            except Exception as ex:
                return self._j({"ok":False,"error":str(ex)})
            c = db(); c.execute("UPDATE empresas SET sello_activo=0 WHERE id=?", (eid,))
            c.commit(); c.close()
            return self._j({"ok":True})

        elif p == "/api/sellar_pdf":
            c = db(); emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
            c.close()
            cfg = _sello_config(emp)
            if not cfg["activo"]:
                return self._j({"ok":False,"error":"El sello está desactivado. Actívalo en Configuración → Sello digital."})
            ruta = _sello_ruta(eid)
            if not (ruta.exists() and ruta.stat().st_size > 100):
                return self._j({"ok":False,"error":"Todavía no has cargado la imagen del sello."})
            nombre = str(body.get("nombre","") or "documento.pdf")
            try:
                origen = str(body.get("origen","") or "").strip()
                if origen == "comprobante_cv":
                    cv = _cv_cargar(eid, int(body.get("id") or 0))
                    pdf = _cv_pdf_bytes(cv)
                    nombre = _cv_nombre_archivo(cv, "pdf")
                else:
                    b64 = str(body.get("pdf_base64","") or "")
                    if "," in b64[:80]: b64 = b64.split(",",1)[1]
                    pdf = base64.b64decode(b64)
                if not pdf:
                    return self._j({"ok":False,"error":"No se recibió ningún PDF"})
                sellado = _sellar_pdf_bytes(pdf, ruta.read_bytes(), {
                    "posicion": body.get("posicion", cfg["posicion"]),
                    "escala":   body.get("escala",   cfg["escala"]),
                    "opacidad": body.get("opacidad", cfg["opacidad"]),
                    "pagina":   body.get("pagina",   cfg["pagina"])})
            except Exception as ex:
                return self._j({"ok":False,"error":str(ex)})
            base_n = nombre[:-4] if nombre.lower().endswith(".pdf") else nombre
            return self._j({"ok":True, "nombre": base_n + "_sellado.pdf",
                            "pdf_base64": base64.b64encode(sellado).decode()})

        elif p == "/api/firmar_pdf":
            c = db()
            emp = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()) or {}
            c.close()
            nombre = str(body.get("nombre","") or "documento.pdf")
            origen = str(body.get("origen","") or "").strip()
            try:
                if origen == "comprobante_cv":
                    cv = _cv_cargar(eid, int(body.get("id") or 0))
                    pdf = _cv_pdf_bytes(cv)
                    nombre = _cv_nombre_archivo(cv, "pdf")
                else:
                    b64 = str(body.get("pdf_base64","") or "")
                    if "," in b64[:80]:
                        b64 = b64.split(",",1)[1]
                    pdf = base64.b64decode(b64)
                if not pdf:
                    return self._j({"ok":False,"error":"No se recibió ningún PDF"})
                firmado, finfo = _firma_pdf_bytes(pdf, emp, {
                    "pagina":    body.get("pagina","ultima"),
                    "posicion":  body.get("posicion","inf-der"),
                    "visible":   body.get("visible", True),
                    "qr":        body.get("qr","datos"),
                    "url_base":  body.get("url_base",""),
                    "razon":     body.get("razon",""),
                    "ubicacion": body.get("ubicacion",""),
                    "con_tsa":   body.get("con_tsa", False),
                    "tsa_url":   body.get("tsa_url", FIRMA_TSA_DEFAULT)})
            except Exception as ex:
                return self._j({"ok":False,"error":str(ex)})
            base_n = nombre[:-4] if nombre.lower().endswith(".pdf") else nombre
            finfo["archivo"] = base_n + "_firmado.pdf"
            finfo["usuario_id"] = sess["usuario_id"]
            if finfo.get("token"):
                _firma_registrar(eid, finfo["token"], finfo)
            return self._j({"ok":True,
                            "nombre": base_n + "_firmado.pdf",
                            "token": finfo.get("token",""),
                            "qr": finfo.get("qr",""),
                            "sha256": finfo.get("sha256",""),
                            "pdf_base64": base64.b64encode(firmado).decode()})

        elif p == "/api/firma_verificar":
            b64 = str(body.get("pdf_base64","") or "")
            if "," in b64[:80]:
                b64 = b64.split(",",1)[1]
            try:
                return self._j(_firma_pdf_info(base64.b64decode(b64)))
            except Exception as ex:
                return self._j({"ok":False,"error":str(ex)})

        elif p == "/api/comprobante_cv_email":
            destino = str(body.get("destino","") or "").strip()
            if "@" not in destino:
                return self._j({"ok":False,"error":"Escribe un correo válido"})
            try:
                cv = _cv_cargar(eid, int(body.get("id") or 0))
            except Exception as ex:
                return self._j({"ok":False,"error":str(ex)})
            res = enviar_correo_cv(cv, destino, str(body.get("mensaje","") or ""),
                                   bool(body.get("con_excel", True)))
            if res.get("ok"):
                try:
                    c = db()
                    c.execute("UPDATE comprobantes_cv SET cliente_email=? WHERE id=? AND empresa_id=?",
                              (destino, cv["id"], eid))
                    c.commit(); c.close()
                except Exception:
                    pass
            return self._j(res)

        elif p == "/api/cargar_compra_xml":
            c = db()
            try:
                info = _parse_comprobante_compra(body.get("xml",""))
            except Exception as e:
                c.close(); return self._j({"ok":False,"error":"XML inválido: " + str(e)})
            if not info:
                c.close(); return self._j({"ok":False,"error":"No es una factura electrónica válida"})
            if info["autorizacion"] and c.execute("SELECT 1 FROM compras WHERE empresa_id=? AND numero_autorizacion=?", (eid, info["autorizacion"])).fetchone():
                c.close(); return self._j({"ok":False,"dup":True,"numero":info["numero"],"error":"Ya estaba cargada"})
            prov = c.execute("SELECT id FROM proveedores WHERE empresa_id=? AND ruc_cedula=?", (eid, info["ruc"])).fetchone()
            if prov:
                pid = prov[0]
            else:
                tipo_id = "04" if len(info["ruc"]) == 13 else "05"
                c.execute("INSERT INTO proveedores (empresa_id,nombre,ruc_cedula,tipo_identificacion,created_at) VALUES (?,?,?,?,?)",
                          (eid, info["razon"] or info["ruc"], info["ruc"], tipo_id, now_ec()))
                pid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            c.execute("""INSERT INTO compras
                (empresa_id,numero,numero_autorizacion,proveedor_id,usuario_id,fecha,fecha_registro,
                 subtotal,iva,total,tipo,forma_pago,estado,estado_pago,notas,sustento,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (eid, info["numero"], info["autorizacion"], pid, sess["usuario_id"], info["fecha"], now_ec()[:10],
                 info["subtotal"], info["iva"], info["total"], "GASTO", "01", "REGISTRADA", "PENDIENTE",
                 "Carga masiva XML", "01", now_ec()))
            cid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            cfgc = _cfg_contable(c, eid)
            generar_asiento_auto(c, eid, sess["usuario_id"], info["fecha"],
                "Compra " + info["numero"] + " — " + info["razon"], "COMPRA", cid,
                [(cfgc["cta_gastos"], info["subtotal"], 0),
                 (cfgc["cta_iva_compras"], info["iva"], 0),
                 (cfgc["cta_cxp"], 0, info["total"])])
            c.commit(); c.close()
            return self._j({"ok":True,"id":cid,"numero":info["numero"],"proveedor":info["razon"],"total":info["total"]})

        elif p == "/api/preview_compras_txt":
            facs = _parse_txt_compras(body.get("txt","") or "")
            c = db()
            out = []
            n_fact = n_skip = n_dup = 0
            for f in facs:
                if not f["es_factura"]:
                    n_skip += 1; continue
                ya = bool(f["clave"] and c.execute("SELECT 1 FROM compras WHERE empresa_id=? AND numero_autorizacion=?", (eid, f["clave"])).fetchone())
                if ya: n_dup += 1
                else: n_fact += 1
                out.append({"ruc":f["ruc"],"razon":f["razon"],"serie":f["serie"],"clave":f["clave"],
                            "fecha":f["fecha"],"subtotal":f["subtotal"],"iva":f["iva"],"total":f["total"],"dup":ya})
            c.close()
            tot_sub = round(sum(x["subtotal"] for x in out), 2)
            tot_iva = round(sum(x["iva"] for x in out), 2)
            tot_tot = round(sum(x["total"] for x in out), 2)
            return self._j({"ok":True,"facturas":out,"nuevas":n_fact,"repetidas":n_dup,"omitidas":n_skip,
                            "subtotal":tot_sub,"iva":tot_iva,"total":tot_tot})

        elif p == "/api/cargar_compras_txt":
            facs = _parse_txt_compras(body.get("txt","") or "")
            c = db(); cfgc = _cfg_contable(c, eid)
            # Cuentas elegidas por el usuario (con defaults de la configuración)
            cta_gasto_glob = (body.get("cuenta_gasto") or cfgc["cta_gastos"]).strip()
            cta_iva = (body.get("cuenta_iva") or cfgc["cta_iva_compras"]).strip()
            cancel = (body.get("cancelacion") or "credito").strip()  # credito | caja | bancos
            if cancel == "caja":
                cta_haber = (body.get("cuenta_haber") or cfgc["cta_caja"]).strip(); estado_pago = "PAGADA"
            elif cancel == "bancos":
                cta_haber = (body.get("cuenta_haber") or cfgc["cta_bancos"]).strip(); estado_pago = "PAGADA"
            else:
                cta_haber = (body.get("cuenta_haber") or cfgc["cta_cxp"]).strip(); estado_pago = "PENDIENTE"
            cuentas_fila = body.get("cuentas") or {}   # { clave_acceso: cuenta_gasto }
            ok = dup = skip = err = 0
            for f in facs:
                if not f["es_factura"]:
                    skip += 1; continue
                ruc=f["ruc"]; razon=f["razon"]; serie=f["serie"]; clave=f["clave"]; fe=f["fecha"]
                subtotal=f["subtotal"]; iva=f["iva"]; total=f["total"]
                if clave and c.execute("SELECT 1 FROM compras WHERE empresa_id=? AND numero_autorizacion=?", (eid, clave)).fetchone():
                    dup += 1; continue
                prov = c.execute("SELECT id FROM proveedores WHERE empresa_id=? AND ruc_cedula=?", (eid, ruc)).fetchone()
                if prov:
                    pid = prov[0]
                else:
                    tipo_id = "04" if len(ruc) == 13 else "05"
                    c.execute("INSERT INTO proveedores (empresa_id,nombre,ruc_cedula,tipo_identificacion,created_at) VALUES (?,?,?,?,?)",
                              (eid, razon or ruc, ruc, tipo_id, now_ec()))
                    pid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                c.execute("""INSERT INTO compras
                    (empresa_id,numero,numero_autorizacion,proveedor_id,usuario_id,fecha,fecha_registro,
                     subtotal,iva,total,tipo,forma_pago,estado,estado_pago,notas,sustento,created_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (eid, serie, clave, pid, sess["usuario_id"], fe, now_ec()[:10],
                     subtotal, iva, total, "GASTO", "01", "REGISTRADA", estado_pago,
                     "Carga TXT SRI", "01", now_ec()))
                cid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                cta_gasto = (cuentas_fila.get(clave) or cta_gasto_glob).strip() or cta_gasto_glob
                generar_asiento_auto(c, eid, sess["usuario_id"], fe, "Compra " + serie + " — " + razon, "COMPRA", cid,
                    [(cta_gasto, subtotal, 0),
                     (cta_iva, iva, 0),
                     (cta_haber, 0, total)])
                ok += 1
            c.commit(); c.close()
            return self._j({"ok":True,"creadas":ok,"repetidas":dup,"omitidas":skip,"errores":err})

        elif p == "/api/probar_clave_sri":
            clave = re.sub(r"\D", "", (body.get("clave") or ""))
            if len(clave) != 49: return self._j({"ok":False,"error":"La clave debe tener 49 dígitos (recibida: "+str(len(clave))+")"})
            c0 = db()
            amb0 = str((c0.execute("SELECT ambiente FROM empresas WHERE id=?", (eid,)).fetchone() or ["2"])[0] or "2"); c0.close()
            res = {}
            for nombre, ambp in [("produccion","2"),("pruebas","1")]:
                d = _consultar_autorizacion_sri(clave, ambp, timeout=15)
                res[nombre] = {"conexion_ok": not d["error_conexion"], "error_conexion": d["error_conexion"][:200],
                               "estado": d["estado"], "numero_comprobantes": d["numero_comprobantes"],
                               "mensajes": d["mensajes"][:3], "trae_xml": bool(d["xml"]),
                               "respuesta_inicio": d["raw_inicio"][:250]}
            return self._j({"ok":True,"clave":clave,"ambiente_configurado":("produccion" if amb0=="2" else "pruebas"),"resultados":res})

        elif p == "/api/probar_sri":
            import time as _t
            resultados = {}
            for nombre, ambp in [("produccion","2"),("pruebas","1")]:
                t0 = _t.time()
                try:
                    # Consulta mínima con clave dummy: si el SRI responde (aunque diga que no existe), hay conexión
                    xml_text, estado, msg = _descargar_comprobante_sri("0"*49, ambp)
                    ms = int((_t.time()-t0)*1000)
                    if "ERROR_CONEXION" in (estado or ""):
                        resultados[nombre] = {"ok":False,"ms":ms,"detalle":msg[:150]}
                    else:
                        resultados[nombre] = {"ok":True,"ms":ms,"detalle":"El SRI respondió correctamente"}
                except Exception as ex:
                    resultados[nombre] = {"ok":False,"ms":int((_t.time()-t0)*1000),"detalle":str(ex)[:150]}
            return self._j({"ok":True,"resultados":resultados})

        elif p == "/api/diagnostico_txt":
            txt = body.get("txt","") or ""
            lines = txt.replace("\r","").split("\n")
            muestra = [l for l in lines if l.strip()][:5]
            facs = _parse_txt_emitidos(txt)
            con_clave = sum(1 for f in facs if len(f["clave"]) == 49)
            sin_clave = sum(1 for f in facs if len(f["clave"]) != 49)
            ejemplos = []
            for f in facs[:5]:
                ejemplos.append({"serie":f["serie"],"clave":f["clave"],"len_clave":len(f["clave"]),
                                 "es_factura":f["es_factura"],"total":f["total"]})
            return self._j({"ok":True,"version":APP_VERSION,"total_lineas":len(muestra),
                            "primeras_lineas":muestra,"facturas_detectadas":len(facs),
                            "con_clave_49":con_clave,"sin_clave_49":sin_clave,"ejemplos":ejemplos})

        elif p == "/api/preview_facturas_txt":
            facs = _parse_txt_emitidos(body.get("txt","") or "")
            c = db()
            out = []; t_sub = t_iva = t_tot = 0.0; nf = 0
            for f in facs:
                if not f["es_factura"]: continue
                dup = bool(c.execute("SELECT 1 FROM facturas WHERE empresa_id=? AND numero=?", (eid, f["serie"])).fetchone())
                f = dict(f); f["dup"] = dup
                out.append(f)
                if not dup:
                    nf += 1; t_sub += f["subtotal"]; t_iva += f["iva"]; t_tot += f["total"]
            c.close()
            return self._j({"facturas": out, "nuevas": nf, "total_subtotal": round(t_sub,2), "total_iva": round(t_iva,2), "total": round(t_tot,2)})

        elif p == "/api/asignar_sucursales":
            """Reparte entre las sucursales las facturas que no la tienen.

            No hace falta el PDF: el establecimiento está en el número de
            cada comprobante. Sirve para todo lo emitido antes de activar
            el módulo de sucursales.
            """
            c = db()
            solo_ver = bool(body.get("solo_ver"))
            tablas = [("facturas", "numero"), ("notas_credito", "numero"),
                      ("guias_remision", "numero"), ("liquidaciones_compra", "numero")]
            resumen = {}
            total = 0
            for tabla, campo in tablas:
                try:
                    filas = rl(c.execute("SELECT id, %s AS num, clave_acceso FROM %s "
                                         "WHERE empresa_id=? AND IFNULL(sucursal_id,0)=0" % (campo, tabla),
                                         (eid,)).fetchall())
                except Exception:
                    continue
                n = 0
                for fila in filas:
                    sid = _suc_de_numero(c, eid, fila.get("num"), fila.get("clave_acceso"))
                    if not sid:
                        continue
                    if not solo_ver:
                        c.execute("UPDATE %s SET sucursal_id=? WHERE id=?" % tabla, (sid, fila["id"]))
                    n += 1
                if n:
                    resumen[tabla] = n
                    total += n
            # Establecimientos que aparecen en los comprobantes y no tienen sucursal
            faltantes = {}
            for fila in rl(c.execute("""SELECT numero FROM facturas WHERE empresa_id=?
                                        AND IFNULL(sucursal_id,0)=0""", (eid,)).fetchall()):
                m = re.match(r"\s*(\d{3})-", str(fila.get("numero") or ""))
                if m and not _suc_por_codigo(c, eid, m.group(1), "001"):
                    faltantes[m.group(1)] = faltantes.get(m.group(1), 0) + 1
            if not solo_ver:
                c.commit()
            c.close()
            return self._j({"ok": True, "asignadas": total, "detalle": resumen,
                            "establecimientos_sin_sucursal": faltantes})

        elif p == "/api/comparar_rides_pdf":
            """Compara los RIDE con lo que ya está cargado, sin tocar nada.

            Sirve para las facturas que entraron por el TXT: ese archivo no
            trae el cliente (quedan en CONSUMIDOR FINAL) y a veces tampoco
            los valores. Aquí se ve qué cambiaría antes de aplicar.
            """
            pdfs = body.get("pdfs") or []
            if not pdfs:
                return self._j({"ok": False, "error": "No se recibió ningún PDF"})
            c = db()
            _ruc = str((rd(c.execute("SELECT ruc FROM empresas WHERE id=?", (eid,)).fetchone()) or {}).get("ruc") or "")
            filas = []
            for item in pdfs:
                nom = ""; dato = item
                if isinstance(item, dict):
                    nom = str(item.get("nombre") or ""); dato = item.get("b64") or ""
                try:
                    crudo = base64.b64decode(str(dato).split(",")[-1])
                except Exception:
                    filas.append({"archivo": nom, "ok": False, "error": "Archivo ilegible"}); continue
                try:
                    f = _parse_ride_pdf(crudo, _ruc)
                except ValueError as ex:
                    c.close(); return self._j({"ok": False, "error": str(ex)})
                if not f:
                    filas.append({"archivo": nom, "ok": False,
                                  "error": "No se pudo leer (escaneo o no es un RIDE)"}); continue
                act = None
                if f.get("clave"):
                    act = rd(c.execute("""SELECT f.*, cl.nombre as cli_nombre, cl.ruc_cedula as cli_ruc
                                          FROM facturas f LEFT JOIN clientes cl ON cl.id=f.cliente_id
                                          WHERE f.empresa_id=? AND f.clave_acceso=?""",
                                       (eid, f["clave"])).fetchone())
                if not act and f.get("numero"):
                    act = rd(c.execute("""SELECT f.*, cl.nombre as cli_nombre, cl.ruc_cedula as cli_ruc
                                          FROM facturas f LEFT JOIN clientes cl ON cl.id=f.cliente_id
                                          WHERE f.empresa_id=? AND f.numero=?""",
                                       (eid, f["numero"])).fetchone())
                _sid_pdf = _suc_de_numero(c, eid, f.get("numero"), f.get("clave"))
                _snom = ""
                if _sid_pdf:
                    _sr = rd(c.execute("SELECT codigo, nombre FROM sucursales WHERE id=?", (_sid_pdf,)).fetchone()) or {}
                    _snom = str(_sr.get("codigo") or "") + " · " + str(_sr.get("nombre") or "")
                fila = {"archivo": nom, "ok": True, "numero": f["numero"], "clave": f["clave"],
                        "sucursal": _snom, "sucursal_id": _sid_pdf,
                        "fecha": f["fecha"], "pdf_cliente": f["cliente_nombre"], "pdf_ruc": f["cliente_ruc"],
                        "pdf_subtotal": f["subtotal"], "pdf_iva": f["iva"], "pdf_total": f["total"]}
                if not act:
                    fila.update({"estado": "no_existe",
                                 "detalle": "No está cargada en el sistema"})
                    filas.append(fila); continue
                r_act = str(act.get("cli_ruc") or "")
                generico = (not r_act) or r_act.startswith("9999999999") or \
                           "CONSUMIDOR FINAL" in str(act.get("cli_nombre") or "").upper()
                difiere_val = (abs(float(act.get("total") or 0) - f["total"]) > 0.01 or
                               abs(float(act.get("subtotal") or 0) - f["subtotal"]) > 0.01 or
                               abs(float(act.get("iva") or 0) - f["iva"]) > 0.01)
                fila.update({"id": act["id"], "act_cliente": act.get("cli_nombre") or "",
                             "act_ruc": r_act, "act_subtotal": float(act.get("subtotal") or 0),
                             "act_iva": float(act.get("iva") or 0), "act_total": float(act.get("total") or 0),
                             "act_estado": act.get("estado") or "",
                             "cambia_cliente": bool(generico and f["cliente_ruc"] != r_act
                                                    and not f["cliente_ruc"].startswith("9999999999")),
                             "cambia_valores": bool(difiere_val),
                             "sin_sucursal": bool(_sid_pdf and not int(act.get("sucursal_id") or 0)),
                             "sin_clave": not str(act.get("clave_acceso") or "").strip()})
                fila["estado"] = ("actualizable" if (fila["cambia_cliente"] or fila["cambia_valores"]
                                                     or fila["sin_clave"] or fila["sin_sucursal"]) else "al_dia")
                filas.append(fila)
            c.close()
            return self._j({"ok": True, "filas": filas})

        elif p == "/api/actualizar_facturas_pdf":
            """Completa las facturas ya cargadas con lo que dice el RIDE.

            Solo toca lo que haga falta: el cliente genérico y los valores que
            no cuadran. Si cambian los valores, rehace el asiento contable,
            porque el que estaba se armó con los importes viejos.
            """
            pdfs = body.get("pdfs") or []
            hacer_cliente = body.get("cliente", True)
            hacer_valores = body.get("valores", True)
            c = db(); cfgc = _cfg_contable(c, eid)
            _ruc = str((rd(c.execute("SELECT ruc FROM empresas WHERE id=?", (eid,)).fetchone()) or {}).get("ruc") or "")
            cta_v15 = cfgc["cta_ventas"]; cta_v0 = cfgc.get("cta_ventas_0") or cfgc["cta_ventas"]
            cta_ivav = cfgc["cta_iva_ventas"]; cta_cxc = cfgc["cta_cxc"]
            n_cli = n_val = n_clave = n_asi = n_suc = 0
            sin_hallar = ilegibles = 0
            detalle = []
            for item in pdfs:
                dato = item.get("b64") if isinstance(item, dict) else item
                try:
                    crudo = base64.b64decode(str(dato).split(",")[-1])
                    f = _parse_ride_pdf(crudo, _ruc)
                except ValueError as ex:
                    c.close(); return self._j({"ok": False, "error": str(ex)})
                except Exception:
                    f = None
                if not f:
                    ilegibles += 1; continue
                act = None
                if f.get("clave"):
                    act = rd(c.execute("SELECT * FROM facturas WHERE empresa_id=? AND clave_acceso=?",
                                       (eid, f["clave"])).fetchone())
                if not act and f.get("numero"):
                    act = rd(c.execute("SELECT * FROM facturas WHERE empresa_id=? AND numero=?",
                                       (eid, f["numero"])).fetchone())
                if not act:
                    sin_hallar += 1; continue
                fid = act["id"]; cambios = []

                # ── Cliente ──
                cli_id = act.get("cliente_id")
                cnom = (f.get("cliente_nombre") or "").strip()
                cruc = (f.get("cliente_ruc") or "").strip()
                if hacer_cliente and cruc and not cruc.startswith("9999999999"):
                    actual = rd(c.execute("SELECT ruc_cedula, nombre FROM clientes WHERE id=?",
                                          (cli_id,)).fetchone()) or {}
                    r_act = str(actual.get("ruc_cedula") or "")
                    generico = (not r_act) or r_act.startswith("9999999999") or \
                               "CONSUMIDOR FINAL" in str(actual.get("nombre") or "").upper()
                    if generico and cruc != r_act:
                        cli = c.execute("SELECT id FROM clientes WHERE empresa_id=? AND ruc_cedula=?",
                                        (eid, cruc)).fetchone()
                        if cli:
                            cli_id = cli[0]
                        else:
                            tipo_id = "04" if len(cruc) == 13 else ("05" if len(cruc) == 10 else "07")
                            c.execute("""INSERT INTO clientes (empresa_id,nombre,ruc_cedula,tipo_identificacion,created_at)
                                         VALUES (?,?,?,?,?)""",
                                      (eid, cnom or "SIN NOMBRE", cruc, tipo_id, now_ec()))
                            cli_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                        c.execute("UPDATE facturas SET cliente_id=? WHERE id=?", (cli_id, fid))
                        n_cli += 1; cambios.append("cliente")

                # ── Valores ──
                tot = f["total"]; sub = f["subtotal"]; iva = f["iva"]
                difiere = (abs(float(act.get("total") or 0) - tot) > 0.01 or
                           abs(float(act.get("subtotal") or 0) - sub) > 0.01 or
                           abs(float(act.get("iva") or 0) - iva) > 0.01)
                if hacer_valores and difiere:
                    c.execute("UPDATE facturas SET subtotal=?, iva=?, total=? WHERE id=?",
                              (sub, iva, tot, fid))
                    # El detalle viejo quedó con los importes anteriores
                    try:
                        c.execute("DELETE FROM factura_items WHERE factura_id=?", (fid,))
                        for it in (f.get("items") or []):
                            c.execute("""INSERT INTO factura_items
                                (factura_id,codigo,descripcion,cantidad,precio_unitario,descuento,subtotal)
                                VALUES (?,?,?,?,?,?,?)""",
                                (fid, str(it.get("codigo","") or ""), str(it.get("descripcion","") or ""),
                                 float(it.get("cantidad",0) or 0), float(it.get("precio_unitario",0) or 0),
                                 float(it.get("descuento",0) or 0), float(it.get("subtotal",0) or 0)))
                    except Exception:
                        pass
                    n_val += 1; cambios.append("valores")
                    # Rehacer el asiento: el anterior se armó con los importes viejos
                    try:
                        revertir_asiento_auto(c, eid, "VENTA", fid)
                        lineas = [(cta_cxc, tot, 0)]
                        if f["base_15"] > 0: lineas.append((cta_v15, 0, f["base_15"]))
                        if f["base_0"] > 0:  lineas.append((cta_v0, 0, f["base_0"]))
                        if iva > 0:          lineas.append((cta_ivav, 0, iva))
                        generar_asiento_auto(c, eid, sess["usuario_id"], act.get("fecha") or f["fecha"],
                                             "Venta " + str(act.get("numero") or "") + " — " + (cnom or ""),
                                             "VENTA", fid, lineas, forzar=True)
                        n_asi += 1; cambios.append("asiento")
                    except Exception as ex:
                        log.warning("No se pudo rehacer el asiento de la factura %s: %s", fid, ex)

                # ── Sucursal, si todavía no la tiene ──
                try:
                    if not int(act.get("sucursal_id") or 0):
                        _sid = _suc_de_numero(c, eid, act.get("numero"), f.get("clave"))
                        if _sid:
                            c.execute("UPDATE facturas SET sucursal_id=? WHERE id=?", (_sid, fid))
                            n_suc += 1; cambios.append("sucursal")
                except Exception:
                    pass

                # ── Clave de acceso faltante ──
                if f.get("clave") and not str(act.get("clave_acceso") or "").strip():
                    c.execute("UPDATE facturas SET clave_acceso=?, autorizacion=COALESCE(NULLIF(autorizacion,''),?) WHERE id=?",
                              (f["clave"], f["clave"], fid))
                    n_clave += 1; cambios.append("clave")

                if cambios:
                    detalle.append({"numero": act.get("numero"), "cambios": cambios})
            c.commit(); c.close()
            return self._j({"ok": True, "clientes": n_cli, "valores": n_val,
                            "claves": n_clave, "asientos": n_asi, "sucursales": n_suc,
                            "no_encontradas": sin_hallar, "ilegibles": ilegibles,
                            "detalle": detalle[:300]})

        elif p == "/api/leer_rides_pdf":
            """Lee los RIDE y devuelve lo extraído, sin guardar nada."""
            pdfs = body.get("pdfs") or []
            if not pdfs:
                return self._j({"ok": False, "error": "No se recibió ningún PDF"})
            c = db()
            _ruc = str((rd(c.execute("SELECT ruc FROM empresas WHERE id=?", (eid,)).fetchone()) or {}).get("ruc") or "")
            existentes = set()
            for r0 in c.execute("SELECT numero FROM facturas WHERE empresa_id=?", (eid,)).fetchall():
                existentes.add(str(r0[0] or ""))
            c.close()
            filas, malos = [], 0
            for item in pdfs:
                nom = ""
                dato = item
                if isinstance(item, dict):
                    nom = str(item.get("nombre") or ""); dato = item.get("b64") or ""
                try:
                    crudo = base64.b64decode(str(dato).split(",")[-1])
                except Exception:
                    malos += 1; continue
                try:
                    f = _parse_ride_pdf(crudo, _ruc)
                except ValueError as ex:
                    return self._j({"ok": False, "error": str(ex)})
                if not f:
                    malos += 1
                    filas.append({"archivo": nom, "ok": False,
                                  "error": "No se pudo leer (PDF escaneado o no es un RIDE de factura)"})
                    continue
                f["archivo"] = nom
                f["ok"] = True
                f["duplicada"] = f.get("numero") in existentes
                filas.append(f)
            return self._j({"ok": True, "filas": filas, "ilegibles": malos})

        elif p == "/api/cargar_facturas_txt":
            facs = _parse_txt_emitidos(body.get("txt","") or "")
            c = db(); cfgc = _cfg_contable(c, eid)
            cancel = (body.get("cancelacion") or "credito").strip()  # credito | caja | bancos
            if cancel == "caja":      cta_debe = cfgc["cta_caja"];   estado_pago = "PAGADA"
            elif cancel == "bancos":  cta_debe = cfgc["cta_bancos"]; estado_pago = "PAGADA"
            else:                     cta_debe = cfgc["cta_cxc"];    estado_pago = "PENDIENTE"
            cta_v15 = cfgc["cta_ventas"]; cta_v0 = cfgc.get("cta_ventas_0") or cfgc["cta_ventas"]; cta_ivav = cfgc["cta_iva_ventas"]
            # Cliente genérico para la carga (el TXT de emitidos no trae el cliente)
            gc = c.execute("SELECT id FROM clientes WHERE empresa_id=? AND ruc_cedula=?", (eid, "9999999999999")).fetchone()
            if gc: cli_id = gc[0]
            else:
                c.execute("INSERT INTO clientes (empresa_id,nombre,ruc_cedula,tipo_identificacion,created_at) VALUES (?,?,?,?,?)",
                          (eid, "CONSUMIDOR FINAL / VARIOS", "9999999999999", "07", now_ec()))
                cli_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            ok = dup = skip = 0
            for f in facs:
                if not f["es_factura"]: skip += 1; continue
                serie = f["serie"]; clave = f["clave"]; fe = f["fecha"] or today_ec()
                sub = f["subtotal"]; iva = f["iva"]; tot = f["total"]
                if c.execute("SELECT 1 FROM facturas WHERE empresa_id=? AND numero=?", (eid, serie)).fetchone():
                    dup += 1; continue
                c.execute("""INSERT INTO facturas (empresa_id,numero,clave_acceso,cliente_id,usuario_id,fecha,subtotal,iva,total,
                    estado,estado_sri,autorizacion,fecha_autorizacion,notas,created_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (eid, serie, clave, cli_id, sess["usuario_id"], fe, sub, iva, tot,
                     "AUTORIZADA", "AUTORIZADA", clave, f.get("fecha_aut") or "", "Carga TXT SRI emitidos", now_ec()))
                fid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                base15 = round(iva / 0.15, 2) if iva > 0 else 0.0
                base0 = round(sub - base15, 2)
                if base0 < 0: base0 = 0.0
                lineas = [(cta_debe, tot, 0)]
                if base15 > 0: lineas.append((cta_v15, 0, base15))
                if base0 > 0:  lineas.append((cta_v0, 0, base0))
                if iva > 0:    lineas.append((cta_ivav, 0, iva))
                generar_asiento_auto(c, eid, sess["usuario_id"], fe, "Venta " + serie, "VENTA", fid, lineas)
                if estado_pago == "PAGADA":
                    c.execute("UPDATE facturas SET estado='PAGADA' WHERE id=?", (fid,))
                else:
                    _cxc_add_factura(c, eid, cli_id, fid, serie, tot, fe, sess["usuario_id"])
                ok += 1
            c.commit(); c.close()
            return self._j({"ok":True,"creadas":ok,"repetidas":dup,"omitidas":skip})

        elif p == "/api/preview_facturas_xml":
            xmls = body.get("xmls") or []
            c = db()
            out = []; t_sub = t_iva = t_tot = 0.0; nf = 0
            for x in xmls:
                f = _parse_factura_venta_xml(x)
                if not f: out.append({"error": True, "numero": "(XML inválido)"}); continue
                dup = bool(c.execute("SELECT 1 FROM facturas WHERE empresa_id=? AND numero=?", (eid, f["numero"])).fetchone())
                f = dict(f); f["dup"] = dup
                out.append(f)
                if not dup:
                    nf += 1; t_sub += f["subtotal"]; t_iva += f["iva"]; t_tot += f["total"]
            c.close()
            return self._j({"facturas": out, "nuevas": nf, "total_subtotal": round(t_sub,2), "total_iva": round(t_iva,2), "total": round(t_tot,2)})

        elif p in ("/api/cargar_facturas_xml", "/api/cargar_facturas_pdf"):
            # Mismo camino para XML y para RIDE en PDF: cambia solo el lector.
            # El PDF se usa cuando el portal del SRI está caído o el XML
            # original ya no se puede descargar.
            _es_pdf = (p == "/api/cargar_facturas_pdf")
            xmls = (body.get("pdfs") if _es_pdf else body.get("xmls")) or []
            c = db(); cfgc = _cfg_contable(c, eid)
            cancel = (body.get("cancelacion") or "credito").strip()
            if cancel == "caja":      cta_debe = cfgc["cta_caja"];   estado_pago = "PAGADA"
            elif cancel == "bancos":  cta_debe = cfgc["cta_bancos"]; estado_pago = "PAGADA"
            else:                     cta_debe = cfgc["cta_cxc"];    estado_pago = "PENDIENTE"
            cta_v15 = cfgc["cta_ventas"]; cta_v0 = cfgc.get("cta_ventas_0") or cfgc["cta_ventas"]; cta_ivav = cfgc["cta_iva_ventas"]
            ok = dup = err = 0
            _ruc_emp = str((rd(c.execute("SELECT ruc FROM empresas WHERE id=?", (eid,)).fetchone()) or {}).get("ruc") or "")
            _sin_texto = 0
            for x in xmls:
                if _es_pdf:
                    try:
                        _crudo = base64.b64decode(str(x).split(",")[-1])
                    except Exception:
                        err += 1; continue
                    try:
                        f = _parse_ride_pdf(_crudo, _ruc_emp)
                    except ValueError as _ex:
                        c.close(); return self._j({"ok": False, "error": str(_ex)})
                    if not f:
                        _sin_texto += 1
                else:
                    f = _parse_factura_venta_xml(x)
                if not f: err += 1; continue
                serie = f["numero"]; clave = f["clave"]; fe = f["fecha"] or today_ec()
                if c.execute("SELECT 1 FROM facturas WHERE empresa_id=? AND numero=?", (eid, serie)).fetchone():
                    dup += 1; continue
                # Cliente real desde el XML (crear si no existe)
                cruc = (f.get("cliente_ruc") or "9999999999999").strip()
                cnom = (f.get("cliente_nombre") or "CONSUMIDOR FINAL").strip()
                cli = c.execute("SELECT id FROM clientes WHERE empresa_id=? AND ruc_cedula=?", (eid, cruc)).fetchone()
                if cli: cli_id = cli[0]
                else:
                    tipo_id = "04" if len(cruc) == 13 else ("05" if len(cruc) == 10 else "07")
                    c.execute("INSERT INTO clientes (empresa_id,nombre,ruc_cedula,tipo_identificacion,created_at) VALUES (?,?,?,?,?)",
                              (eid, cnom, cruc, tipo_id, now_ec()))
                    cli_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                iva = f["iva"]; base15 = f["base_15"]; base0 = f["base_0"]; tot = f["total"]; sub = f["subtotal"]
                c.execute("""INSERT INTO facturas (empresa_id,numero,clave_acceso,cliente_id,usuario_id,fecha,subtotal,iva,total,
                    estado,estado_sri,autorizacion,notas,created_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (eid, serie, clave, cli_id, sess["usuario_id"], fe, sub, iva, tot,
                     "AUTORIZADA", "AUTORIZADA", clave, "Carga XML ventas", now_ec()))
                fid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                # La sucursal sale del establecimiento del propio número
                try:
                    _sid = _suc_de_numero(c, eid, serie, clave)
                    if _sid:
                        c.execute("UPDATE facturas SET sucursal_id=? WHERE id=?", (_sid, fid))
                except Exception:
                    pass
                for it in (f.get("items") or []):
                    c.execute("""INSERT INTO factura_items (factura_id,codigo,descripcion,cantidad,precio_unitario,descuento,subtotal) VALUES (?,?,?,?,?,?,?)""",
                        (fid, str(it.get("codigo","") or ""), str(it.get("descripcion","") or ""), float(it.get("cantidad",0) or 0), float(it.get("precio_unitario",0) or 0), float(it.get("descuento",0) or 0), float(it.get("subtotal",0) or 0)))
                lineas = [(cta_debe, tot, 0)]
                if base15 > 0: lineas.append((cta_v15, 0, base15))
                if base0 > 0:  lineas.append((cta_v0, 0, base0))
                if iva > 0:    lineas.append((cta_ivav, 0, iva))
                generar_asiento_auto(c, eid, sess["usuario_id"], fe, "Venta " + serie + " — " + cnom, "VENTA", fid, lineas)
                if estado_pago == "PAGADA":
                    c.execute("UPDATE facturas SET estado='PAGADA' WHERE id=?", (fid,))
                else:
                    _cxc_add_factura(c, eid, cli_id, fid, serie, tot, fe, sess["usuario_id"])
                ok += 1
            c.commit(); c.close()
            _res = {"ok":True,"creadas":ok,"repetidas":dup,"errores":err}
            if _es_pdf and _sin_texto:
                _res["sin_texto"] = _sin_texto
                _res["aviso"] = ("%d PDF no tienen texto legible (son escaneos o imágenes). "
                                 "De esos no se puede extraer nada." % _sin_texto)
            return self._j(_res)

        elif p == "/api/completar_facturas_sri":
            claves = body.get("claves") or []
            c = db(); cfgc = _cfg_contable(c, eid)
            amb = str((c.execute("SELECT ambiente FROM empresas WHERE id=?", (eid,)).fetchone() or ["2"])[0] or "2")
            cancel = (body.get("cancelacion") or "credito").strip()
            if cancel == "caja":      cta_debe = cfgc["cta_caja"];   estado_pago = "PAGADA"
            elif cancel == "bancos":  cta_debe = cfgc["cta_bancos"]; estado_pago = "PAGADA"
            else:                     cta_debe = cfgc["cta_cxc"];    estado_pago = "PENDIENTE"
            cta_v15 = cfgc["cta_ventas"]; cta_v0 = cfgc.get("cta_ventas_0") or cfgc["cta_ventas"]; cta_ivav = cfgc["cta_iva_ventas"]
            res = []; ok = dup = err = 0
            amb_confirmado = None   # una vez que un ambiente responde, usarlo para todo el lote
            errores_conexion_seguidos = 0
            for clave in claves:
                clave = re.sub(r"\D", "", (clave or "").strip())
                if not clave: continue
                if len(clave) != 49:
                    err += 1; res.append({"clave":clave,"ok":False,"error":"Clave de acceso inválida (debe tener 49 dígitos). Revisa que el TXT sea el de 'Comprobantes Emitidos Autorizados' del SRI."}); continue
                if c.execute("SELECT 1 FROM facturas WHERE empresa_id=? AND clave_acceso=?", (eid, clave)).fetchone():
                    dup += 1; res.append({"clave":clave,"ok":False,"dup":True}); continue
                # Cortar rápido si el SRI no responde repetidamente (sin internet / SRI caído)
                if errores_conexion_seguidos >= 3:
                    err += 1; res.append({"clave":clave,"ok":False,"error":"Se omitió: el SRI no responde (3 fallas de conexión seguidas). Revisa internet o reintenta más tarde."}); continue
                usar = amb_confirmado or amb
                xml_text, estado, msg = _descargar_comprobante_sri(clave, usar)
                # Solo si AÚN no se ha confirmado ambiente, probar el otro
                if not xml_text and amb_confirmado is None and estado in ("NO_DISPONIBLE","ERROR_XML",""):
                    otro = "1" if usar == "2" else "2"
                    xt2, es2, ms2 = _descargar_comprobante_sri(clave, otro)
                    if xt2:
                        xml_text, estado, msg = xt2, es2, ms2
                        amb_confirmado = otro
                        log.info("SRI: comprobantes encontrados en ambiente %s; se usará para el resto del lote", otro)
                elif xml_text and amb_confirmado is None:
                    amb_confirmado = usar
                if "ERROR_CONEXION" in (estado or ""):
                    errores_conexion_seguidos += 1
                else:
                    errores_conexion_seguidos = 0
                if not xml_text:
                    detalle = estado
                    if "ERROR_CONEXION" in estado:
                        detalle = "Sin conexión al SRI (revisa internet)"
                    elif estado in ("NO_DISPONIBLE",""):
                        detalle = "El SRI no devolvió el comprobante (¿clave incorrecta o ambiente equivocado?)"
                    if msg: detalle += " · " + msg
                    err += 1; res.append({"clave":clave,"ok":False,"error": detalle}); continue
                f = _parse_factura_venta_xml(xml_text)
                if not f:
                    err += 1; res.append({"clave":clave,"ok":False,"error":"No se pudo leer el XML"}); continue
                serie = f["numero"]
                if c.execute("SELECT 1 FROM facturas WHERE empresa_id=? AND numero=?", (eid, serie)).fetchone():
                    dup += 1; res.append({"clave":clave,"ok":False,"dup":True}); continue
                cruc = (f.get("cliente_ruc") or "9999999999999").strip()
                cnom = (f.get("cliente_nombre") or "CONSUMIDOR FINAL").strip()
                cli = c.execute("SELECT id FROM clientes WHERE empresa_id=? AND ruc_cedula=?", (eid, cruc)).fetchone()
                if cli: cli_id = cli[0]
                else:
                    tipo_id = "04" if len(cruc) == 13 else ("05" if len(cruc) == 10 else "07")
                    c.execute("INSERT INTO clientes (empresa_id,nombre,ruc_cedula,tipo_identificacion,created_at) VALUES (?,?,?,?,?)",
                              (eid, cnom, cruc, tipo_id, now_ec()))
                    cli_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                iva = f["iva"]; base15 = f["base_15"]; base0 = f["base_0"]; tot = f["total"]; sub = f["subtotal"]; fe = f["fecha"] or today_ec()
                c.execute("""INSERT INTO facturas (empresa_id,numero,clave_acceso,cliente_id,usuario_id,fecha,subtotal,iva,total,
                    estado,estado_sri,autorizacion,notas,created_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (eid, serie, clave, cli_id, sess["usuario_id"], fe, sub, iva, tot,
                     "AUTORIZADA", "AUTORIZADA", clave, "Completado desde SRI", now_ec()))
                fid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                for it in (f.get("items") or []):
                    c.execute("""INSERT INTO factura_items (factura_id,codigo,descripcion,cantidad,precio_unitario,descuento,subtotal) VALUES (?,?,?,?,?,?,?)""",
                        (fid, str(it.get("codigo","") or ""), str(it.get("descripcion","") or ""), float(it.get("cantidad",0) or 0), float(it.get("precio_unitario",0) or 0), float(it.get("descuento",0) or 0), float(it.get("subtotal",0) or 0)))
                lineas = [(cta_debe, tot, 0)]
                if base15 > 0: lineas.append((cta_v15, 0, base15))
                if base0 > 0:  lineas.append((cta_v0, 0, base0))
                if iva > 0:    lineas.append((cta_ivav, 0, iva))
                generar_asiento_auto(c, eid, sess["usuario_id"], fe, "Venta " + serie + " — " + cnom, "VENTA", fid, lineas)
                if estado_pago == "PAGADA":
                    c.execute("UPDATE facturas SET estado='PAGADA' WHERE id=?", (fid,))
                else:
                    _cxc_add_factura(c, eid, cli_id, fid, serie, tot, fe, sess["usuario_id"])
                ok += 1; res.append({"clave":clave,"ok":True,"numero":serie,"cliente":cnom,"total":tot})
            c.commit(); c.close()
            return self._j({"ok":True,"creadas":ok,"repetidas":dup,"errores":err,"resultados":res})

        elif p == "/api/reclasificar_inventario_gastos":
            c = db(); cfgc = _cfg_contable(c, eid)
            inv = cfgc["cta_inventario"]; gas = cfgc["cta_gastos"]
            nom_gas = _nombre_cuenta(c, eid, gas)
            n = c.execute("""UPDATE asiento_detalle SET cuenta_codigo=?, cuenta_nombre=?
                WHERE cuenta_codigo=? AND asiento_id IN (
                    SELECT id FROM asientos_contables WHERE empresa_id=? AND tipo='COMPRA' AND estado='ACTIVO')""",
                (gas, nom_gas, inv, eid)).rowcount
            c.execute("UPDATE compras SET tipo='GASTO' WHERE empresa_id=? AND tipo='COMPRA'", (eid,))
            c.commit(); c.close()
            return self._j({"ok":True,"reclasificadas":n})

        elif p == "/api/reclasificar_por_proveedor":
            c = db(); cfg = _cfg_contable(c, eid)
            gen = cfg["cta_gastos"]; iva = cfg["cta_iva_compras"]
            # 1) Aprender: por proveedor, la cuenta de gasto específica más usada (distinta de la genérica y del IVA)
            rows = c.execute("""SELECT co.proveedor_id pid, d.cuenta_codigo cod, COUNT(*) n
                FROM asientos_contables a
                JOIN compras co ON co.id=a.origen_id
                JOIN asiento_detalle d ON d.asiento_id=a.id
                WHERE a.empresa_id=? AND a.tipo='COMPRA' AND a.estado='ACTIVO'
                  AND d.debe>0 AND d.cuenta_codigo<>? AND d.cuenta_codigo<>?
                GROUP BY co.proveedor_id, d.cuenta_codigo""", (eid, iva, gen)).fetchall()
            pref = {}; best = {}
            for r in rows:
                pid = r["pid"]; n = r["n"]
                if pid is None: continue
                if n > best.get(pid, 0):
                    best[pid] = n; pref[pid] = r["cod"]
            # 2) Aplicar: a las compras cuyo gasto sigue en la cuenta genérica, ponerles la cuenta del proveedor
            objetivos = c.execute("""SELECT a.id aid, co.proveedor_id pid
                FROM asientos_contables a JOIN compras co ON co.id=a.origen_id
                WHERE a.empresa_id=? AND a.tipo='COMPRA' AND a.estado='ACTIVO'""", (eid,)).fetchall()
            aplicados = 0
            for o in objetivos:
                cod = pref.get(o["pid"])
                if not cod: continue
                ln = c.execute("SELECT id FROM asiento_detalle WHERE asiento_id=? AND debe>0 AND cuenta_codigo=?",
                               (o["aid"], gen)).fetchone()
                if not ln: continue
                nom = _nombre_cuenta(c, eid, cod)
                c.execute("UPDATE asiento_detalle SET cuenta_codigo=?, cuenta_nombre=? WHERE id=?", (cod, nom, ln["id"]))
                aplicados += 1
            c.commit(); c.close()
            return self._j({"ok":True,"proveedores_mapeados":len(pref),"asientos_actualizados":aplicados})

        elif p == "/api/exportar_reporte":
            formato = (body.get("formato") or "excel").lower()
            titulo = body.get("titulo") or "Reporte"
            periodo = body.get("periodo") or ""
            secciones = body.get("secciones") or []
            if formato == "excel":
                import openpyxl, io
                from openpyxl.styles import Font, PatternFill
                wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Reporte"
                r = 1
                ws.cell(r, 1, titulo).font = Font(bold=True, size=14); r += 2
                if periodo:
                    ws.cell(r, 1, periodo).font = Font(italic=True, size=10); r += 2
                maxcols = 2
                for s in secciones:
                    heads = s.get("headers") or []
                    maxcols = max(maxcols, len(heads), len(s.get("pie") or []))
                    cab = ws.cell(r, 1, s.get("titulo", "")); cab.font = Font(bold=True, color="FFFFFF")
                    for cc in range(1, maxcols + 1):
                        ws.cell(r, cc).fill = PatternFill("solid", fgColor="1A56DB")
                    r += 1
                    if heads:
                        for j, hh in enumerate(heads, 1):
                            ws.cell(r, j, hh).font = Font(bold=True)
                        r += 1
                    for fila in s.get("filas", []):
                        for j, val in enumerate(fila, 1):
                            ws.cell(r, j, val)
                        r += 1
                    pie = s.get("pie")
                    if pie:
                        for j, val in enumerate(pie, 1):
                            ws.cell(r, j, val).font = Font(bold=True)
                        r += 1
                    r += 1
                for col in range(1, maxcols + 1):
                    ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = 34 if col == 1 else 15
                buf = io.BytesIO(); wb.save(buf); buf.seek(0)
                b64 = base64.b64encode(buf.read()).decode()
                return self._j({"ok": True, "filename": titulo.replace(" ", "_") + ".xlsx", "b64": b64,
                                "mime": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"})
            else:
                def esc(s): return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                H = ["<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word'><head><meta charset='utf-8'>",
                     "<style>body{font-family:Arial,sans-serif}h1{font-size:16pt}h3{font-size:12pt;color:#1A56DB;margin:12px 0 4px}",
                     "table{border-collapse:collapse;width:100%;margin-bottom:8px}td,th{border:1px solid #ccc;padding:4px 7px;font-size:10pt}",
                     ".r{text-align:right}.tot td{font-weight:bold;background:#f0f4ff}</style></head><body>"]
                H.append("<h1>" + esc(titulo) + "</h1>")
                if periodo: H.append("<p>" + esc(periodo) + "</p>")
                for s in secciones:
                    H.append("<h3>" + esc(s.get("titulo", "")) + "</h3><table>")
                    heads = s.get("headers") or []
                    if heads:
                        H.append("<tr>" + "".join("<th>" + esc(x) + "</th>" for x in heads) + "</tr>")
                    for fila in s.get("filas", []):
                        H.append("<tr>" + "".join(("<td class='r'>" if j > 0 else "<td>") + esc(v) + "</td>" for j, v in enumerate(fila)) + "</tr>")
                    pie = s.get("pie")
                    if pie:
                        H.append("<tr class='tot'>" + "".join(("<td class='r'>" if j > 0 else "<td>") + esc(v) + "</td>" for j, v in enumerate(pie)) + "</tr>")
                    H.append("</table>")
                H.append("</body></html>")
                b64 = base64.b64encode("".join(H).encode("utf-8")).decode()
                return self._j({"ok": True, "filename": titulo.replace(" ", "_") + ".doc", "b64": b64, "mime": "application/msword"})

        elif p == "/api/recuadrar_asientos":
            c = db()
            asientos = c.execute("""SELECT a.id, COALESCE(SUM(d.debe),0) td, COALESCE(SUM(d.haber),0) th
                FROM asientos_contables a JOIN asiento_detalle d ON d.asiento_id=a.id
                WHERE a.empresa_id=? AND a.estado='ACTIVO'
                GROUP BY a.id""", (eid,)).fetchall()
            arreglados = 0
            for a in asientos:
                diff = round(float(a["td"]) - float(a["th"]), 2)
                if diff == 0 or abs(diff) > 0.05:
                    continue
                # Línea de mayor monto del asiento
                ln = c.execute("""SELECT id, debe, haber FROM asiento_detalle WHERE asiento_id=?
                    ORDER BY (CASE WHEN debe>haber THEN debe ELSE haber END) DESC LIMIT 1""", (a["id"],)).fetchone()
                if not ln: continue
                d = float(ln["debe"] or 0); h = float(ln["haber"] or 0)
                if d >= h:
                    c.execute("UPDATE asiento_detalle SET debe=? WHERE id=?", (round(d - diff, 2), ln["id"]))
                else:
                    c.execute("UPDATE asiento_detalle SET haber=? WHERE id=?", (round(h + diff, 2), ln["id"]))
                arreglados += 1
            c.commit(); c.close()
            return self._j({"ok":True,"arreglados":arreglados})

        elif p == "/api/sembrar_plan":
            # Carga el plan NIIF estándar incrustado para la empresa actual (si está vacío)
            c = db()
            ya = c.execute("SELECT COUNT(*) FROM plan_cuentas WHERE empresa_id=?", (eid,)).fetchone()[0]
            if ya > 0:
                c.close(); return self._j({"ok":True,"n":ya,"mensaje":"El plan ya tenía cuentas"})
            for cod, nom, niv, tip, nat, gru, pad in PLAN_NIIF_DEFAULT:
                c.execute("INSERT INTO plan_cuentas (empresa_id,codigo,codigo_rapido,nombre,nivel,tipo,naturaleza,grupo,padre_codigo,activa,editable) VALUES (?,?,?,?,?,?,?,?,?,1,1)",
                          (eid, cod, cod.replace(".",""), nom, niv, tip, nat, gru, pad))
            c.commit()
            n = c.execute("SELECT COUNT(*) FROM plan_cuentas WHERE empresa_id=?", (eid,)).fetchone()[0]
            c.close()
            return self._j({"ok":True,"n":n})

        elif p == "/api/generar_asientos_historico":
            # Genera los asientos automáticos de documentos YA ingresados (sin duplicar)
            c = db(); cfg = _cfg_contable(c, eid); uid = sess["usuario_id"]; creados = 0
            def _falta(tipo, oid):
                return not c.execute("SELECT 1 FROM asientos_contables WHERE empresa_id=? AND tipo=? AND origen_id=? AND estado='ACTIVO'", (eid,tipo,oid)).fetchone()
            # VENTAS
            for f in c.execute("SELECT id,numero,fecha,subtotal,iva,total,estado,forma_pago FROM facturas WHERE empresa_id=? AND estado NOT IN ('ANULADA','RECHAZADA')", (eid,)).fetchall():
                if not _falta("VENTA", f["id"]): continue
                if generar_asiento_auto(c, eid, uid, f["fecha"], "Venta factura " + str(f["numero"]), "VENTA", f["id"],
                    [(cfg["cta_cxc"], f["total"], 0),(cfg["cta_ventas"],0,f["subtotal"]),(cfg["cta_iva_ventas"],0,f["iva"])]): creados += 1
            # COMPRAS
            for cp in c.execute("SELECT id,numero,fecha,subtotal,iva,total,tipo,forma_pago FROM compras WHERE empresa_id=? AND estado!='ANULADA'", (eid,)).fetchall():
                if not _falta("COMPRA", cp["id"]): continue
                cta_d = cfg["cta_inventario"] if str(cp["tipo"]) == "COMPRA" else cfg["cta_gastos"]
                fp = cp["forma_pago"] or "01"; cta_h = cfg["cta_caja"] if fp == "01" else cfg["cta_cxp"]
                if generar_asiento_auto(c, eid, uid, cp["fecha"], "Compra/Gasto " + str(cp["numero"] or ("#"+str(cp["id"]))), "COMPRA", cp["id"],
                    [(cta_d, cp["subtotal"], 0),(cfg["cta_iva_compras"], cp["iva"], 0),(cta_h, 0, cp["total"])]): creados += 1
            # NOTAS DE CRÉDITO
            for nc in c.execute("SELECT id,numero,fecha,subtotal,iva,total FROM notas_credito WHERE empresa_id=? AND estado NOT IN ('ANULADA','RECHAZADA')", (eid,)).fetchall():
                if not _falta("NOTA_CREDITO", nc["id"]): continue
                if generar_asiento_auto(c, eid, uid, nc["fecha"], "Nota de crédito " + str(nc["numero"]), "NOTA_CREDITO", nc["id"],
                    [(cfg["cta_dev_ventas"], nc["subtotal"], 0),(cfg["cta_iva_ventas"], nc["iva"], 0),(cfg["cta_cxc"], 0, nc["total"])]): creados += 1
            # COBROS (cuentas_cobrar tipo PAGO/ABONO)
            for pg in c.execute("SELECT id,fecha,monto,referencia FROM cuentas_cobrar WHERE empresa_id=? AND tipo IN ('PAGO','ABONO') AND monto<0", (eid,)).fetchall():
                if not _falta("COBRO", pg["id"]): continue
                monto = abs(float(pg["monto"]))
                if generar_asiento_auto(c, eid, uid, pg["fecha"], "Cobro cliente — " + str(pg["referencia"] or "abono"), "COBRO", pg["id"],
                    [(cfg["cta_caja"], monto, 0),(cfg["cta_cxc"], 0, monto)]): creados += 1
            # RETENCIONES
            for rt in c.execute("SELECT id,numero,fecha,proveedor_nombre,total_ret_iva,total_ret_renta,total_retenido FROM retenciones WHERE empresa_id=? AND estado!='ANULADA'", (eid,)).fetchall():
                if not _falta("RETENCION", rt["id"]): continue
                if generar_asiento_auto(c, eid, uid, rt["fecha"], "Retención " + str(rt["numero"]) + " — " + str(rt["proveedor_nombre"] or ""), "RETENCION", rt["id"],
                    [(cfg["cta_cxp"], rt["total_retenido"], 0),(cfg["cta_ret_iva"], 0, rt["total_ret_iva"]),(cfg["cta_ret_renta"], 0, rt["total_ret_renta"])]): creados += 1
            c.commit(); c.close()
            return self._j({"ok":True,"creados":creados})


        elif p == "/api/recalcular_cxc":
            c = db()
            clientes = [r[0] for r in c.execute("SELECT DISTINCT cliente_id FROM facturas WHERE empresa_id=? AND cliente_id IS NOT NULL", (eid,)).fetchall()]
            for cli_id in clientes:
                tot_facs = c.execute("SELECT COALESCE(SUM(total),0) FROM facturas WHERE cliente_id=? AND empresa_id=? AND estado NOT IN ('ANULADA')", (cli_id,eid)).fetchone()[0]
                tot_pagos = c.execute("SELECT COALESCE(SUM(monto),0) FROM cuentas_cobrar WHERE cliente_id=? AND empresa_id=? AND tipo='PAGO'", (cli_id,eid)).fetchone()[0]
                tot_nc = c.execute("SELECT COALESCE(SUM(monto),0) FROM cuentas_cobrar WHERE cliente_id=? AND empresa_id=? AND tipo='NOTA_CREDITO'", (cli_id,eid)).fetchone()[0]
                saldo = float(tot_facs) - float(tot_pagos) - float(tot_nc)
                ultimo = c.execute("SELECT id FROM cuentas_cobrar WHERE cliente_id=? AND empresa_id=? ORDER BY id DESC LIMIT 1", (cli_id,eid)).fetchone()
                if ultimo:
                    c.execute("UPDATE cuentas_cobrar SET saldo=? WHERE id=?", (max(0,saldo), ultimo[0]))
            c.commit(); c.close()
            return self._j({"ok":True,"mensaje":"Saldos recalculados para "+str(len(clientes))+" clientes"})


        elif p == "/api/duplicar_factura":
            fid = body.get("id"); c = db()
            f_orig = rd(c.execute("SELECT * FROM facturas WHERE id=? AND empresa_id=?", (fid,eid)).fetchone())
            if not f_orig: c.close(); return self._j({"ok":False,"error":"Factura no encontrada"})
            items_orig = rl(c.execute("SELECT * FROM factura_items WHERE factura_id=?", (fid,)).fetchall())
            # Obtener siguiente número (máximo real de la serie + 1)
            emp2 = rd(c.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone())
            estab = (emp2.get("estab") or "001") if emp2 else "001"
            pto = (emp2.get("pto_emi") or "001") if emp2 else "001"
            sec_inicio = int(emp2.get("sec_inicio_fac",0) or 0) if emp2 else 0
            sig = _siguiente_secuencial_factura(c, eid, estab, pto, sec_inicio)
            num = str(estab).zfill(3) + "-" + str(pto).zfill(3) + "-" + str(sig).zfill(9)
            fecha_hoy = body.get("fecha") or now_ec()[:10]
            # Insertar nueva factura
            c.execute("""INSERT INTO facturas (empresa_id,numero,cliente_id,usuario_id,fecha,subtotal,iva,total,
                estado,notas,forma_pago,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                (eid, num, f_orig.get("cliente_id"), sess["usuario_id"], fecha_hoy,
                float(f_orig.get("subtotal",0)), float(f_orig.get("iva",0)), float(f_orig.get("total",0)),
                "PENDIENTE", f_orig.get("notas",""), f_orig.get("forma_pago","01"), now_ec()))
            new_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            # Copiar items
            for it in items_orig:
                c.execute("INSERT INTO factura_items (factura_id,codigo,descripcion,cantidad,precio_unitario,descuento,subtotal) VALUES (?,?,?,?,?,?,?)",
                    (new_id, it.get("codigo",""), it.get("descripcion",""),
                    float(it.get("cantidad",1)), float(it.get("precio_unitario",0)),
                    float(it.get("descuento",0)), float(it.get("subtotal",0))))
            c.commit(); c.close()
            return self._j({"ok":True,"id":new_id,"numero":num})


        elif p == "/api/guardar_tema":
            tema = body.get("tema","oscuro")
            if tema not in ("oscuro","crema","claro","marino"):
                tema = "oscuro"
            c = db()
            c.execute("UPDATE empresas SET tema=? WHERE id=?", (tema, eid))
            c.commit(); c.close()
            return self._j({"ok":True})

        else: return self._j({"error":"Función no disponible en esta versión del servidor (v"+APP_VERSION+"). Actualiza sri_server.py en esta máquina y reinicia el servidor.","ruta":p},404)

# ════════════════════════════════════════════════════════════
# INICIO
# ════════════════════════════════════════════════════════════
if __name__ == "__main__":
    # ── Auto-configuración en máquina nueva ───────────────────
    import shutil, webbrowser
    if getattr(sys, "frozen", False):
        # Ejecutable empaquetado: los datos viven junto al .exe
        BASE_DIR = Path(sys.executable).resolve().parent
    else:
        _script_dir  = Path(__file__).resolve().parent
        _parent_dir  = _script_dir.parent
        # ── Sincronizar raíz ↔ servidor/: SIEMPRE gana el archivo MÁS NUEVO ──
        # (evita que una copia vieja siga corriendo, y también que una raíz
        #  vieja "pise" una copia más nueva en carpetas desordenadas)
        def _sync_gana_mas_nuevo(_yo, _otro, _reiniciar_si_me_pisan):
            try:
                if not _otro.exists():
                    shutil.copy2(_yo, _otro)
                    print(f"[AUTO-SETUP] Copia creada: {_otro}")
                    return
                if _otro.read_bytes() == _yo.read_bytes():
                    return
                if _otro.stat().st_mtime > _yo.stat().st_mtime:
                    # El otro archivo es MÁS NUEVO → me actualizo con él
                    shutil.copy2(_otro, _yo)
                    print(f"[AUTO-SETUP] Versión más nueva detectada en {_otro.parent.name or 'raíz'} — actualizando...")
                    if _reiniciar_si_me_pisan:
                        print("[AUTO-SETUP] Reiniciando el servidor con la versión nueva...")
                        os.execl(sys.executable, sys.executable, str(_yo.resolve()))
                else:
                    # Yo soy más nuevo → actualizo al otro
                    shutil.copy2(_yo, _otro)
                    print(f"[AUTO-SETUP] Copia sincronizada: {_otro}")
            except Exception as _e:
                print(f"[AUTO-SETUP] No se pudo sincronizar: {_e}")

        if _script_dir.name != "servidor":
            _srv_dir = _script_dir / "servidor"
            _srv_dir.mkdir(exist_ok=True)
            _sync_gana_mas_nuevo(Path(__file__), _srv_dir / "sri_server.py", _reiniciar_si_me_pisan=True)
        else:
            _sync_gana_mas_nuevo(Path(__file__), _parent_dir / "sri_server.py", _reiniciar_si_me_pisan=True)
        # BASE_DIR: siempre la carpeta RAÍZ del proyecto (donde está index.html)
        if _script_dir.name == "servidor":
            BASE_DIR = _script_dir.parent
        else:
            BASE_DIR = _script_dir

    init_db()
    PORT = 7845

    def get_local_ip():
        try:
            import socket
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    LOCAL_IP = get_local_ip()
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), API)
    srv.daemon_threads = True
    lic = estado_licencia()

    log.info("=" * 65)
    log.info("  DAVI&LOZA SOFT v3 | Facturación Electrónica SRI Ecuador")
    log.info("=" * 65)
    log.info("  Esta máquina  : http://localhost:%s", PORT)
    log.info("  Red local     : http://%s:%s  ← Usar en otras PCs", LOCAL_IP, PORT)
    log.info("  Base de datos : %s", DB_PATH)
    log.info("  Directorio    : %s", BASE_DIR)
    log.info("  Max conexiones: %s simultáneas por empresa", MAX_CONEXIONES_POR_EMPRESA)
    _chequear_version_index()
    log.info("-" * 65)
    if lic["activa"]:
        log.info("  Licencia      : ✓ ACTIVA — %s", lic["mensaje"])
    else:
        log.warning("  Licencia      : ✗ NO ACTIVA — %s", lic["mensaje"])
    log.info("=" * 65)
    log.info("  INSTRUCCIONES MULTIMÁQUINA:")
    log.info("  Otras PCs → Chrome → http://%s:%s/index.html", LOCAL_IP, PORT)
    log.info("  Máximo %s computadoras simultáneas", MAX_CONEXIONES_POR_EMPRESA)
    log.info("=" * 65)
    threading.Thread(target=_watchdog_apagado, daemon=True).start()
    # Abrir el navegador automáticamente (solo en esta máquina, una sola vez)
    def _abrir_navegador():
        time.sleep(1.5)
        if os.environ.get("DLS_NO_BROWSER") == "1":
            return
        try:
            lock = BASE_DIR / ".browser_lock"
            ahora = time.time()
            if lock.exists():
                try:
                    if ahora - float(lock.read_text().strip() or 0) < 20:
                        return  # ya se abrió hace menos de 20s (evita 2 ventanas)
                except Exception:
                    pass
            lock.write_text(str(ahora))
        except Exception:
            pass
        try: webbrowser.open("http://localhost:%s/index.html" % PORT)
        except Exception: pass
    threading.Thread(target=_abrir_navegador, daemon=True).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        log.info("Servidor detenido")